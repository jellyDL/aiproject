/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: conv3D_cuda_unopt.h
* 文件标识: _CONV3D_CUDA_UNOPT_H_
* 摘    要: 非优化3D卷积调用头文件
*
* 当前版本: 1.0.0
* 作    者: 许鸿尧
* 日    期: 2016-11-29
* 备    注:
***************************************************************************************************/
#ifndef _CONV3D_CUDA_UNOPT_H_
#define _CONV3D_CUDA_UNOPT_H_
#ifdef __cplusplus
extern "C" {
#endif 

/***************************************************************************************************
* 功  能: 非优化3D卷积CUDA实现
* 参  数: 
*         i_data               -I 输入特征数据
*         k_data               -I 输入卷积数据
*         o_data               -O 输出数据
*         b_data               -I bias数据
*         in_n                 -I 输入特征数据个数
*         in_c                 -I 输入特征数据通道数
*         in_h                 -I 输入特征数据高
*         in_w                 -I 输入特征数据宽
*         out_c                -I 输出特征数据通道数
*         out_h                -I 输出特征数据高
*         out_w                -I 输出特征数据宽
*         k_w                  -I 卷积核宽
*         k_h                  -I 卷积核高
*         pad_w                -I 加边宽
*         pad_h                -I 加边高
*         stride_w             -I stride宽
*         stride_h             -I stride高
*         is_bias_relu         -I 是否执行bias_relu
* 返回值: 无
***************************************************************************************************/
void conv3D_cuda_unopt(void  *i_data,
                       void  *k_data,
                       void  *o_data,
                       void  *b_data,
                       int    in_n,     
                       int    in_c,     
                       int    in_h,     
                       int    in_w, 
                       int    out_c,
                       int    out_w, 
                       int    out_h,       
                       int    k_w,   
                       int    k_h,
                       int    pad_w,
                       int    pad_h,
                       int    stride_w,
                       int    stride_h,
					   int    is_bias,
                       int    is_relu);
#ifdef __cplusplus
}
#endif
#endif