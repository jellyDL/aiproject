#ifdef LINUX
//#if  1
#ifndef RPNLAYER_H
#define RPNLAYER_H 
#include <stddef.h>

//#pragma message "RPN LAYER H"

// ENUMS {{{
typedef enum
{
    STATUS_SUCCESS              = 0,
    STATUS_FAILURE              = 1,
    STATUS_BAD_PARAM            = 2,
    STATUS_NOT_SUPPORTED        = 3
} frcnnStatus_t;

typedef enum
{
    INT8      = 0,
    INT16     = 1,
    INT32     = 2,
    INT64     = 3,
    FLOAT16   = 4,
    FLOAT32   = 5,
    FLOAT64   = 6
} DType_t;

typedef enum
{
    NCHW = 0,
    NC4HW = 1
} DLayout_t;

typedef enum
{
    NOT_ALIGNED = 0,
    ALIGNED = 1
} ROILayout_t;

//typedef enum
//{
//    RPN_MODE_CPU     = 0,
//    RPN_MODE_GPU     = 1
//} rpnMode_t;
// }}}

// GENERATE ANCHORS {{{
// For now it takes host pointers - ratios and scales but
// in GPU MODE anchors should be device pointer
frcnnStatus_t generateAnchors(cudaStream_t stream,
                              int numRatios,
                              float * ratios,
                              int numScales,
                              float * scales,
                              int baseSize,
                              float *anchors);
//}}}

// BBD2P {{{
frcnnStatus_t bboxDeltas2Proposals(cudaStream_t     stream,
                                   const int        N,
                                   const int        A,
                                   const int        H,
                                   const int        W,
                                   const int        featureStride,
                                   const float      minBoxSize, 
                                   const float *    imInfo,
                                   const float *    anchors,
                                   const DType_t    t_deltas,
                                   const DLayout_t  l_deltas,
                                   const void *     deltas,
                                   const DType_t    t_proposals,
                                   const DLayout_t  l_proposals,
                                   void *           proposals,
                                   const DType_t    t_scores,
                                   const DLayout_t  l_scores,
                                   void *           scores);
// }}}

// NMS {{{
frcnnStatus_t nms(cudaStream_t      stream,
                  const int         N,
                  const int         R,
                  const int         preNmsTop,
                  const int         nmsMaxOut,
                  const float       iouThreshold,
                  //const float       minBoxSize,
                  //const float *     imInfo,
                  const DType_t     t_fgScores,
                  const DLayout_t   l_fgScores,
                  void *            fgScores,
                  const DType_t     t_proposals,
                  const DLayout_t   l_proposals,
                  const void *      proposals,
                  void *            workspace,
                  const DType_t     t_rois,
                  const ROILayout_t l_rois,
                  void *            rois,
                  int *             count);
// }}}

// WORKSPACE SIZES {{{
size_t proposalsForwardNMSWorkspaceSize(int N,
                                        int A,
                                        int H,
                                        int W,
                                        int nmsMaxOut);

size_t proposalsForwardBboxWorkspaceSize(int N,
                                         int A,
                                         int H,
                                         int W);

size_t proposalForwardFgScoresWorkspaceSize(int N,
                                            int A, 
                                            int H, 
                                            int W);

size_t proposalsInferenceWorkspaceSize(int N,
                                       int A,
                                       int H,
                                       int W,
                                       int nmsMaxOut);

size_t RPROIInferenceFusedWorkspaceSize(int N,
                                        int A,
                                        int H,
                                        int W,
                                        int nmsMaxOut);
// }}}

// PROPOSALS INFERENCE {{{
frcnnStatus_t proposalsInference(cudaStream_t      stream,
                                 const int         N,
                                 const int         A,
                                 const int         H,
                                 const int         W,
                                 const int         featureStride,
                                 const int         preNmsTop,
                                 const int         nmsMaxOut,
                                 const float       iouThreshold,
                                 const float       minBoxSize,
                                 const float *     imInfo,
                                 const float *     anchors,
                                 const DType_t     t_scores,
                                 const DLayout_t   l_scores,
                                 const void *      scores,
                                 const DType_t     t_deltas,
                                 const DLayout_t   l_deltas,
                                 const void *      deltas,
                                 void *            workspace,
                                 const DType_t     t_rois,
                                 const ROILayout_t l_rois,
                                 void *            rois,
                                 int *             count);
// }}}

// EXTRACT FG SCORES {{{
frcnnStatus_t extractFgScores(cudaStream_t      stream,
                              const int         N,
                              const int         A,
                              const int         H,
                              const int         W,
                              const DType_t     t_scores,
                              const DLayout_t   l_scores,
                              const void *      scores,
                              const DType_t     t_fgScores,
                              const DLayout_t   l_fgScores,
                              void *            fgScores);
// }}}

// ROI INFERENCE {{{
frcnnStatus_t roiInference(cudaStream_t         stream,
                           const int            R, // TOTAL number of rois -> ~nmsMaxOut * N
                           const int            N, // Batch size
                           const int            C, // Channels
                           const int            H, // Input feature map H
                           const int            W, // Input feature map W
                           const int            poolingH, // Output feature map H
                           const int            poolingW, // Output feature map W
                           const float          spatialScale,
                           const DType_t        t_rois,
                           const ROILayout_t    l_rois,
                           const void *         rois,
                           const DType_t        t_featureMap,
                           const DLayout_t      l_featureMap,
                           const void *         featureMap,
                           const DType_t        t_top,
                           const DLayout_t      l_top,
                           void *               top);
// }}}

// ROI FORWARD {{{
frcnnStatus_t roiForward(cudaStream_t         stream,
                         const int            R, // TOTAL number of rois -> ~nmsMaxOut * N
                         const int            N, // Batch size
                         const int            C, // Channels
                         const int            H, // Input feature map H
                         const int            W, // Input feature map W
                         const int            poolingH, // Output feature map H
                         const int            poolingW, // Output feature map W
                         const float          spatialScale,
                         const DType_t        t_rois,
                         const ROILayout_t    l_rois,
                         const void *         rois,
                         const DType_t        t_featureMap,
                         const DLayout_t      l_featureMap,
                         const void *         featureMap,
                         const DType_t        t_top,
                         const DLayout_t      l_top,
                         void *               top,
                         int *                maxIds);
// }}}

// RP ROI Fused INFERENCE {{{
frcnnStatus_t RPROIInferenceFused(cudaStream_t      stream,
                                  const int         N,
                                  const int         A,
                                  const int         C,
                                  const int         H,
                                  const int         W,
                                  const int         poolingH,
                                  const int         poolingW,
                                  const int         featureStride,
                                  const int         preNmsTop,
                                  const int         nmsMaxOut,
                                  const float       iouThreshold,
                                  const float       minBoxSize,
                                  const float       spatialScale,
                                  const float *     imInfo,
                                  const float *     anchors,
                                  const DType_t     t_scores,
                                  const DLayout_t   l_scores,
                                  const void *      scores,
                                  const DType_t     t_deltas,
                                  const DLayout_t   l_deltas,
                                  const void *      deltas,
                                  const DType_t     t_featureMap,
                                  const DLayout_t   l_featureMap,
                                  const void *      featureMap,
                                  void *            workspace,
                                  const DType_t     t_rois,
                                  const ROILayout_t l_rois,
                                  void *            rois,
                                  const DType_t     t_top,
                                  const DLayout_t   l_top,
                                  void *            top,
                                  int *             count);
// }}}

// RPRPOI Fused Inference cpu {{{
frcnnStatus_t RPROIInferenceFused_cpu(const int         N,
                                      const int         A,
                                      const int         C,
                                      const int         H,
                                      const int         W,
                                      const int         poolingH,
                                      const int         poolingW,
                                      const int         featureStride,
                                      const int         preNmsTop,
                                      const int         nmsMaxOut,
                                      const float       iouThreshold,
                                      const float       minBoxSize,
                                      const float       spatialScale,
                                      const float *     imInfo,
                                      const float *     anchors,
                                      const DType_t     t_scores,
                                      const DLayout_t   l_scores,
                                      const void *      vscores,
                                      const DType_t     t_deltas,
                                      const DLayout_t   l_deltas,
                                      const void *      vdeltas,
                                      const DType_t     t_featureMap,
                                      const DLayout_t   l_featureMap,
                                      const void *      vfeatureMap,
                                      const DType_t     t_rois,
                                      const ROILayout_t l_rois,
                                      void *            vrois,
                                      const DType_t     t_top,
                                      const DLayout_t   l_top,
                                      void *            vtop,
                                      int *             count);
// }}}

// GENERATE ANCHORS CPU {{{
frcnnStatus_t generateAnchors_cpu(int numRatios,
                                  float * ratios,
                                  int numScales,
                                  float * scales,
                                  int baseSize,
                                  float * anchors);
// }}}

#endif /* ifndef RPNLAYER_H */

#endif