/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: cnn_cuda_config.h
* �ļ���ʶ: _CNN_CUDA_CONFIG_H_
* ժ    Ҫ:
*
* ��ǰ�汾: 1.0.0
* ��    ��: Ѧ����
* ��    ��: 2016-02-29
* ��    ע:
***************************************************************************************************/
#ifndef _CNN_CUDA_CONFIG_H_
#define _CNN_CUDA_CONFIG_H_


#include <stdio.h>
#include <cublas_v2.h>
#include <cudnn.h>
#include <cuda_runtime.h>
#ifdef CNN_USED_AS_FRCNN
#include "cnnfp16_lib.h"
#else
#include "cnn_lib.h"
#endif
#include "cnn_common.h"
#include "vca_common.h"
#include "layer_base.h"

#ifdef __cplusplus
extern "C" {
#endif

#define         CNN_CUDA_ERROR_CODE_BASE        (0x86000000)                                                //CUDA��������ʼ��ַ
#define         CNN_CUDART_ERROR_CODE_LENGTH    (10000)                                                     //CUDA����ʱ��������󳤶�
#define         CNN_CUBLAS_ERROR_CODE_BASE      (CNN_CUDA_ERROR_CODE_BASE + CNN_CUDART_ERROR_CODE_LENGTH)   //CUBLAS��������ʼ��ַ
#define         CNN_CUBLAS_ERROR_CODE_LENGTH    (1000)                                                      //CUBLAS��������󳤶�
#define         CNN_CUDNN_ERROR_CODE_BASE       (CNN_CUBLAS_ERROR_CODE_BASE + CNN_CUBLAS_ERROR_CODE_LENGTH) //CUDNN��������ʼ��ַ

#define         CNN_CUDNN_MEM_SIZE              (15 * 1024 * 1024)              //cudnn workspace memory size
#define         CNN_CUDA_BLOCK_SIZE             (128)                           //ÿ��һάblock���߳���
#define         CNN_CUDA_BLOCK_SIZE_X           (16)                            //ÿ����άblock���߳���(x����)
#define         CNN_CUDA_BLOCK_SIZE_Y           (16)                            //ÿ����άblock���߳���(y����)
#define         CNN_TX1_MAX_SHARED_MEMORY_BYTES (49152)                         //TX1ÿ��block�������sm�ֽ���(Ĭ������)


#define         CNN_CUDA_ERROR_COMMON_BASE      (20000)

#define         CNN_CUDA_NOT_IMPLEMENT          (CNN_CUDA_ERROR_COMMON_BASE + (1))
#define         CNN_PROPOSAL_FAILED             (CNN_CUDA_ERROR_COMMON_BASE + (2))
#define         CNN_ROIPOOLING_FAILED           (CNN_CUDA_ERROR_COMMON_BASE + (3))

#if             CUDNN_VERSION < 4000
#define         CUDNN_DATA_HALF                 CUDNN_DATA_FLOAT
#endif

typedef         float                       float_t;                            //float����

#define         ZIP_NUM                          2                              //2��fp16 zip

#define         CUDA_DEFAULT_STREAM             (0)                             //Ĭ����
//hik cudnn handle
typedef struct _HIKCUDNN_HANDLE_
{
    void                *cudnn_handle;                  //cudnn handle             

    void                *tensorFormat;                  //tensor format   

    void                *srcTensorDesc;                 //src    tensor descriptor
    void                *dstTensorDesc;                 //dst    tensor descriptor
    void                *biasTensorDesc;                //bias   tensor descriptor

    void                *filterDesc;                    //filter       descriptor
    void                *lrn_desc;                      //lrn          descriptor
    void                *convDesc;                      //convolution  descriptor
    void                *poolingDesc;                   //pooling      descriptor

    char                reserved[64];
}HIKCUDNN_HANDLE;

//hik cublas handle
typedef struct _HIK_CUBLAS_HANDLE_
{
    void                               *cublas_handle;                   //cublas handle

    char                                reserved[64];
}HIKCUBLAS_HANDLE;

//hik cuda handle
typedef struct _HIKCUDA_HANDLE_
{
    HIKCUDNN_HANDLE                     cudnn_handle;                    //cnn cudnn handle
    HIKCUBLAS_HANDLE                    cublas_handle;                   //cnn cublas handle
}HIKCUDA_HANDLE;


//cnn cudnn handle
typedef struct _CNN_CUDNN_HANDLE_
{
    void                                *cudnn_handle;                   //cudnn handle             
    void                                *cudnn_mem;                      //cudnn memory
    size_t                              cudnn_mem_size;                  //cudnn memory size

    void                                *srcTensorDesc;                  //src    tensor descriptor
    void                                *dstTensorDesc;                  //dst    tensor descriptor
    void                                *biasTensorDesc;                 //bias   tensor descriptor

    void                                *filterDesc;                     //filter       descriptor
    void                                *lrn_desc;                       //lrn          descriptor
    void                                *convDesc;                       //convolution  descriptor
    void                                *poolingDesc;                    //pooling      descriptor

}CNN_CUDNN_HANDLE;


//cnn cublas handle
typedef struct _CNN_CUBLAS_HANDLE_
{
    void                                *cublas_handle;                  //cublas handle
}CNN_CUBLAS_HANDLE;


//CUDA Handle
typedef struct _CNN_CUDA_HANDLE_
{
    CNN_CUDNN_HANDLE                    cudnn_handle;                   //cnn cudnn handle
    CNN_CUBLAS_HANDLE                   cublas_handle;                  //cnn cublas handle
}CNN_CUDA_HANDLE;

//3D����ʵ�ַ���ö��
typedef enum _CNN_CONV_METHOD
{
    CNN_CONV_METHOD_CUDNN,                                             //ʹ��cudnn
    CNN_CONV_METHOD_CUBLAS,                                            //ʹ��cublas
    CNN_CONV_METHOD_CUSTOMIZED,                                        //ʹ���Լ�д��kernel
    CNN_CONV_METHOD_MIX                                                //��Ϸ���
}CNN_CONV_METHOD;


/***************************************************************************************************
* ��  ��: ��HIKCUDA_HANDLE��ֵ��CNN_CUDA_HANDLE
* ��  ��: 
*         cuda_handle            -O   cnn cuda handle
*         hik_cuda_handle        -I   hik cuda handle
*         cnn_buf                -I   �ڴ滺��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_create_cuda_handle(CNN_CUDA_HANDLE              *cuda_handle, 
                               HIKCUDA_HANDLE               *hik_cuda_handle, 
                               CNN_BUF                      *cnn_buf);

/***************************************************************************************************
* ��  ��: ��cudnn�Ĵ�����ת����VCA������
* ��  ��:
*         cudnn_sts           -I         cudnn״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cudnn_error_code(cudnnStatus_t  cudnn_sts);


/***************************************************************************************************
* ��  ��: ��cublas�Ĵ�����ת����VCA������
* ��  ��:
*         cublas_sts           -I         cublas״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cublas_error_code(cublasStatus_t  cublas_sts);


/***************************************************************************************************
* ��  ��: ��cuda����ʱ�Ĵ�����ת����VCA������
* ��  ��:
*         cuda_err           -I         cuda������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cudart_error_code(cudaError_t  cuda_err);


#ifdef __cplusplus
}
#endif
#endif /* _CNN_CUDA_CONFIG_H_ */
