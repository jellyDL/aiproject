/**
****************************************************************************************************
* 
* ��Ȩ��Ϣ��Copyright (c) 2012, ���ݺ����������ּ����ɷ����޹�˾
* 
* �ļ����ƣ�_ipg_defs.h
* ժ    Ҫ��ר�û�IPGͼ�������ڲ��Ľṹ�塢�궨�塢�������͵�
* ��    ע��IPG: Image Processing Group
*           
****************************************************************************************************
*/
/**
****************************************************************************************************
====================================================================================================
* V 0.1.0
* ��  �ߣ�������
* ��  �ڣ�2012.10.26
*---------------------------------------------------------------------------------------------------
* 1. ���ݡ�ͼ�����㷨�⿪���淶�� V0.1.0����
====================================================================================================
* V 0.1.1
* ��  �ߣ�������
* ��  �ڣ�2012.11.08
*---------------------------------------------------------------------------------------------------
* 1. �޸�IPG_STATUS�ṹ��
====================================================================================================
* V 0.1.2
* ��  �ߣ�������
* ��  �ڣ�2012.11.09
*---------------------------------------------------------------------------------------------------
* 1. �޸Ľṹ��˵����ʽ
* 2. ���Ӹ������Ͷ���
====================================================================================================
* V 0.1.3
* ��  �ߣ�������
* ��  �ڣ�2012.11.27
*---------------------------------------------------------------------------------------------------
* 1. _SET_CFG_TYPE, _GET_CFG_TYPE��Ϊ���õĽṹ�壬���������Ҫ�����ڵ����㷨������չ
====================================================================================================
* V 0.1.4
* ��  �ߣ�������
* ��  �ڣ�2012.11.28
*---------------------------------------------------------------------------------------------------
* 1. �궨��IPG_ABS, IPG_MIN, IPG_MAX
* 2. ȥ��NULL��VOID����
====================================================================================================
* V 0.1.5
* ��  �ߣ�������
* ��  �ڣ�2012.12.27
*---------------------------------------------------------------------------------------------------
* 1. ����IPG_STS_WARNING�����ھ�����ʾ
* 2. ����IPG_FLOOR, IPG_CEIL��
====================================================================================================
* V 0.1.6
* ��  �ߣ�������
* ��  �ڣ�2012.12.28
*---------------------------------------------------------------------------------------------------
* 1. ����ϵ����ѧ���㺯������
====================================================================================================
* V 0.1.7
* ��  �ߣ�������
* ��  �ڣ�2013.01.01
*---------------------------------------------------------------------------------------------------
* 1. ���Ӹ����������С�궨��
====================================================================================================
* V 0.1.8
* ��  �ߣ�������
* ��  �ڣ�2013.01.06
*---------------------------------------------------------------------------------------------------
* 1. ��ԭ����ipg_defs�ֳ������֣�һ����ר����ipg�㷨���ڲ���ipg_defs_inner.h����һ�������ڽӿ�
====================================================================================================
* V 0.1.9
* ��  �ߣ�������
* ��  �ڣ�2013.01.15
*---------------------------------------------------------------------------------------------------
* 1. ����IPG_IMG_MAX_PEL_NUM��IPG_MAX_MEM_SIZE��
****************************************************************************************************
*/
#ifndef __IPG_DEFS_H_
#define __IPG_DEFS_H_


#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>
#include <math.h>


#ifdef __cplusplus        
extern "C" 
{
#endif

	/*--------------------------------------------------------------------------*/
	/* ���ݡ�C��̬�����⿪���淶���������������Ͷ���                            */
	/*--------------------------------------------------------------------------*/
	typedef signed char         S08;
	typedef unsigned char       U08;
	typedef signed short        S16;
	typedef unsigned short      U16;
	typedef signed int          S32;
	typedef unsigned int        U32;
	typedef float               F32;
	typedef double              F64;

#if defined( _WIN32 ) || defined ( _WIN64 )
	typedef signed __int64      S64;
	typedef unsigned __int64    U64;
#else
	typedef signed long long    S64;
	typedef unsigned long long  U64;
#endif

	typedef struct _SC08
	{
		S08  re;
		S08  im;
	} SC08;

	typedef struct _SC16
	{
		S16  re;
		S16  im;
	} SC16;

	typedef struct _UC16
	{
		U16  re;
		U16  im;
	} UC16;

	typedef struct _SC32
	{
		S32  re;
		S32  im;
	} SC32;

	typedef struct _FC32
	{
		F32  re;
		F32  im;
	} FC32;

	typedef struct _FC64
	{
		F64  re;
		F64  im;
	} FC64;

#ifndef VOID
#define VOID   void
#endif

#ifndef NULL
#define NULL   ((VOID*)0)
#endif

	/*--------------------------------------------------------------------------*/
	/* ���������Сֵ                                                           */
	/*--------------------------------------------------------------------------*/
#define IPG_MIN_U08    ( 0 )
#define IPG_MAX_U08    ( 0xFF )
#define IPG_MAX_U16    ( 0xFFFF )
#define IPG_MAX_U32    ( 0xFFFFFFFF )
#define IPG_MIN_U16    ( 0 )
#define IPG_MIN_U32    ( 0 )
#define IPG_MIN_S08    (-128 )
#define IPG_MAX_S08    ( 127 )
#define IPG_MIN_S16    (-32768 )
#define IPG_MAX_S16    ( 32767 )
#define IPG_MIN_S32    (-2147483647 - 1 )
#define IPG_MAX_S32    ( 2147483647 )

#if defined( _WIN32 ) || defined ( _WIN64 )
#define IPG_MAX_S64  ( 9223372036854775807i64 )
#define IPG_MIN_S64  (-9223372036854775807i64 - 1 )
#else
#define IPG_MAX_S64  ( 9223372036854775807LL )
#define IPG_MIN_S64  (-9223372036854775807LL - 1 )
#endif

#define IPG_MINABS_F32 ( 1.175494351e-38f )
#define IPG_MAXABS_F32 ( 3.402823466e+38f )
#define IPG_EPS_F32    ( 1.192092890e-07f )
#define IPG_MINABS_F64 ( 2.2250738585072014e-308 )
#define IPG_MAXABS_F64 ( 1.7976931348623158e+308 )
#define IPG_EPS_F64    ( 2.2204460492503131e-016 )


	/*--------------------------------------------------------------------------*/
	/* ���峣�õĳ���                                                           */
	/*--------------------------------------------------------------------------*/
#define IPG_PI    ( 3.14159265358979323846 )  /* ANSI C does not support M_PI */
#define IPG_2PI   ( 6.28318530717958647692 )  /* 2*pi                         */
#define IPG_PI2   ( 1.57079632679489661923 )  /* pi/2                         */
#define IPG_PI4   ( 0.78539816339744830961 )  /* pi/4                         */
#define IPG_PI180 ( 0.01745329251994329577 )  /* pi/180                       */
#define IPG_RPI   ( 0.31830988618379067154 )  /* 1/pi                         */
#define IPG_SQRT2 ( 1.41421356237309504880 )  /* sqrt(2)                      */
#define IPG_SQRT3 ( 1.73205080756887729353 )  /* sqrt(3)                      */
#define IPG_LN2   ( 0.69314718055994530942 )  /* ln(2)                        */
#define IPG_LN3   ( 1.09861228866810969139 )  /* ln(3)                        */
#define IPG_E     ( 2.71828182845904523536 )  /* e                            */
#define IPG_RE    ( 0.36787944117144232159 )  /* 1/e                          */
#define IPG_EPS23 ( 1.19209289e-07f )
#define IPG_EPS52 ( 2.2204460492503131e-016 )


	/*--------------------------------------------------------------------------*/
	/* ������ѧ����                                                             */
	/*--------------------------------------------------------------------------*/
#define IPG_ABS(x)             (((x) < 0) ? (-(x)) : (x))
#define IPG_MAX(a,b)           (((a) < (b)) ? (b) : (a))
#define IPG_MIN(a,b)           (((a) > (b)) ? (b) : (a))
#define IPG_CLIP(v,minv,maxv)  IPG_MIN((maxv),IPG_MAX((v),(minv)))
#define IPG_ROUND(x)           (((x) < 0.0) ? (S32)((x) - 0.5) : (S32)((x) + 0.5))


#define IPG_LABS(x)            labs(x)

	//˫����
#define IPG_FABS(x)            fabs(x)
#define IPG_SQRT(x)            sqrt(x)
#define IPG_LOG(x)             log(x)
#define IPG_LOG10(x)           log10(x)
#define IPG_POW(x,y)           pow((x),(y))
#define IPG_EXP(x)             exp(x)
#define IPG_FLOOR(x)           floor(x)
#define IPG_CEIL(x)            ceil(x)

#define IPG_SIN(x)             sin(x)
#define IPG_COS(x)             cos(x)
#define IPG_TAN(x)             tan(x)
#define IPG_ASIN(x)            asin(x)
#define IPG_ACOS(x)            acos(x)
#define IPG_ATAN(x)            atan(x)
#define IPG_SINH(x)            sinh(x)
#define IPG_COSH(x)            cosh(x)
#define IPG_TANH(x)            tanh(x)

	//������
#define IPG_FABSF(x)           fabsf(x)
#define IPG_SQRTF(x)           sqrtf(x)
#define IPG_LOGF(x)            logf(x)
#define IPG_LOG10F(x)          log10f(x)
#define IPG_POWF(x,y)          powf((x),(y))
#define IPG_EXPF(x)            expf(x)
#define IPG_FLOORF(x)          floorf(x)
#define IPG_CEILF(x)           ceilf(x)

#define IPG_SINF(x)            sinf(x)
#define IPG_COSF(x)            cosf(x)
#define IPG_TANF(x)            tanf(x)
#define IPG_ASINF(x)           asinf(x)
#define IPG_ACOSF(x)           acosf(x)
#define IPG_ATANF(x)           atanf(x)
#define IPG_SINHF(x)           sinhf(x)
#define IPG_COSHF(x)           coshf(x)
#define IPG_TANHF(x)           tanhf(x)

	/*--------------------------------------------------------------------------*/
	/* ��������                                                               */
	/*--------------------------------------------------------------------------*/
#define IPG_SIZE_ALIGN(roiSize,align)    (((roiSize)+((align)-1))&(~((align)-1))) //�������
#define IPG_SIZE_ALIGN_4(size)      IPG_SIZE_ALIGN(size,4)
#define IPG_SIZE_ALIGN_8(size)      IPG_SIZE_ALIGN(size,8)
#define IPG_SIZE_ALIGN_16(size)     IPG_SIZE_ALIGN(size,16)
#define IPG_SIZE_ALIGN_32(size)     IPG_SIZE_ALIGN(size,32)
#define IPG_SIZE_ALIGN_64(size)     IPG_SIZE_ALIGN(size,64)
#define IPG_SIZE_ALIGN_128(size)    IPG_SIZE_ALIGN(size,128)


	/*--------------------------------------------------------------------------*/
	/* �ڴ����                                                                 */
	/*--------------------------------------------------------------------------*/
#define IPG_MALLOC        malloc
#define IPG_FREE          free
#define IPG_MEMSET        memset
#define IPG_MEMCPY        memcpy


	/*--------------------------------------------------------------------------*/
	/* �㷨����ʹ�û����ṹ��                                                   */
	/*--------------------------------------------------------------------------*/
	typedef struct _IPG_RECT
	{
		S32 x;
		S32 y;
		S32 width;
		S32 height;
	} IPG_RECT;

	typedef struct _IPG_POINT
	{
		S32 x;
		S32 y;
	} IPG_POINT;

	typedef struct _IPG_SIZE
	{
		S32 width;
		S32 height;
	} IPG_SIZE;


	/*--------------------------------------------------------------------------*/
	/* ͼ�������С�ߴ�                                                       */
	/*--------------------------------------------------------------------------*/
#define IPG_IMG_WIDTH_MIN    (8)
#define IPG_IMG_WIDTH_MAX    (65535)
#define IPG_IMG_HEIGHT_MIN   (8)
#define IPG_IMG_HEIGHT_MAX   (65535)
#define IPG_IMG_MAX_PEL_NUM  (0x07ffffff) //���ͼ��ֱ���

	/*--------------------------------------------------------------------------*/
	/* ��ֵ�㷨���� (interpolation)                                             */
	/*--------------------------------------------------------------------------*/
	enum {
		IPGI_INTER_NN       = 1,
		IPGI_INTER_LINEAR   = 2,
		IPGI_INTER_CUBIC    = 4,
		IPGI_INTER_LANCZOS2 = 8,
		IPGI_INTER_LANCZOS3 = 16
	};

	/*--------------------------------------------------------------------------*/
	/* �㷨����ʹ�õ�����ڴ棬S32��ʾ�����Ϊ0x7fffffff - 0x400��1K���룩      */
	/*--------------------------------------------------------------------------*/
#define IPG_MAX_MEM_SIZE     (2147482623)

#ifdef __cplusplus        
}
#endif


#endif//__IPG_DEFS_H_

