/*******************************************************************************
* 
* 版权信息：版权所有 (c) 2010-2018, 杭州海康威视软件有限公司, 保留所有权利
*
* 文件名称：hik3Dconv_error_code.h
* 文件标识：_HIK3DCONV_ERROR_CODE_H_
* 摘    要：3D卷积错误码
*
* 当前版本：1.0.0
* 作    者：许鸿尧
* 日    期：2016年12月07日
* 备    注：vca_error_code.h 基础上扩展CUDA错误码
********************************************************************************/

#ifndef _HIK3DCONV_ERROR_CODE_H_
#define _HIK3DCONV_ERROR_CODE_H_

#include "vca_error_code.h"
#include "cuda.h"
#ifdef __cplusplus
extern "C" {
#endif
#define HIK3DCONV_E_EXT   (0X86000000)
#define HIK3DCONV_CUDA_SUCCESS                                                      HIK3DCONV_E_EXT + CUDA_SUCCESS
#define HIK3DCONV_CUDA_ERROR_INVALID_VALUE                                          HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_VALUE
#define HIK3DCONV_CUDA_ERROR_OUT_OF_MEMORY                                          HIK3DCONV_E_EXT + CUDA_ERROR_OUT_OF_MEMORY
#define HIK3DCONV_CUDA_ERROR_NOT_INITIALIZED	                                    HIK3DCONV_E_EXT + CUDA_ERROR_NOT_INITIALIZED	
#define HIK3DCONV_CUDA_ERROR_DEINITIALIZED                                          HIK3DCONV_E_EXT + CUDA_ERROR_DEINITIALIZED
#define HIK3DCONV_CUDA_ERROR_PROFILER_DISABLED                                      HIK3DCONV_E_EXT + CUDA_ERROR_PROFILER_DISABLED
#define HIK3DCONV_CUDA_ERROR_PROFILER_NOT_INITIALIZED	                            HIK3DCONV_E_EXT + CUDA_ERROR_PROFILER_NOT_INITIALIZED	
#define HIK3DCONV_CUDA_ERROR_PROFILER_ALREADY_STARTED                               HIK3DCONV_E_EXT + CUDA_ERROR_PROFILER_ALREADY_STARTED
#define HIK3DCONV_CUDA_ERROR_PROFILER_ALREADY_STOPPED                               HIK3DCONV_E_EXT + CUDA_ERROR_PROFILER_ALREADY_STOPPED
#define HIK3DCONV_CUDA_ERROR_NO_DEVICE                                              HIK3DCONV_E_EXT + CUDA_ERROR_NO_DEVICE
#define HIK3DCONV_CUDA_ERROR_INVALID_DEVICE                                         HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_DEVICE
#define HIK3DCONV_CUDA_ERROR_INVALID_IMAGE                                          HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_IMAGE
#define HIK3DCONV_CUDA_ERROR_INVALID_CONTEXT                                        HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_CONTEXT
#define HIK3DCONV_CUDA_ERROR_CONTEXT_ALREADY_CURRENT                                HIK3DCONV_E_EXT + CUDA_ERROR_CONTEXT_ALREADY_CURRENT
#define HIK3DCONV_CUDA_ERROR_UNMAP_FAILED                                           HIK3DCONV_E_EXT + CUDA_ERROR_UNMAP_FAILED
#define HIK3DCONV_CUDA_ERROR_MAP_FAILED                                             HIK3DCONV_E_EXT + CUDA_ERROR_MAP_FAILED
#define HIK3DCONV_CUDA_ERROR_ARRAY_IS_MAPPED                                        HIK3DCONV_E_EXT + CUDA_ERROR_ARRAY_IS_MAPPED
#define HIK3DCONV_CUDA_ERROR_ALREADY_MAPPED                                         HIK3DCONV_E_EXT + CUDA_ERROR_ALREADY_MAPPED
#define HIK3DCONV_CUDA_ERROR_NO_BINARY_FOR_GPU                                      HIK3DCONV_E_EXT + CUDA_ERROR_NO_BINARY_FOR_GPU
#define HIK3DCONV_CUDA_ERROR_ALREADY_ACQUIRED                                       HIK3DCONV_E_EXT + CUDA_ERROR_ALREADY_ACQUIRED
#define HIK3DCONV_CUDA_ERROR_NOT_MAPPED                                             HIK3DCONV_E_EXT + CUDA_ERROR_NOT_MAPPED
#define HIK3DCONV_CUDA_ERROR_NOT_MAPPED_AS_ARRAY                                    HIK3DCONV_E_EXT + CUDA_ERROR_NOT_MAPPED_AS_ARRAY
#define HIK3DCONV_CUDA_ERROR_NOT_MAPPED_AS_POINTER                                  HIK3DCONV_E_EXT + CUDA_ERROR_NOT_MAPPED_AS_POINTER
#define HIK3DCONV_CUDA_ERROR_ECC_UNCORRECTABLE                                      HIK3DCONV_E_EXT + CUDA_ERROR_ECC_UNCORRECTABLE
#define HIK3DCONV_CUDA_ERROR_UNSUPPORTED_LIMIT                                      HIK3DCONV_E_EXT + CUDA_ERROR_UNSUPPORTED_LIMIT
#define HIK3DCONV_CUDA_ERROR_CONTEXT_ALREADY_IN_USE                                 HIK3DCONV_E_EXT + CUDA_ERROR_CONTEXT_ALREADY_IN_USE
#define HIK3DCONV_CUDA_ERROR_PEER_ACCESS_UNSUPPORTED                                HIK3DCONV_E_EXT + CUDA_ERROR_PEER_ACCESS_UNSUPPORTED
#define HIK3DCONV_CUDA_ERROR_INVALID_PTX                                            HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_PTX
#define HIK3DCONV_CUDA_ERROR_INVALID_GRAPHICS_CONTEXT                               HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_GRAPHICS_CONTEXT
#define HIK3DCONV_CUDA_ERROR_INVALID_SOURCE                                         HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_SOURCE
#define HIK3DCONV_CUDA_ERROR_FILE_NOT_FOUND                                         HIK3DCONV_E_EXT + CUDA_ERROR_FILE_NOT_FOUND
#define HIK3DCONV_CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND                         HIK3DCONV_E_EXT + CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND
#define HIK3DCONV_CUDA_ERROR_SHARED_OBJECT_INIT_FAILED                              HIK3DCONV_E_EXT + CUDA_ERROR_SHARED_OBJECT_INIT_FAILED
#define HIK3DCONV_CUDA_ERROR_OPERATING_SYSTEM                                       HIK3DCONV_E_EXT + CUDA_ERROR_OPERATING_SYSTEM
#define HIK3DCONV_CUDA_ERROR_INVALID_HANDLE                                         HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_HANDLE
#define HIK3DCONV_CUDA_ERROR_NOT_FOUND                                              HIK3DCONV_E_EXT + CUDA_ERROR_NOT_FOUND
#define HIK3DCONV_CUDA_ERROR_NOT_READY                                              HIK3DCONV_E_EXT + CUDA_ERROR_NOT_READY
#define HIK3DCONV_CUDA_ERROR_ILLEGAL_ADDRESS                                        HIK3DCONV_E_EXT + CUDA_ERROR_ILLEGAL_ADDRESS
#define HIK3DCONV_CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES                                HIK3DCONV_E_EXT + CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES
#define HIK3DCONV_CUDA_ERROR_LAUNCH_TIMEOUT                                         HIK3DCONV_E_EXT + CUDA_ERROR_LAUNCH_TIMEOUT
#define HIK3DCONV_CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING                          HIK3DCONV_E_EXT + CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING
#define HIK3DCONV_CUDA_ERROR_PEER_ACCESS_ALREADY_ENABLED                            HIK3DCONV_E_EXT + CUDA_ERROR_PEER_ACCESS_ALREADY_ENABLED
#define HIK3DCONV_CUDA_ERROR_PEER_ACCESS_NOT_ENABLED                                HIK3DCONV_E_EXT + CUDA_ERROR_PEER_ACCESS_NOT_ENABLED
#define HIK3DCONV_CUDA_ERROR_PRIMARY_CONTEXT_ACTIVE                                 HIK3DCONV_E_EXT + CUDA_ERROR_PRIMARY_CONTEXT_ACTIVE
#define HIK3DCONV_CUDA_ERROR_CONTEXT_IS_DESTROYED                                   HIK3DCONV_E_EXT + CUDA_ERROR_CONTEXT_IS_DESTROYED
#define HIK3DCONV_CUDA_ERROR_ASSERT                                                 HIK3DCONV_E_EXT + CUDA_ERROR_ASSERT
#define HIK3DCONV_CUDA_ERROR_TOO_MANY_PEERS                                         HIK3DCONV_E_EXT + CUDA_ERROR_TOO_MANY_PEERS
#define HIK3DCONV_CUDA_ERROR_HOST_MEMORY_ALREADY_REGISTERED                         HIK3DCONV_E_EXT + CUDA_ERROR_HOST_MEMORY_ALREADY_REGISTERED
#define HIK3DCONV_CUDA_ERROR_HOST_MEMORY_NOT_REGISTERED                             HIK3DCONV_E_EXT + CUDA_ERROR_HOST_MEMORY_NOT_REGISTERED
#define HIK3DCONV_CUDA_ERROR_HARDWARE_STACK_ERROR                                   HIK3DCONV_E_EXT + CUDA_ERROR_HARDWARE_STACK_ERROR
#define HIK3DCONV_CUDA_ERROR_ILLEGAL_INSTRUCTION                                    HIK3DCONV_E_EXT + CUDA_ERROR_ILLEGAL_INSTRUCTION
#define HIK3DCONV_CUDA_ERROR_MISALIGNED_ADDRESS                                     HIK3DCONV_E_EXT + CUDA_ERROR_MISALIGNED_ADDRESS
#define HIK3DCONV_CUDA_ERROR_INVALID_ADDRESS_SPACE                                  HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_ADDRESS_SPACE
#define HIK3DCONV_CUDA_ERROR_INVALID_PC                                             HIK3DCONV_E_EXT + CUDA_ERROR_INVALID_PC
#define HIK3DCONV_CUDA_ERROR_LAUNCH_FAILED                                          HIK3DCONV_E_EXT + CUDA_ERROR_LAUNCH_FAILED
#define HIK3DCONV_CUDA_ERROR_NOT_PERMITTED                                          HIK3DCONV_E_EXT + CUDA_ERROR_NOT_PERMITTED
#define HIK3DCONV_CUDA_ERROR_NOT_SUPPORTED                                          HIK3DCONV_E_EXT + CUDA_ERROR_NOT_SUPPORTED
#define HIK3DCONV_CUDA_ERROR_UNKNOWN                                                HIK3DCONV_E_EXT + CUDA_ERROR_UNKNOWN

/* 自定义参数校验 */
#define HIK3DCONV_LIB_CHECK_ERROR(sts, errcode)                   \
{                                                                 \
    if (sts == 1)                                                 \
    {                                                             \
        printf("[%s %d %x] \n", __FILE__, __LINE__, (errcode));   \
	    return errcode;							                  \
    }                                                             \
}  

/* CUDA返回码校验 */ 
#define HIK3DCONV_LIB_CHECK_CUDA(status)                         \
{                                                                \
    if (status != 0)                                             \
    {                                                            \
    	printf("[%s %d %x] \n", __FILE__, __LINE__, (status));   \
		return HIK3DCONV_E_EXT + status;                         \
    }                                                            \
}	
#ifdef __cplusplus
}
#endif 

#endif /* _HIK_VCA_LIB_ERROR_CODE_H_ */

