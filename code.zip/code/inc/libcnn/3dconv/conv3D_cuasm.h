/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: conv3D_cuasm.h
* 文件标识: _CONV3D_CUASM_H_
* 摘    要: 3D卷积汇编调用头文件
*
* 初始版本: 1.0.0
* 作    者: 许鸿尧
* 日    期: 2016-09-07
* 当前版本: 1.0.1
* 作    者: 许鸿尧
* 日    期: 2016-11-29
* 备    注: 重命名文件名和宏
***************************************************************************************************/
#ifndef _CONV3D_CUASM_H_
#define _CONV3D_CUASM_H_

#include "cuda_fp16.h"
#include "cuda.h"
#include "stdio.h"

#ifdef __cplusplus
extern "C" {
#endif
/***************************************************************************************************
* 宏定义
***************************************************************************************************/
/*64对齐版本宏设置*/  
#define CONV3D_CUASM_ALGIN64_CUDA_BLOCK_THREADS (128)               //block线程数
#define CONV3D_CUASM_ALGIN64_MATRIX_ROW_STRIDE  (64)                //block处理卷积核矩阵数据块行数
#define CONV3D_CUASM_ALGIN64_MATRIX_COL_STRIDE  (4)                 //block处理卷积核矩阵数据块列数
#define CONV3D_CUASM_ALGIN64_CUDA_BLOCK_SIZE_X  (128)               //单位block处理数X方向
#define CONV3D_CUASM_ALGIN64_CUDA_BLOCK_SIZE_Y  (64)                //单位block处理数Y方向
#define CONV3D_CUASM_ALGIN64_KERNEL_OFFSET      (CONV3D_CUASM_ALGIN64_CUDA_BLOCK_THREADS / CONV3D_CUASM_ALGIN64_MATRIX_COL_STRIDE) //卷积核矩阵纵向偏移
/*128对齐版本宏设置*/                      
#define CONV3D_CUASM_ALGIN128_CUDA_BLOCK_THREADS (256)               //block线程数
#define CONV3D_CUASM_ALGIN128_MATRIX_ROW_STRIDE  (128)               //block处理卷积核矩阵数据块行数
#define CONV3D_CUASM_ALGIN128_MATRIX_COL_STRIDE  (8)                 //block处理卷积核矩阵数据块列数
#define CONV3D_CUASM_ALGIN128_CUDA_BLOCK_SIZE_X  (128)               //单位block处理数X方向
#define CONV3D_CUASM_ALGIN128_CUDA_BLOCK_SIZE_Y  (128)               //单位block处理数Y方向 
#define CONV3D_CUASM_ALGIN128_KERNEL_OFFSET      (CONV3D_CUASM_ALGIN128_CUDA_BLOCK_THREADS / CONV3D_CUASM_ALGIN128_MATRIX_COL_STRIDE) //卷积核矩阵纵向偏移


#define CONV3D_CUASM_ALFA_X             (0x3c00)                     //alfa fp16二进制值1
#define CONV3D_CUASM_BETA_X             (0x0)                        //beta fp16二进制值0
#define CONV3D_CUASM_RELU_THETA_X       (0x0)                        //relu theta fp16x2二进制值0
#define CONV3D_CUASM_RELU_THETA_X_M1000 (0xe3d0e3d0)                 //relu theta fp16x2二进制值-1000
#define CONV3D_CUASM_ACC_START          (0x258)                      //增量表起始地址
#define CONV3D_CUASM_MAX_LEN_ACC        (200)                         //最大增量表长度
#define CONV3D_CUASM_HEX_ZERO           (0x0)                        //16进制0
/***************************************************************************************************
* 枚举
***************************************************************************************************/
/*汇编实现方法*/
typedef enum _CONV3D_CUASM_VER_
{
    CONV3D_CUASM_VER_ALGIN64,   //64对齐版本
    CONV3D_CUASM_VER_ALGIN128,  //128对齐版本
    CONV3D_CUDA_VER_SMALL       //小图像卷积版本
}CONV3D_CUASM_VER;
/***************************************************************************************************
* 结构体
***************************************************************************************************/
/* 魔数与偏移量结构体 */
typedef struct _CONV3D_CUASM_MAGICS_
{
    int m;                             //魔数
    int s;                             //偏移量
}CONV3D_CUASM_MAGICS;
//3D卷积参数结构体
//C=A*B,其中A表示特征图矩阵，B表示卷积核矩阵，C表示输出矩阵
//w_stride, h_stride表示偏移表宽高，
//w_pitch,  h_pitch表示原始数据带pitch的宽高
typedef struct _CONV3D_CUASM_PARAM_
{
    
    void       *src_feat;           //输入特征图指针                                      c[0x0][0x140]
    #ifdef CONV3D_CUASM_BITS_32
    void       *src_feat_h;
    #endif
    void       *filter;             //卷积核指针                                          c[0x0][0x148]
    #ifdef CONV3D_CUASM_BITS_32
    void       *filter_h;
    #endif
    void       *dst_feat;           //输出特征图指针                                      c[0x0][0x150]
    #ifdef CONV3D_CUASM_BITS_32
    void       *dst_feat_h;
    #endif
    
    //long long   src_feat;           //输入特征图指针                                      c[0x0][0x140]
    //long long   filter;             //卷积核指针                                          c[0x0][0x148]
    //long long   dst_feat;           //输出特征图指针                                      c[0x0][0x150]
//
    long long   reserved_0;         //保留字段   
    long long   f_offset_0;         //卷积矩阵偏移32*kw*kh*c                              c[0x0][0x160]
    long long   reserved_1;         //保留字段   
    long long   f_offset_1;         //卷积矩阵偏移8-96*kw*kh*c                            c[0x0][0x170]
    int         reserved_2;         //保留字段   
    int         kw_kh_c_pitch;      //矩阵A*B，表示A的列数或B的行数kw*kh*c                c[0x0][0x17c] 
    int         reserved_3;         //保留字段   
    int         n_hw;               //特征图矩阵B列数，nhw                                c[0x0][0x184]
    int         k_num;              //卷积核矩阵A行数，卷积核个数                         c[0x0][0x188]
    int         kw_kh_c;            //矩阵A*B，表示A的列数或B的行数kw*kh*c                c[0x0][0x18c]
    long long   reserved_4[4];      //保留字   
    half        alfa;               //alfa参数,计算结果*alfa,通常设置1                    c[0x0][0x1b0]
    half        beta;               //beta参数,计算结果*alfa+输出位置数据*beta,通常设置0  c[0x0][0x1b2]
    int         reserved_5;         //保留字
    int         is_kwkhc_mod8;      //kw*kh*c是否为8的倍数                                c[0x0][0x1b8]
    int         reserved_6;         //保留字   
    
    void       *offset_table;       //偏移表地址                                          c[0x0][0x1c0]
    #ifdef CONV3D_CUASM_BITS_32
    void       *offset_table_h;
    #endif
    
    //long long   offset_table;
    long long   reserved_7;         //保留字   
    unsigned    incr_start;         //增量表起始位置(bytes)                               c[0x0][0x1d0]
    unsigned    incr_end;           //增量表结束位置(bytes)                               c[0x0][0x1d4]
    int         desc_length;        //递减步长(bytes)                                     c[0x0][0x1d8]
    int         incr_length;        //递增步长(bytes)                                     c[0x0][0x1dc]
    long long   reserverd_8[6];     //保留字   
    int         n_size;             //不同batch间的原始数据上的跨距(c*w_pitch*h_pitch)    c[0x0][0x210]
    int         reserved_9;         //保留字   
    int         chw_out;            //输出c*h_out*w_out                                   c[0x0][0x218]
    int         nhw_out;            //输出n*h_out*w_out                                   c[0x0][0x21c]
    int         w_out;              //输出w_out                                           c[0x0][0x220]
    int         datatype_out;       //输出数据之间的间隔                                  c[0x0][0x224]
    int         hw_in;              //输入hw=h_stride * w_stride                          c[0x0][0x228]
    int         magic_hw;           //输入hw的magic数                                     c[0x0][0x22c]
    int         shift_hw;           //输入hw的shift数                                     c[0x0][0x230]
    int         w_in;               //输入width=w_stride                                  c[0x0][0x234]
    int         magic_w;            //输入width的magic数                                  c[0x0][0x238]
    int         shift_w;            //输入width的shift数                                  c[0x0][0x23c]
    int         reserved_10;        //保留字   
    half2       relu_theta;         //relu比较阈值                                        c[0x0][0x244]
    int         is_bias;            //是否bias处理                                        c[0x0][0x248]
    int         reserved_11;        //保留字   
    
    void       *bias;               //bias数据指针                                        c[0x0][0x250]
    #ifdef CONV3D_CUASM_BITS_32
    void       *bias_h;
    #endif   
     
    //long long   bias;                                    
    int         acc[CONV3D_CUASM_MAX_LEN_ACC];            //迭代累加值
} CONV3D_CUASM_PARAM;

/***************************************************************************************************
* 功  能: 3D卷积CUDA调用
*           i_data           //输入数据
*           k_data           //卷积核数据
*           o_data           //输出数据
*           off_tab          //偏移量
*           b_data           //bias数据
*           i_n              //输入特征图数
*           i_c              //输入特征图通道数
*           i_h              //输入特征图高度
*           i_w              //输入特征图宽度
*           k_n              //卷积核数
*           k_h              //卷积核高度
*           k_w              //卷积核宽度
*           s_h              //纵向跨度
*           s_w              //横向跨度   
*           i_pad_h          //输入pad高度
*           i_pad_w          //输入pad宽度
*           o_pad_h          //输出pad高度
*           o_pad_w          //输出pad宽度
*           zero_pad_h       //填充0 pad高度
*           zero_pad_w       //填充0 pad宽度
*           is_bias          //是否使用bias
*           is_relu          //是否使用relu
*           cuasm_ver        //汇编实现方法   
* 返回值: 错误码
***************************************************************************************************/
int conv3D_cuasm_cudacall(void               *i_data,
                          void               *k_data,
                          void               *o_data,
                          void               *off_tab,
                          void               *b_data,
                          int                 i_n,
                          int                 i_c,
                          int                 i_h,
                          int                 i_w,
                          int                 k_n,
                          int                 k_h,
                          int                 k_w,
                          int                 s_h,
                          int                 s_w,
                          int                 i_pad_h,
                          int                 i_pad_w,
                          int                 o_pad_h,
                          int                 o_pad_w,
                          int                 zero_pad_h,
                          int                 zero_pad_w,
                          int                 is_bias,
                          int                 is_relu,
                          CONV3D_CUASM_VER    cuasm_ver);

#ifdef __cplusplus
}
#endif
#endif