/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: hik3Dconv_type.h
* 文件标识: _HIK3DCONV_TYPE_H_
* 摘    要: 基本类型头文件
*
* 当前版本: 1.0.1
* 作    者: 许鸿尧
* 日    期: 2016-11-29
* 备    注: 
***************************************************************************************************/
#ifndef _HIK3DCONV_TYPE_H_
#define _HIK3DCONV_TYPE_H_

#ifdef __cplusplus
extern "C" {
#endif
/***************************************************************************************************
* 宏定义
***************************************************************************************************/
/* HRESULT定义 */
#ifndef _HRESULT_DEFINED
#define _HRESULT_DEFINED
typedef unsigned int HRESULT;
#endif
/* 开辟内存数 */
#define HIK3DCONV_LIB_MEM_TAB_NUM (3)
/* 最大设备数 */
#define HIK3DCONV_MAX_DEVICES (10)
/***************************************************************************************************
* 枚举
***************************************************************************************************/
/* 内存对齐属性 */
typedef enum _HIK3DCONV_LIB_MEM_ALIGNMENT_ 
{
    HIK3DCONV_LIB_MEM_ALIGN_4BYTE    = 4,
    HIK3DCONV_LIB_MEM_ALIGN_8BYTE    = 8,
    HIK3DCONV_LIB_MEM_ALIGN_16BYTE   = 16,
    HIK3DCONV_LIB_MEM_ALIGN_32BYTE   = 32,
    HIK3DCONV_LIB_MEM_ALIGN_64BYTE   = 64,
    HIK3DCONV_LIB_MEM_ALIGN_128BYTE  = 128,
    HIK3DCONV_LIB_MEM_ALIGN_256BYTE  = 256,
    HIK3DCONV_LIB_MEM_ALIGN_END      = 0xFFFFF
}HIK3DCONV_LIB_MEM_ALIGNMENT;
/* 数据类型 */
typedef enum _HIK3DCONV_LIB_MEM_DATA_TYPE_
{
    HIK3DCONV_LIB_MEM_DATA_TYPE_FP16,
    HIK3DCONV_LIB_MEM_DATA_TYPE_FP16X2,
    HIK3DCONV_LIB_MEM_DATA_TYPE_FP32
}HIK3DCONV_LIB_MEM_DATA_TYPE;
/* 数据分配空间 */
typedef enum _HIK3DCONV_LIB_MEM_SPACE_
{
    HIK3DCONV_LIB_MEM_CPU,
    HIK3DCONV_LIB_MEM_GPU
}HIK3DCONV_LIB_MEM_SPACE;

/* 实现方式 */
typedef enum _HIK3DCONV_LIB_KINDS_
{
  HIK3DCONV_LIB_CUASM_ALGIN64,
  HIK3DCONV_LIB_CUASM_ALGIN128,
  HIK3DCONV_LIB_CUDA_SMALL
}HIK3DCONV_LIB_KINDS;

/***************************************************************************************************
* 结构体
***************************************************************************************************/    
/* 张量数据结构(目前只支持4维数据) */
typedef struct _HIK3DCONV_LIB_TENSOR_
{
  int n;                                                //个数
  int c;                                                //通道数
  int h;                                                //高度
  int w;                                                //宽度
}HIK3DCONV_LIB_TENSOR;
/* 内存参数 */
typedef struct _HIK3DCONV_LIB_MEM_PARAM_
{
  int                  width;                           //原始输入宽度
  int                  height;                          //原始输入高度
}HIK3DCONV_LIB_MEM_PARAM;
/* 内存分配结构体 */
typedef struct _HIK3DCONV_LIB_MEM_TAB_
{
  unsigned int                 size;                     //以BYTE为单位的内存大小
  void                        *base;                     //分配出的内存指针
  HIK3DCONV_LIB_MEM_ALIGNMENT  alignment;                //内存对齐属性
  HIK3DCONV_LIB_MEM_DATA_TYPE  data_type;                //内存开辟数据类型
  HIK3DCONV_LIB_MEM_SPACE      space;                    //数据分配空间
}HIK3DCONV_LIB_MEM_TAB;
/* 输入结构体 */
typedef struct _HIK3DCONV_LIB_IN_BUF_
{
    void         *i_data;                               //输入数据
    void         *k_data;                               //卷积数据
    void         *b_data;                               //bias数据
    unsigned char reserved[32];                         //保留字段
}HIK3DCONV_LIB_IN_BUF;

/* 输出结构体 */
typedef struct _HIK3DCONV_LIB_OUT_BUF_
{
    void         *o_data;                               //输出数据
    unsigned char reserved[32];                         //保留字段
}HIK3DCONV_LIB_OUT_BUF;

/* 配置结构体 */
typedef struct _HIK3DCONV_LIB_CONFIG_
{
  HIK3DCONV_LIB_TENSOR i_dim;                           //输入维度
  HIK3DCONV_LIB_TENSOR k_dim;                           //卷积系数维度
  int                  stride_h;                        //stride高度
  int                  stride_w;                        //stride宽度
  int                  i_pad_h;                         //输入pad高度
  int                  i_pad_w;                         //输入pad宽度
  int                  o_pad_h;                         //输出pad高度
  int                  o_pad_w;                         //输出pad宽度
  int                  zero_pad_h;                      //填充0 pad高度
  int                  zero_pad_w;                      //填充0 pad宽度
  int                  is_bias;                         //是否启用bias
  int                  is_relu;                         //是否启用relu
  HIK3DCONV_LIB_KINDS  kind;                            //选择哪种实现方式
  unsigned char        reserved[32];                    //保留字段
}HIK3DCONV_LIB_CONFIG;

/* 当前库使用设备信息 */
typedef struct _HIK3DCONV_LIB_DEV_INFO_
{
    int device_id;                                        //设备ID号
    int sms;                                              //设备上的multiprocessor数量
    int major;                                            //计算力的大版本号，比如X.Y中的X
    int minor;                                            //计算力的小版本号，比如X.Y中的Y
    int global_mem;                                       //可用global内存(bytes)
    int const_mem;                                        //可用constant内存(bytes)
    int shared_mem_perblock;                              //每个block可用shared 内存(bytes)
    int regs_perblock;                                    //每个block可用寄存器数
    int l2cache_size;                                     //l2 cache大小(bytes)
    int sm_clock;                                         //multiprocessor频率(khz)
    int mm_clock;                                         //global内存峰值时钟频率(khz)
    int mm_bus_width;                                     //global内存带宽(bits)
}HIK3DCONV_LIB_DEV_INFO;
/* 库信息 */
typedef struct _HIK3DCONV_LIB_INFO_
{
  int                    use_devices;                     //可使用设备数
  int                    cuda_verion;                     //cuda版本
  int                    lib_version;                     //库版本
  HIK3DCONV_LIB_DEV_INFO dev_info[HIK3DCONV_MAX_DEVICES]; //当前算法库使用设备信息
}HIK3DCONV_LIB_INFO;
#ifdef __cplusplus
}
#endif
#endif