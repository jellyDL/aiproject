/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: conv3D_cuasm_offset.h
* 文件标识: _CONV3D_CUASM_OFFSET_H_
* 摘    要: 计算偏移量表头文件
*
* 初始版本: 1.0.0
* 作    者: 许鸿尧
* 日    期: 2016-09-09
* 当前版本: 1.0.1
* 作    者: 许鸿尧
* 日    期: 2016-11-29
* 备    注: 合成库，修改函数名
* 当前版本: 1.0.2
* 作    者: 许鸿尧
* 日    期: 2016-12-02
* 备    注: 区分填充与零填充，考虑宽高不同的情况
***************************************************************************************************/
#ifndef _CONV3D_CUASM_OFFSET_H_
#define _CONV3D_CUASM_OFFSET_H_
#ifdef __cplusplus
extern "C" {
#endif

/***************************************************************************************************
* 功  能: 计算偏移量和zero padding
* 参  数: 
*         offset_table      - O 输出数据
*         data              - O 填边数据
*         n                 - I 输入batch数
*         c                 - I 输入channel
*         h                 - I 输入原始数据初始高度
*         w                 - I 输入原始数据初始宽度
*         h_stride          - I stride后输入高度
*         w_stride          - I stride后输入宽度
*         stride_h          - I 元素间纵向跨度
*         stride_w          - I 元素间横向跨度
*         h_pitch           - I 原始数据横向填充后高度
*         w_pitch           - I 原始数据横向填充后长度
*         pad_h             - I 填充高度
*         pad_w             - I 填充宽度
*         zeropad_h         - I 零填充高度
*         zeropad_w         - I 零填充宽度
* 返回值: 错误码
***************************************************************************************************/
int conv3D_cuasm_offset_zeropadding(int     *offset_table,
                                    void    *data,
                                    int      n,
                                    int      c,
                                    int      h,
                                    int      w,
                                    int      h_stride,
                                    int      w_stride,
                                    int      stride_h,
                                    int      stride_w,
                                    int      h_pitch,
                                    int      w_pitch,
                                    int      pad_h,
                                    int      pad_w,
                                    int      zeropad_h,
                                    int      zeropad_w);
#ifdef __cplusplus
}
#endif
#endif