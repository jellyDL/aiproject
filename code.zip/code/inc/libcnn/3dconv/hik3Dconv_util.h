/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: hik3Dconv_util.h
* 文件标识: _HIK3DCONV_UTIL_H_
* 摘    要: 通用操作头文件
*
* 当前版本: 1.0.1
* 作    者: 许鸿尧
* 日    期: 2016-10-18
* 备    注: 
***************************************************************************************************/
#ifndef _HIK3DCONV_UTIL_H_
#define _HIK3DCONV_UTIL_H_

#include "cuda.h"
#include "cuda_fp16.h"
#include "./3dconv/hik3Dconv_error_code.h"
#ifdef __cplusplus
extern "C" {
#endif
/***************************************************************************************************
* 宏定义
***************************************************************************************************/
/* 对齐计算 */
#define HIK3DCONV_LIB_SIZE_ALIGN(size, align)     (((size)+((align)-1))&(~((align)-1)))

/* 内存对齐方式 */
#define HIK3DCONV_LIB_ALIGN_BYTES	(16)

/* 版本信息*/
#define HIK3DCONV_LIB_MAJOR      1
#define HIK3DCONV_LIB_MINOR      0
#define HIK3DCONV_LIB_PATCHLEVEL 0

#define HIK3DCONV_LIB_VERSION  (HIK3DCONV_LIB_MAJOR * 1000 + \
								HIK3DCONV_LIB_MINOR * 100  + \
								HIK3DCONV_LIB_PATCHLEVEL)


/***************************************************************************************************
* 枚举
***************************************************************************************************/
/* 清空缓存类型 */
typedef enum _HIK3DCONV_LIB_MEMCLEAR_TYPE_
{
    HIK3DCONV_LIB_CLEAR_CPU,   //CPU缓存清空
    HIK3DCONV_LIB_CLEAR_GPU,   //GPU缓存清空
    HIK3DCONV_LIB_CLEAR_NONE   //缓存不清空
}HIK3DCONV_LIB_MEMCLEAR_TYPE;

/***************************************************************************************************
* 结构体
***************************************************************************************************/
/* 存储空间管理结构体 */
typedef struct _HIK3DCONV_LIB_MEM_BUF_
{
    void     *start;                           //缓存起始位置
    void     *end;                             //缓存结束位置
    void     *cur_pos;                         //缓存空余起始位置
    HIK3DCONV_LIB_MEMCLEAR_TYPE memclear_type; //清空缓存类型
}HIK3DCONV_LIB_MEM_BUF;

/* 卷积结构体 */
typedef struct _HIK3DCONV_LIB_HANDLE_
{
    void      *off_tab;                //偏移量
    int        i_n;                    //输入特征图数
    int        i_c;                    //输入特征图通道数
    int        i_h;                    //输入特征图高度
    int        i_w;                    //输入特征图宽度
    int        k_n;                    //卷积核数
    int        k_h;                    //卷积核高度
    int        k_w;                    //卷积核宽度
    int        s_h;                    //纵向跨度
    int        s_w;                    //横向跨度 
    int        i_pad_h;                //输入加边高度
    int        i_pad_w;                //输入加边宽度
    int        o_pad_h;                //输出加边高度
    int        o_pad_w;                //输出加边宽度
    int        zero_pad_h;             //填充0 加边高度
    int        zero_pad_w;             //填充0 加边宽度
    int        is_bias;                //是否使用bias
    int        is_relu;                //是否使用relu
    int        conv_kind;              //cuasm实现类型	
} HIK3DCONV_LIB_HANDLE;

/****************************************************************************************************
* 功  能：在缓存buf中分配一块大小为size, 16个字节对齐的内存块
* 参  数：
*      buf          - I 缓存管理结构体
*      size         - O 分配内存的大小
* 返回值：(void*)分配得到内存位置指针
* 备  注：
*****************************************************************************************************/
void *hik3dconv_alloc_buffer(HIK3DCONV_LIB_MEM_BUF *buf,
                             int                    size);
#ifdef __cplusplus
}
#endif
#endif