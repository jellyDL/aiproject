/***************************************************************************************************
* 版权信息：版权所有(c) , 杭州海康威视数字技术股份有限公司, 保留所有权利
*
* 文件名称: relu_layer_cuda.h
* 文件标识: _RELU_LAYER_CUDA_H_
* 摘    要: relu层的CUDA函数定义
*
* 当前版本: 1.0.0
* 作    者: 薛纪令
* 日    期: 2016-03-25
* 备    注:
***************************************************************************************************/
#ifndef _RELU_LAYER_CUDA_H_
#define _RELU_LAYER_CUDA_H_

#include <stdio.h>
#include "cnnfp16_lib.h"
#include "cnn_common.h"
#include "vca_common.h"
#include "layer_base.h"
#include "cnn_cuda_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/***************************************************************************************************
* 功  能: relu层的CUDA实现
* 参  数:
*         act_in_gpu          - I 输入数据
*         act_out_gpu         - O 输出数据
*         type				  - I 数据类型
*         numel               - I 单batch数据大小
*         batch_size          - I batch大小
* 返回值: 错误码
* 备注:
***************************************************************************************************/
HRESULT cnn_relu_forward_cuda(float_t             *act_in_gpu,
							  float_t             *act_out_gpu,
							  BLOB_DATA_TYPE       type,
                              BLOB_DATA_FORMAT     format,
							  const int            numel,
							  int                  batch_size,
							  int                  c,
							  int                  h,
							  int                  w,
                              int                  pad_zip_in,
                              int                  pad_zip_out);



#ifdef __cplusplus
}
#endif
#endif /* _RELU_LAYER_CUDA_H_ */
