#include <iostream>
#include <fstream>
#include <stdio.h>
#include "vca_base.h"
#include <typeinfo>

// #ifndef STABILITY_TEST
// #define HEIGHT  1080
// #define WIDTH   1920
// #else
// #define HEIGHT  2160
// #define WIDTH   4096
// #endif

//#define HEIGHT  2160
//#define WIDTH   4096

//#define TEST_HANDLE_RECREATE

#define HEIGHT  1080
#define WIDTH   1920

#define USE_OPENCV

#define PED_ATTR       3
#define CAR_ATTR       2
#define BUS_ATTR       1

#define ZIP_TEST

//#define PED_ATTR     15
//#define CAR_ATTR     7
//#define BUS_ATTR     6

#define MAX_BATCH_SIZE          (32)

#define GROUND_TRUTH_HEIGHT     (720)
#define GROUND_TRUTH_WIDTH      (1280)

//#define SKIP_VERSION_INFO                     // �Ϻ��ṩ����Щģ��ǰ�ĸ��ֽ��ǰ汾��Ϣ
//#define DFR_BUILD_MODEL_TEST                  // DFR��ģģ����Щ����ͼ���ͨ������1 
//#define COMPARE_WITH_GROUND_TRUTH

#ifdef LINUX
#include <opencv2/opencv.hpp>
#include <sys/time.h>
#else
#include <windows.h>
#include <opencv2/opencvlib.h>
#endif

#include "opt_profile.h"
#include "hik_cuda_lib.h"

#include <vector>
using namespace std;

//#define CNN_USED_AS_FRCNN                     // ����CNN��ӿ�����

#define V210TX1                         // ����txt���ְ���V210_VTX1����V210

#ifdef CNN_USED_AS_FRCNN
#define TX1FP16                         // ����txt����_fp32����_fp16
#endif

// �㷨����ص�һЩ��Ϣ
typedef struct _CNN_LIB_INFO_
{
    int  support_zip;                // �Ƿ�֧��ZIP
    int  horizontal_fusion_num;      // horitontal fusion�ľ�������
}CNN_LIB_INFO;

//#define TEST_LIBCUDA

#define CHECK_ERR(sts, str)                                          \
{                                                                    \
if (sts)                                                             \
{                                                                    \
    fprintf(stderr, "[error code %x %s %d %s] \n",sts, __FILE__, __LINE__, (str));     \
    exit(-1);                                                        \
}                                                                    \
}

#define CHECK_ERR_PCODE(sts, err, str)                                          \
{                                                                    \
if (sts)                                                             \
{                                                                    \
    fprintf(stderr, "[error code %d %x %s %d %s] \n", err, err, __FILE__, __LINE__, (str));     \
    exit(-1);                                                        \
}                                                                    \
}

//////////////////////////////////////////////////////////////////////////////////
//#define STABILITY_TEST                  //���ȶ���

#ifndef CNN_USED_AS_FRCNN
#include "cnn_lib.h"
#else

#include "cnnfp16_lib.h"

#define HIK_CNN_BLOB_MAX_DIM                HIK_CNNFP16_BLOB_MAX_DIM        
#define HIK_CNN_MEM_TAB_NUM                 HIK_CNNFP16_MEM_TAB_NUM         
#define HIK_CNN_MAX_IN_BLOB                 HIK_CNNFP16_MAX_IN_BLOB         
#define HIK_CNN_MAX_OUT_BLOB                HIK_CNNFP16_MAX_OUT_BLOB        

#define HKA_CNN_OUT_BLOB_INFO               HKA_CNNFP16_OUT_BLOB_INFO
#define HKA_CNN_PARAM                       HKA_CNNFP16_PARAM
#define HKA_CNN_BLOB_TYPE                   HKA_CNNFP16_BLOB_TYPE
#define HKA_BLOB                            HKA_BLOBFP16
#define HKA_CNN_PROCTYPE                    HKA_CNNFP16_PROCTYPE
#define HKA_CNN_FORWARD_IN_INFO             HKA_CNNFP16_FORWARD_IN_INFO
#define HKA_CNN_FORWARD_OUT_INFO            HKA_CNNFP16_FORWARD_OUT_INFO
#define HKA_CNN_MODEL_PARAM                 HKA_CNNFP16_MODEL_PARAM
#define PROC_TYPE_FORWARD                   PROCFP16_TYPE_FORWARD

#define HIKCNN_GetMemSize                   HIKCNNFP16_GetMemSize
#define HIKCNN_GetModelMemSize              HIKCNNFP16_GetModelMemSize
#define HIKCNN_Create                       HIKCNNFP16_Create
#define HIKCNN_CreateModel                  HIKCNNFP16_CreateModel
#define HIKCNN_Process                      HIKCNNFP16_Process
#define HIKCNN_LibInfo                      HIKCNNFP16_LibInfo

#define HKA_DT_FLT32                        HKA_DTFP16_FLT32
#define HKA_DT_UINT8                        HKA_DTFP16_UINT8
#define HKA_DT_FLT16                        HKA_DTFP16_FLT16

#endif

extern "C" HRESULT HIKCNN_LibInfo(void *handle, void *info);

float       img_info[3];

static void *alloc_memory(size_t size, size_t aligment, bool gpu_mem)
{
    void    *data;

    if (!gpu_mem)                       //alloc CPU memory
    {
#ifdef LINUX
        int ret = posix_memalign(&data, aligment, size);
        if (ret != 0)
        {
            data = NULL;
        }
#else
        data = (char *)_aligned_malloc(size, aligment);
#endif
    }
    else                                //alloc GPU memory
    {
#ifdef CNN_CUDA_OPT
        data = HIKCUDA_Malloc(size);
#endif
    }
    return data;
}

static void free_memory(void  *data, bool gpu_mem)
{
    if (!gpu_mem)                       //free CPU memory
    {
#ifdef LINUX
        free(data);
#else
        _aligned_free(data);
#endif
    }
    else
    {
#ifdef CNN_CUDA_OPT
        HIKCUDA_Free(data);             //free GPU memory
#endif
    }
}

static void alloc_mem_tab(VCA_MEM_TAB_V2  *mem_tab, size_t tab_num)
{
    for (int i = 0; i < tab_num; i++)
    {
        printf("tab %d memsize: %f M\n", i, mem_tab[i].size / 1024.0 / 1024.0);

        if (mem_tab[i].size > 0)
        {
            mem_tab[i].base = alloc_memory(mem_tab[i].size, mem_tab[i].alignment, (mem_tab[i].plat == VCA_MEM_PLAT_GPU));
            CHECK_ERR(mem_tab[i].base == NULL, "alloc_memory failed");
        }
        else
        {
            mem_tab[i].base = NULL;
        }
    }
}

static void alloc_mem_tab(VCA_MEM_TAB_V2  *mem_tab, int num)
{
    for (int i = 0; i < num; i++)
    {
        printf("tab %d memsize: %f M\n", i, mem_tab[i].size / 1024.0 / 1024.0);

        if (mem_tab[i].size > 0)
        {
            mem_tab[i].base = alloc_memory(mem_tab[i].size, mem_tab[i].alignment, (mem_tab[i].plat == VCA_MEM_PLAT_GPU));
            CHECK_ERR(mem_tab[i].base == NULL, "alloc_memory failed");
        }
        else
        {
            mem_tab[i].base = NULL;
        }
    }
}

static void free_mem_tab(VCA_MEM_TAB_V2  *mem_tab)
{
    for (int i = 0; i < HIK_CNN_MEM_TAB_NUM; i++)
    {
        if (mem_tab[i].base)
        {
            free_memory(mem_tab[i].base, (mem_tab[i].plat == VCA_MEM_PLAT_GPU));
        }
    }
}

static void free_mem_tab(VCA_MEM_TAB_V2  *mem_tab, int num)
{
    for (int i = 0; i < num; i++)
    {
        if (mem_tab[i].base)
        {
            free_memory(mem_tab[i].base, (mem_tab[i].plat == VCA_MEM_PLAT_GPU));
        }
    }
}

#ifndef TEST_LIBCUDA

using namespace cv;

Mat             global_img[MAX_BATCH_SIZE];


typedef struct _CNN_MODEL_
{
    HKA_CNN_MODEL_PARAM     model_parm;
    VCA_MEM_TAB_V2          mem_tab[HIK_CNN_MEM_TAB_NUM];
    void                   *handle;
} CNN_MODEL;


HRESULT CreateModel(CNN_MODEL *model)
{
    printf("```````````````````````\n");

    HRESULT     hr = HIKCNN_GetModelMemSize(&model->model_parm, model->mem_tab);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_GetModelMemSize");

    alloc_mem_tab(model->mem_tab, HIK_CNN_MEM_TAB_NUM);

    hr = HIKCNN_CreateModel(&model->model_parm, model->mem_tab, &model->handle);
    printf("%d\n", hr);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_CreateModel");

    printf("HIKCNN_CreateModel succeed\n");
    return HIK_VCA_LIB_S_OK;
}

HRESULT CreateModel(CNN_MODEL *model, int num)
{
    HRESULT hr;

    for (int i = 0; i < num; i++)
    {
        hr = CreateModel(model + i);
        assert(hr == HIK_VCA_LIB_S_OK);
    }

    return HIK_VCA_LIB_S_OK;
}



void ReleaseModel(CNN_MODEL *model)
{
    free_mem_tab(model->mem_tab);
}

template<typename T>
Mat decode_img(string img_root, string img_name, bool color, T *dst, int *height, int *width, int resize_height = 0, int resize_width = 0)
{
    string                  img_path    = img_root + "/" + img_name;
    cv::Mat                 img         = cv::imread(img_path, color ? CV_LOAD_IMAGE_COLOR : CV_LOAD_IMAGE_GRAYSCALE);
    int                     mat_height  = img.rows;
    int                     mat_width   = img.cols;
    int                     mat_channel = img.channels();
    CHECK_ERR(mat_height == 0 || mat_width == 0, "imread failed");
    bool                    use_bin     = false;
    cv::Mat                 img_resized(img);

    if (resize_height && resize_width && (mat_height != resize_height || mat_width != resize_width))
    {
        cv::resize(img, img_resized, cv::Size(resize_width, resize_height));
#ifdef STABILITY_TEST
//         for (int h = 0; h < img_resized.rows; h++)
//         {
//             for (int w = 0; w < img_resized.cols; w++)
//             {
//                 for (int c = 0; c < img_resized.channels(); c++)
//                 {
//                     img_resized.data[img_resized.cols * img_resized.channels() * h + w * img_resized.channels() + c] += ((rand() % 150) - 150);
//                 }
//             }
//         }
// 
//         string result_name = "Y:/nfs/data/frcnn_data/fp16_test_data/bmp_hp_1600/" + img_name;
//         imwrite(result_name, img_resized);
#endif

        mat_height  = resize_height;
        mat_width   = resize_width;
    }

    char        bin_path[256] = {0};

    strcpy(bin_path, img_path.c_str());
    strcat(bin_path, ".bin");

    //FILE        *bin_file;       
    //FILE        *file = fopen("Y:/nfs/data/frcnn_data/fp16_test_data/bmp_1080p/img_result_x86.txt", "w");

    for (int c = 0; c < mat_channel; c++)
    {
        for (int h = 0; h < mat_height; h++)
        {
            for (int w = 0; w < mat_width; w++)
            {
                dst[(c * mat_height + h) * mat_width + w] = img_resized.data[mat_width * mat_channel * h + w * mat_channel + c];
            }
        }
    }

    //for (int c = 0; c < 1; c++)
    //{
    //    for (int h = 0; h < 5; h++)
    //    {
    //        for (int w = 0; w < 5; w++)
    //        {
    //            printf("%f\n", dst[(c * mat_height + h) * mat_width + w]);
    //        }
    //    }
    //}

#if 0
    if (use_bin == false)
    {
        printf("bin_path %s\n", bin_path);
        bin_file = fopen(bin_path, "wb");
        if (!bin_file)
        {
            printf("open bin file failed\n");
            exit(-1);
        }

        fwrite(dst, 1, sizeof(T) * mat_channel * mat_height * mat_width, bin_file);

        fclose(bin_file);
    }
    else
    {
        printf("bin_path %s\n", bin_path);
        bin_file = fopen(bin_path, "rb");
        if (!bin_file)
        {
            printf("open bin file failed\n");
            exit(-1);
        }

        fread(dst, 1, sizeof(T) * mat_channel * mat_height * mat_width, bin_file);

        fclose(bin_file);
    }
#endif

    *height = mat_height;
    *width  = mat_width;

    return img_resized;
}

template<typename T>
void decode_img(string img_root, string *img_path, bool color, T *dst, int *height, int *width, int batch_size, int resize_height = 0, int resize_width = 0)
{
    for (int i = 0; i < batch_size; i++)
    {
        global_img[i] = decode_img(img_root, img_path[i], color, dst, height, width, resize_height, resize_width);
        dst += *height * *width * (color ? 3 : 1);
    }
}



typedef struct _OUT_INFO_
{
    int                             out_layer_num;
    int                             out_layer[HIK_CNN_MAX_OUT_BLOB];                //���������
    int                             layer_out_blob[HIK_CNN_MAX_OUT_BLOB];           //ÿһ������blob���
    HKA_CNN_FORWARD_OUT_INFO        cnn_out_info;
}OUT_INFO;

static void set_out_info(OUT_INFO       *out_info)
{
#if 0
    out_info->out_layer_num     = 4;

    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1]      = -2;
    out_info->layer_out_blob[1] = -1;

    out_info->out_layer[2]      = -3;
    out_info->layer_out_blob[2] = -1;

    out_info->out_layer[3]      = 1;
    out_info->layer_out_blob[3] = -1;
#endif

#if 0
    out_info->out_layer_num     = 3;

    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1] = -2;
    out_info->layer_out_blob[1] = -1;

    out_info->out_layer[2] = -3;
    out_info->layer_out_blob[2] = -1;

#endif

#if 0
    out_info->out_layer_num     = 1;
    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;
#endif

#if 1
    out_info->out_layer_num     = 1;
    out_info->out_layer[0]      = -1;
    //out_info->out_layer[0]      = 26;
    //out_info->out_layer[0]      = 100;
    //out_info->out_layer[0]      = 18;
    //out_info->out_layer[0]      = 26;
    out_info->layer_out_blob[0] = -1;
#endif

#if 0
    out_info->out_layer_num = 1;

    out_info->out_layer[0] = -1;
    out_info->layer_out_blob[0] = -1;
#endif

#if 0                                      // AVR
    out_info->out_layer_num     = 6;

    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1]      = -2;
    out_info->layer_out_blob[1] = -1;

    out_info->out_layer[2]      = -3;
    out_info->layer_out_blob[2] = -1;

    out_info->out_layer[3]      = -4;
    out_info->layer_out_blob[3] = -1;

    out_info->out_layer[4]      = -5;
    out_info->layer_out_blob[4] = -1;

    out_info->out_layer[5]      = -6;
    out_info->layer_out_blob[5] = -1;
#endif
     

#if 0                                      // AVR 7 label
    out_info->out_layer_num     = 7;

    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1]      = -2;
    out_info->layer_out_blob[1] = -1;

    out_info->out_layer[2]      = -3;
    out_info->layer_out_blob[2] = -1;

    out_info->out_layer[3]      = -4;
    out_info->layer_out_blob[3] = -1;

    out_info->out_layer[4]      = -5;
    out_info->layer_out_blob[4] = -1;

    out_info->out_layer[5]      = -6;
    out_info->layer_out_blob[5] = -1;

    out_info->out_layer[6]      = -7;
    out_info->layer_out_blob[6] = -1;
#endif

#if 0 // ���ֿ� new
    out_info->out_layer_num     = 6;
    //out_info->out_layer_num     = 1;

    out_info->out_layer[0]      = -1;           // softmax_test_dalei
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1]      = -14;          // softmax_test_zhedang_xifen
    out_info->layer_out_blob[1] = -1;

    out_info->out_layer[2]      = -27;          // orient_ip2
    out_info->layer_out_blob[2] = -1;

    out_info->out_layer[3]      = -29;          // orient_ip1
    out_info->layer_out_blob[3] = -1;
    
    out_info->out_layer[4]      = -39;          // orient_conv1
    out_info->layer_out_blob[4] = -1;

    out_info->out_layer[5]      = -52;          // orient_conv1
    out_info->layer_out_blob[5] = -1;
    
#endif


#if 0
    out_info->out_layer_num     = 2;
    out_info->out_layer[0]      = -1;
    out_info->layer_out_blob[0] = -1;

    out_info->out_layer[1]      = -2;
    out_info->layer_out_blob[1] = -1;
#endif
}

static void set_cnn_param(HKA_CNN_PARAM     *cnn_param, 
                          int               in_blob_num,
                          int               height, 
                          int               width, 
                          int               channel, 
                          int               batch_size, 
                          void              *model_data, 
                          int               model_data_size, 
                          OUT_INFO          *out_info)
{
    cnn_param->in_blob_shape[0][0]      = batch_size;
    cnn_param->in_blob_shape[0][1]      = channel;
    cnn_param->in_blob_shape[0][2]      = height;
    cnn_param->in_blob_shape[0][3]      = width;

    cnn_param->in_blob_num              = in_blob_num;
    cnn_param->out_blob_num             = out_info->out_layer_num;

    if (cnn_param->in_blob_num > 1)
    {
        cnn_param->in_blob_shape[1][0]  = 1;     // batch_size
        cnn_param->in_blob_shape[1][1]  = 1;     // channel_num 
        cnn_param->in_blob_shape[1][2]  = 1;     // input_height
        cnn_param->in_blob_shape[1][3]  = 3;     // input_width 
    }

    for (int i = 0; i < cnn_param->out_blob_num; i++)
    {
        cnn_param->out_blob_info[i].layer_idx = out_info->out_layer[i];
        cnn_param->out_blob_info[i].blob_idx  = out_info->layer_out_blob[i];
    }
}

template<typename T>
static void set_cnn_proc_info(HKA_CNN_FORWARD_IN_INFO           *proc_in, 
                              int                                in_blob_num,
                              int                                last_layer,
                              int                                height,
                              int                                width,
                              int                                channel,
                              int                                batch_size,
                              T                                 *data)
{
    proc_in->end_layer_idx              = last_layer;

    proc_in->in_blob[0].shape[0]        = batch_size;
    proc_in->in_blob[0].shape[1]        = channel;
    proc_in->in_blob[0].shape[2]        = height;
    proc_in->in_blob[0].shape[3]        = width;

    if (typeid(T) == typeid(char))
    {
        cout << "typeid(T) == typeid(char)" << endl;
        proc_in->in_blob[0].type            = HKA_DT_UINT8;
    }
    else if (typeid(T) == typeid(float))
    {
        cout << "typeid(T) == typeid(float)" << endl;
        proc_in->in_blob[0].type            = HKA_DT_FLT32;
    }
    else
    {
        cout << "data type not support" << endl;
        exit(0);
    }

    proc_in->in_blob[0].data            = (void *)data;
    img_info[0]                         = height;
    img_info[1]                         = width;
    img_info[2]                         = 1.0f;
    proc_in->in_blob_num                = in_blob_num;

    if (in_blob_num > 1)
    {
        proc_in->in_blob[1].shape[0]    = 1;
        proc_in->in_blob[1].shape[1]    = 1;
        proc_in->in_blob[1].shape[2]    = 1;
        proc_in->in_blob[1].shape[3]    = 3;
        proc_in->in_blob[1].type        = HKA_DT_FLT32;
        proc_in->in_blob[1].data        = (void*)img_info;
    }
}

static void process_frcnn_out(HKA_BLOB      *blob, 
                              Mat           img, 
                              string        img_path, 
                              string        img_name,
                              FILE          *result_bus,
                              FILE          *result_truck,
                              FILE          *result_ped,
                              FILE          *result_car,
                              int           batch_index)
{
    float       *rec = (float *)blob->data;
    int          point[4];
    int          cls_no;
    float        conf;
    int          car_num = 0;
    int          ped_num = 0;
    int          bus_num = 0;
    int          bi;

    float        scale_h = 1.0f;
    float        scale_w = 1.0f;

    if (img.cols != GROUND_TRUTH_WIDTH)
    {
        scale_w = 1.0f * GROUND_TRUTH_WIDTH / img.cols;
    }
    if (img.rows != GROUND_TRUTH_HEIGHT)
    {
        scale_h = 1.0f * GROUND_TRUTH_HEIGHT / img.rows;
    }

    const       int out_elt_num = 7;

    for (int i = 0; i < blob->shape[0]; i++)
    {
        cls_no      = (int)rec[i * out_elt_num];
        bi          = (int)rec[i * out_elt_num + 6];

        if (bi == batch_index)
        {
            conf = rec[i * out_elt_num + 1];

            point[0] = max((int)rec[i * out_elt_num + 2], 0);
            point[1] = max((int)rec[i * out_elt_num + 3], 0);
            point[2] = min((int)rec[i * out_elt_num + 4], img.cols);
            point[3] = min((int)rec[i * out_elt_num + 5], img.rows);

            char a[10] = { 0 };
            if (cls_no == PED_ATTR)         //PED
            {
                sprintf(a, "%g", conf);
                putText(img, a, Point(point[0], point[1]), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0), 2);
                rectangle(img, Point(point[0], point[1]), Point(point[2], point[3]), Scalar(0, 0, 255), 2);
                ped_num++;
            }
            else if (cls_no == BUS_ATTR)    //BUS
            {
                sprintf(a, "%g", conf);
                putText(img, a, Point(point[0], point[1]), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0), 2);
                rectangle(img, Point(point[0], point[1]), Point(point[2], point[3]), Scalar(0, 255, 0), 2);
                bus_num++;
            }
            else if (cls_no == CAR_ATTR)    //CAR
            {
                sprintf(a, "%g", conf);
                putText(img, a, Point(point[0], point[1]), FONT_HERSHEY_SIMPLEX, 1.0, Scalar(0), 2);
                rectangle(img, Point(point[0], point[1]), Point(point[2], point[3]), Scalar(255, 0, 0), 2);
                car_num++;
            }
        }
    }

    fprintf(result_ped, "%d %s\n", ped_num, img_name.c_str());
    fprintf(result_car, "%d %s\n", car_num, img_name.c_str());
    fprintf(result_bus, "%d %s\n", bus_num, img_name.c_str());

    for (int i = 0; i < blob->shape[0]; i++)
    {
        cls_no   = (int)rec[i * out_elt_num];
        bi       = (int)rec[i * out_elt_num + 6];

        if (bi == batch_index)
        {
            conf = rec[i * out_elt_num + 1];
            point[0] = max((int)rec[i * out_elt_num + 2], 0);
            point[1] = max((int)rec[i * out_elt_num + 3], 0);
            point[2] = min((int)rec[i * out_elt_num + 4], img.cols);
            point[3] = min((int)rec[i * out_elt_num + 5], img.rows);

#ifdef COMPARE_WITH_GROUND_TRUTH
            if (scale_w != 1.0f)
            {
                point[0] *= scale_w;
                point[2] *= scale_w;
            }
            if (scale_h != 1.0f)
            {
                point[1] *= scale_h;
                point[3] *= scale_h;
            }
#endif
            char a[10] = { 0 };

            if (cls_no == PED_ATTR)   //PED
            {
                fprintf(result_ped, "%d ", point[0]);
                fprintf(result_ped, "%d ", point[1]);
                fprintf(result_ped, "%d ", point[2]);
                fprintf(result_ped, "%d ", point[3]);
                fprintf(result_ped, "%f ", conf);
                fprintf(result_ped, "\n");
            }
            else if (cls_no == BUS_ATTR)  //BUS
            {
                fprintf(result_bus, "%d ", point[0]);
                fprintf(result_bus, "%d ", point[1]);
                fprintf(result_bus, "%d ", point[2]);
                fprintf(result_bus, "%d ", point[3]);
                fprintf(result_bus, "%f ", conf);
                fprintf(result_bus, "\n");
            }
            else if (cls_no == CAR_ATTR)  //CAR
            {
                fprintf(result_car, "%d ", point[0]);
                fprintf(result_car, "%d ", point[1]);
                fprintf(result_car, "%d ", point[2]);
                fprintf(result_car, "%d ", point[3]);
                fprintf(result_car, "%f ", conf);
                fprintf(result_car, "\n");
            }
        }
    }

#ifdef LINUX
    string      result_img = img_path + "/result_tx1";
#else
    string      result_img = img_path + "/result_x86";
#endif

    result_img += "/";
    result_img += img_name;
    //result_img += ".jpg";

    cout << result_img << endl;

    bool        ret = imwrite(result_img.c_str(), img);

    if (!ret) cout << "imwrite failed\n";

    fflush(result_ped);
    fflush(result_car);
    fflush(result_bus);
    fflush(result_truck);
}

static void process_frcnn_out(HKA_BLOB      *blob, 
                              int           batch_size,
                              string        img_path, 
                              string        *img_name,
                              FILE          *result_bus,
                              FILE          *result_truck,
                              FILE          *result_ped,
                              FILE          *result_car)
{
   for (int i = 0; i < batch_size; i++)
       process_frcnn_out(blob, global_img[i], img_path, img_name[i], result_bus, result_truck, result_ped, result_car, i);
}

static void process_cnn_out(HKA_BLOB      *oblob, 
                            string         img_name,
                            FILE          *result_cls)
{
    float       *d  = (float*)oblob->data;
    int          n  = oblob->shape[1] * oblob->shape[2] * oblob->shape[3];

    if (n > 0)
    {
        int max_pos = 0;
        float max_v = d[0];
        for (int i = 1; i < n; i++)
        {
            if (d[i] > max_v)
            {
                max_v = d[i];
                max_pos = i;
            }
        }
        fprintf(result_cls, "max_pos: %d  max_v: %f\n", max_pos, max_v);
        printf("max_pos: %d  max_v: %f\n", max_pos, max_v);
    }
    fflush(result_cls);
}


static void process_frcnn_out2(HKA_BLOB      *oblob, 
                              string        *img_name,
                              FILE          *result_cls)
{
    float       *d              = (float*)oblob->data;
    int          batch_size     = oblob->shape[0];
    int          n              = batch_size * oblob->shape[1] * oblob->shape[2] * oblob->shape[3];

    if (n > 0)
    {
        for (int k = 0; k < 1; k++)
        {
            int         max_pos     = 0;
            float       max_v       = d[0];

            for (int i = 1; i < n; i++)
            {
                if (d[i] > max_v)
                {
                    max_v = d[i];
                    max_pos = i;
                }
            }
            d += n;
            fprintf(result_cls, "max_pos: %d  max_v: %f\n", max_pos, max_v);
            printf("max_pos: %d  max_v: %f\n", max_pos, max_v);
        }
    }
    fflush(result_cls);
}

static void process_cnn_out(HKA_BLOB      *oblob, 
                            string        *img_name,
                            FILE          *result_cls)
{
    float       *d              = (float*)oblob->data;
    int          batch_size     = oblob->shape[0];
    int          n              = oblob->shape[1] * oblob->shape[2] * oblob->shape[3];
    printf("-------------- %d %d %d %d %d %d\n",oblob->shape[0], oblob->shape[1], oblob->shape[2], oblob->shape[3], n, batch_size);

    if (n > 0)
    {
        for (int k = 0; k < batch_size; k++)
        {
            int         max_pos     = 0;
            float       max_v       = d[0];

            for (int i = 1; i < n; i++)
            {
                if (d[i] > max_v)
                {
                    max_v = d[i];
                    max_pos = i;
                }
            }
            d += n;
            fprintf(result_cls, "max_pos: %d  max_v: %f\n", max_pos, max_v);
            printf("max_pos: %d  max_v: %f\n", max_pos, max_v);
        }
    }
    fflush(result_cls);
}

static int get_batch_line(ifstream &in_list, string *batch_line, int batch_size)
{
    int         readed_line = 0;
    string      line;

    while (batch_size--)
    {
        getline(in_list, line);
        if(line.size() == 0) break;

        if((line.c_str())[0] == '#')
        {
            batch_size++;
            continue;
        }
        if((line.c_str())[line.length() - 1] == '\r')   ((char *)(line.c_str()))[line.length() - 1] = 0;

        batch_line[readed_line] = line;
        readed_line++;
    }
    return readed_line;
}


void save_blob(FILE *file, HKA_BLOB *blob)
{
    int     num = blob->shape[0] * blob->shape[1] * blob->shape[2] * blob->shape[3];
    float   *data = (float *)blob->data;


    int nwrite;
    for (int i = 0; i < num; i++)
    {
        fprintf(file, "%f\n", data[i]);
    }
    fflush(file);
    //nwrite = fwrite(blob->data, 1, bytes, file);
    //CHECK_ERR(nwrite != bytes, "fwrite failed");
}

static char *get_img_dir_name(char *img_root)
{
    int     length = strlen(img_root);
    char    *pstr = img_root + length - 1;
    while(*pstr-- != '/');

    pstr    += 2;
    return pstr;
}


void rand_set_size(int &rh, int &rw)
{
    const int max_height = 2160;
    const int max_width  = 4096;

    const int min_height = 280;
    const int min_width  = 470;


    rh  = rand() % max_height + 1;
    rw  = rand() % max_width + 1;

    rh  = rh < min_height ? min_height : rh;
    rw  = rw < min_width ? min_width : rw;
}

//rcnn_flag = true,  ����FRCNN
//rcnn_flag = false, ����CNN
template<typename T>
void test_libcnn(bool    rcnn_flag,
                 string  data_root,
                 string  img_root,
                 string  model_name,
                 int     rh         = 0,
                 int     rw         = 0,
                 int     batch_size = 1)
{
    string          out_txt_path    = img_root;
    string          model_path      = data_root + "/" + model_name;
    
    float           scale_h         = 1.0f;
    float           scale_w         = 1.0f;

    cout<<model_path<<endl;
    FILE            *model_file     = fopen(model_path.c_str(), "rb");
    CHECK_ERR(model_file == NULL, "fopen failed");

    string          img_list        = img_root + "/imagelist.txt";
    int             model_file_size = 0;

    fseek(model_file, 0, SEEK_END);
    model_file_size                 = ftell(model_file);
    rewind(model_file);

#ifdef SKIP_VERSION_INFO
    model_file_size -= 4;
#endif

    char            *model_data     = (char *)alloc_memory(model_file_size, 128, false);
    CHECK_ERR(model_data == NULL, "alloc_memory failed");

    int             nread           = fread(model_data, 1, model_file_size, model_file);
    CHECK_ERR(nread != model_file_size, "fread failed");

#ifdef SKIP_VERSION_INFO
    model_data += 4;
#endif

    int             max_height      = HEIGHT;
    int             max_width       = WIDTH;

#ifndef STABILITY_TEST
    if (rh && rw)
    {
        max_height = rh;
        max_width = rw;
    }
#endif
  printf("MMMMM max_width=%d  max_height=%d rw=%d rh=%d \n",max_width, max_height, rw, rh);
#ifdef DFR_BUILD_MODEL_TEST
    int             channel         = 1;
#else
    int             channel         = 3;
#endif

    bool            recreate        = false;

    int             prev_height     = max_height;
    int             prev_width      = max_width;

    T               *input_data     = new T[max_height * max_width * channel * batch_size];
    CHECK_ERR(input_data == NULL, "malloc failed");

    OUT_INFO        out_info;
    HKA_CNN_PARAM   cnn_param;

    CNN_MODEL model;
    memset(&model, 0, sizeof(CNN_MODEL));

    model.model_parm.model_data     = model_data;
    model.model_parm.model_datasize = model_file_size;

    CreateModel(&model);

    set_out_info(&out_info);
    set_cnn_param(&cnn_param, rcnn_flag ? 2 : 1, max_height, max_width, channel, batch_size, model_data, model_file_size, &out_info);

    cnn_param.model_handle = model.handle;

    VCA_MEM_TAB_V2     mem_tab[HIK_CNN_MEM_TAB_NUM], mem_tab_cuda_handle;
    HRESULT            hr;

    hr            = HIKCNN_GetMemSize(&cnn_param, mem_tab);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_GetMemSize");
    
#ifdef CNN_CUDA_OPT
    hr = HIKCUDA_GetMemSize(&mem_tab_cuda_handle);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_GetMemSize");

    mem_tab_cuda_handle.base = alloc_memory(mem_tab_cuda_handle.size, mem_tab_cuda_handle.alignment, false);
    CHECK_ERR(mem_tab_cuda_handle.base == NULL, "alloc_memory failed");
#endif


    alloc_mem_tab(mem_tab, HIK_CNN_MEM_TAB_NUM);

    void            *cnn_handle, *cuda_handle;
    
#ifdef CNN_CUDA_OPT
    hr = HIKCUDA_Create(&mem_tab_cuda_handle, &cuda_handle);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Create");
#endif

#ifdef CNN_CUDA_OPT
    cnn_param.cuda_handle = cuda_handle;
#endif

    hr            = HIKCNN_Create(&cnn_param, mem_tab, &cnn_handle);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_Create");

#ifdef ZIP_TEST
    CNN_LIB_INFO lib_info;
    hr = HIKCNN_LibInfo(cnn_handle, &lib_info);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_LibInfo");

    printf("support_zip:  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %d\n",
            lib_info.support_zip);
#endif

    string          line;
    ifstream        in_list(img_list.c_str());

    int             cur_height;
    int             cur_width;

    HKA_CNN_FORWARD_IN_INFO  proc_in;
    HKA_CNN_FORWARD_IN_INFO  proc_im_info;
    HKA_CNN_FORWARD_OUT_INFO proc_out;

    set_cnn_proc_info(&proc_in, rcnn_flag ? 2 : 1, -1, prev_height, prev_width, channel, batch_size, input_data);

    FILE            *result_car     = 0;
    FILE            *result_truck   = 0;
    FILE            *result_bus     = 0;
    FILE            *result_ped     = 0;
    FILE            *result_cls     = 0;

    string          txt_base_name   = "";
    char            str_h[32];
    char            str_w[32];
    char            *img_dir = get_img_dir_name((char *)img_root.c_str());

    sprintf(str_h, "%d", rh);
    sprintf(str_w, "%d", rw);

    txt_base_name   += img_dir;
#ifdef COMPARE_WITH_GROUND_TRUTH
    txt_base_name   += "_comgdth";
#endif
#ifdef V210TX1
    txt_base_name += "_V210_VTX1";
#else
    txt_base_name += "_V210";
#endif
    char        bs[16];
    sprintf(bs, "%d", batch_size);

    if (batch_size != 1)
    {
        txt_base_name += "_b";
        txt_base_name += bs;
    }
    txt_base_name   += "_";
    txt_base_name   += model_name;
    txt_base_name   += "_";
    txt_base_name   += str_h;
    txt_base_name   += "_";
    txt_base_name   += str_w;

    out_txt_path   += "/";
    out_txt_path   += txt_base_name;

#ifdef LINUX
#ifdef TX1FP16
    if (rcnn_flag)
    {
        result_bus      = fopen((out_txt_path + "_result_bus_tx1_fp16.txt").c_str(),   "w");
        result_truck    = fopen((out_txt_path + "_result_truck_tx1_fp16.txt").c_str(), "w");
        result_ped      = fopen((out_txt_path + "_result_ped_tx1_fp16.txt").c_str(),   "w");
        result_car      = fopen((out_txt_path + "_result_car_tx1_fp16.txt").c_str(),   "w");
        CHECK_ERR(!result_bus || !result_car || !result_ped || !result_truck,      "fopen failed");
    }
    //else
    //{
        result_cls      = fopen((out_txt_path + "_result_cls_tx1_fp16.txt").c_str(), "w");
        CHECK_ERR(!result_cls, "fopen failed");
    //}
#else
    if (rcnn_flag)
    {
        result_bus      = fopen((out_txt_path + "_result_bus_tx1_fp32.txt").c_str(),   "w");
        result_truck    = fopen((out_txt_path + "_result_truck_tx1_fp32.txt").c_str(), "w");
        result_ped      = fopen((out_txt_path + "_result_ped_tx1_fp32.txt").c_str(), "w");
        result_car      = fopen((out_txt_path + "_result_car_tx1_fp32.txt").c_str(), "w");
        CHECK_ERR(!result_bus || !result_car || !result_ped || !result_truck, "fopen failed");
    }
    //else
    //{
        result_cls      = fopen((out_txt_path + "_result_cls_tx1_fp32.txt").c_str(), "w");
        CHECK_ERR(!result_cls, "fopen failed");
    //}
    
#endif
#else
   
#ifdef CNN_CUDA_OPT
    if (rcnn_flag)
    {
        result_bus      = fopen((out_txt_path + "_result_bus_x86_gpu.txt").c_str(), "w");
        result_truck    = fopen((out_txt_path + "_result_truck_x86_gpu.txt").c_str(), "w");
        result_ped      = fopen((out_txt_path + "_result_ped_x86_gpu.txt").c_str(), "w");
        result_car      = fopen((out_txt_path + "_result_car_x86_gpu.txt").c_str(), "w");
        CHECK_ERR(!result_bus || !result_car || !result_ped || !result_truck, "fopen failed");
    }
    //else
    //{
        result_cls      = fopen((out_txt_path + "_result_cls_x86_gpu.txt").c_str(), "w");
        CHECK_ERR(!result_cls, "fopen failed");
   // }
#else
    if (rcnn_flag)
    {
        result_bus   = fopen((out_txt_path + "_result_bus_x86.txt").c_str(), "w");
        result_truck = fopen((out_txt_path + "_result_truck_x86.txt").c_str(), "w");
        result_ped   = fopen((out_txt_path + "_result_ped_x86.txt").c_str(), "w");
        result_car   = fopen((out_txt_path + "_result_car_x86.txt").c_str(), "w");
        CHECK_ERR(!result_bus || !result_car || !result_ped || !result_truck, "fopen failed");
    }
    //else
    //{
        result_cls = fopen((out_txt_path + "_result_cls_x86.txt").c_str(), "w");
        CHECK_ERR(!result_cls, "fopen failed");
    //}
    
#endif

#endif

    int                 line_read;
    string              img_name[MAX_BATCH_SIZE];
    string              img_full_name[MAX_BATCH_SIZE];

    for (int i = 0; i < 1024; i++)
    {
        OPT_PROFILE_TIME_RESET(i);
    }

    FILE    *blob_file;
    if(batch_size > 1)
    {
       blob_file = fopen("blob_data_batch.txt", "w");
    }
    else
    {
        blob_file = fopen("blob_data_batch.txt", "w");
    }

    CHECK_ERR(blob_file == NULL, "fopen failed");

    int count = 0;

    while((line_read = get_batch_line(in_list, img_name, batch_size)) == batch_size)
    {
        cout << "------------------------------------" << endl;
        for (int i = 0; i < batch_size; i++)
        {
            img_full_name[i] = img_root + "/" + img_name[i];
            cout << img_name[i] << endl;
        }

        if (count >= 1)
        {
            //exit(0);
        }
        else
        {
            count++;
        }

#ifdef STABILITY_TEST 
        rand_set_size(rh, rw);
#endif

        decode_img(img_root, img_name, (channel == 3) ? true : false, input_data, &cur_height, &cur_width, batch_size, rh, rw);
        //printf("height width�� %d %d\n", cur_height, cur_width);
        
#ifndef TEST_HANDLE_RECREATE
        //if (prev_height != cur_height || prev_width != cur_width)
        if (1)
#else
        while(1)
#endif
        {
            if (recreate)
            {
                //�����ȵ���HIKCNN_Release�����ͷ�mem_tab

                int release_count = 1;
                while(release_count--)
                {
#ifdef CNN_CUDA_OPT
                    hr = HIKCUDA_Release(cuda_handle);
                    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Release failed");
#endif
                }

                model.model_parm.model_data = model_data;
                model.model_parm.model_datasize = model_file_size;

                ReleaseModel(&model);
                CreateModel(&model);
                printf("--------++-----------------------------------------------------------------------------------------recreate model handle\n");

                free_mem_tab(mem_tab);
                free_memory(mem_tab_cuda_handle.base, false);

                set_cnn_param(&cnn_param, rcnn_flag ? 2 : 1, cur_height, cur_width, channel, batch_size, model_data, model_file_size, &out_info);

                cnn_param.model_handle = model.handle;

                hr = HIKCNN_GetMemSize(&cnn_param, mem_tab);
                CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_GetMemSize");

                mem_tab[0].size -= 1;

                //�����ڴ棬�����㷨����GPU�汾����CPU�汾��mem_tab�ĺ��岻ͬ��
                alloc_mem_tab(mem_tab, HIK_CNN_MEM_TAB_NUM);

#ifdef CNN_CUDA_OPT
                hr = HIKCUDA_GetMemSize(&mem_tab_cuda_handle);
                CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_GetMemSize");

                mem_tab_cuda_handle.base = alloc_memory(mem_tab_cuda_handle.size, mem_tab_cuda_handle.alignment, false);
                CHECK_ERR(mem_tab_cuda_handle.base == NULL, "alloc_memory failed");

                printf("--------------------------------------------------------------------------------------------------recreate cuda handle\n");
                hr = HIKCUDA_Create(&mem_tab_cuda_handle, &cuda_handle);
                CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Create");
                cnn_param.cuda_handle = cuda_handle;
#endif

                hr = HIKCNN_Create(&cnn_param, mem_tab, &cnn_handle);
                CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_Create");

#ifdef ZIP_TEST
                hr = HIKCNN_LibInfo(cnn_handle, &lib_info);
                CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_LibInfo");

                printf("support_zip:  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %d\n",
                        lib_info.support_zip);
                printf("fusion_layer: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %d\n",
                        lib_info.horizontal_fusion_num);
#endif
            }
            set_cnn_proc_info(&proc_in,rcnn_flag ? 2 : 1, -1, cur_height, cur_width, channel, batch_size, input_data);
        }
#ifndef TEST_HANDLE_RECREATE

        OPT_PROFILE_TIME_START(1022);

        int profile_count = 1;

        for (int n = 0; n < profile_count; n++)
        {
            hr = HIKCNN_Process(cnn_handle, PROC_TYPE_FORWARD, &proc_in, sizeof(proc_in), &proc_out, sizeof(proc_out));
            CHECK_ERR_PCODE(hr != HIK_VCA_LIB_S_OK, hr, "HIKCNN_Process");
        }
       
        OPT_PROFILE_TIME_STOP(1022, "HIKCNN_Process", profile_count, 1);

        CHECK_ERR(proc_out.blob_num != out_info.out_layer_num, "HIKCNN_Process");
        CHECK_ERR(!rcnn_flag && proc_out.output_blob[0].shape[0] != batch_size, "HIKCNN_Process");

        //cout << "process succeed.........\n";
        if (rcnn_flag)            //����frcnn���
        //if (0)
        {
            //for (int i = 0; i < proc_out.blob_num; i++)
            int i;
            for (i = 0; i < 1; i++)
            {
                printf("+++++++++++++++++++++++++proc_out.output_blob[i]: %d %d %d %d \n", proc_out.output_blob->shape[0], proc_out.output_blob->shape[1], proc_out.output_blob->shape[2], proc_out.output_blob->shape[3]);
                process_frcnn_out(&proc_out.output_blob[i], batch_size, img_root, img_name, result_bus, result_truck, result_ped, result_car);
                //save_blob(blob_file, &proc_out.output_blob[i]);
                //process_cnn_out(&proc_out.output_blob[i], img_name, result_cls);
                //process_frcnn_out2(&proc_out.output_blob[i], img_name, result_cls);
            }
            for (i = 0; i < proc_out.blob_num; i++)
            {
                //save_blob(blob_file, &proc_out.output_blob[i]);
            }
//             printf("write blob done............\n");
        }
        else                      //����cnn���
        {
            for (int i = 0; i < proc_out.blob_num; i++)
            {
                process_cnn_out(&proc_out.output_blob[i], img_name, result_cls);
            }
        }
#endif
        prev_height     = cur_height;
        prev_width      = cur_width;
        //exit(0);
    }

#ifdef CNN_CUDA_OPT
    int release_count = 1;
    while (release_count--)
    {
        hr = HIKCUDA_Release(cuda_handle);
        CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Release failed");
    }
#endif

    ReleaseModel(&model);

    free_memory(mem_tab_cuda_handle.base, false);
    free_mem_tab(mem_tab);

    if (result_truck)
    {
        fclose(result_truck);
    }
    if (result_car)
    {
        fclose(result_car);
    }
    if (result_ped)
    {
        fclose(result_ped);
    }
    if (result_bus)
    {
        fclose(result_bus);
    }
    if (result_cls)
    {
        fclose(result_cls);
    }
    if (blob_file)
    {
        fclose(blob_file);
    }

    delete[] input_data;

#ifdef SKIP_VERSION_INFO
    model_data -= 4;
#endif
    free_memory(model_data, false);

    cout<<"done.................\n";
}

//rcnn_flag = true,  ����FRCNN
//rcnn_flag = false, ����CNN
template<typename T>
void test__multi_libcnn(bool        rcnn_flag,
                        string      data_root,
                        string      img_root,
                        int         rh          = 0,
                        int         rw          = 0,
                        int         batch_size  = 1)
{
    const int       model_num                   = 3;
    string          model_name[model_num]       = {"ZF-tucker-new.bin", "vggSBR_no_model_name.bin", "m33_test.bin"};
    string          out_txt_path[model_num];
    string          model_path[model_num];
    int             model_file_size[model_num];

    FILE            *model_file[model_num];
    char            *model_data[model_num];

    HKA_CNN_BLOB_TYPE   input_type = HKA_DT_UINT8;

    for (int i = 0; i < model_num; i++)
    {
        model_path[i] = data_root + "/" + model_name[i];
        cout << model_path[i] << endl;

        model_file[i] = fopen(model_path[i].c_str(), "rb");
        assert(model_file[i] != NULL);

        fseek(model_file[i], 0, SEEK_END);
        model_file_size[i] = ftell(model_file[i]);
        rewind(model_file[i]);

        model_data[i]  = (char *)alloc_memory(model_file_size[i], 128, false);
        assert(model_data != NULL);

        int             nread = fread(model_data[i], 1, model_file_size[i], model_file[i]);
        assert(nread == model_file_size[i]);
    }
    
    float           scale_h         = 1.0f;
    float           scale_w         = 1.0f;
    string          img_list        = img_root + "/imagelist.txt";

#ifdef SKIP_VERSION_INFO
    model_file_size -= 4;
#endif

#ifdef SKIP_VERSION_INFO
    model_data += 4;
#endif
    int             max_height      = HEIGHT;
    int             max_width       = WIDTH;
#ifndef STABILITY_TEST
    if (rh && rw)
    {
        max_height = rh;
        max_width = rw;
    }
#endif

#ifdef DFR_BUILD_MODEL_TEST
    int             channel         = 1;
#else
    int             channel         = 3;
#endif
    bool            recreate        = false;
    int             prev_height     = max_height;
    int             prev_width      = max_width;

    T               *input_data     = new T[max_height * max_width * channel * batch_size];
    CHECK_ERR(input_data == NULL, "malloc failed");

    OUT_INFO        out_info[model_num];
    HKA_CNN_PARAM   cnn_param[model_num];
    CNN_MODEL       model[model_num];

    for (int i = 0; i < model_num; i++)
    {
        memset(&model[i], 0, sizeof(CNN_MODEL));

        model[i].model_parm.model_data      = model_data[i];
        model[i].model_parm.model_datasize  = model_file_size[i];
    }
    
    CreateModel(model, model_num);

    for (int i = 0; i < model_num; i++)
    {
        set_out_info(&out_info[i]);
        set_cnn_param(&cnn_param[i], rcnn_flag ? 2 : 1, max_height, max_width, channel, batch_size, model_data, model_file_size[i], &out_info[i]);
        cnn_param[i].model_handle = model[i].handle;
    }

    VCA_MEM_TAB_V2     mem_tab[model_num][HIK_CNN_MEM_TAB_NUM], mem_tab_cuda_handle;
    HRESULT            hr;

    void              *cnn_handle[model_num], *cuda_handle;

#ifdef CNN_CUDA_OPT
    hr = HIKCUDA_GetMemSize(&mem_tab_cuda_handle);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_GetMemSize");

    mem_tab_cuda_handle.base = alloc_memory(mem_tab_cuda_handle.size, mem_tab_cuda_handle.alignment, false);
    CHECK_ERR(mem_tab_cuda_handle.base == NULL, "alloc_memory failed");

    hr = HIKCUDA_Create(&mem_tab_cuda_handle, &cuda_handle);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Create");
#endif

    size_t max_mem = 0;

    for (int i = 0; i < model_num; i++)
    {
        hr = HIKCNN_GetMemSize(&cnn_param[i], mem_tab[i]);
        CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_GetMemSize");
        
        alloc_mem_tab(&mem_tab[i][0], 2);

        max_mem = (mem_tab[i][2].size > max_mem) ? mem_tab[i][2].size : max_mem;

#ifdef CNN_CUDA_OPT
        cnn_param[i].cuda_handle = cuda_handle;
#endif
    }

    void *data_gpu_tab2 = alloc_memory(max_mem, mem_tab[0][2].alignment, mem_tab[0][2].plat == VCA_MEM_PLAT_GPU);
    assert(data_gpu_tab2);

    for (int i = 0; i < model_num; i++)
    {
        mem_tab[i][2].base = data_gpu_tab2;

        hr = HIKCNN_Create(&cnn_param[i], &mem_tab[i][0], &cnn_handle[i]);
        CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_Create");
    }


#ifdef ZIP_TEST
    CNN_LIB_INFO lib_info;
    for (int i = 0; i < model_num; i++)
    {
        hr = HIKCNN_LibInfo(cnn_handle[i], &lib_info);
        CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCNN_LibInfo");

        printf("support_zip:  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %d\n",
                lib_info.support_zip);
        printf("fusion_layer: ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ %d\n",
                lib_info.horizontal_fusion_num);
    }
#endif

    string          line;
    ifstream        in_list(img_list.c_str());

    int             cur_height;
    int             cur_width;

    HKA_CNN_FORWARD_IN_INFO  proc_in[model_num];
    HKA_CNN_FORWARD_IN_INFO  proc_im_info;
    HKA_CNN_FORWARD_OUT_INFO proc_out[model_num];

    for (int i = 0; i < model_num; i++)
    {
        set_cnn_proc_info(&proc_in[i], rcnn_flag ? 2 : 1, -1, prev_height, prev_width, channel, batch_size, input_data, HKA_DT_UINT8);
    }

    FILE            *result_car[model_num]     = {0};
    FILE            *result_truck[model_num]   = {0};
    FILE            *result_bus[model_num]     = {0};
    FILE            *result_ped[model_num]     = {0};
    FILE            *result_cls[model_num]     = {0};

    char            str_h[32];
    char            str_w[32];
    char            *img_dir = get_img_dir_name((char *)img_root.c_str());

    sprintf(str_h, "%d", rh);
    sprintf(str_w, "%d", rw);

    char        bs[16];
    sprintf(bs, "%d", batch_size);

    string          txt_base_name[model_num];
    for (int i = 0; i < model_num; i++)
    {
        txt_base_name[i] = "";
        txt_base_name[i] += img_dir;

#ifdef COMPARE_WITH_GROUND_TRUTH
        txt_base_name[i] += "_comgdth";
#endif
#ifdef V210TX1
        txt_base_name[i] += "_V210_VTX1";
#else
        txt_base_name[i] += "_V210";
#endif

        if (batch_size != 1)
        {
            txt_base_name[i] += "_b";
            txt_base_name[i] += bs;
        }
        txt_base_name[i] += "_";
        txt_base_name[i] += model_name[i];
        txt_base_name[i] += "_";
        txt_base_name[i] += str_h;
        txt_base_name[i] += "_";
        txt_base_name[i] += str_w;

        out_txt_path[i] = img_root;

        out_txt_path[i] += "/";
        out_txt_path[i] += txt_base_name[i];
    }

    for (int i = 0; i < model_num; i++)
    {
#ifdef LINUX
#ifdef TX1FP16
    if (rcnn_flag)
    {
        result_bus[i]      = fopen((out_txt_path[i] + "_result_bus_tx1_fp16.txt").c_str(),   "w");
        result_truck[i]    = fopen((out_txt_path[i] + "_result_truck_tx1_fp16.txt").c_str(), "w");
        result_ped[i]      = fopen((out_txt_path[i] + "_result_ped_tx1_fp16.txt").c_str(),   "w");
        result_car[i]      = fopen((out_txt_path[i] + "_result_car_tx1_fp16.txt").c_str(),   "w");
        CHECK_ERR(!result_bus[i] || !result_car[i] || !result_ped[i] || !result_truck[i],      "fopen failed");
    }
        result_cls[i]      = fopen((out_txt_path[i] + "_result_cls_tx1_fp16.txt").c_str(), "w");
        CHECK_ERR(!result_cls[i], "fopen failed");
#else
    if (rcnn_flag)
    {
        result_bus[i]      = fopen((out_txt_path[i] + "_result_bus_tx1_fp32.txt").c_str(),   "w");
        result_truck[i]    = fopen((out_txt_path[i] + "_result_truck_tx1_fp32.txt").c_str(), "w");
        result_ped[i]      = fopen((out_txt_path[i] + "_result_ped_tx1_fp32.txt").c_str(), "w");
        result_car[i]      = fopen((out_txt_path[i] + "_result_car_tx1_fp32.txt").c_str(), "w");
        CHECK_ERR(!result_bus[i] || !result_car[i] || !result_ped[i] || !result_truck[i], "fopen failed");
    }
        result_cls[i]      = fopen((out_txt_path[i] + "_result_cls_tx1_fp32.txt").c_str(), "w");
        CHECK_ERR(!result_cls[i], "fopen failed");
#endif

#else
 

#ifdef CNN_CUDA_OPT

        if (rcnn_flag)
        {
            result_bus[i]      = fopen((out_txt_path[i] + "_result_bus_x86_gpu.txt").c_str(), "w");
            result_truck[i]    = fopen((out_txt_path[i] + "_result_truck_x86_gpu.txt").c_str(), "w");
            result_ped[i]      = fopen((out_txt_path[i] + "_result_ped_x86_gpu.txt").c_str(), "w");
            result_car[i]      = fopen((out_txt_path[i] + "_result_car_x86_gpu.txt").c_str(), "w");
            CHECK_ERR(!result_bus[i] || !result_car[i] || !result_ped[i] || !result_truck[i], "fopen failed");
        }
        result_cls[i] = fopen((out_txt_path[i] + "_result_cls_x86_gpu.txt").c_str(), "w");
        CHECK_ERR(!result_cls, "fopen failed");
#else
        if (rcnn_flag)
        {
            result_bus[i]   = fopen((out_txt_path[i] + "_result_bus_x86.txt").c_str(), "w");
            result_truck[i] = fopen((out_txt_path[i] + "_result_truck_x86.txt").c_str(), "w");
            result_ped[i]   = fopen((out_txt_path[i] + "_result_ped_x86.txt").c_str(), "w");
            result_car[i]   = fopen((out_txt_path[i] + "_result_car_x86.txt").c_str(), "w");
            CHECK_ERR(!result_bus[i] || !result_car[i] || !result_ped[i] || !result_truck[i], "fopen failed");
        }
        result_cls[i] = fopen((out_txt_path[i] + "_result_cls_x86.txt").c_str(), "w");
        CHECK_ERR(!result_cls[i], "fopen failed");
#endif
#endif
    }

    int                 line_read;
    string              img_name[MAX_BATCH_SIZE];
    string              img_full_name[MAX_BATCH_SIZE];

    for (int i = 0; i < 1024; i++)
    {
        OPT_PROFILE_TIME_RESET(i);
    }

    int count = 0;

    while((line_read = get_batch_line(in_list, img_name, batch_size)) == batch_size)
    {
        cout << "------------------------------------" << endl;
        for (int i = 0; i < batch_size; i++)
        {
            img_full_name[i] = img_root + "/" + img_name[i];
            cout << img_name[i] << endl;
        }

        if (count >= 1)
        {
            //exit(0);
        }
        else
        {
            count++;
        }

#ifdef STABILITY_TEST 
        rand_set_size(rh, rw);
#endif

        decode_img(img_root, img_name, (channel == 3) ? true : false, input_data, &cur_height, &cur_width, batch_size, rh, rw);

        int profile_count = 1;

        for (int i = 0; i < model_num; i++)
        {
            OPT_PROFILE_TIME_START(1022);

            for (int n = 0; n < profile_count; n++)
            {
                hr = HIKCNN_Process(cnn_handle[i], 
                                    PROC_TYPE_FORWARD,
                                    &proc_in[i], 
                                    sizeof(HKA_CNN_FORWARD_IN_INFO),
                                    &proc_out[i], 
                                    sizeof(HKA_CNN_FORWARD_OUT_INFO));
                CHECK_ERR_PCODE(hr != HIK_VCA_LIB_S_OK, hr, "HIKCNN_Process");
            }

            printf("process succeed\n");
                

            OPT_PROFILE_TIME_STOP(1022, "HIKCNN_Process", profile_count, 1);

            CHECK_ERR(proc_out[i].blob_num != out_info[i].out_layer_num, "HIKCNN_Process");
            CHECK_ERR(!rcnn_flag && proc_out[i].output_blob[0].shape[0] != batch_size, "HIKCNN_Process");
        }
        for (int xi = 0; xi < model_num; xi++)
        {
            if (rcnn_flag)            //����frcnn���
            {
                for (int i = 0; i < 1; i++)
                {
                    printf("+++++++++++++++++++++++++proc_out.output_blob[i]: %d %d %d %d \n",
                                                            proc_out[xi].output_blob->shape[0],
                                                            proc_out[xi].output_blob->shape[1],
                                                            proc_out[xi].output_blob->shape[2],
                                                            proc_out[xi].output_blob->shape[3]);
                    process_frcnn_out(&proc_out[xi].output_blob[i],
                                      batch_size,
                                      img_root,
                                      img_name,
                                      result_bus[xi],
                                      result_truck[xi],
                                      result_ped[xi],
                                      result_car[xi]);
                }
            }
            else                      //����cnn���
            {
                for (int i = 0; i < proc_out[xi].blob_num; i++)
                {
                    process_cnn_out(&proc_out[xi].output_blob[i], img_name, result_cls[xi]);
                }
            }
        }

        prev_height     = cur_height;
        prev_width      = cur_width;
    }

#ifdef CNN_CUDA_OPT

    int release_count = 1;
    while (release_count--)
    {
        hr = HIKCUDA_Release(cuda_handle);
        CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_Release failed");
    }
#endif

#ifdef CNN_CUDA_OPT
    free_memory(mem_tab_cuda_handle.base, false);
    free_memory(data_gpu_tab2, mem_tab[0][2].plat == VCA_MEM_PLAT_GPU);
#endif

    for (int i = 0; i < model_num; i++)
    {
        ReleaseModel(&model[i]);
        free_mem_tab(&mem_tab[i][0], 2);

        if (result_truck[i])
        {
            fclose(result_truck[i]);
        }
        if (result_car[i])
        {
            fclose(result_car[i]);
        }
        if (result_ped[i])
        {
            fclose(result_ped[i]);
        }
        if (result_bus[i])
        {
            fclose(result_bus[i]);
        }
        if (result_cls[i])
        {
            fclose(result_cls[i]);
        }
    }

    delete[] input_data;

#ifdef SKIP_VERSION_INFO
    model_data -= 4;
#endif
    for (int i = 0; i < model_num; i++)
    {
        free_memory(model_data[i], false);
    }

    cout << "done.................\n";
}

static void test_lib(int model_opt, int res_opt , int img_opt, int batch_size)
{
    bool            rcnn_flag;
    string          data_root;
    string          img_root;
    string          model_name;
    int             rh, rw;

//#define TEST_FRCNN

#ifdef TEST_FRCNN
    char            models[64][256] = {"test_21.bin",
                                       "inception_resnet_v1.4_34846.bin",
                                       "full_face.bin",
                                       "ZF-tucker-new.bin",
                                       "VGG_SBR_zzq.bin",
                                       "m46_prune_0.07_decay_0.0001_faster_rcnn_iter_1250000.bin",
                                       "vggSBR_no_model_name.bin",
                                       "vggSBR-maxsize-1300-newtry2-sdp-6class-ohem-v3_iter_330000-mergebn.bin",
                                       "model.bin",                             // �ϵ�SDP
                                       "VGG_SBR.bin",
                                       "detect_model.bin",
                                       "vggSBR-sdp-7class-ohem-v3-33w.bin",
                                       "yang-no-bn.bin",
                                       "m46_pruned_0.08_test.bin",
                                       "m100_3_prune_0.07_faster_rcnn_iter_580000.bin",
                                       "m102_pruned2_0.060000_test.bin",
                                       "m46_prune_0.07_decay_0.0001_faster_rcnn_iter_1250000_256.bin",
                                       "m46-5_test.bin",
                                       "m46_4000_100.bin",
                                       "test.bin",
                                       "ZF_faster_rcnn_final.bin",
                                       "m22_11_faster_rcnn_iter_70000.bin",
                                       "vggSBR.bin",
                                       "vggSBR_no_model_name.bin",
                                       "m33_test.bin",
                                       "detect_model.bin",
                                       "vggSBR.bin",
                                       "m46_test_4000_100.bin",
                                       "test_1.5T_I120000.bin",             // concat�����Reshape
                                       "m46_test.bin",                      // ��9x9����
                                       "m67_test.bin",                      // �ܲ��ˣ�����ģ�ͱȽ���
                                       "m49_test_4000_100.bin",
                                       "600G_I90000.bin",                   // concat�����Reshape
                                       "model_panzuozhou.bin",              // PASS
                                       "m27-1_faster_rcnn_iter_700000.bin", // ROI-Pooling���ش�����
                                       "M22-3-tucker_test.bin",             // �ܲ���
                                       "m27-1_faster_rcnn_iter_110W.bin",   // ROI-Pooling���ش����롣
                                       "1.4T_4sclaes_I90000.bin",           // concat�����reshape
                                       "hik_zhian3_440000_forhms.bin",
                                       "m17.bin",
                                       "m22-1-s-new.bin",
                                       "hik_zhian3_440000_forhms.bin",
                                       "hik_zhian3_ZF_tucker_iter540000.bin",
                                       "ZF_gie_test_origin(1).bin",
                                       "test_gie03.bin",
                                       "test_gie02.bin",
                                       "test_gie.bin",
                                       "iter240000.bin",
                                       "M22-1-s.bin",
                                       "M22-1.bin",
                                       "test_1_7_new.bin",
                                       "test.bin",
                                       "squeezenet5_no_concat2.bin",
                                       "test_fastest.bin",
                                       "hik_zhian_ZF_tuck.bin",
                                       "ZF_tucker_iter_100000_thr_0.8.bin",
                                       "squeezenet5_no_concat3.bin",
                                       "squeezenet5-no-cls-concat.bin",
                                       "squeezenet5_I90000.bin"};

    int             resize_hw[256][2] = {{224, 224},
		                                 {256, 256}, 
		                                 {173, 141}, 
                                         {1080, 1920}, 
                                         {720, 1280}, 
                                         {1080, 1920}, 
                                         {1080, 1080}, 
                                         {960, 1080}, 
                                         {0, 0}
                                        };

    char            img_dir[32][256] = {"/fp16_test_data/bmp",
		                                "/fp16_test_data/bmp_face_1000",
                                        "/fp16_test_data/bmp_1080p",
                                        "/fp16_test_data/bmp_hp",
                                        "/fp16_test_data/bmp_mr",
                                        "/fp16_test_data/ATM/img",
                                        "/fp16_test_data/enroll_bmp/img",
                                        "/fp16_test_data/bmp_mr",
                                        "/fp16_test_data/bmp_hik",
                                        "/fp16_test_data/bmp_mr_1000",
                                        "/fp16_test_data/bmp_hp_1600",
                                        "/fp16_test_data/img_hy",
                                        "/fp16_test_data/bmp_panzuozhou",
                                        "/fp16_test_data/bmp_1920_540"};

    //rcnn_flag       = true;
    rcnn_flag       = false;

#ifdef LINUX
    data_root       = "/wangjl/data_tmp/data/frcnn_data";
#else
    data_root       = "Y:/nfs/data/frcnn_data";
#endif

    img_root        = data_root + img_dir[img_opt];

    OPT_PROFILE_TIME_RESET(77);

    model_name      = models[model_opt];
    rh              = resize_hw[res_opt][0];
    rw              = resize_hw[res_opt][1];

    cout << "model: " << model_name << "  h w: " << rh << " " << rw << endl;

#ifdef CNN_CUDA_OPT
    // GPU�汾֧��char��float����
    test_libcnn<char>(rcnn_flag, data_root, img_root, model_name, rh, rw, batch_size);
#else
    // CPU�汾ֻ֧��float����
    test_libcnn<float>(rcnn_flag, data_root, img_root, model_name, rh, rw, batch_size);
#endif
    //test__multi_libcnn(rcnn_flag, data_root, img_root, rh, rw, batch_size);

#else // TEST_FRCNN

    //rcnn_flag       = false;
    rcnn_flag    = true;

#ifdef LINUX
    data_root       = "/wangjl/data_tmp/data/frcnn_data";
#else
    data_root       = "Y:/nfs/data/frcnn_data";
#endif

    //img_root      = data_root + "/fp16_test_data/ATM/img";
    img_root      = data_root + "/fp16_test_data/bmp_1080p";
    //img_root      = data_root + "/person";

    //img_root        = data_root + "/fp16_test_data/bmp_face";
    //img_root        = data_root + "/fp16_test_data/bmp_hp";

    int             opt;

    opt             =38;
    
    if (opt == 0)
    {
        model_name  = "bvlc_googlenet_without_mean.bin";  // ��lrn, softmax����������ģ���е㲻ͬ
        rh          = rcnn_flag ? 0 : 224;
        rw          = rcnn_flag ? 0 : 224;
    }
    else if (opt == 1)
    {
        model_name  = "test_ysc.bin";
        rh          = rcnn_flag ? 0 : 299;
        rw          = rcnn_flag ? 0 : 299;
    }
    else if (opt == 2)
    {
        model_name  = "ResNet-50.bin";                              // ����������Щ��ReLU��Щ����
        rh          = rcnn_flag ? 0 : 224;
        rw          = rcnn_flag ? 0 : 224;
    }
    else if (opt == 3)
    {
        model_name  = "gender+handcarry_expt31_iter_94000_with_meanfile_scale.bin";
        rh          = rcnn_flag ? 0 : 221;
        rw          = rcnn_flag ? 0 : 111;
    }
    else if(opt == 4)
    {                                                               
        model_name  = "googlenetv1_hhst_expt1_iter_22800.bin";      // ģ����txt�Բ���
        rh          = rcnn_flag ? 0 : 224;                          
        rw          = rcnn_flag ? 0 : 224;                          
    }                                                               
    else if(opt == 5)                                               // ģ����txt�Բ���
    {                                                              
        model_name  = "googlenetv1_scmsc_expt1_iter_13400.bin";    
        rh          = rcnn_flag ? 0 : 224;                         
        rw          = rcnn_flag ? 0 : 224;                         
    }                                                              
    else if (opt == 6)
    {
        model_name  = "vggmx_hhst_t_expt2_iter_36200.bin";
        rh          = rcnn_flag ? 0 : 248;
        rw          = rcnn_flag ? 0 : 248;
    }
    else if (opt == 7)
    {
        model_name  = "vggmx_scmsc_t_expt1_iter_32800.bin";
        rh          = rcnn_flag ? 0 : 248;
        rw          = rcnn_flag ? 0 : 248;
    }
    else if (opt == 8)
    {
        model_name  = "pedestrian_modeling.bin";
        rh          = rcnn_flag ? 0 : 224;
        rw          = rcnn_flag ? 0 : 224;
    }
    else if (opt == 10)                         // channel = 3
    {
        model_name  = "abn_face_cls_loss1.bin";
        rh          = rcnn_flag ? 0 : 224;
        rw          = rcnn_flag ? 0 : 224;
    }
    else if (opt == 11)                         // channel 1
    {
        model_name  = "full_face.bin";
        rh          = rcnn_flag ? 0 : 173;
        rw          = rcnn_flag ? 0 : 141;
    }
    else if (opt == 12)
    {
        model_name  = "eye_patch.bin";
        rh          = rcnn_flag ? 0 : 101;
        rw          = rcnn_flag ? 0 : 101;
    }
    else if (opt == 13)
    {
        model_name  = "avr_6label_v4_sy.bin";
        rh          = rcnn_flag ? 0 : 299;
        rw          = rcnn_flag ? 0 : 299;
    }
    else if (opt == 14)
    {
        model_name  = "v_pf_zg_1226.bin";

        rh          = rcnn_flag ? 0 : 40;
        rw          = rcnn_flag ? 0 : 40;
    }
    else if (opt == 15)
    {
        model_name  = "inception_resnet_v1.4_34816.bin";
        model_name  = "inception_resnet_v1.4_34846.bin";

        rh          = rcnn_flag ? 0 : 256;
        rw          = rcnn_flag ? 0 : 256;
    }
    else if (opt == 16)
    {
        model_name = "feature_model_inception_resnet.bin";   // channel = 3

        rh = rcnn_flag ? 0 : 256;
        rw = rcnn_flag ? 0 : 256;
    }
    else if (opt == 17)
    {
        model_name = "feature_model_resnet.bin";             // channel

        rh = rcnn_flag ? 0 : 237;
        rw = rcnn_flag ? 0 : 205;
    }
    else if (opt == 18)
    {
        model_name = "en_avr_7label.bin";

        rh = rcnn_flag ? 0 : 299;
        rw = rcnn_flag ? 0 : 299;
    }
    else if (opt == 19)
    {
        model_name = "pr_model.bin";

        rh = rcnn_flag ? 0 : 224;
        rw = rcnn_flag ? 0 : 224;
    }
    else if (opt == 20)
    {
        model_name = "en_tsc_2label_pad.bin";

        rh = rcnn_flag ? 0 : 224;
        rw = rcnn_flag ? 0 : 224;
    }
    else if (opt == 21)
    {
        model_name = "VBR_front4080_V6.2.2build170110.bin";

        rh = rcnn_flag ? 0 : 224;
        rw = rcnn_flag ? 0 : 224;
    }
    else if (opt == 22)
    {
        model_name = "googlenet_v1.bin";

        rh = rcnn_flag ? 0 : 224;
        rw = rcnn_flag ? 0 : 224;
    }
    else if (opt == 23)
    {
        model_name = "v_pingfen_hb_zhenggang_1128.bin";

        rh = rcnn_flag ? 0 : 40;
        rw = rcnn_flag ? 0 : 40;
    }
    else if (opt == 24)
    {
        model_name = "inception_v3_expt1_iter_194000nobn.bin";

        rh = rcnn_flag ? 0 : 229;
        rw = rcnn_flag ? 0 : 229;
    }
    else if (opt == 25)
    {
        model_name = "M22-1_classifier_test.bin";
        model_name = "M22-1_classifier_new.bin";
        model_name = "M22-1_classifier_new(1).bin";
        model_name = "M22-1_classifier_new(2).bin";
        
        rh = rcnn_flag ? 0 : 64;
        rw = rcnn_flag ? 0 : 64;
    }
    else if (opt == 26)
    {
        model_name = "feature_model_resnet_iter_21.bin";
        rh = rcnn_flag ? 0 : 203;
        rw = rcnn_flag ? 0 : 171;
    }
    else if (opt == 27)
    {
        model_name = "feature_model_inception_resnet.bin";
        rh = rcnn_flag ? 0 : 256;
        rw = rcnn_flag ? 0 : 256;
    }
    else if (opt == 28)
    {
        model_name = "cnn_cls_model.bin";
        rh = rcnn_flag ? 0 : 112;
        rw = rcnn_flag ? 0 : 112;
    }
	else if(opt == 29)
	{
		model_name = "m33_test.bin";
		rh = rcnn_flag ? 0 : 600;
		rw = rcnn_flag ? 0 : 800;
	}
	else if(opt == 30)
	{
		model_name = "m46-5_test.bin";
		rh = rcnn_flag ? 0 : 600;
		rw = rcnn_flag ? 0 : 800;
	}
	else if(opt == 31)
	{
		model_name = "m49_test_4000_100.bin";
		rh = rcnn_flag ? 0 : 600;
		rw = rcnn_flag ? 0 : 800;
	}
    else if(opt == 32)
	{
		model_name = "detect_model.bin";
		rh = rcnn_flag ? 0 : 238;
		rw = rcnn_flag ? 0 : 293;
	}
	else if(opt == 33)
	{
		model_name = "v_pf_zg_1226.bin";
		rh = rcnn_flag ? 0 : 40;
		rw = rcnn_flag ? 0 : 40;
	}    
	else if(opt == 34)
	{
		model_name = "vggSBR_no_model_name.bin";
		rh = rcnn_flag ? 0 : 1080;
		rw = rcnn_flag ? 0 : 1920;
	}
	else if(opt == 35)
	{
		model_name = "bvlc_googlenet_without_mean.bin";
		rh = rcnn_flag ? 0 : 224;
		rw = rcnn_flag ? 0 : 224;
	}
	else if(opt == 36)
	{
		model_name = "vggmx_hhst_t_expt2_iter_36200.bin";
		rh = rcnn_flag ? 0 : 248;
		rw = rcnn_flag ? 0 : 248;
	}
		else if(opt == 37)
	{
		model_name = "cnn_dir_shd.bin";
		rh = rcnn_flag ? 0 : 224;
		rw = rcnn_flag ? 0 : 224;
	}
				else if(opt == 38)
	{
		model_name = "SBR_6W5_IN_15W_conf65.bin";
		rh = rcnn_flag ? 0 : 1080;
		rw = rcnn_flag ? 0 : 1920;
	}
 printf("CCC\n\n");
#ifdef CNN_CUDA_OPT
    // GPU�汾֧��float��char����
    test_libcnn<char>(rcnn_flag, data_root, img_root, model_name, rh, rw, batch_size);
#else
    // CPU�汾ֻ֧��float����
    test_libcnn<float>(rcnn_flag, data_root, img_root, model_name, rh, rw, batch_size);
#endif

#endif // TEST_FRCNN
}
#endif

#define CUDA_HANDLE_SIZE 100
#ifdef CNN_CUDA_OPT
void test_libcuda()
{
    void *handle[CUDA_HANDLE_SIZE];
    HRESULT hr;

    VCA_MEM_TAB_V2  mem_tab;
    hr = HIKCUDA_GetMemSize(&mem_tab);
    CHECK_ERR(hr != HIK_VCA_LIB_S_OK, "HIKCUDA_GetMemSize");

    mem_tab.base = alloc_memory(mem_tab.size, mem_tab.alignment, false);

    printf("%d\n", mem_tab.size);

    while(1)
    {
        for (int i = 0; i < CUDA_HANDLE_SIZE; i++)
        {
            hr = HIKCUDA_Create(&mem_tab, &handle[i]);
            if (hr != HIK_VCA_LIB_S_OK)
            {
                printf("HIKCUDA_Create failed\n");
            }
            hr = HIKCUDA_Release(handle[i]);
            if (hr != HIK_VCA_LIB_S_OK)
            {
                printf("HIKCUDA_Release failed\n");
            }
        }
    }
}
#endif


#if 0
static void test_libfrcnn(int ih, int iw, int batch_size, const char *model_name_str, bool rcnn_flag)
{
    string          data_root;
    string          img_root;
    string          model_name;

    int             rh, rw;

#ifdef LINUX
    //data_root = "./data";
    data_root = "/tmp_data/data/frcnn_data";
#else
    data_root = "Y:/nfs/data/frcnn_data";
#endif
    img_root    = data_root + "/fp16_test_data/bmp_1080p";
    model_name  = model_name_str;

    rh = ih;
    rw = iw;

    cout << "model: " << model_name << "  h w: " << rh << " " << rw << " batch_size: " << batch_size << endl;

    test_libcnn<char>(rcnn_flag, data_root, img_root, model_name, rh, rw, batch_size);
}

int main(int argc, char *argv[])
{
    int     batch_size;
    char    *model_str;
    bool    rcnn_flag;
    int     height;
    int     width;

    if (argc == 6)
    {
        model_str   = argv[1];
        height      = atoi(argv[2]);
        width       = atoi(argv[3]);
        batch_size  = atoi(argv[4]);
        rcnn_flag   = (atoi(argv[5]) == 1) ? true : false;
    }
    else
    {
        cout << "usage error: model_name height width batch_size rcnn_flag" << endl;
        cout << "rcnn_flag->1 test frcnn for detection, rcnn_flag->0 test cnn for classification" << endl;
    }

    test_libfrcnn(height, width, batch_size, model_str, rcnn_flag);

    return 0;
}

#else

#if 0
void zip_unzip_test(int n, int c, int h, int w, int pad_h, int pad_w)
{
    HRESULT     hr;
    int         i;
  
    int num = n * c * h * w;

    float threshold = 0.01;

    // gen data

    float *data_cpu = (float *)malloc(num * sizeof(float));
    float *data_gpu;

    for (i = 0; i < num; i++)
    {
        data_cpu[i] = rand() % 10 * 0.7892;
    }
    cudaMalloc(&data_gpu, num * sizeof(float));

    cudaMemcpy(data_gpu, data_cpu, num * sizeof(float), cudaMemcpyHostToDevice);

    void *data_gpu_half;
    cudaMalloc(&data_gpu_half, num * sizeof(short));

    hr = cnn_float2half(data_gpu, (cnn_half*)data_gpu_half, num);
    assert(hr == HIK_VCA_LIB_S_OK);

    void *data_gpu_half_pad;
    cudaMalloc(&data_gpu_half_pad, n * c * (h + 2 * pad_h) * (w + 2 * pad_w) * sizeof(short));

    hr = CNN_zip_and_pad(data_gpu_half, data_gpu_half_pad, n, c, h, w, pad_h, pad_w);
    assert(hr == HIK_VCA_LIB_S_OK);

    hr = CNN_unzip_and_unpad(data_gpu_half_pad, data_gpu_half, n, c, h, w, pad_h, pad_w);
    assert(hr == HIK_VCA_LIB_S_OK);

    float *data_gpu_result;
    cudaMalloc(&data_gpu_result, num * sizeof(float));

    hr = cnn_half2float((cnn_half*)data_gpu_half, data_gpu_result, num);
    assert(hr == HIK_VCA_LIB_S_OK);

    float *data_result = (float*)malloc(num * sizeof(float));

    cudaMemcpy(data_result, data_gpu_result, num * sizeof(float), cudaMemcpyDeviceToHost);

    for (i = 0; i < num; i++)
    {
        float diff = ((data_result[i] - data_cpu[i]) > 0.0f) ? (data_result[i] - data_cpu[i]) : 0 - (data_result[i] - data_cpu[i]);
        if (diff > threshold)
        {
            printf("%f %f\n", data_result[i], data_cpu[i]);
        }
    }

}

void zip_unzip_test()
{
    zip_unzip_test(2, 24, 13, 13, 2, 2);
    zip_unzip_test(2, 2, 156, 13, 2, 2);
    zip_unzip_test(2, 48, 13, 13, 2, 2);
    zip_unzip_test(2, 256, 13, 13, 2, 2);
    zip_unzip_test(200, 384, 6, 6, 2, 2);
    zip_unzip_test(200, 13824, 1, 1, 2, 2);
    zip_unzip_test(200, 8, 1, 1, 2, 2);
    zip_unzip_test(200, 2, 1, 1, 2, 2);
}

#endif

#if 0
void cudaMemcpyProfile()
{
    void *data01, *data02;
    int size =  100 * 1024 * 1024;

    cudaMalloc(&data01, size);
    cudaMalloc(&data02, size);

    for (int n = 0; n < 1000; n++)
    {
        OPT_PROFILE_TIME_BY_EVENT_START(555);
        cudaMemcpy(data01, data02, size, cudaMemcpyDeviceToDevice);
        OPT_PROFILE_TIME_BY_EVENT_STOP(555, "copy", 1, 1);
    }

    exit(0);
}
#endif

int main(int argc, char *argv[])
{
    int     model_opt   = 1;
    int     res_opt     = 1;
    int     img_opt     = 1;
    int     batch_size  = 6;

    if (argc == 2)
    {
        batch_size = atoi(argv[1]);
    }

    test_lib(model_opt, res_opt, img_opt, batch_size);
    return 0;
}

#endif

