#include <cuda_runtime.h>
#include <stdlib.h>
#include <cudnn.h>
#include <cublas.h>
#include "vca_error_code.h"
#include "hka_defs.h"
#include "hik_cuda_lib.h"


#define         HIKCUDA_CUDA_ERROR_CODE_BASE        (0x86000000)                                                        //CUDA��������ʼ��ַ
#define         HIKCUDA_CUDART_ERROR_CODE_LENGTH    (10000)                                                             //CUDA����ʱ��������󳤶�
#define         HIKCUDA_CUBLAS_ERROR_CODE_BASE      (HIKCUDA_CUDA_ERROR_CODE_BASE + HIKCUDA_CUDART_ERROR_CODE_LENGTH)   //CUBLAS��������ʼ��ַ
#define         HIKCUDA_CUBLAS_ERROR_CODE_LENGTH    (1000)                                                              //CUBLAS��������󳤶�
#define         HIKCUDA_CUDNN_ERROR_CODE_BASE       (HIKCUDA_CUBLAS_ERROR_CODE_BASE + HIKCUDA_CUBLAS_ERROR_CODE_LENGTH) //CUDNN��������ʼ��ַ


//����У�鷵��״̬��
#define HIKCUDA_CHECK_ERROR(sts, str, ret)                                      \
{                                                                               \
if (sts)                                                                        \
    {                                                                           \
    printf("[%s %d %s] \n", __FILE__, __LINE__, (str));                         \
    return (ret);                                                               \
    }                                                                           \
}

//hik cudnn handle
typedef struct _HIKCUDNN_HANDLE_
{
    void                                *cudnn_handle;                  //cudnn handle             

    void                                *tensorFormat;                  //tensor format   

    void                                *srcTensorDesc;                 //src    tensor descriptor
    void                                *dstTensorDesc;                 //dst    tensor descriptor
    void                                *biasTensorDesc;                //bias   tensor descriptor

    void                                *filterDesc;                    //filter       descriptor
    void                                *lrn_desc;                      //lrn          descriptor
    void                                *convDesc;                      //convolution  descriptor
    void                                *poolingDesc;                   //pooling      descriptor

    char                                reserved[64];
}HIKCUDNN_HANDLE;


//hik cublas handle
typedef struct _HIK_CUBLAS_HANDLE_
{
    void                               *cublas_handle;                 //cublas handle

    char                                reserved[64];
}HIKCUBLAS_HANDLE;

//hik cuda handle
typedef struct _HIKCUDA_HANDLE_
{
    HIKCUDNN_HANDLE                    cudnn_handle;                   //cnn cudnn handle
    HIKCUBLAS_HANDLE                   cublas_handle;                  //cnn cublas handle
}HIKCUDA_HANDLE;

// ����ṹ��
typedef struct
{
    void                                *start;                       //������ʼλ��
    void                                *end;                         //�������λ��
    void                                *cur_pos;                     //���������ʼλ��
} HIKCUDA_BUF;


/***************************************************************************************************
* ��  ��: ����CUDA�ڴ棬�ӿ�ͬ��׼C malloc
* ��  ��: 
*         size            - I   ������ڴ��С
* ����ֵ: ��
***************************************************************************************************/
void * HIKCUDA_Malloc(size_t size)
{
    void            *data;
    return          (cudaMalloc(&data, size) == cudaSuccess) ? data : NULL;
}


/***************************************************************************************************
* ��  ��: �ͷ�CUDA�ڴ�,�ӿ�ͬ��׼C free
* ��  ��:
*         data            - I   �ڴ��ַ
* ����ֵ: ��
***************************************************************************************************/
void HIKCUDA_Free(void *data)
{
    //���ǵ���׼C freeû�з��ش����룬HIKCUDA_FreeҲ�����أ�����cudaFree�п��ܷ��ش����롣
    cudaFree(data);
}


/***************************************************************************************************
* ��  ��: ��cudnn�Ĵ�����ת����VCA������
* ��  ��:
*         cudnn_sts           -I         cudnn״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT HIKCUDA_convert_cudnn_error_code(cudnnStatus_t  cudnn_sts)
{
    return HIKCUDA_CUDNN_ERROR_CODE_BASE + (int)cudnn_sts;
}

/***************************************************************************************************
* ��  ��: ��cublas�Ĵ�����ת����VCA������
* ��  ��:
*         cublas_sts           -I         cublas״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT HIKCUDA_convert_cublas_error_code(cublasStatus_t  cublas_sts)
{
    return HIKCUDA_CUBLAS_ERROR_CODE_BASE + (int)cublas_sts;
}


/***************************************************************************************************
* ��  ��: ��ȡ���ܿ�������ڴ��С
* ��  ��:
*         mem_tab                - O �ڴ������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT HIKCUDA_GetMemSize(VCA_MEM_TAB_V2  mem_tab[HIK_CUDA_MEM_TAB_NUM])
{
    HIKCUDA_CHECK_ERROR((NULL == mem_tab), "mem_tab is NULL", HIK_VCA_LIB_E_PTR_NULL);

    mem_tab[0].size       = HKA_SIZE_ALIGN_128(sizeof(HIKCUDA_HANDLE));
    mem_tab[0].alignment  = VCA_MEM_ALIGN_128BYTE;
    mem_tab[0].base       = NULL;

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �ڻ���ivs_buf�з���һ���СΪsize, align���ֽڶ�����ڴ��
* ��  ��: ivs_buf                - I/O ��������ṹ��
*         size                   - I   �����ڴ�Ĵ�С
*         alignment              - I   �ڴ�Ķ��뷽ʽ
*         clean                  - I   �Ƿ�����
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
void *HIKCUDA_alloc_buffer(HIKCUDA_BUF          *ivs_buf,
                           unsigned int         size,
                           int                  align,
                           unsigned int         clean)
{
    void        *buf;
    unsigned int free_size;

    HIKCUDA_CHECK_ERROR(0 == align, "align is 0",                                  HIK_VCA_LIB_KEY_PARAM_ERR);
    HIKCUDA_CHECK_ERROR(0 != ((align - 1) & align), "0 != ((align - 1) & align",   HIK_VCA_LIB_KEY_PARAM_ERR);

    /* �����п����ڴ���ʼλ�� */
    buf = (void *)(((size_t)ivs_buf->cur_pos + (align - 1)) & (~(align - 1)));

    /* ���㻺���еĿ���ռ��С */
    free_size = (char *)ivs_buf->end - (char *)buf;

    /*�ռ䲻�������ؿ�ָ��*/
    if (free_size < size)
    {
        buf = NULL;
    }
    else
    {
        /* ��շ����ڴ� */
        if (clean)
        {
            memset(buf, 0, size);
        }

        /* ���¿���ָ��λ�� */
        ivs_buf->cur_pos = (void *)((char *)buf + size);
    }

    return buf;
}

/***************************************************************************************************
* ��  ��: ����cudnn handle
* ��  ��:
*         cnn_cudnn_handle           -I         cuda handle
* ����ֵ: ������
***************************************************************************************************/
static HRESULT CUDA_release_cudnn_handle(HIKCUDNN_HANDLE *hik_cudnn_handle)
{
    cudnnStatus_t       sts;
    cudnnStatus_t       sts_ret = CUDNN_STATUS_SUCCESS;

    if (hik_cudnn_handle->srcTensorDesc)
    {
        sts         = cudnnDestroyTensorDescriptor(hik_cudnn_handle->srcTensorDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        //�������Դ�ͷ�ʧ�ܣ���Ҫ�����ͷ�������Դ���˴����ܷ���
        hik_cudnn_handle->srcTensorDesc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->srcTensorDesc;
    }
   
    if (hik_cudnn_handle->dstTensorDesc)
    {
        sts         = cudnnDestroyTensorDescriptor(hik_cudnn_handle->dstTensorDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->dstTensorDesc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->dstTensorDesc;
    }
    
    if (hik_cudnn_handle->biasTensorDesc)
    {
        sts         = cudnnDestroyTensorDescriptor(hik_cudnn_handle->biasTensorDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->biasTensorDesc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->biasTensorDesc;
    }
   
    if (hik_cudnn_handle->filterDesc)
    {
        sts         = cudnnDestroyFilterDescriptor(hik_cudnn_handle->filterDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->filterDesc = (sts == CUDNN_STATUS_SUCCESS)  ? 0 : hik_cudnn_handle->filterDesc;
    }
    
    if (hik_cudnn_handle->convDesc)
    {
        sts         = cudnnDestroyConvolutionDescriptor(hik_cudnn_handle->convDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->convDesc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->convDesc;
    }
    
    if (hik_cudnn_handle->poolingDesc)
    {
        sts         = cudnnDestroyPoolingDescriptor(hik_cudnn_handle->poolingDesc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->poolingDesc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->poolingDesc;
    }
    
    if (hik_cudnn_handle->lrn_desc)
    {
#if CUDNN_VERSION >= 4000
        sts         = cudnnDestroyLRNDescriptor(hik_cudnn_handle->lrn_desc);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->lrn_desc = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->lrn_desc;
#endif
    }
   
    if (hik_cudnn_handle->cudnn_handle)
    {
        sts         = cudnnDestroy(hik_cudnn_handle->cudnn_handle);
        sts_ret     = (sts == CUDNN_STATUS_SUCCESS) ? sts_ret : sts;
        hik_cudnn_handle->cudnn_handle = (sts == CUDNN_STATUS_SUCCESS) ? 0 : hik_cudnn_handle->cudnn_handle;
    }

    return (sts_ret == CUDNN_STATUS_SUCCESS) ? HIK_VCA_LIB_S_OK : HIKCUDA_convert_cudnn_error_code(sts_ret);
}


/***************************************************************************************************
* ��  ��: ����cudnn handle
* ��  ��:
*         hik_cudnn_handle           -I         hik cudnn handle
* ����ֵ: ������
***************************************************************************************************/
static HRESULT CUDA_create_cudnn_handle(HIKCUDNN_HANDLE *hik_cudnn_handle)
{
    cudnnStatus_t           cudnn_sts;

    cudnn_sts = cudnnCreate(&hik_cudnn_handle->cudnn_handle);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->cudnn_handle = 0;
        printf("cudnnCreate failed %s %d\n", __FILE__, __LINE__);
        //�������Դ����ʧ�ܣ���ֱ�ӷ��أ���������������Դ
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreateTensorDescriptor(&hik_cudnn_handle->srcTensorDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->srcTensorDesc = 0;
        printf("cudnnCreateTensorDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreateTensorDescriptor(&hik_cudnn_handle->dstTensorDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->dstTensorDesc = 0;
        printf("cudnnCreateTensorDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreateTensorDescriptor(&hik_cudnn_handle->biasTensorDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->biasTensorDesc = 0;
        printf("cudnnCreateTensorDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreateFilterDescriptor(&hik_cudnn_handle->filterDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->filterDesc = 0;
        printf("cudnnCreateFilterDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreateConvolutionDescriptor(&hik_cudnn_handle->convDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->convDesc = 0;
        printf("cudnnCreateConvolutionDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

    cudnn_sts = cudnnCreatePoolingDescriptor(&hik_cudnn_handle->poolingDesc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->poolingDesc = 0;
        printf("cudnnCreatePoolingDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }

#if CUDNN_VERSION >= 4000
    cudnn_sts = cudnnCreateLRNDescriptor(&hik_cudnn_handle->lrn_desc);
    if (cudnn_sts != CUDNN_STATUS_SUCCESS)
    {
        hik_cudnn_handle->lrn_desc = 0;
        printf("cudnnCreateLRNDescriptor failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cudnn_error_code(cudnn_sts);
    }
#else
    hik_cudnn_handle->lrn_desc = 0;
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����cublas handle
* ��  ��:
*         cnn_cublas_handle          -I   cublas handle
* ����ֵ: ������
***************************************************************************************************/
static HRESULT CUDA_create_cublas_handle(HIKCUBLAS_HANDLE *hik_cublas_handle)
{
    cublasStatus_t cublas_sts;

    cublas_sts = cublasCreate_v2(&hik_cublas_handle->cublas_handle);
    if (cublas_sts != CUBLAS_STATUS_SUCCESS)
    {
        hik_cublas_handle->cublas_handle = 0;
        printf("cublasCreate_v2 failed %s %d\n", __FILE__, __LINE__);
        return HIKCUDA_convert_cublas_error_code(cublas_sts);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����cublas handle
* ��  ��:
*         cnn_cublas_handle          -I   cublas handle
* ����ֵ: ������
***************************************************************************************************/
static HRESULT CUDA_release_cublas_handle(HIKCUBLAS_HANDLE *hik_cublas_handle)
{
    cublasStatus_t  sts;

    if (hik_cublas_handle->cublas_handle)
    {
        sts = cublasDestroy_v2(hik_cublas_handle->cublas_handle);
        HIKCUDA_CHECK_ERROR(sts != CUBLAS_STATUS_SUCCESS, "cublasDestroy_v2 failed", HIKCUDA_convert_cublas_error_code(sts));
        hik_cublas_handle->cublas_handle = 0;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����CUDA Handle
* ��  ��:
*         mem_tab                - I �ڴ������
*         handle                 - O ���ܿ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT HIKCUDA_Create(VCA_MEM_TAB_V2  mem_tab[HIK_CUDA_MEM_TAB_NUM], void **handle)
{
    HIKCUDA_HANDLE  *cuda_handle;
    HIKCUDA_BUF     buf;
    HRESULT         hr;
    int             is_ok           = 1;

    HIKCUDA_CHECK_ERROR((NULL == mem_tab[0].base),  "mem_tab[0].base is NULL", HIK_VCA_LIB_E_PTR_NULL);
    HIKCUDA_CHECK_ERROR((NULL == handle),           "handle is NULL",          HIK_VCA_LIB_E_PTR_NULL);

#ifdef _HIK_DECRYPT
    // ����������ɫ������ܹ�
    HIK_GetKeyResult();
#endif

    buf.start       = mem_tab[0].base;
    buf.cur_pos     = mem_tab[0].base;
    buf.end         = (void*)((size_t)buf.cur_pos + mem_tab[0].size - 1);;

    cuda_handle = (HIKCUDA_HANDLE*)HIKCUDA_alloc_buffer(&buf, sizeof(HIKCUDA_HANDLE), mem_tab[0].alignment, 1);
    HIKCUDA_CHECK_ERROR(NULL == cuda_handle, "cuda_handle is NULL", HIK_VCA_LIB_E_MEM_OUT);

    hr              = CUDA_create_cudnn_handle(&cuda_handle->cudnn_handle);

    if (hr != HIK_VCA_LIB_S_OK)
    {
        CUDA_release_cudnn_handle(&cuda_handle->cudnn_handle);
    }

    hr              |= CUDA_create_cublas_handle(&cuda_handle->cublas_handle);

    if (hr != HIK_VCA_LIB_S_OK)
    {
        CUDA_release_cublas_handle(&cuda_handle->cublas_handle);
    }

    *handle = cuda_handle;

    return hr;
}

/***************************************************************************************************
* ��  ��: ����cuda handle
* ��  ��:
*         cuda_handle            -I/O cuda handle
* ����ֵ: ������
***************************************************************************************************/
HRESULT HIKCUDA_Release(void          *handle)
{
    HRESULT     hr;
    HIKCUDA_HANDLE  *hik_cuda_handle = handle;

    HIKCUDA_CHECK_ERROR((NULL == hik_cuda_handle), "hik_cuda_handle is NULL", HIK_VCA_LIB_E_PTR_NULL);

    hr  = CUDA_release_cublas_handle(&hik_cuda_handle->cublas_handle);
    hr |= CUDA_release_cudnn_handle(&hik_cuda_handle->cudnn_handle);

    HIKCUDA_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_release_cudnn(cublas)_handle failed", hr);

    return HIK_VCA_LIB_S_OK;
}