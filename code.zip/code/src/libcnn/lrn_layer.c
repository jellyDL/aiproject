/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: lrn_layer.c
* �ļ���ʶ: LRN_LAYER_C
* ժ    Ҫ: lrn��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-02
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <float.h>
#include <math.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#include "cnn_basic_kernel.h"
#include "lrn_layer_cuda.h"
#endif // CNN_CUDA_OPT
#include <string.h>
#include <stdio.h>
#include "lrn_layer.h"

#ifdef LINUX
#define STRNCMP strncasecmp
#else
#define STRNCMP strnicmp
#endif

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_LRN_Reshape(void       *handle,
                        LAYER_DATA *ld)
{
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);

    ld->output_blobs[0].ndims    = ld->input_blobs[0]->ndims;
    ld->output_blobs[0].type     = cnn_get_blob_type();
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].shape[1] = ld->input_blobs[0]->shape[1];
    ld->output_blobs[0].shape[2] = ld->input_blobs[0]->shape[2];
    ld->output_blobs[0].shape[3] = ld->input_blobs[0]->shape[3];

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         lrn_layer              - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_LRN_init_model(const char *hyperparams,
                     const char *param_blobs,
                     LAYER_MODEL *ld,
                     LRN_MODEL  *lrn_model)
{
    int         r;
    HRESULT     hr;
    const char  norm_region[] = "norm_region";
    const char  local_size[]  = "local_size";
    const char  alpha[]       = "alpha";
    const char  beta[]        = "beta";
    char        lrn_type[256] = { 0 };
    const char *ptr;

    HKA_CHECK_ERROR(ld->input_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    lrn_model->type = CHANNEL_NRM;
    if (ptr = strstr(hyperparams, norm_region))
    {
        r = sscanf(ptr + strlen(norm_region) + 1, "%s", lrn_type);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        if (STRNCMP(lrn_type, "ACROSS_CHANNELS", strlen("ACROSS_CHANNELS")) == 0)
        {
            lrn_model->type = CHANNEL_NRM;
        }
        else if (STRNCMP(lrn_type, "WITHIN_CHANNEL", strlen("WITHIN_CHANNEL")) == 0)
        {
            // lrn_layer->type = SPATIAL_NRM;
            return HIK_VCA_CNN_MODEL_ERROR;
        }
        else
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }
    }

    lrn_model->size = 5;
    if (ptr = strstr(hyperparams, local_size))
    {
        r = sscanf(ptr + strlen(local_size) + 1, "%d", &lrn_model->size);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        if ((lrn_model->size % 2 != 1) || (lrn_model->size <= 0))
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }
    }

    lrn_model->alpha = 1.0;
    if (ptr = strstr(hyperparams, alpha))
    {
        r = sscanf(ptr + strlen(alpha) + 1, "%lf", &lrn_model->alpha);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    lrn_model->beta = 0.75;
    if (ptr = strstr(hyperparams, beta))
    {
        r = sscanf(ptr + strlen(beta) + 1, "%lf", &lrn_model->beta);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_LRN_Create(LAYER_DATA *ld,
                       CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                       void      **handle)
{
    HRESULT    hr;
    LRN_LAYER *lrn_layer;

    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];
    CNN_BUF                 *cpu_data_buf = &mem_buf[1];
    CNN_BUF                 *gpu_data_buf = &mem_buf[2];

#ifndef CNN_CUDA_OPT
    gpu_data_buf    = NULL;
#else
    cpu_data_buf    = NULL;
#endif

    lrn_layer = (LRN_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                              CNN_SIZE_ALIGN(sizeof(LRN_LAYER)),
                                              CNN_MEM_ALIGN_SIZE,
                                              1);
    HKA_CHECK_MEMOUT(lrn_layer);

    lrn_layer->model = ld->layer_model->model_handle;

    hr = CNN_LRN_Reshape(NULL, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

     hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                                cpu_data_buf,
                                gpu_data_buf,
                                CNN_MEM_ALIGN_SIZE,
                                CNN_CUDA_MEM_ALIGNMENT,
                                NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    *handle = lrn_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_LRN_GetMemsize(LAYER_DATA *ld,
                           VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT   hr;
    LRN_LAYER lrn_layer;

    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2     *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2     *gpu_data_tab   = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_data_tab                    = NULL; 
#else
    cpu_data_tab                    = NULL; 
#endif

    lrn_layer.model = ld->layer_model->model_handle;
    
    hr = CNN_LRN_Reshape(NULL, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(LRN_LAYER)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(gpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_LRN_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    HRESULT    hr;
    LRN_MODEL *lrn_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    lrn_model = (LRN_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(LRN_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(lrn_model);

    hr = CNN_LRN_init_model(hyperparams, param_blobs, ld, lrn_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
 
    *handle = lrn_model;

    return HIK_VCA_LIB_S_OK;
}


HRESULT CNN_LRN_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT   hr;
    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    
    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(LRN_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: dst[i] += src[i] * src[i]
* ��  ��: src                    - I   Դ
*         dst                    - I/O Ŀ��
*         n                      - I   ���ݸ���
* ����ֵ: ��
***************************************************************************************************/
void CNN_LRN_add_sqr(const float *src,
                     float       *dst,
                     int          n)
{
    int i;

    for (i = 0; i < n; i++)
    {
        dst[i] += src[i] * src[i];
    }
}

/***************************************************************************************************
* ��  ��: dst[i] -= src[i] * src[i]
* ��  ��: src                    - I   Դ
*         dst                    - I/O Ŀ��
*         n                      - I   ���ݸ���
* ����ֵ: ��
***************************************************************************************************/
void CNN_LRN_sub_sqr(const float *src,
                     float       *dst,
                     int          n)
{
    int i;

    for (i = 0; i < n; i++)
    {
        dst[i] -= src[i] * src[i];
    }
}

/***************************************************************************************************
* ��  ��: ִ�й�һ��
* ��  ��: src                    - I   Դ
*         dst                    - I/O ��һ��������λ��
*         accum_sqr              - I   ƽ�����ۻ�
*         n                      - I   ���ݸ���
*         alpha_over_size        - I   alpha/size
*         beta                   - I   ����beta
* ����ֵ: ��
***************************************************************************************************/
void CNN_LRN_norm(const float *src,
                  float       *dst,
                  const float *accum_sqr,
                  int          n,
                  float        alpha_over_size,
                  float        beta)
{
    int i;

    for (i = 0; i < n; i++)
    {
        dst[i] = src[i] * powf(accum_sqr[i] * alpha_over_size + 1.0f, -beta);
    }
}

/***************************************************************************************************
* ��  ��: ��ͨ�����й�һ��
* ��  ��: srcBlob                - I ����blob
*         dstBlob                - O ���blob
*         lrn_layer              - I lrn layer�ľ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_LRN_channel_noramlization(CNN_BLOB  *srcBlob,
                                   CNN_BLOB  *dstBlob,
                                   LRN_LAYER *lrn_layer)
{
    int    num      = srcBlob->shape[0];
    int    channels = srcBlob->shape[1];
    int    ksize    = (lrn_layer->model->size - 1) / 2;
    float *accum_sqr, *src_ptr, *dst_ptr;
    int    plane_size;
    int    cn, n;
    int    tmp;
    float  alpha_over_size = lrn_layer->model->alpha / lrn_layer->model->size;

    plane_size = dstBlob->shape[2] * dstBlob->shape[3];

    for (n = 0; n < num; n++)
    {
        accum_sqr = CNN_BLOB_GetPtr(dstBlob, n, channels - 1, 0, 0);
        memset(accum_sqr, 0, plane_size * data_type_size[dstBlob->type]);

        tmp = HKA_MIN(ksize, channels);
        for (cn = 0; cn < tmp; cn++)
        {
            src_ptr = CNN_BLOB_GetPtr(srcBlob, n, cn, 0, 0);
            CNN_LRN_add_sqr(src_ptr, accum_sqr, plane_size);
        }

        for (cn = 0; cn < channels; cn++)
        {
            if (cn + ksize < channels)
            {
                src_ptr = CNN_BLOB_GetPtr(srcBlob, n, cn + ksize, 0, 0);
                CNN_LRN_add_sqr(src_ptr, accum_sqr, plane_size);
            }

            if (cn - ksize - 1 >= 0)
            {
                src_ptr = CNN_BLOB_GetPtr(srcBlob, n, cn - ksize - 1, 0, 0);
                CNN_LRN_sub_sqr(src_ptr, accum_sqr, plane_size);
            }

            src_ptr = CNN_BLOB_GetPtr(srcBlob, n, cn, 0, 0);
            dst_ptr = CNN_BLOB_GetPtr(dstBlob, n, cn, 0, 0);
            CNN_LRN_norm(src_ptr, dst_ptr, accum_sqr, plane_size, alpha_over_size, lrn_layer->model->beta);
        }
    }
}

/*
void CNN_LRN_spatial_normalization(BLOB      *srcBlob,
                                   BLOB      *dstBlob,
                                   LRN_LAYER *lrn_layer)
{
    int num      = srcBlob->shape[0];
    int channels = srcBlob->shape[1];

    for (int n = 0; n < num; n++)
    {
        for (int cn = 0; cn < channels; cn++)
        {
            Mat    src      = srcBlob.getPlane(n, cn);
            Mat    dst      = dstBlob.getPlane(n, cn);
            uchar *dataDst0 = dst.data;

            cv::pow(srcBlob.getPlane(n, cn), 2, dst);
            // TODO: check border type
            cv::boxFilter(dst, dst, dst.depth(), cv::Size(size, size), cv::Point(-1, -1), false, cv::BORDER_CONSTANT);
            dst.convertTo(dst, dst.type(), alpha / (size * size), 1);
            cv::pow(dst, beta, dst);
            cv::divide(src, dst, dst);

            CV_Assert(dataDst0 == dst.data); // debug
        }
    }
}*/

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_LRN_Forward(void       *handle,
                        LAYER_DATA *ld)
{
    LRN_LAYER *lrn_layer = (LRN_LAYER *)handle;

    CNN_BLOB *src = ld->input_blobs[0];
    CNN_BLOB *dst = &ld->output_blobs[0];
    switch (lrn_layer->model->type)
    {
    case CHANNEL_NRM:
        {
            CNN_LRN_channel_noramlization(src, dst, lrn_layer);
            break;
        }

    case SPATIAL_NRM:
        {
            // CNN_LRN_spatial_normalization(src, dst, lrn_layer);
            break;
        }

    default:
        {
            break;
        }
    }
    return HIK_VCA_LIB_S_OK;
}


#ifdef CNN_CUDA_OPT

#if CUDNN_VERSION >= 4000
/***************************************************************************************************
* ��  ��: lrnǰ�򴫲�(cudnn��)
* ��  ��: 
*         cnn_cudnn_handle          - I   cudnn handle
*         in_data                   - I   ����
*         out_data                  - O   ���
*         type                      - I   LRN����
*         in_n                      - I   ����n
*         in_c                      - I   ����c
*         in_h                      - I   ����h
*         in_w                      - I   ����w
*         out_n                     - I   ���n
*         out_c                     - I   ���c
*         out_h                     - I   ���h
*         out_w                     - I   ���w
*         lrnN                      - I   LRN���� N
*         lrnAlpha                  - I   LRN���� ALPHA
*         lrnbeta                   - I   LRN���� BETA
*         lrnk                      - I   LRN���� k
* ����ֵ: ������
***************************************************************************************************/
static HRESULT cnn_lrn_forward_cudnn(CNN_CUDNN_HANDLE          *cnn_cudnn_handle,
                                     float_t                   *in_data,
                                     float_t                   *out_data,
                                     BLOB_DATA_TYPE            type,
                                     int                       in_n,
                                     int                       in_c,
                                     int                       in_h,
                                     int                       in_w,
                                     int                       out_n,
                                     int                       out_c,
                                     int                       out_h,
                                     int                       out_w,
                                     int                       lrnN,
                                     double                    lrnAlpha,
                                     double                    lrnbeta,
                                     double                    lrnk)
{
    cudnnHandle_t                   cudnn_handle       = cnn_cudnn_handle->cudnn_handle;
    cudnnTensorDescriptor_t         src_tensor_desc    = cnn_cudnn_handle->srcTensorDesc;
    cudnnTensorDescriptor_t         dst_tensor_desc    = cnn_cudnn_handle->dstTensorDesc;
    cudnnLRNDescriptor_t            lrn_desc           = cnn_cudnn_handle->lrn_desc;

    cudnnTensorFormat_t             tensor_format      = CUDNN_TENSOR_NCHW;                   //Ŀǰֻ֧�������ڴ����з�ʽ
    cudnnDataType_t                 data_type          = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;                    

    cudnnStatus_t                   cudnn_sts;
    float                           alpha              = 1.0f;
    float                           beta               = 0.0f;

    cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc, tensor_format, data_type, in_n, in_c, in_h, in_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
    cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc, tensor_format, data_type, out_n, out_c, out_h, out_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
    cudnn_sts = cudnnSetLRNDescriptor(lrn_desc, lrnN, lrnAlpha, lrnbeta, lrnk);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetLRNDescriptor failed",      CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnLRNCrossChannelForward(cudnn_handle,
                                            lrn_desc,
                                            CUDNN_LRN_CROSS_CHANNEL_DIM1,
                                            &alpha,
                                            src_tensor_desc,
                                            in_data,
                                            &beta,
                                            dst_tensor_desc,
                                            out_data);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnLRNCrossChannelForward failed", CNN_convert_cudnn_error_code(cudnn_sts));

    return HIK_VCA_LIB_S_OK;
}
#endif

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: 
*         lrn_layer              - I/O lrn layer
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_LRN_Forward_Cuda_Opt(LRN_LAYER          *lrn_layer,
                                 LAYER_DATA         *ld)
{
    CNN_BLOB            *src                = ld->input_blobs[0];
    CNN_BLOB            *dst                = &ld->output_blobs[0];
    HRESULT             hr;
    void                *src_data           = src->data_gpu;
    void                *dst_data           = dst->data_gpu;
    BLOB_DATA_TYPE      type;
    BLOB_DATA_FORMAT    format;
    CNN_CUDNN_HANDLE    *cnn_cudnn_handle   = &ld->cuda_handle->cudnn_handle;

    int                 in_n                = src->shape[0];
    int                 in_c                = src->shape[1];
    int                 in_h                = src->shape[2];
    int                 in_w                = src->shape[3];

    int                 out_n               = dst->shape[0];
    int                 out_c               = dst->shape[1];
    int                 out_h               = dst->shape[2];
    int                 out_w               = dst->shape[3];

    int                 lrn_n               = lrn_layer->model->size;
    double              lrn_alpha           = lrn_layer->model->alpha;
    double              lrn_beta            = lrn_layer->model->beta;

    type                = src->type;
    format              = src->format;

printf("LRN %d %d %d %d \n",in_n,in_c,in_h,in_w);

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "format not support", CNN_CUDA_NOT_IMPLEMENT);

    if (type == CNN_DT_FLT16)
    {
        src_data = src->data_gpu_fp16;
        dst_data = dst->data_gpu_fp16;
    }

    switch (lrn_layer->model->type)
    {
    case CHANNEL_NRM:
        {
 #ifndef CNN_LRN_CUDA_OPT                                   //TK1ƽ̨���붨�������
            hr = cnn_lrn_forward_cudnn(cnn_cudnn_handle,
                                       src_data,       
                                       dst_data,
                                       type,
                                       in_n,
                                       in_c,
                                       in_h,
                                       in_w,
                                       out_n,
                                       out_c,
                                       out_h,
                                       out_w,
                                       lrn_n,
                                       lrn_layer->model->alpha,
                                       lrn_layer->model->beta,
                                       1.0f);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_lrn_forward_cudnn", hr);
#else
           if (format == CNN_FORMAT_NCHW)
           {
               hr = cnn_lrn_forward_cuda(src_data,
                                         dst_data,
                                         type,
                                         in_n,
                                         in_c,
                                         in_h,
                                         in_w,
                                         out_n,
                                         out_c,
                                         out_h,
                                         out_w,
                                         lrn_n,
                                         lrn_layer->model->alpha,
                                         lrn_layer->model->beta);
               CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_lrn_forward_cudnn", hr);
           }
           else
           {
              hr = cnn_lrn_forward_cuda_zip(src_data,
                                            dst_data,
                                            type,
                                            in_n,
                                            in_c,
                                            in_h,
                                            in_w,
                                            out_n,
                                            out_c,
                                            out_h,
                                            out_w,
                                            lrn_n,
                                            lrn_layer->model->alpha,
                                            lrn_layer->model->beta,
                                            ld->input_blobs[0]->pad.pad_h,
                                            ld->output_blobs[0].pad.pad_h);
              CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_lrn_forward_cuda_zip", hr);
          }          
		   
#endif
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_lrn_forward_cudnn", hr);
            break;
        }

    case SPATIAL_NRM:
        {
            // CNN_LRN_spatial_normalization(src, dst, lrn_layer);
            printf("not supprrt ............\n");
            return HIK_VCA_LIB_KEY_PARAM_ERR;
            break;
        }

    default:
        {
            printf("not supprrt ............\n");
            return HIK_VCA_LIB_KEY_PARAM_ERR;
            break;
        }
    }

    return HIK_VCA_LIB_S_OK;
}

#endif // CNN_CUDA_OPT