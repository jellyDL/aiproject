/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: layer_base.c
* �ļ���ʶ: LAYER_BASE_C
* ժ    Ҫ: �������йصĻ�������ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-01-30
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <string.h>
#include <stdio.h>
#include "cnn_common.h"
#ifdef CNN_CUDA_OPT
#include "cnn_cuda_config.h"
#endif // CNN_CUDA_OPT
#include "layer_base.h"
#include "vca_error_code.h"
#include "net.h"
#include "hka_defs.h"
#include "fully_connected_layer.h"
#include "softmax_layer.h"

/***************************************************************************************************
* ��  ��: ��ȡ����صĲ���
* ��  ��: hyperparams            - I ������ַ�����ʽ�Ĳ�����Ϣ
*         kernel_w               - O �˿���
*         kernel_h               - O �˸߶�
*         pad_w                  - O pad����
*         pad_h                  - O pad�߶�
*         stride_w               - O stride����
*         stride_h               - O stride�߶�
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BASE_GetKernelParams(const char *hyperparams,
                                 int        *kernel_w,
                                 int        *kernel_h,
                                 int        *pad_w,
                                 int        *pad_h,
                                 int        *stride_w,
                                 int        *stride_h)
{
    int         r, tmp;
    const char *ptr1, *ptr2;
    const char  kw[]    = "kernel_w";
    const char  kh[]    = "kernel_h";
    const char  ks[]    = "kernel_size";
    const char  pdw[]   = "pad_w";
    const char  pdh[]   = "pad_h";
    const char  pd[]    = "pad";
    const char  strdw[] = "stride_w";
    const char  strdh[] = "stride_h";
    const char  strd[]  = "stride";

    if ((ptr1 = strstr(hyperparams, kw)) && (ptr2 = strstr(hyperparams, kh)))
    {
        r = sscanf(ptr1 + strlen(kw) + 1, "%d", &tmp);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        *kernel_w = tmp;
        r         = sscanf(ptr2 + strlen(kh) + 1, "%d", &tmp);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        *kernel_h = tmp;
    }
    else if (ptr1 = strstr(hyperparams, ks))
    {
        r = sscanf(ptr1 + strlen(ks) + 1, "%d", &tmp);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        *kernel_w = *kernel_h = tmp;
    }
    else
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    *pad_w = *pad_h = 0;
    ptr1   = strstr(hyperparams, pdw);
    ptr2   = strstr(hyperparams, pdh);
    if (ptr1 || ptr2)
    {
        if (ptr1)
        {
            r = sscanf(ptr1 + strlen(pdw) + 1, "%d", &tmp);
            HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
            *pad_w = tmp;
        }
        if (ptr2)
        {
            r = sscanf(ptr2 + strlen(pdh) + 1, "%d", &tmp);
            HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
            *pad_h = tmp;
        }
    }
    else if (ptr1 = strstr(hyperparams, pd))
    {
        r = sscanf(ptr1 + strlen(pd) + 1, "%d", &tmp);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        *pad_w = *pad_h = tmp;
    }

    *stride_w = *stride_h = 1;
    ptr1      = strstr(hyperparams, strdw);
    ptr2      = strstr(hyperparams, strdh);
    if (ptr1 || ptr2)
    {
        if (ptr1)
        {
            r = sscanf(ptr1 + strlen(strdw) + 1, "%d", &tmp);
            HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
            *stride_w = tmp;
        }
        if (ptr2)
        {
            r = sscanf(ptr2 + strlen(strdh) + 1, "%d", &tmp);
            HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
            *stride_h = tmp;
        }
    }
    else if (ptr1 = strstr(hyperparams, strd))
    {
        r = sscanf(ptr1 + strlen(strd) + 1, "%d", &tmp);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        *stride_w = *stride_h = tmp;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡ�������
* ��  ��: param_blobs            - I ������ϢԴ
*         blob                   - O �洢������blob
*         blob_n                 - I blob����
*         type                   - I blob��������
*         blob_init_func         - I ��ʼ��blob�ĺ���
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BASE_GetParamBlobs(const char    *param_blobs,
                               CNN_BLOB      *blob,
                               int            blob_n,
                               BLOB_DATA_TYPE type,
                               HRESULT        (*blob_init_func[MAX_PARAM_BLOB_NUM])(CNN_BLOB *, void *))
{
    const char *ptr = param_blobs;
    int         blob_size;
    int         bi;
    int         bn = *(int *)(ptr);
    HRESULT     hr;

    if (bn != blob_n)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr += sizeof(int);


    for (bi = 0; bi < bn; bi++)
    {
        blob[bi].ndims      = 4;
        blob[bi].shape[0]   = *(int *)(ptr + sizeof(int) * 0);
        blob[bi].shape[1]   = *(int *)(ptr + sizeof(int) * 1);
        blob[bi].shape[2]   = *(int *)(ptr + sizeof(int) * 2);
        blob[bi].shape[3]   = *(int *)(ptr + sizeof(int) * 3);
        blob[bi].pad.pad_h  = 0;
        blob[bi].pad.pad_w  = 0;
        ptr += sizeof(int) * 4;

        blob_size = CNN_BLOB_GetDataNum(&blob[bi]);

        if (CNN_DT_FLT32 == type)
        {
            blob[bi].type = CNN_DT_FLT32;
            if (blob_init_func && blob_init_func[bi])           // ֻ��ģ��������Ҫ����
            {
                //ÿ����Զ���blob_init_func��֧�ָ�����blob��ʼ��
                //����ȫ���Ӳ���Խ�ϵ��ת�ã����������ת��ϵ����ʽ(NCHW->CHWN��)
                hr = blob_init_func[bi](blob + bi, ptr);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "blob_init_func failed", hr);
            }
        }
        else if (CNN_DT_FLT16 == type)
        {
            blob[bi].type = CNN_DT_FLT16;
            if (blob_init_func && blob_init_func[bi])           // ֻ��ģ��������Ҫ����
            {
                hr = blob_init_func[bi](blob + bi, ptr);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "blob_init_func failed", hr);
            }
        }
        ptr += blob_size * sizeof(float);
    }
     
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����memory tab
* ��  ��:
*         mem_tab                   - O memory tab
*         size                      - I memory tab��С
*         align                     - I memory tab�����ֽ���
* ����ֵ:  ��
***************************************************************************************************/
void CNN_BASE_SetMemTab(VCA_MEM_TAB_V2   *mem_tab,
                     unsigned int      size,
                     VCA_MEM_ALIGNMENT align,
                     VCA_MEM_ATTRS     attrs,
                     VCA_MEM_PLAT      plat)
{
    if (mem_tab)                // ���ΪNULL��ʲô������
    {
        mem_tab->size      = size;
        mem_tab->alignment = align;
        mem_tab->attrs     = attrs;
        mem_tab->plat      = plat;
    }
}


/***************************************************************************************************
* ��  ��: ������blob�ڴ��Ų���ʽ
* ��  ��: 
*         in_blob            - I  ����blob
*         in_blob_num        - I  ����blob����
*         out_blob           - I  ���blob
*         out_blob_num       - I  ���blob����
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BASE_SetBlobFormat(CNN_BLOB      **in_blob,
                               int             in_blob_num,
                               CNN_BLOB      *out_blob,
                               int            out_blob_num)
{
    int n;
    BLOB_DATA_FORMAT format;

    CNN_CHECK_ERROR(in_blob_num  < 0,  "in_blob_num  < 0" , HIK_VCA_CNN_MODEL_ERROR);
    CNN_CHECK_ERROR(out_blob_num <= 0, "out_blob_num <= 0", HIK_VCA_CNN_MODEL_ERROR);

    if (in_blob_num > 0)
    {
        format = in_blob[0]->format;
        for (n = 0; n < out_blob_num; n++)
        {
            out_blob[n].format = format;
        }
    }
    return HIK_VCA_LIB_S_OK;
}


static void CNN_BASE_set_special_layer_data_pad(NET *net, LAYER_DATA *layer)
{
    int         i, j; 
    LAYER_DATA *input_layer;

    // ������blob����ͬһ��layer
    for (i = 0; i < layer->layer_model->input_blobs_num; i++)
    {
        if (layer->layer_model->in_place == 1)
        {
            // �ٶ�inplace��ֻ��һ������
            CNN_CHECK_ERROR(layer->layer_model->input_blobs_num != 1, 
                            "layer->layer_model->input_blobs_num != 1",
                            HIK_VCA_CNN_MODEL_ERROR);
           input_layer = &net->layers[layer->layer_model->input_blobs_id[0].lid - 1];

           CNN_BASE_set_special_layer_data_pad(net, input_layer);
        }
        else
        {
            input_layer = &net->layers[layer->layer_model->input_blobs_id[i].lid - 1];
            for (j = 0; j < input_layer->output_blobs_num; j++)
            {
                input_layer->output_blobs[j].pad.pad_h = 0;
                input_layer->output_blobs[j].pad.pad_w = 0;
            }
        }
    }
}


/***************************************************************************************************
* ��  ��: ����layer����output blob��pad_h��pad_w
* ��  ��:
*         in_blob            - I  ����blob
*         in_blob_num        - I  ����blob����
*         out_blob           - I  ���blob
*         out_blob_num       - I  ���blob����
* ����ֵ: ������
***************************************************************************************************/
void CNN_BASE_set_layer_data_pad(NET *net, LAYER_DATA *layer, int pad_h, int pad_w)
{
    int                      i;
    LAYER_MODEL             *softmax_model;
    LAYER_MODEL             *fc_model;

#ifndef ARCH_SUPPORT_FP16
    pad_h = pad_w = 0;
#endif
    if ((pad_h == 0) && (pad_w == 0))
    {
        for (i = 0; i < layer->output_blobs_num; i++)
        {
            layer->output_blobs[i].pad.pad_h = 0;
            layer->output_blobs[i].pad.pad_w = 0;
        }
    }
    else
    {
        for (i = 0; i < layer->output_blobs_num; i++)
        {
            if (strcmp(layer->layer_model->type, "InnerProduct") == 0)
            {
                layer->output_blobs[i].pad.pad_h = layer->input_blobs[0]->pad.pad_h;
                layer->output_blobs[i].pad.pad_w = layer->input_blobs[0]->pad.pad_w;

                // ȫ���ӵ����ֻ֧��UNPAD
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "Softmax") == 0)
            {
                // ��������һ�㣬����padΪ0
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
                softmax_model                    = layer->layer_model;

                // ����������һ��
                if (softmax_model->layer_output.out_num > 0)
                {
                    layer->output_blobs[i].pad.pad_h = pad_h;
                    layer->output_blobs[i].pad.pad_w = pad_w;
                }
            }
            else if (strcmp(layer->layer_model->type, "RpnProposal") == 0)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "FrcnOutput") == 0)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "RpnProposalSdp") == 0)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "FrcnOutputSdp") == 0)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "Concat") == 0)
            {
                layer->output_blobs[0].pad.pad_h = layer->input_blobs[0]->pad.pad_h;
                layer->output_blobs[0].pad.pad_w = layer->input_blobs[0]->pad.pad_w;
            }
            else if (strcmp(layer->layer_model->type, "Reshape") == 0)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
            else if (strcmp(layer->layer_model->type, "ReLU") == 0)
            {
                layer->output_blobs[i].pad.pad_h = layer->input_blobs[i]->pad.pad_h;
                layer->output_blobs[i].pad.pad_w = layer->input_blobs[i]->pad.pad_w;
            }
            else if (strcmp(layer->layer_model->type, "Dropout") == 0)
            {
                layer->output_blobs[i].pad.pad_h = layer->input_blobs[i]->pad.pad_h;
                layer->output_blobs[i].pad.pad_w = layer->input_blobs[i]->pad.pad_w;
            }
            else if (strcmp(layer->layer_model->type, "ROIPooling") == 0)
            {
                layer->output_blobs[0].pad.pad_h = pad_h;
                layer->output_blobs[0].pad.pad_w = pad_w;
                layer->output_blobs[1].pad.pad_h = 0;
                layer->output_blobs[1].pad.pad_w = 0;
                layer->output_blobs[2].pad.pad_h = 0;
                layer->output_blobs[2].pad.pad_w = 0;
                layer->output_blobs[3].pad.pad_h = 0;
                layer->output_blobs[3].pad.pad_w = 0;
            }
            else
            {
                layer->output_blobs[i].pad.pad_h = pad_h;
                layer->output_blobs[i].pad.pad_w = pad_w;
            }
        } 
    }
}

/***************************************************************************************************
* ��  ��: �����������в��pad
* ��  ��:
*         net               - I/0  ����handle
*         process_flag      - I    �Ƿ���process������  
* ����ֵ: ������
***************************************************************************************************/
void CNN_BASE_set_net_pad(NET *net, int process_flag)
{
    int         i, li, iter;
    LAYER_DATA  *layer;

    int         net_pad_h = net->net_model->net_pad.pad_h;
    int         net_pad_w = net->net_model->net_pad.pad_w;

    int         support_zip;               // ģ���Ƿ�֧��ZIP
    int         not_zip;                   // ��ģ��֧��ZIP��ǰ����,����ʱ����batch�Ƿ�2������ȷ���Ƿ����ZIP
                                           // 1 -> ��zip�� 0 -> zip

    support_zip = net->net_model->support_zip;
    not_zip = net->layers[0].output_blobs[0].shape[0] % 2; // ����batch_size��������ʱ�Ƿ�zip
    not_zip = support_zip ? not_zip : 1;                   // ������籾����֧��ZIP������not_zipΪ1

    // getmemsize��createʱҲҪ����CNN_BASE_set_net_pad�� ��ʱ���ڴ�һ��Ҫpad
    if (!process_flag)
    {
        not_zip = 0;
    }

    net_pad_h = not_zip ? 0 : net_pad_h;
    net_pad_w = not_zip ? 0 : net_pad_w;

    for (li = 0; li < net->layer_num; li++)
    {
        layer = &net->layers[li];
        // ����ÿһ���pad
        CNN_BASE_set_layer_data_pad(net, layer, net_pad_h, net_pad_w);
    }

    for (li = 0; li < net->layer_num; li++)
    {
        layer = &net->layers[li];
        LAYER_MODEL *layer_model = layer->layer_model;
    
        if (CNN_NET_type_in_output(net->net_model, layer_model, "Reshape") == 1)
        {
            for (i = 0; i < layer->output_blobs_num; i++)
            {
                layer->output_blobs[i].pad.pad_h = 0;
                layer->output_blobs[i].pad.pad_w = 0;
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: ��ʼ��blob format
* ��  ��:
*         ld                  - I layer data
*         li                  - I layer id
* ����ֵ: ��
* ��  ע:
***************************************************************************************************/
void CNN_BASE_set_layer_data_format(LAYER_DATA *ld, int li, int not_zip)
{
    int                      i;
    LAYER_MODEL             *layer_model;

#ifndef ARCH_SUPPORT_FP16

    for (i = 0; i < ld->output_blobs_num; i++)
    {
        ld->output_blobs[i].format = CNN_FORMAT_NCHW;
    }

#else

    for (i = 0; i < ld->output_blobs_num; i++)
    {
        if (li > 0)
        {
            // ���softmax�����һ��
            if (strcmp(ld->layer_model->type, "Softmax") == 0)
            {
                ld->output_blobs[i].format      = CNN_FORMAT_NCHW;
                layer_model                     = ld->layer_model;

                // ���softmax�������һ��
                if (layer_model->layer_output.out_num > 0)
                {
                    ld->output_blobs[i].format  = not_zip ? CNN_FORMAT_NCHW : CNN_FORMAT_NCHW_ZIP;
                }
            }
            else if (strcmp(ld->layer_model->type, "RpnProposal") == 0)
            {
                // RPN�����ROI
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
            else if (strcmp(ld->layer_model->type, "RpnProposalSdp") == 0)
            {
                // RPN�����ROI
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
            else if (strcmp(ld->layer_model->type, "FrcnOutput") == 0)
            {
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
            else if (strcmp(ld->layer_model->type, "FrcnOutputSdp") == 0)
            {
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
            else if (strcmp(ld->layer_model->type, "InnerProduct") == 0)
            {
                // ȫ���ӵ����ֻ֧��UNZIP��UNPAD
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
            else
            {
                ld->output_blobs[i].format = ld->input_blobs[0]->format;
            }
        }
        else
        {
            if ((ld->output_blobs[0].shape[0] % 2 == 0) && 
                (not_zip == 0))
            {
                ld->output_blobs[i].format = CNN_FORMAT_NCHW_ZIP;
            }
            else
            {
                ld->output_blobs[i].format = CNN_FORMAT_NCHW;
            }
        }
    }

#endif
}
