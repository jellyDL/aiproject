#ifdef  LINUX
/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: 
* �ļ���ʶ: 
* ժ    Ҫ: 
*
* ��ǰ�汾: 1.0.0
* ��    ��: Ѧ����
* ��    ��: 2016-02-28
* ��    ע:
*
* �ļ�����: 
* �ļ���ʶ: 
* ժ    Ҫ: 
*
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "cnn_basic_kernel.h"
#include "cnn_cuda_error.h"
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

#endif  //CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "proposal_layer.h"
#include "proposal_layer_cuda.h"
#include "_ipgs_sort.h"
#include "rpnlayer.h"

#include "roi_pooling_layer_cuda.h"
#include "cnn_half.h"
#include "roi_pooling_layer.h"

/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
extern "C" HRESULT CNN_ROI_Forward_NV_Opt(ROI_POOLING_LAYER       *roi_pooling_layer,
                                          LAYER_DATA              *ld);

/***************************************************************************************************
* ��  ��: roi pooling��ǰ�򴫲�(CUDA��)
* ��  ��: 
*         roi_pooling_layer      - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
extern HRESULT CNN_ROIPOOL_Forward_Cuda_Opt(ROI_POOLING_LAYER       *roi_pooling_layer,
						                    LAYER_DATA              *ld);

/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
extern "C" HRESULT CNN_PROPOSAL_Forward_NV_Opt(PROPOSAL_LAYER         *proposal_layer,
	                                           LAYER_DATA             *ld)
{
    CNN_BLOB			   *input_score      = ld->input_blobs[0];            // ����score����
    CNN_BLOB			   *input_bbox       = ld->input_blobs[1];            // ����bbox����
    const CNN_BLOB         *im_info          = ld->input_blobs[2];            // ͼƬ����
    CNN_BLOB               *output_roi       = &ld->output_blobs[0];          // ���blobs
    HRESULT                 hr;
    BLOB_DATA_TYPE          type;
    float                   score_value;
    int                     index;
    int                     plane_size;
    PROPOSAL_MODEL         *proposal_model   = proposal_layer->model;
    float                  *proposal_gpu     = proposal_layer->proposal_gpu;
    int                     num_anchor;
    int                     min_size         = proposal_layer->min_size;             // 16
    int                     pre_num_topN     = proposal_model->pre_nms_topN;
    int                     post_num_topN    = proposal_model->post_nms_topN;
    float                   nms_thresh       = proposal_model->nms_thresh;           // 0.7
    frcnnStatus_t           status;

    const int               feature_stride   = proposal_model->feat_stride;          // 16
    const int               pre_nms_top      = pre_num_topN;
    const int               nms_max_out      = post_num_topN;
    const float             iou_threshold    = proposal_model->nms_thresh;
    const int               min_box_size     = proposal_layer->min_size;
    int                     anchor_scale_num = proposal_model->anchor_scales_num;

    void                   *workspace_dev;
    cudaError_t             err;
    int                     roi_count;
    cudaStream_t            stream;
    int                     i;
    float                   *proi_data;

    const int N = input_bbox->shape[0];
    const int A = proposal_layer->anchor.scales_num * 3;
    const int H = input_bbox->shape[2];
    const int W = input_bbox->shape[3];

    int                     next_roi_flag;
    ROI_POOLING_LAYER      *roi_pooling_layer;
    LAYER_DATA             *roi_pooling_ld;

    const int max_batch_size = 1024;

    type = input_bbox->type;

    if (type == CNN_DT_FLT16)
    {
        input_bbox->data_gpu = proposal_layer->prev_out[0].data_gpu;
        hr = cnn_blob_half2float(input_bbox);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);
    }

    err = cudaMalloc(&workspace_dev, 30 * 1024 * 1024);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", CNN_convert_cudart_error_code(err));


    void *im_info_gpu;
    int im_info_size = sizeof(float ) * 4;
    err = cudaMalloc(&im_info_gpu, im_info_size * max_batch_size);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", CNN_convert_cudart_error_code(err));

    for (int i = 0; i < N; i++)
    {
        cudaMemcpy((char *)im_info_gpu + i * im_info_size, im_info->data, im_info_size, cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
    }

    float *anchor_dev;
    err = cudaMalloc(&anchor_dev, proposal_layer->temp_data.anchors_size * sizeof(float) * 10);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", CNN_convert_cudart_error_code(err));

    int *out_roi_num_gpu;
    err = cudaMalloc(&out_roi_num_gpu, sizeof(int) * max_batch_size);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", CNN_convert_cudart_error_code(err));

    void *out_roi_dev;
    err = cudaMalloc(&out_roi_dev, CNN_BLOB_GetDataNum(output_roi) * sizeof(float));
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", CNN_convert_cudart_error_code(err));

    float   *out_roi  = (float *)malloc(CNN_BLOB_GetDataNum(output_roi) * sizeof(float));
    int     out_roi_num[max_batch_size];

    float   r[3]      = { 0.5f, 1.0f, 2.0f };
    float   s[4]      = { 4.0f, 8.0f, 16.0f, 32.0f };
    float   *anchor   = (float *)malloc(proposal_layer->temp_data.anchors_size * sizeof(float));

    //status = generateAnchors_cpu(3, r, 4, s, 16, anchor);
    //CNN_CHECK_ERROR(status != STATUS_SUCCESS, "generateAnchors_cpu failed", CNN_ROIPOOLING_FAILED);

    status = generateAnchors(0, 3, r, 4, s, 16, anchor_dev);
    CNN_CHECK_ERROR(status != STATUS_SUCCESS, "generateAnchors failed", CNN_ROIPOOLING_FAILED);

    //cudaMemcpy(anchor_dev, proposal_layer->anchor.data, proposal_layer->temp_data.anchors_size * sizeof(float), cudaMemcpyHostToDevice);
    cudaMemcpy(anchor, anchor_dev, proposal_layer->temp_data.anchors_size * sizeof(float), cudaMemcpyDeviceToHost);

    next_roi_flag = proposal_layer->do_roi;

    if (next_roi_flag)
    {
        roi_pooling_layer   = proposal_layer->roi_info.roi_pooling_layer;
        roi_pooling_ld      = proposal_layer->roi_info.ld;

        CNN_BLOB            *roi_input_blob  = roi_pooling_ld->input_blobs[0];
        CNN_BLOB            *roi_output_blob = &roi_pooling_ld->output_blobs[0];
        ROI_POOLING_MODEL   *roi_model       = roi_pooling_layer->model;

        const int   pooled_height = roi_model->pooled_h;
        const int   pooled_width  = roi_model->pooled_w;
        const float spatial_scale = roi_model->spatial_scale;

        printf("------------------------------------------ fused\n");

        cudaDeviceSynchronize();
#ifdef OPT_TIMER
        OPT_PROFILE_TIME_BY_EVENT_START(888);
#endif

        //for (int i = 0; i < 100; i++)
        {
             RPROIInferenceFused(CUDA_DEFAULT_STREAM,
                                 N, 
                                 A,
                                 roi_input_blob->shape[1],
                                 H,
                                 W,
                                 pooled_height,
                                 pooled_width,
                                 feature_stride,
                                 pre_nms_top,
                                 post_num_topN,
                                 nms_thresh,
                                 min_box_size,
                                 spatial_scale,
                                 (const float*)im_info_gpu,
                                 (const float*)anchor_dev,
                                 FLOAT32,
                                 NCHW,
                                 input_score->data_gpu,
                                 FLOAT32,
                                 NCHW,
                                 input_bbox->data_gpu,
                                 FLOAT32,
                                 NCHW,
                                 roi_input_blob->data_gpu,
                                 workspace_dev,
                                 FLOAT32,
                                 1 ? ALIGNED : NOT_ALIGNED,
                                 out_roi_dev,
                                 FLOAT32,
                                 NCHW,
                                 roi_output_blob->data_gpu,
                                 out_roi_num_gpu);
            CNN_CHECK_ERROR(status != STATUS_SUCCESS, "RPROIInferenceFused failed", CNN_PROPOSAL_FAILED);
        }

#ifdef OPT_TIMER
        OPT_PROFILE_TIME_BY_EVENT_STOP(888, "RPROIInferenceFused", 1, 1);
#endif

    }
    else
    {
#ifdef OPT_TIMER
        OPT_PROFILE_TIME_BY_EVENT_START(888);
#endif
        status = proposalsInference(CUDA_DEFAULT_STREAM,
                                    N, 
                                    A, 
                                    H, 
                                    W,
                                    feature_stride,
                                    pre_nms_top,
                                    nms_max_out,
                                    iou_threshold,
                                    min_box_size,
                                    (const float *)im_info_gpu,
                                    (const float *)anchor_dev,
                                    FLOAT32,
                                    NCHW,
                                    input_score->data_gpu, //scores
                                    FLOAT32,
                                    NCHW,
                                    input_bbox->data_gpu,  //deltas
                                    workspace_dev,
                                    FLOAT32,
                                    1 ? ALIGNED : NOT_ALIGNED,
                                    out_roi_dev,
                                    (int *)out_roi_num_gpu);
        CNN_CHECK_ERROR(status != STATUS_SUCCESS, "proposalsInference failed", CNN_PROPOSAL_FAILED);
#ifdef OPT_TIMER
        OPT_PROFILE_TIME_BY_EVENT_STOP(888, "proposalsInference", 1, 1);
#endif
    }
    
    err = cudaMemcpy(out_roi_num, out_roi_num_gpu, sizeof(int) * max_batch_size, cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    err = cudaMemcpy(out_roi, out_roi_dev, sizeof(float) * CNN_BLOB_GetDataNum(output_roi), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    for (int i = 0; i < N; i++)
    {
        output_roi->shape[0]    = out_roi_num[i];
    }

    int batch_size = 0;
    int prev_roi;
    //���
    for (i = 0; i < output_roi->shape[0]; i++)
    {
        prev_roi = out_roi_num[batch_size];

        //*((float *)output_roi->data + 5 * i) = (float)0.0f;
        *((float *)output_roi->data + 5 * i) = (float)0.0f;

        memcpy(((float*)output_roi->data + 5 * i + 1),
            (float*)out_roi + 4 * i,
            4 * sizeof(float));
    }

    int roi_start = 0;
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < out_roi_num[i]; j++)
        {
            
        }
       roi_start += out_roi_num[i];
    }
    

    printf("out_roi_num: %d %d\n", out_roi_num[0], out_roi_num[1]);

#if 0
    for (i = 0; i < output_roi->shape[0]; i++)
    {
        printf("roi_id: %d %f %f %f %f\n", i + 1,
                                           *((float *)output_roi->data + 5 * i + 1), 
                                           *((float *)output_roi->data + 5 * i + 2),
                                           *((float *)output_roi->data + 5 * i + 3),
                                           *((float *)output_roi->data + 5 * i + 4));
    }
#endif
    
    //err = cudaMemcpy(output_roi->data, out_roi_dev, sizeof(float) * CNN_BLOB_GetDataNum(output_roi), cudaMemcpyDeviceToHost);
    //CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    cudaFree(out_roi_dev);
    cudaFree(anchor_dev);
    cudaFree(im_info_gpu);
    cudaFree(out_roi_num_gpu);
    cudaFree(workspace_dev);
    free(anchor);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
extern "C" HRESULT CNN_ROI_Forward_NV_Opt(ROI_POOLING_LAYER       *roi_pooling_layer,
                                          LAYER_DATA              *ld)
{
     frcnnStatus_t       status;
     ROI_POOLING_MODEL  *roi_model = (ROI_POOLING_MODEL *)roi_pooling_layer->model;
     CNN_BLOB           *input_blob = ld->input_blobs[0];
     CNN_BLOB           *roi_list_blob = ld->input_blobs[1];
     CNN_BLOB           *out_blob = &ld->output_blobs[0];
     cudaError_t         err;
     int                 i;

#if 1
     float *roi_data = (float *)malloc(sizeof(float) * CNN_BLOB_GetDataNum(roi_list_blob));

     for (i = 0; i < CNN_BLOB_GetDataNum(roi_list_blob) / 5; i++)
     {
         roi_data[i * 4 + 0] = ((float*)roi_list_blob->data)[i * 5 + 1];
         roi_data[i * 4 + 1] = ((float*)roi_list_blob->data)[i * 5 + 2];
         roi_data[i * 4 + 2] = ((float*)roi_list_blob->data)[i * 5 + 3];
         roi_data[i * 4 + 3] = ((float*)roi_list_blob->data)[i * 5 + 4];
     }

     free(roi_data);

     //����proposal���п���
     err = cudaMemcpy(roi_list_blob->data_gpu,
                      roi_data,
                      sizeof(float) * CNN_BLOB_GetDataNum(roi_list_blob) / 5 * 4, 
                      cudaMemcpyHostToDevice);
     CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
#endif

     status = roiInference(CUDA_DEFAULT_STREAM,
                           roi_list_blob->shape[0],      
                           input_blob->shape[0],         
                           input_blob->shape[1],         
                           input_blob->shape[2],         
                           input_blob->shape[3],         
                           roi_model->pooled_h,
                           roi_model->pooled_w,
                           roi_model->spatial_scale,
                           FLOAT32,
                           1 ? ALIGNED : NOT_ALIGNED,
                           roi_list_blob->data_gpu,
                           FLOAT32,
                           NCHW,
                           input_blob->data_gpu,
                           FLOAT32,
                           NCHW,
                           out_blob->data_gpu);
     CNN_CHECK_ERROR(status != STATUS_SUCCESS, "roiInference failed", CNN_ROIPOOLING_FAILED);
     
     return HIK_VCA_LIB_S_OK;
}
#endif
