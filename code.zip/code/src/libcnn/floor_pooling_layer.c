#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#endif // CNN_CUDA_OPT
#include "floor_pooling_layer.h"
#include "hka_types.h"

#ifdef LINUX
#define STRNCMP    strncasecmp
#else
#define STRNCMP    strnicmp
#endif

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: pooling_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOLING_compute_in_out_shape(FLOOR_POOLING_LAYER *pooling_layer,
                                               LAYER_DATA          *ld)
{
    int                  inp_h, inp_w;
    int                  out_h, out_w;
    FLOOR_POOLING_MODEL *model = pooling_layer->model;

    HKA_CHECK_ERROR(ld->input_blobs_num != 1,       HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1,      HIK_VCA_CNN_MODEL_ERROR);

    inp_h = ld->input_blobs[0]->shape[2];
    inp_w = ld->input_blobs[0]->shape[3];

    // Yeah, something strange Caffe scheme-)
    out_h = (int)((inp_h + 2 * model->pad_h - model->kernel_h) / (float)model->stride_h) + 1;
    out_w = (int)((inp_w + 2 * model->pad_w - model->kernel_w) / (float)model->stride_w) + 1;

    if (model->pad_h || model->pad_w)
    {
        // If we have padding, ensure that the last pooling starts strictly
        // inside the image (instead of at the padding); otherwise clip the last.
        if ((out_h - 1) * model->stride_h >= inp_h + model->pad_h)
        {
            --out_h;
        }
        if ((out_w - 1) * model->stride_w >= inp_w + model->pad_w)
        {
            --out_w;
        }
    }

    pooling_layer->inp_h = inp_h;
    pooling_layer->inp_w = inp_w;

    pooling_layer->out_h = out_h;
    pooling_layer->out_w = out_w;

    ld->output_blobs[0].ndims    = 4;
    ld->output_blobs[0].type     = cnn_get_blob_type();
    ld->output_blobs[0].shape[3] = pooling_layer->out_w;
    ld->output_blobs[0].shape[2] = pooling_layer->out_h;
    ld->output_blobs[0].shape[1] = ld->input_blobs[0]->shape[1];
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_Reshape(void       *handle,
                               LAYER_DATA *ld)
{
    return CNN_FLOOR_POOLING_compute_in_out_shape((FLOOR_POOLING_LAYER *)handle, ld);
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_init_model(const char          *hyperparams,
                                  const char          *param_blobs,
                                  LAYER_MODEL         *ld,
                                  FLOOR_POOLING_MODEL *pooling_model)
{
    int         r;
    HRESULT     hr;
    const char  pool[]         = "pool";
    char        pool_type[256] = { 0 };
    const char *ptr;

    hr = CNN_BASE_GetKernelParams(hyperparams,
                                  &pooling_model->kernel_w, &pooling_model->kernel_h,
                                  &pooling_model->pad_w, &pooling_model->pad_h,
                                  &pooling_model->stride_w, &pooling_model->stride_h);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    pooling_model->type = FLOOR_MAX_POOLING;
    if (ptr = strstr(hyperparams, pool))
    {
        r = sscanf(ptr + strlen(pool) + 1, "%s", pool_type);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

        if (STRNCMP(pool_type, "max", 3) == 0)
        {
            pooling_model->type = FLOOR_MAX_POOLING;
        }
        else if (STRNCMP(pool_type, "ave", 3) == 0)
        {
            pooling_model->type = FLOOR_AVE_POOLING;
        }
        else
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_Create(LAYER_DATA *ld,
                              CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                              void      **handle)
{
    int                  hr;
    FLOOR_POOLING_LAYER *pooling_layer;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#else
    cpu_data_buf = NULL;
#endif

    pooling_layer = (FLOOR_POOLING_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                            CNN_SIZE_ALIGN(sizeof(FLOOR_POOLING_LAYER)),
                                                            CNN_MEM_ALIGN_SIZE,
                                                            1);
    HKA_CHECK_MEMOUT(pooling_layer);

    pooling_layer->model = ld->layer_model->model_handle;

    hr = CNN_FLOOR_POOL_Reshape(pooling_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    *handle = pooling_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_GetMemsize(LAYER_DATA    *ld,
                                  VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    int                 hr;
    FLOOR_POOLING_LAYER pooling_layer;

    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2 *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *gpu_data_tab   = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_data_tab = NULL;
#else
    cpu_data_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    pooling_layer.model = ld->layer_model->model_handle;

    hr = CNN_FLOOR_POOL_Reshape(&pooling_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(FLOOR_POOLING_LAYER)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0])), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(gpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0])), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_FLOOR_POOL_CreateModel(const char  *hyperparams,
                                   const char  *param_blobs,
                                   LAYER_MODEL *ld,
                                   CNN_BUF      mem_buf[MODEL_MEM_TAB_NUM],
                                   void       **handle)
{
    HRESULT              hr;
    FLOOR_POOLING_MODEL *pooling_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    pooling_model = (FLOOR_POOLING_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
                                                            CNN_SIZE_ALIGN(sizeof(FLOOR_POOLING_MODEL)),
                                                            CNN_MEM_ALIGN_SIZE,
                                                            1);
    HKA_CHECK_MEMOUT(pooling_model);

    hr = CNN_FLOOR_POOL_init_model(ld->hyperparams, ld->param_blobs, ld, pooling_model);
    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, "CNN_POOL_init_model error", hr);

    *handle = pooling_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_FLOOR_POOL_GetModelMemsize(const char    *hyperparams,
                                       const char    *param_blobs,
                                       LAYER_MODEL   *ld,
                                       VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(FLOOR_POOLING_MODEL)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: max pooling
* ��  ��: input                  - I   ����blob
*         output                 - I/O ���blob
*         pooling_layer          - I   �ò�ľ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_FLOOR_POOL_max_pooling(CNN_BLOB                  *input,
                                CNN_BLOB                  *output,
                                const FLOOR_POOLING_LAYER *pooling_layer)
{
    int   hstart;
    int   wstart;
    int   hend;
    int   wend;
    int   n, c, ph, pw, w, h;
    int   inp_w, inp_h;
    int   out_w, out_h;
    int   pad_w, pad_h;
    int   stride_w, stride_h;
    int   kernel_w, kernel_h;
    int   index;
    float max_val;

    float *src_data;
    float *dst_data;

    inp_w    = input->shape[3];
    inp_h    = input->shape[2];
    out_w    = pooling_layer->out_w;
    out_h    = pooling_layer->out_h;
    pad_w    = pooling_layer->model->pad_w;
    pad_h    = pooling_layer->model->pad_h;
    stride_w = pooling_layer->model->stride_w;
    stride_h = pooling_layer->model->stride_h;
    kernel_w = pooling_layer->model->kernel_w;
    kernel_h = pooling_layer->model->kernel_h;

    for (n = 0; n < input->shape[0]; ++n)
    {
        for (c = 0; c < input->shape[1]; ++c)
        {
            src_data = (float *)CNN_BLOB_GetPtr(input, n, c, 0, 0);
            dst_data = (float *)CNN_BLOB_GetPtr(output, n, c, 0, 0);

            for (ph = 0; ph < out_h; ++ph)
            {
                for (pw = 0; pw < out_w; ++pw)
                {
                    hstart  = ph * stride_h - pad_h;
                    wstart  = pw * stride_w - pad_w;
                    hend    = HKA_MIN(hstart + kernel_h, inp_h);
                    wend    = HKA_MIN(wstart + kernel_w, inp_w);
                    hstart  = HKA_MAX(hstart, 0);
                    wstart  = HKA_MAX(wstart, 0);
                    max_val = -FLT_MAX;

                    for (h = hstart; h < hend; ++h)
                    {
                        for (w = wstart; w < wend; ++w)
                        {
                            index = h * inp_w + w;
                            if (src_data[index] > max_val)
                            {
                                max_val = src_data[index];
                            }
                        }
                    }

                    dst_data[ph * out_w + pw] = max_val;
                }
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: average pooling
* ��  ��: input                  - I   ����blob
*         output                 - I/O ���blob
*         pooling_layer          - I   �ò�ľ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_FLOOR_POOL_ave_pooling(CNN_BLOB                  *input,
                                CNN_BLOB                  *output,
                                const FLOOR_POOLING_LAYER *pooling_layer)
{
    int hstart;
    int wstart;
    int hend;
    int wend;
    int n, c, ph, pw, w, h;
    int inp_w, inp_h;
    int out_w, out_h;
    int pad_w, pad_h;
    int stride_w, stride_h;
    int kernel_w, kernel_h;
    int pool_size;

    float *src_data;
    float *dst_data;

    inp_w    = input->shape[3];
    inp_h    = input->shape[2];
    out_w    = pooling_layer->out_w;
    out_h    = pooling_layer->out_h;
    pad_w    = pooling_layer->model->pad_w;
    pad_h    = pooling_layer->model->pad_h;
    stride_w = pooling_layer->model->stride_w;
    stride_h = pooling_layer->model->stride_h;
    kernel_w = pooling_layer->model->kernel_w;
    kernel_h = pooling_layer->model->kernel_h;

    for (n = 0; n < input->shape[0]; ++n)
    {
        for (c = 0; c < input->shape[1]; ++c)
        {
            src_data = (float *)CNN_BLOB_GetPtr(input, n, c, 0, 0);
            dst_data = (float *)CNN_BLOB_GetPtr(output, n, c, 0, 0);

            for (ph = 0; ph < out_h; ++ph)
            {
                for (pw = 0; pw < out_w; ++pw)
                {
                    hstart    = ph * stride_h - pad_h;
                    wstart    = pw * stride_w - pad_w;
                    hend      = HKA_MIN(hstart + kernel_h, inp_h + pad_h);
                    wend      = HKA_MIN(wstart + kernel_w, inp_w + pad_w);
                    pool_size = (hend - hstart) * (wend - wstart);
                    hstart    = HKA_MAX(hstart, 0);
                    wstart    = HKA_MAX(wstart, 0);
                    hend      = HKA_MIN(hend, inp_h);
                    wend      = HKA_MIN(wend, inp_w);

                    dst_data[ph * out_w + pw] = 0.f;

                    for (h = hstart; h < hend; ++h)
                    {
                        for (w = wstart; w < wend; ++w)
                        {
                            dst_data[ph * out_w + pw] += src_data[h * inp_w + w];
                        }
                    }

                    dst_data[ph * out_w + pw] /= pool_size;
                }
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_Forward(void       *handle,
                               LAYER_DATA *ld)
{
    FLOOR_POOLING_LAYER *pooling_layer = (FLOOR_POOLING_LAYER *)handle;

    switch (pooling_layer->model->type)
    {
    case FLOOR_MAX_POOLING:
        CNN_FLOOR_POOL_max_pooling(ld->input_blobs[0], &ld->output_blobs[0], pooling_layer);
        break;

    case FLOOR_AVE_POOLING:
        CNN_FLOOR_POOL_ave_pooling(ld->input_blobs[0], &ld->output_blobs[0], pooling_layer);
        break;

    default:
        break;
    }

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: cudnnʵ��ǰ��pooling
* ��  ��:
*         cnn_cudnn_handle              - I  cudnn handle
*         in_data                       - I  ��������
*         out_data                      - O  �������
*         in_n                          - I  ����n
*         in_c                          - I  ����c
*         in_h                          - I  ����h
*         in_w                          - I  ����w
*         out_n                         - I  ���n
*         out_c                         - I  ���c
*         out_h                         - I  ���h
*         out_w                         - I  ���w
*         pool_h                        - I  pooling���ڸ�
*         pool_w                        - I  pooling���ڿ�
*         stride_h                      - I  pooling stride(h����)
*         pad_h                         - I  pooling ����(h����)
*         pad_w                         - I  pooling ����(w����)
*         pool_type                     - I  pooling ����
* ����ֵ: ��
***************************************************************************************************/
static HRESULT cnn_floor_pooling_forward_cudnn(CNN_CUDNN_HANDLE  *cnn_cudnn_handle,
                                               float_t           *in_data,
                                               float_t           *out_data,
                                               BLOB_DATA_TYPE     type,
                                               int                in_n,
                                               int                in_c,
                                               int                in_h,
                                               int                in_w,
                                               int                out_n,
                                               int                out_c,
                                               int                out_h,
                                               int                out_w,
                                               int                pool_h,
                                               int                pool_w,
                                               int                stride_h,
                                               int                stride_w,
                                               int                pad_h,
                                               int                pad_w,
                                               cudnnPoolingMode_t pool_type)
{
    cudnnStatus_t cudnn_sts;
    cudnnHandle_t cudnn_handle = cnn_cudnn_handle->cudnn_handle;
    int           win[2]       = { pool_h, pool_w };
    int           pad[2]       = { pad_h, pad_w };
    int           stride[2]    = { stride_h, stride_w };

    cudnnTensorDescriptor_t  src_tensor_desc = cnn_cudnn_handle->srcTensorDesc;
    cudnnTensorDescriptor_t  dst_tensor_desc = cnn_cudnn_handle->dstTensorDesc;
    cudnnPoolingDescriptor_t pooling_desc    = cnn_cudnn_handle->poolingDesc;
    cudnnTensorFormat_t      tensor_format   = CUDNN_TENSOR_NCHW;                              // Ŀǰֻ֧�������ڴ����з�ʽ
    cudnnDataType_t          data_type       = (type == CNN_DT_FLT32) ?  CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;
    float                    alpha           = 1.0f;
    float                    beta            = 0.0f;

    cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc,
                                           tensor_format,
                                           data_type,
                                           in_n,
                                           in_c,
                                           in_h,
                                           in_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensor4dDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc,
                                           tensor_format,
                                           data_type,
                                           in_n,
                                           out_c,
                                           out_h,
                                           out_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensor4dDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if (CUDNN_VERSION >= 5000)
    cudnn_sts = cudnnSetPoolingNdDescriptor(pooling_desc,
                                            pool_type,
					                        0,
                                            2,
                                            win,
                                            pad,
                                            stride);
#else
    cudnn_sts = cudnnSetPoolingNdDescriptor(pooling_desc,
                                            pool_type,
                                            2,
                                            win,
                                            pad,
                                            stride);
#endif
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnPoolingForward failed", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnPoolingForward(cudnn_handle,
                                    pooling_desc,
                                    &alpha,
                                    src_tensor_desc,
                                    in_data,
                                    &beta,
                                    dst_tensor_desc,
                                    out_data);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnPoolingForward failed", CNN_convert_cudnn_error_code(cudnn_sts));

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: pooling��ǰ�򴫲�(CUDA�� )
* ��  ��:
*         pooling_layer                 - I/O  layer
*         ld                            - I/O  �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FLOOR_POOL_Forward_Cuda_Opt(FLOOR_POOLING_LAYER *pooling_layer,
                                        LAYER_DATA          *ld)
{
    HRESULT hr;

    CNN_BLOB          *in_blob  = ld->input_blobs[0];
    CNN_BLOB          *out_blob = &ld->output_blobs[0];
    cudnnPoolingMode_t pool_type;
    BLOB_DATA_TYPE     type;
    void              *in_data  = in_blob->data_gpu;
    void              *out_data = out_blob->data_gpu;

    type = in_blob->type;

    if (type == CNN_DT_FLT16)
    {
        in_data  = in_blob->data_gpu_fp16;
        out_data = out_blob->data_gpu_fp16;
    }

    switch (pooling_layer->model->type)
    {
    case FLOOR_MAX_POOLING:
        pool_type = CUDNN_POOLING_MAX;
        break;

    case FLOOR_AVE_POOLING:
        pool_type = CUDNN_POOLING_AVERAGE_COUNT_INCLUDE_PADDING;
        break;

    default:
        return HIK_VCA_LIB_KEY_PARAM_ERR;

        break;
    }

    hr = cnn_floor_pooling_forward_cudnn(&ld->cuda_handle->cudnn_handle,
                                         in_data,
                                         out_data,
                                         type,
                                         in_blob->shape[0],
                                         in_blob->shape[1],
                                         in_blob->shape[2],
                                         in_blob->shape[3],
                                         out_blob->shape[0],
                                         out_blob->shape[1],
                                         out_blob->shape[2],
                                         out_blob->shape[3],
                                         pooling_layer->model->kernel_h,
                                         pooling_layer->model->kernel_w,
                                         pooling_layer->model->stride_h,
                                         pooling_layer->model->stride_w,
                                         pooling_layer->model->pad_h,
                                         pooling_layer->model->pad_w,
                                         pool_type);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_pooling_forward_cudnn failed", hr);

    return HIK_VCA_LIB_S_OK;
}

#endif // CNN_CUDA_OPT