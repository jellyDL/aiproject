/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: net_ex.c
* �ļ���ʶ: 
* ժ    Ҫ: ������չ��صĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: Ѧ����
* ��    ��: 2016-12-19
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "convolution_layer.h"
#include "net_ex.h"
#include "cnn_cuda_config.h"

#define NET_EX_CONV_MAX_KERNEL_H        (11)     // ���֧�ֵľ����˴�С(height)
#define NET_EX_CONV_MAX_KERNEL_W        (11)     // ���֧�ֵľ����˴�С(width)

//#define CNN_CLOSE_ZIP                         // �ر�ZIP����

/***************************************************************************************************
* ��  ��: �ж�ȫ���Ӳ��Ƿ�֧��zip��ʽ
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_NET_EX_fullyconnect_support_zip(NET_MODEL *net, int* ret)
{
    int             layer_size;
    int             li, i;
    const char     *layer_type;
    LAYER_MODEL    *layer;

    layer_size      = net->layer_num;
    *ret            = 1;

    for (li = 0; li < layer_size; li++)
    {
        layer       = &net->layers[li];
        layer_type  = layer->type;

        if (strcmp(layer_type, "InnerProduct") == 0)
        {
            // ȫ���ӵ����������Convolution
            if (CNN_NET_type_in_output(net, layer, "Convolution"))
            {
                *ret = 0;
                return HIK_VCA_LIB_S_OK;
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �жϾ������Ƿ�֧��zip��ʽ
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_NET_EX_Convolution_support_zip(NET_MODEL *net, int* ret)
{
    int                  layer_size;
    int                  li, i;
    const char          *layer_type;
    LAYER_MODEL         *layer;
    CONVOLUTION_MODEL   *conv_model;
    int                  has_conv;

    layer_size  = net->layer_num;
    *ret        = 1;
    has_conv    = 0;

    for (li = 0; li < layer_size; li++)
    {
        layer = &net->layers[li];
        layer_type = layer->type;

        if (strcmp(layer_type, "Convolution") == 0)
        {
            conv_model = (CONVOLUTION_MODEL*)layer->model_handle;
            if ((conv_model->ker_h > NET_EX_CONV_MAX_KERNEL_H) ||
                (conv_model->ker_w > NET_EX_CONV_MAX_KERNEL_H))
            {
                *ret = 0;
                return HIK_VCA_LIB_S_OK;
            }

            has_conv = 1;
        }
    }

    // ���û�о����㣬��֧��ZIP
    if (has_conv == 0)
    {
        *ret = 0;
        return HIK_VCA_LIB_S_OK;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �ж�concat���Ƿ�֧��zip��ʽ
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_NET_EX_Concat_support_zip(NET_MODEL *net, int* ret)
{
    int                  layer_size;
    int                  li, i;
    const char          *layer_type;
    LAYER_MODEL         *layer;
    LAYER_MODEL         *layer_input;
    const char          *layer_input_type;

    layer_size = net->layer_num;
    *ret       = 1;

    for (li = 0; li < layer_size; li++)
    {
        layer       = &net->layers[li];
        layer_type  = layer->type;


        if (strcmp(layer_type, "Concat") == 0)
        {
            if (CNN_NET_type_in_output(net, layer, "Reshape"))
            {
                *ret = 0;
                return HIK_VCA_LIB_S_OK;
            }

            // ���reshape���������
            if (layer->input_layers_id.ele_num > 0)
            {
                layer_input = CNN_NET_get_layer_model(net, layer->input_layers_id.elements[0]);
                layer_type  = layer_input->type;

                // �������������ͱ�����ͬ
                for (i = 1; i < layer->input_layers_id.ele_num; i++)
                {
                    layer_input = CNN_NET_get_layer_model(net, layer->input_layers_id.elements[i]);
                    if (strcmp(layer_type, layer_input->type) != 0)
                    {
                        *ret = 0;
                        return HIK_VCA_LIB_S_OK;
                    }
                }
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �ж�Reshape���Ƿ�֧��zip��ʽ
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_NET_EX_Reshape_support_zip(NET_MODEL *net, int* ret)
{
    int                  layer_size;
    int                  li, i;
    const char          *layer_type;
    LAYER_MODEL         *layer;

    layer_size  = net->layer_num;
    *ret        = 1;

    for (li = 0; li < layer_size; li++)
    {
        layer       = &net->layers[li];
        layer_type  = layer->type;

        if (strcmp(layer_type, "Reshape") == 0)
        {
            if (CNN_NET_type_in_output(net, layer, "Convolution"))
            {
                *ret = 0;
                return HIK_VCA_LIB_S_OK;
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �жϲ��Ƿ�֧��zip
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_NET_EX_layer_support_zip(NET_MODEL *net, int* ret)
{
    int                  layer_size;
    int                  li, i;
    const char          *layer_type;
    LAYER_MODEL         *layer;

    // ֧��zip��ʽ�Ĳ�����
    const char* support_zip_types[] = { "BN", 
                                        "Eltwise", 
                                        "ReLU", 
                                        "Input", 
                                        "Convolution",                   
                                        "Pooling",
                                        "InnerProduct",                   
                                        "Concat",                         
                                        "Dropout",                       
                                        "Reshape",
                                        "Softmax",                        
                                        "LRN",
                                        "FrcnOutput",
                                        "RpnProposal",
                                        "FrcnOutputSdp",
                                        "RpnProposalSdp",
                                        "ROIPooling",
                                        0 };

    const char **support_zip_types_ptr;

    layer_size  = net->layer_num;

    for (li = 0; li < layer_size; li++)
    {
        layer                   = &net->layers[li];
        layer_type              = layer->type;
        *ret                    = 0;
        support_zip_types_ptr   = support_zip_types;

        do 
        {
            if (strcmp(*support_zip_types_ptr, layer_type) == 0)
            {
                *ret = 1;
            }
        } while (*++support_zip_types_ptr);

        // ֻҪ��һ��type������support_zip_types����retΪ0
        if (*ret == 0)
        {
            break;
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �ж������Ƿ�֧��zip��ʽ
* ��  ��:
*         net                    - I ����ģ��
*         ret                    - O ���, 1->֧�֣� 0->��֧��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_EX_support_zip(const NET_MODEL *net, int *ret)
{
    int             layer_size;
    int             li, i;
    const char     *layer_type;
    LAYER_MODEL    *layer;
    HRESULT         hr;

    // �������飬����ж��Ƿ�ȫ��֧��zip
    HRESULT         (*pfunc[])(NET_MODEL *net, int* ret) = {CNN_NET_EX_fullyconnect_support_zip, 
                                                            CNN_NET_EX_Convolution_support_zip,
                                                            CNN_NET_EX_Concat_support_zip,
                                                            CNN_NET_EX_Reshape_support_zip,
                                                            CNN_NET_EX_layer_support_zip,
                                                            0};
    HRESULT         (**ppfunc)(NET_MODEL *net, int* ret) = pfunc;

    CNN_CHECK_ERROR(net == NULL, "net == NULL", HIK_VCA_LIB_E_PTR_NULL);
    CNN_CHECK_ERROR(ret == NULL, "ret == NULL", HIK_VCA_LIB_E_PTR_NULL);

    layer_size = net->layer_num;
    *ret       = 1;

#ifndef ARCH_SUPPORT_FP16
    *ret   = 0;
    return HIK_VCA_LIB_S_OK;
#endif

#ifdef CNN_CLOSE_ZIP
    *ret   = 0;
    return HIK_VCA_LIB_S_OK;
#endif

    for (li = 0; li < layer_size; li++)
    {
        layer       = &net->layers[li];
        layer_type  = layer->type;

        // ��һ����������ͬʱ��Reshape��Convolution
        if (CNN_NET_type_in_output(net, layer, "Reshape") &&
            CNN_NET_type_in_output(net, layer, "Convolution"))
        {
            *ret    = 0;
            return  HIK_VCA_LIB_S_OK;
        }
    }

    do
    {
        // ���ִ��pfunc�����е����к���
        hr = (*ppfunc)(net, ret);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "", hr);

        if (*ret == 0)
        {
            return HIK_VCA_LIB_S_OK;
        }
    } while (*++ppfunc);

    return HIK_VCA_LIB_S_OK;
}

