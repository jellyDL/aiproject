/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: softmax_layer.c
* �ļ���ʶ: SOFTMAX_LAYER_C
* ժ    Ҫ: softmax��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-02
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <string.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#include "cnn_half.h"
#include "cnn_basic_kernel.h"
#endif // CNN_CUDA_OPT
#include <stdio.h>
#include <math.h>
#include "softmax_layer.h"

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: softmax_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_compute_in_out_shape(SOFTMAX_LAYER *softmax_layer,
                                         LAYER_DATA    *ld)
{
    int i = 0;

    HKA_CHECK_ERROR(ld->input_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    if (softmax_layer->model->axis < 0)
    {
        softmax_layer->model->axis += ld->input_blobs[0]->ndims;
    }

    ld->output_blobs[0].ndims       = ld->input_blobs[0]->ndims;
    ld->output_blobs[0].shape[0]    = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].shape[1]    = ld->input_blobs[0]->shape[1];
    ld->output_blobs[0].shape[2]    = ld->input_blobs[0]->shape[2];
    ld->output_blobs[0].shape[3]    = ld->input_blobs[0]->shape[3];
    ld->output_blobs[0].type        = cnn_get_blob_type();                //softmaxʼ����fp32�����������������fp16�������Ҳ��fp16

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_Reshape(void       *handle,
                            LAYER_DATA *ld)
{
    HRESULT        hr;
    SOFTMAX_LAYER *softmax_layer = (SOFTMAX_LAYER *)handle;
    
    hr = CNN_SOFTMAX_compute_in_out_shape(softmax_layer, ld);
    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, "CNN_SOFTMAX_compute_in_out_shape error", hr);

    softmax_layer->max_aggregator.ndims    = ld->output_blobs[0].ndims;
    softmax_layer->max_aggregator.shape[0] = ld->output_blobs[0].shape[0];
    softmax_layer->max_aggregator.shape[1] = ld->output_blobs[0].shape[1];
    softmax_layer->max_aggregator.shape[2] = ld->output_blobs[0].shape[2];
    softmax_layer->max_aggregator.shape[3] = ld->output_blobs[0].shape[3];
    softmax_layer->max_aggregator.type = cnn_get_blob_type();                //softmaxʼ����fp32�����������������fp16�������Ҳ��fp16

    softmax_layer->max_aggregator.shape[softmax_layer->model->axis] = 1;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         softmax_layer          - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_init_model(const char    *hyperparams,
                         const char    *param_blobs,
                         LAYER_MODEL    *ld,
                         SOFTMAX_MODEL *softmax_model)
{
    int         r;
    const char  axis[] = "axis";
    const char *ptr;

    softmax_model->axis = 1;
    if ((NULL != hyperparams) && (ptr = strstr(hyperparams, axis)))
    {
        r = sscanf(ptr + strlen(axis) + 1, "%d", &softmax_model->axis);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }
    
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_Create(LAYER_DATA *ld,
                           CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                           void      **handle)
{
    int            hr;
    SOFTMAX_LAYER *softmax_layer;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#else
    cpu_data_buf = NULL;
#endif

    softmax_layer = (SOFTMAX_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                      CNN_SIZE_ALIGN(sizeof(SOFTMAX_LAYER)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(softmax_layer);

    softmax_layer->model = ld->layer_model->model_handle;

    hr = CNN_SOFTMAX_Reshape(softmax_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    if (ld->input_blobs[0]->type == CNN_DT_FLT16)
    {
        ld->output_blobs[0].data_gpu = CNN_alloc_buffer(gpu_data_buf, 
                                                        CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float)), 
                                                        CNN_CUDA_MEM_ALIGNMENT, 
                                                        0);
        CNN_CHECK_ERROR(ld->output_blobs[0].data_gpu == NULL, "cnn_alloc_blob_buffer", HIK_VCA_LIB_E_MEM_OUT);

        //softmaxʼ����fp32,����һsoftmax���滹��ʹ��fp16�Ĳ㣬��������ݴ�����һ��
        //���softmax�����һ�㣬��data_gpu��Ϊ���
        ld->output_blobs[0].data_gpu_fp16 = CNN_alloc_buffer(gpu_data_buf, 
                                                             CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]) * sizeof(short)), 
                                                             CNN_CUDA_MEM_ALIGNMENT, 
                                                             0);
        CNN_CHECK_ERROR(ld->output_blobs[0].data_gpu_fp16 == NULL, "cnn_alloc_blob_buffer", HIK_VCA_LIB_E_MEM_OUT);

        //softmaxʼ����fp32,����ڴ����ڽ��ϲ��fp16ת��fp32
        softmax_layer->prev_out_gpu = CNN_alloc_buffer(gpu_data_buf, 
                                                       CNN_SIZE_ALIGN(sizeof(float) * CNN_BLOB_GetDataNum(&ld->output_blobs[0])), 
                                                       CNN_CUDA_MEM_ALIGNMENT, 
                                                       0);
        CNN_CHECK_ERROR(softmax_layer->prev_out_gpu == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);

        softmax_layer->input_unzip = CNN_alloc_buffer(gpu_data_buf, 
                                                      CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[0]) * sizeof(short)), 
                                                      CNN_CUDA_MEM_ALIGNMENT,
                                                      0);
        CNN_CHECK_ERROR(softmax_layer->input_unzip == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);

        softmax_layer->output_zip = CNN_alloc_buffer(gpu_data_buf, 
                                                     CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]) * sizeof(short)), 
                                                     CNN_CUDA_MEM_ALIGNMENT,
                                                     0);
        CNN_CHECK_ERROR(softmax_layer->output_zip == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);
    }
    else
    {
        hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                                   cpu_data_buf,
                                   gpu_data_buf,                                                
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);
    }

    hr = cnn_alloc_blob_buffer(&softmax_layer->max_aggregator,
                               cpu_data_buf,
                               NULL,                                                
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    *handle = softmax_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_GetMemsize(LAYER_DATA    *ld,
                               VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT       hr;
    SOFTMAX_LAYER softmax_layer;

    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2 *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *gpu_data_tab   = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_data_tab = NULL;
#else
    cpu_data_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    softmax_layer.model = ld->layer_model->model_handle;

    hr = CNN_SOFTMAX_Reshape(&softmax_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
        
    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(SOFTMAX_LAYER)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(gpu_data_tab, 
                       CNN_SIZE_ALIGN(sizeof(float) * CNN_BLOB_GetDataNum(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_GPU);

    if (ld->input_blobs[0]->type == CNN_DT_FLT16)
    {
        // softmaxʼ��ʹ��fp32����������ڴ����ڽ���һ���fp16����ת��fp32
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           gpu_data_tab->size + CNN_SIZE_ALIGN(sizeof(float) * CNN_BLOB_GetDataNum(ld->input_blobs[0])),
                           CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

        // ���softmax������Ҳ������һ�㣬����뽫softmax fp32�����ת����fp16
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           gpu_data_tab->size + CNN_SIZE_ALIGN(sizeof(short) * CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0])), 
                           CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

        // ��������unzip
        CNN_BASE_SetMemTab(gpu_data_tab,
                           gpu_data_tab->size + CNN_SIZE_ALIGN(sizeof(short) * CNN_BLOB_GetDataNum(ld->input_blobs[0])), 
                           CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
        // �������zip
        CNN_BASE_SetMemTab(gpu_data_tab,
                           gpu_data_tab->size + CNN_SIZE_ALIGN(sizeof(short) * CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0])), 
                           CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    }

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       CNN_SIZE_ALIGN(sizeof(float) * CNN_BLOB_GetDataNum(&ld->output_blobs[0])) +
                       CNN_SIZE_ALIGN(sizeof(float) * CNN_BLOB_GetDataNum(&softmax_layer.max_aggregator)), 
                       CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_SOFTMAX_CreateModel(const char *hyperparams,
                                const char *param_blobs,
                                LAYER_MODEL *ld,
                                CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
                                void      **handle)
{
    int            hr;
    SOFTMAX_MODEL *softmax_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    softmax_model = (SOFTMAX_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
                                                      CNN_SIZE_ALIGN(sizeof(SOFTMAX_MODEL)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(softmax_model);

    hr = CNN_SOFTMAX_init_model(hyperparams, param_blobs, ld, softmax_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = softmax_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_SOFTMAX_GetModelMemsize(const char    *hyperparams,
                                    const char    *param_blobs,
                                    LAYER_MODEL    *ld,
                                    VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT         hr;
    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(SOFTMAX_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ԭ�ؼ���blob��ÿ�����ݵ�exp
* ��  ��: blob                   - I/O blobָ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_SOFTMAX_blob_exp(CNN_BLOB *blob)
{
    float *data = (float *)blob->data;
    int    n    = CNN_BLOB_GetDataNum(blob);
    int    i;

    for (i = 0; i < n; i++)
    {
        data[i] = expf(data[i]);
    }
}


/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_Forward(void       *handle,
                            LAYER_DATA *ld)
{
    SOFTMAX_LAYER *softmax_layer = (SOFTMAX_LAYER *)handle;
    CNN_BLOB      *src           = ld->input_blobs[0];
    CNN_BLOB      *dst           = &ld->output_blobs[0];

    float *src_ptr = CNN_BLOB_GetPtr(src, 0, 0, 0, 0);
    float *dst_ptr = CNN_BLOB_GetPtr(dst, 0, 0, 0, 0);
    float *buf_ptr = CNN_BLOB_GetPtr(&softmax_layer->max_aggregator, 0, 0, 0, 0);

    int outer_size = CNN_BLOB_GetTotal(src, 0, softmax_layer->model->axis);
    int channels   = src->shape[softmax_layer->model->axis];
    int inner_size = CNN_BLOB_GetTotal(src, softmax_layer->model->axis + 1, src->ndims);

    int outer_step = CNN_BLOB_GetTotal(src, softmax_layer->model->axis, src->ndims);
    int cn_step = CNN_BLOB_GetTotal(src, softmax_layer->model->axis + 1, src->ndims);

    int i;
    int cn_dim;
    int outer_dim;
    int src_offset;
    int buf_offset;

    // compute max along axis
    for (outer_dim = 0; outer_dim < outer_size; outer_dim++)
    {
        src_offset = outer_dim * outer_step;
        buf_offset = outer_dim * cn_step;

        memcpy(buf_ptr + buf_offset, src_ptr + src_offset, inner_size * data_type_size[src->type]);

        for (cn_dim = 1; cn_dim < channels; cn_dim++)
        {
            for (i = 0; i < inner_size; i++)
            {
                buf_ptr[buf_offset + i] = HKA_MAX(buf_ptr[buf_offset + i], src_ptr[src_offset + cn_dim * cn_step + i]);
            }
        }
    }

    // subtract max
    for (outer_dim = 0; outer_dim < outer_size; outer_dim++)
    {
        src_offset = outer_dim * outer_step;
        buf_offset = outer_dim * cn_step;

        for (cn_dim = 0; cn_dim < channels; cn_dim++)
        {
            for (i = 0; i < inner_size; i++)
            {
                dst_ptr[src_offset + cn_dim * cn_step + i] = 
                    src_ptr[src_offset + cn_dim * cn_step + i] - buf_ptr[buf_offset + i];
            }
        }
    }

    CNN_SOFTMAX_blob_exp(dst);

    for (outer_dim = 0; outer_dim < outer_size; outer_dim++)
    {
        src_offset = outer_dim * outer_step;
        buf_offset = outer_dim * cn_step;

        // sum exp along axis
        for (i = 0; i < inner_size; i++)
        {
            buf_ptr[buf_offset + i] = 0.f;
        }

        for (cn_dim = 0; cn_dim < channels; cn_dim++)
        {
            for (i = 0; i < inner_size; i++)
            {
                buf_ptr[buf_offset + i] += dst_ptr[src_offset + cn_dim * cn_step + i];
            }
        }

        // divide by computed sum
        for (cn_dim = 0; cn_dim < channels; cn_dim++)
        {
            for (i = 0; i < inner_size; i++)
            {
                dst_ptr[src_offset + cn_dim * cn_step + i] /= buf_ptr[buf_offset + i];
//                 if(dst_ptr[src_offset + cn_dim * cn_step + i] > 0.5)
//                 printf("i : %d  dst_ptr: %f\n", cn_dim, dst_ptr[src_offset + cn_dim * cn_step + i]);
            }
        }
    }
    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

HRESULT static cnn_softmax_forward_cudnn(CNN_CUDNN_HANDLE           *cnn_cudnn_handle,
                                         float_t                    *in_data,
                                         float_t                    *out_data,
                                         BLOB_DATA_TYPE             type,
                                         int                        n,
                                         int                        c,
                                         int                        h,
                                         int                        w)  
{
    cudnnHandle_t                   cudnn_handle    = cnn_cudnn_handle->cudnn_handle;
    cudnnStatus_t                   cudnn_sts;

    float                           alpha           = 1.0f;
    float                           beta            = 0.0f;
    cudnnSoftmaxAlgorithm_t         algo            = CUDNN_SOFTMAX_ACCURATE;
    //cudnnSoftmaxMode_t              mode            = (n == 1) ? CUDNN_SOFTMAX_MODE_CHANNEL : CUDNN_SOFTMAX_MODE_INSTANCE;
    cudnnSoftmaxMode_t              mode            = CUDNN_SOFTMAX_MODE_CHANNEL;
    //cudnnSoftmaxMode_t              mode            = CUDNN_SOFTMAX_MODE_INSTANCE;
    cudnnTensorDescriptor_t         dst_tensor_desc = cnn_cudnn_handle->dstTensorDesc;
    cudnnTensorDescriptor_t         src_tensor_desc = cnn_cudnn_handle->srcTensorDesc;

    cudnnTensorFormat_t             format          = CUDNN_TENSOR_NCHW;
    cudnnDataType_t                 data_type       = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;

    cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc, format, data_type, n, c, h, w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensor4dDescriptor", CNN_convert_cudnn_error_code(cudnn_sts));
    cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc, format, data_type, n, c, h, w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensor4dDescriptor", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnSoftmaxForward(cudnn_handle, 
                                    algo, 
                                    mode, 
                                    &alpha, 
                                    src_tensor_desc, 
                                    in_data, 
                                    &beta,
                                    dst_tensor_desc, 
                                    out_data);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSoftmaxForward", CNN_convert_cudnn_error_code(cudnn_sts));

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: 
*         softmax_layer          - I/O softmax layer
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_SOFTMAX_Forward_Cuda_Opt(SOFTMAX_LAYER         *softmax_layer,
                                     LAYER_DATA            *ld)
{
    CNN_BLOB                   *src            = ld->input_blobs[0];
    CNN_BLOB                   *dst            = &ld->output_blobs[0];
    HRESULT                     hr;
    BLOB_DATA_TYPE              type;
    cudaError_t                 err;
    BLOB_DATA_FORMAT            format         = src->format;

    void                       *src_data       = src->data_gpu;
    void                       *dst_data       = dst->data_gpu;

    int                         i;

    void                       *input_temp, *output_temp;

    input_temp                  = softmax_layer->input_unzip;
    output_temp                 = softmax_layer->output_zip;

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "format not support", CNN_CUDA_NOT_IMPLEMENT);
	type                        = src->type;

    if (type == CNN_DT_FLT16)
    {
        //fp16�汾��src->data_gpuΪNULL
        src->data_gpu  = softmax_layer->prev_out_gpu;
        src_data       = softmax_layer->prev_out_gpu;

        // �ж�format��pad
        if (format == CNN_FORMAT_NCHW_ZIP)
        {
#ifdef ARCH_SUPPORT_FP16
            hr = CNN_unzip_and_unpad(src->data_gpu_fp16,
                                     input_temp,
                                     src->shape[0],
                                     src->shape[1],
                                     src->shape[2],
                                     src->shape[3],
                                     src->pad.pad_h,
                                     src->pad.pad_w);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_unzip_and_unpad", hr);

            err = cudaMemcpy(src->data_gpu_fp16, 
                             input_temp, 
                             CNN_BLOB_GetDataNum(src) * sizeof(short),
                             cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
#endif
        }

        //softmaxʼ����fp32����
        hr = cnn_blob_half2float(src);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float failed", hr);
    }

    hr = cnn_softmax_forward_cudnn(&ld->cuda_handle->cudnn_handle,
                                   src_data,
                                   dst_data,
                                   CNN_DT_FLT32,
                                   src->shape[0],
                                   src->shape[1],
                                   src->shape[2],
                                   src->shape[3]);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_softmax_forward_cudnn failed", hr);

    if (type == CNN_DT_FLT16)
    {
        hr                  = cnn_blob_float2half(dst);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half failed", hr);

        // ֻ����softmax��������������²Ż����
        if (dst->format == CNN_FORMAT_NCHW_ZIP)
        {
#ifdef ARCH_SUPPORT_FP16
            // softmax�������һ��
            if (ld->layer_model->layer_output.out_num > 0)
            {
                // ����pad
                hr = CNN_zip_and_pad(dst->data_gpu_fp16, 
                                     output_temp,
                                     dst->shape[0],
                                     dst->shape[1],
                                     dst->shape[2],
                                     dst->shape[3],
                                     dst->pad.pad_h,
                                     dst->pad.pad_w);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_zip_and_pad", hr);

                err = cudaMemcpy(dst->data_gpu_fp16, 
                                 output_temp, 
                                 CNN_BLOB_GetDataNum_padded(dst) * sizeof(short),
                                 cudaMemcpyDeviceToDevice);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cudaMemcpy", CNN_convert_cudart_error_code(err));
            }
#endif
        }
    }

    return HIK_VCA_LIB_S_OK;
}


#endif //CNN_CUDA_OPT