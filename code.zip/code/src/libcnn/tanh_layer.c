/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: tanh_layer.c
* �ļ���ʶ: TANH_LAYER_C
* ժ    Ҫ: tanh��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ��ѩ��
* ��    ��: 2016-06-23
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <math.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#include "act_layer_cuda.h"
#endif // CNN_CUDA_OPT
#include "tanh_layer.h"

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_TANH_init(const char *hyperparams,
	const char *param_blobs,
	LAYER_MODEL *ld,
	TANH_MODEL *tanh_model)
{
	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_TANH_Reshape(void       *handle,
	LAYER_DATA *ld)
{
	int bi;

	for (bi = 0; bi < ld->output_blobs_num; bi++)
	{
		memcpy(&ld->output_blobs[bi].shape, 
               ld->input_blobs[bi]->shape,
               sizeof(SHAPE_UNIT_TYPE) * CNN_BLOB_MAX_DIM);

        ld->output_blobs[bi].ndims          = ld->input_blobs[bi]->ndims;
        ld->output_blobs[bi].type           = ld->input_blobs[bi]->type;
        ld->output_blobs[bi].format         = ld->input_blobs[bi]->format;
        ld->output_blobs[bi].data           = ld->input_blobs[bi]->data;
        ld->output_blobs[bi].data_gpu       = ld->input_blobs[bi]->data_gpu;
        ld->output_blobs[bi].data_gpu_fp16  = ld->input_blobs[bi]->data_gpu_fp16;
	}

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_TANH_Create(LAYER_DATA *ld,
	CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
	void      **handle)
{
	HRESULT     hr;
	TANH_LAYER *tanh_layer;

	CNN_BUF *cpu_handle_buf = &mem_buf[0];

	HKA_CHECK_ERROR(ld->input_blobs_num != ld->output_blobs_num, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(0 == ld->input_blobs_num, HIK_VCA_CNN_MODEL_ERROR);

	tanh_layer = (TANH_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
		CNN_SIZE_ALIGN(sizeof(TANH_LAYER)),
		CNN_MEM_ALIGN_SIZE,
		1);
	HKA_CHECK_MEMOUT(tanh_layer);

	tanh_layer->model = ld->layer_model->model_handle;

	hr = CNN_TANH_Reshape(tanh_layer, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	*handle = tanh_layer;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_TANH_GetMemsize(LAYER_DATA    *ld,
	VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
	HRESULT         hr;
	VCA_MEM_TAB_V2 *cpu_handle_tab = mem_tab;

	memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

	CNN_BASE_SetMemTab(cpu_handle_tab,
		CNN_SIZE_ALIGN(sizeof(TANH_LAYER)),
		CNN_MEM_ALIGN_SIZE,
		VCA_MEM_PERSIST,
		VCA_MEM_PLAT_CPU);

	hr = CNN_TANH_Reshape(NULL, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_TANH_CreateModel(const char *hyperparams,
	const char *param_blobs,
	LAYER_MODEL *ld,
	CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
	void      **handle)
{
	HRESULT     hr;
	TANH_MODEL *tanh_model;

	CNN_BUF *cpu_handle_buf = &mem_buf[0];

	tanh_model = (TANH_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
		CNN_SIZE_ALIGN(sizeof(TANH_MODEL)),
		CNN_MEM_ALIGN_SIZE,
		1);
	HKA_CHECK_MEMOUT(tanh_model);

	//hr = CNN_RELU_init(hyperparams, param_blobs, ld, tanh_model);
	//HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	*handle = tanh_model;

	return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_TANH_GetModelMemsize(const char    *hyperparams,
	                             const char    *param_blobs,
	                             LAYER_MODEL    *ld,
	                             VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
	VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

	memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

	CNN_BASE_SetMemTab(cpu_handle_tab,
		               CNN_SIZE_ALIGN(sizeof(TANH_MODEL)),
		               CNN_MEM_ALIGN_SIZE,
		               VCA_MEM_PERSIST,
		               VCA_MEM_PLAT_CPU);

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_TANH_Forward(void       *handle,
	                     LAYER_DATA *ld)
{
	int         i, bi;
	int         blob_data_num;
	float       exp_z, exp_nz;
	TANH_LAYER *tanh_layer = (TANH_LAYER *)handle;


	if (CNN_DT_FLT32 == ld->output_blobs[0].type)
	{
		for (bi = 0; bi < ld->output_blobs_num; bi++)
		{
			float *data = (float *)ld->output_blobs[bi].data;
			blob_data_num = CNN_BLOB_GetDataNum(&ld->output_blobs[0]);
			for (i = 0; i < blob_data_num; i++)
			{
				exp_z = exp(data[i]);
				exp_nz = 1.0f / exp_z;
				data[i] = (exp_z - exp_nz) / (exp_z + exp_nz);
			}
		}
	}
    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

static HRESULT cnn_tanh_forward_cudnn(CNN_CUDNN_HANDLE          *cnn_cudnn_handle,
	                                  float_t                   *data,
	                                  BLOB_DATA_TYPE             type,
	                                  int                        n,
	                                  int                        c,
	                                  int                        h,
	                                  int                        w)
{
	return cnn_act_forward_cudnn(cnn_cudnn_handle, data, type, n, c, h, w, CUDNN_ACTIVATION_TANH);
}

/***************************************************************************************************
* ��  ��: tanh��ǰ�򴫲�(CUDA��)
* ��  ��:
*           relu_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_TANH_Forward_Cuda_Opt(TANH_LAYER         *tanh_layer,
	                              LAYER_DATA         *ld)
{
    HRESULT hr;
    CNN_CUDNN_HANDLE *cnn_cudnn_handle = &ld->cuda_handle->cudnn_handle;
    BLOB_DATA_TYPE type = ld->output_blobs[0].type;
    void *data = ld->output_blobs[0].data_gpu;
    CNN_BLOB *in_blob = ld->input_blobs[0];

    type = ld->output_blobs[0].type;

    if (type == CNN_DT_FLT16)
    {
        data = ld->output_blobs[0].data_gpu_fp16;
    }

    if (in_blob->format == CNN_FORMAT_NCHW)
    {
        hr = cnn_tanh_forward_cudnn(cnn_cudnn_handle,
                                    data,
                                    type,
                                    ld->output_blobs[0].shape[0],
                                    ld->output_blobs[0].shape[1],
                                    ld->output_blobs[0].shape[2],
                                    ld->output_blobs[0].shape[3]);
    }
    else
    {
#ifdef ARCH_SUPPORT_FP16
        hr = cnn_tanh_forward_zip(data, //��������H=1,W=1�����
                                   data,
                                   type,
                                   ld->output_blobs[0].shape[0],
                                   ld->output_blobs[0].shape[1],
                                   ld->output_blobs[0].shape[2],
                                   ld->output_blobs[0].shape[3],
                                   0,
                                   0);
#endif
	}

    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_tanh_forward_cudnn", hr);
    return HIK_VCA_LIB_S_OK;
}

#endif  // CNN_CUDA_OPT