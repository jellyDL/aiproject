/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: normalize_layer.c
* �ļ���ʶ: NORMALIZE_LAYER_C
* ժ    Ҫ: normalize��ĺ���ʵ��
*
* ��ʼ�汾: 1.0.0
* ��    ��: ��ѩ��
* ��    ��: 2016-06-23
* ��    ע:
* ��ǰ�汾: 1.0.1
* ��    ��: Ѧ����
* ��    ��: 2016-09-12
* ��    ע: �޸�GPU�汾��ʵ��(ֱ�ӵ���CPU�汾)
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif

#include <string.h>
#include <stdio.h>
#include <math.h>
#ifdef CNN_CUDA_OPT
#include <cublas_v2.h>
#include "math_functions_cuda.h"
#endif // CNN_CUDA_OPT
#include "normalize_layer.h"
#ifdef MKL_OPT
#include "mkl_cblas.h"
#else
#include "cblas.h"
#endif
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NORMALZIE_init(const char *hyperparams,
	                       const char *param_blobs,
	                       LAYER_MODEL *ld,
	                       NORMALIZE_MODEL *normalize_model)
{
	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NORMALIZE_Reshape(void       *handle,
	                          LAYER_DATA *ld)
{
	int bi;
	for (bi = 0; bi < ld->output_blobs_num; bi++)
	{
		ld->output_blobs[bi] = *ld->input_blobs[bi];
	}

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NORMALIZE_Create(LAYER_DATA *ld,
	                         CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
	                         void      **handle)
{
	HRESULT     hr;
	NORMALIZE_LAYER *normalize_layer;
    int         i;

	CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

	HKA_CHECK_ERROR(ld->input_blobs_num != ld->output_blobs_num, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(0 == ld->input_blobs_num, HIK_VCA_CNN_MODEL_ERROR);

	normalize_layer = (NORMALIZE_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
		                                                  CNN_SIZE_ALIGN(sizeof(NORMALIZE_LAYER)),
		                                                  CNN_MEM_ALIGN_SIZE,
		                                                  1);
	HKA_CHECK_MEMOUT(normalize_layer);

	normalize_layer->model = ld->layer_model->model_handle;

	hr = CNN_NORMALIZE_Reshape(normalize_layer, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

#ifdef CNN_CUDA_OPT
    for (i = 0; i < ld->output_blobs_num; i++)
    {
        normalize_layer->prev_out[i].data = CNN_alloc_buffer(cpu_data_buf,
		                                                     CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[i]) * sizeof(float)),
		                                                     CNN_MEM_ALIGN_SIZE,
		                                                     0);
        CNN_CHECK_ERROR(normalize_layer->prev_out[i].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }

#ifdef ARCH_SUPPORT_FP16
    for (i = 0; i < ld->output_blobs_num; i++)
    {
        normalize_layer->prev_out[i].data_gpu = CNN_alloc_buffer(gpu_data_buf,
		                                                         CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[i]) * sizeof(float)),
		                                                         CNN_MEM_ALIGN_SIZE,
		                                                         0);
        CNN_CHECK_ERROR(normalize_layer->prev_out[i].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }
#endif
#endif


	*handle = normalize_layer;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NORMALIZE_GetMemsize(LAYER_DATA    *ld,
	                             VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
	HRESULT         hr;
	VCA_MEM_TAB_V2 *cpu_handle_tab = mem_tab;
    VCA_MEM_TAB_V2 *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *gpu_data_tab   = &mem_tab[2];

    int             i;

	memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

	CNN_BASE_SetMemTab(cpu_handle_tab,
		               CNN_SIZE_ALIGN(sizeof(NORMALIZE_LAYER)),
		               CNN_MEM_ALIGN_SIZE,
		               VCA_MEM_PERSIST,
		               VCA_MEM_PLAT_CPU);

	hr = CNN_NORMALIZE_Reshape(NULL, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    for (i = 0; i < ld->output_blobs_num; i++)
    {
#ifdef CNN_CUDA_OPT
        CNN_BASE_SetMemTab(cpu_data_tab,
		                   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[i]) * sizeof(float)),
		                   CNN_MEM_ALIGN_SIZE,
		                   VCA_MEM_PERSIST,
		                   VCA_MEM_PLAT_CPU);


#ifdef ARCH_SUPPORT_FP16
        CNN_BASE_SetMemTab(gpu_data_tab,
		                   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[i]) * sizeof(float)),
		                   CNN_MEM_ALIGN_SIZE,
		                   VCA_MEM_PERSIST,
		                   VCA_MEM_PLAT_GPU);
#endif

#endif
    }

	return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_NORMALIZE_CreateModel(const char *hyperparams,
	                              const char *param_blobs,
	                              LAYER_MODEL *ld,
	                              CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
	                              void      **handle)
{
	NORMALIZE_MODEL *normalize_model;

	CNN_BUF *cpu_handle_buf = &mem_buf[0];

	normalize_model = (NORMALIZE_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
		                                                  CNN_SIZE_ALIGN(sizeof(NORMALIZE_MODEL)),
		                                                  CNN_MEM_ALIGN_SIZE,
		                                                  1);
	HKA_CHECK_MEMOUT(normalize_model);

	*handle = normalize_model;

	return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_NORMALIZE_GetModelMemsize(const char    *hyperparams,
	                                  const char    *param_blobs,
	                                  LAYER_MODEL    *ld,
	                                  VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
	VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

	memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

	CNN_BASE_SetMemTab(cpu_handle_tab,
		               CNN_SIZE_ALIGN(sizeof(NORMALIZE_MODEL)),
		               CNN_MEM_ALIGN_SIZE,
		               VCA_MEM_PERSIST,
		               VCA_MEM_PLAT_CPU);

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
void CNN_NORMALIZE_Forward(void       *handle,
	                       LAYER_DATA *ld)
{
	int         i, bi, ni;
	int         data_len;
	float       scale;

	NORMALIZE_LAYER *normalize_layer = (NORMALIZE_LAYER *)handle;
	ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

	//if (CNN_DT_FLT32 == ld->output_blobs[0].type)
	{
		for (bi = 0; bi < ld->output_blobs_num; bi++)
		{
			float *data = (float *)ld->output_blobs[bi].data;
			//��ȡ���ݳ���

			data_len = ld->output_blobs[bi].shape[1] * ld->output_blobs[bi].shape[2] * ld->output_blobs[bi].shape[3];
			for ( ni = 0; ni < ld->output_blobs[bi].shape[0]; ni++)
			{
				//�����ڻ�
				scale = 0;
				for (i = 0; i < data_len; i++)
				{
					scale += data[data_len*ni + i] * data[data_len*ni + i];
				}
				//scale = cblas_sasum(data_len, data + data_len*ni, 1);
				scale = 1.0 / sqrtf(scale);
				//��һ��
                for (i = 0; i < data_len; i++)
                {
                    data[i] *= scale;
                }
			}
		}
	}
}

#ifdef CNN_CUDA_OPT

#if 0 //by �ղ�
/***************************************************************************************************
* ��  ��: Normalize��ǰ�򴫲�(CUDA��)
* ��  ��:
*           tanh_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_NORMALIZE_Forward_Cuda_Opt(NORMALIZE_LAYER         *normalize_layer,
	                                   LAYER_DATA              *ld)
{
	int                     i, bi, ni;
	int                     blob_data_num;
	float                   d;
	float                   scale;
	int                     data_len;
	//HRESULT                 hr;
	BLOB_DATA_TYPE          type = ld->output_blobs[0].type;
	float                   *data;
	CNN_CUDA_HANDLE         *cnn_cuda_handle   = ld->cuda_handle;
	cublasStatus_t          cublas_status;

	ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

    //OPT_PROFILE_TIME_BY_EVENT_START(100);

	//��֧��32λ�汾
	if (CNN_DT_FLT32 == ld->output_blobs[0].type)
	{
		for (bi = 0; bi < ld->output_blobs_num; bi++)
		{
			float *data = (float *)ld->output_blobs[bi].data_gpu;
			//��ȡ���ݳ���

			data_len = ld->output_blobs[bi].shape[1] * ld->output_blobs[bi].shape[2] * ld->output_blobs[bi].shape[3];
			for (ni = 0; ni < ld->output_blobs[bi].shape[0]; ni++)
			{
				//�����ڻ�
				//cnn_pow_cuda(data_len, data + data_len*ni, 2, data + data_len*ni);

				cublas_status = cublasSdot_v2(cnn_cuda_handle->cublas_handle.cublas_handle, data_len, data + data_len*ni, 1, data + data_len*ni, 1, &scale);
				CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "cnn_normalize_forward_cuda cublasSasum_v2 failed", cublas_status);
				scale = 1.0 / sqrtf(scale);
				//��һ��
				cublas_status = cublasSscal_v2(cnn_cuda_handle->cublas_handle.cublas_handle, data_len, &scale, data + data_len*ni, 1);
				CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "cnn_normalize_forward_cuda cublasSscal_v2 failed", CNN_convert_cublas_error_code(cublas_status));
			}
		}
	}

    //OPT_PROFILE_TIME_BY_EVENT_STOP(100, "NORM", 1, 1);

	//CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_normalize_forward_cuda", hr);

	return HIK_VCA_LIB_S_OK;
}
#endif


/***************************************************************************************************
* ��  ��: Normalize��ǰ�򴫲�(����CPU�汾)
* ��  ��:
*           tanh_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_NORMALIZE_Forward_Cuda_Opt(NORMALIZE_LAYER    *normalize_layer,
	                                   LAYER_DATA         *ld)
{
    BLOB_DATA_TYPE    type       = ld->output_blobs[0].type;
    BLOB_DATA_FORMAT  format     = ld->output_blobs[0].format;
    HRESULT           hr;
    cudaError_t       err;

    CNN_BLOB          *out_blob  = &ld->output_blobs[0];
    CNN_BLOB          *in_blob   = ld->input_blobs[0];
    CNN_BLOB          *prev_blob = &normalize_layer->prev_out[0];

    void               *temp     = out_blob->data;

    CNN_CHECK_ERROR(ld->output_blobs_num != 1, "ld->output_blobs_num != 1", HIK_VCA_CNN_MODEL_ERROR);
    CNN_CHECK_ERROR(format != CNN_FORMAT_NCHW, "format not support", CNN_CUDA_NOT_IMPLEMENT);

    //��������GPU����CPU
    if (CNN_DT_FLT32 == type) 
    {
        err = cudaMemcpy(prev_blob->data,
                         out_blob->data_gpu,
                         CNN_BLOB_GetDataNum(out_blob) * sizeof(float),
                         cudaMemcpyDeviceToHost);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
    }
    else if (CNN_DT_FLT16 == type)
    {
        hr = cnn_half2float(in_blob->data_gpu_fp16, prev_blob->data_gpu, CNN_BLOB_GetDataNum(in_blob));
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_half2float", hr);

        err = cudaMemcpy(prev_blob->data,
                         prev_blob->data_gpu,
                         CNN_BLOB_GetDataNum(in_blob) * sizeof(float),
                         cudaMemcpyDeviceToHost);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
    }
    else
    {
        CNN_CHECK_ERROR(1, "data type not support", CNN_CUDA_NOT_IMPLEMENT);
    }

    CNN_CHECK_ERROR(out_blob->data != NULL, "out_blob->data != NULL", HIK_VCA_LIB_KEY_PARAM_ERR);

    out_blob->data = prev_blob->data;

    CNN_NORMALIZE_Forward(normalize_layer, ld);

    //��������CPU����GPU
    if (CNN_DT_FLT32 == type)
    {
        err = cudaMemcpy(out_blob->data_gpu,
                         prev_blob->data,
                         CNN_BLOB_GetDataNum(out_blob) * sizeof(float),
                         cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
    }
    else if (CNN_DT_FLT16 == type)
    {
        err = cudaMemcpy(prev_blob->data_gpu,
                         out_blob->data,
                         CNN_BLOB_GetDataNum(out_blob) * sizeof(float),
                         cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

        hr = cnn_float2half(prev_blob->data_gpu, out_blob->data_gpu_fp16, CNN_BLOB_GetDataNum(out_blob));
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_float2half", hr);
    }
    else
    {
        printf("data type not support\n");
        return HIK_VCA_LIB_KEY_PARAM_ERR;
    }

    out_blob->data = temp;
	return HIK_VCA_LIB_S_OK;
}


#endif  // CNN_CUDA_OPT