/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: reshape_layer.c
* �ļ���ʶ: RESHAPE_LAYER_C
* ժ    Ҫ: reshape��Ľṹ��ͺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-19
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "reshape_layer.h"
#include "cnn_common.h"

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RESHAPE_Reshape(void       *handle,
                            LAYER_DATA *ld)
{
    int            i, sum, num;
    int            minus_one_dim;
    RESHAPE_LAYER *reshape_layer = (RESHAPE_LAYER *)handle;

    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);

    for (i = 0; i < CNN_BLOB_MAX_DIM; i++)
    {
        ld->output_blobs[0].shape[i] = 1;
    }

    num           = 0;
    sum           = 1;
    minus_one_dim = -1;
    for (i = 0; i < ld->input_blobs[0]->ndims; i++)
    {
        if (-1 == reshape_layer->model->reshape_param[i])
        {
            minus_one_dim = i;
            num++;
        }
        else if (0 == reshape_layer->model->reshape_param[i])
        {
            ld->output_blobs[0].shape[i] = ld->input_blobs[0]->shape[i];
            sum *= ld->output_blobs[0].shape[i];
        }
        else
        {
            ld->output_blobs[0].shape[i] = reshape_layer->model->reshape_param[i];
            sum *= ld->output_blobs[0].shape[i];
        }
    }
    HKA_CHECK_ERROR(num > 1, HIK_VCA_CNN_MODEL_ERROR);

    if (-1 != minus_one_dim)
    {
        if (sum == 0)
        {
            ld->output_blobs[0].shape[minus_one_dim] = 0;
        }
        else
        {
            ld->output_blobs[0].shape[minus_one_dim] = CNN_BLOB_GetDataNum(ld->input_blobs[0]) / sum;
        }
    }
    if (CNN_BLOB_GetDataNum(ld->input_blobs[0]) != CNN_BLOB_GetDataNum(&ld->output_blobs[0]))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

#ifdef CNN_CUDA_OPT
    CNN_CHECK_ERROR(ld->input_blobs_num != 1, "ld->input_blobs_num != 1", CNN_CUDA_NOT_IMPLEMENT);
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         reshape_layer          - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RESHAPE_init_model(const char    *hyperparams,
                               const char    *param_blobs,
                               LAYER_MODEL    *ld,
                               RESHAPE_MODEL *reshape_model)
{
    int         r, i, n;
    int         num = 0;
    const char  dim[] = "dim";
    const char *ptr;

    HKA_CHECK_ERROR(ld->input_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    ptr = hyperparams;
    ptr = strstr(ptr, dim);
    HKA_CHECK_PTR(ptr);
    ptr += strlen(dim) + 1;

    for (i = 0; i < CNN_BLOB_MAX_DIM; i++)
    {
        r = sscanf(ptr, "%d%n", &reshape_model->reshape_param[i], &n);
        CNN_CHECK_ERROR(1 != r, "reshape_param must have 4 dim", HIK_VCA_CNN_MODEL_ERROR);

        ptr += n + 1;

        if (reshape_model->reshape_param[i] == -1)
        {
            num++;
        }
    }

    CNN_CHECK_ERROR(num > 1, "CNN_RESHAPE_init_model: more than one (reshape_param == -1)", 
        HIK_VCA_CNN_MODEL_ERROR);
    
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RESHAPE_Create(LAYER_DATA *ld,
                           CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                           void      **handle)
{
    int            hr;
    RESHAPE_LAYER *reshape_layer;

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

    reshape_layer = (RESHAPE_LAYER *)CNN_alloc_buffer(&mem_buf[0],
                                                      CNN_SIZE_ALIGN(sizeof(RESHAPE_LAYER)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(reshape_layer);

    reshape_layer->model = ld->layer_model->model_handle;

    ld->output_blobs[0] = *ld->input_blobs[0];

    hr = CNN_RESHAPE_Reshape(reshape_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = reshape_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RESHAPE_GetMemsize(LAYER_DATA    *ld,
                               VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT         hr;
    RESHAPE_LAYER   reshape_layer;
    VCA_MEM_TAB_V2 *cpu_handle_tab = mem_tab;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    reshape_layer.model = ld->layer_model->model_handle;

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(RESHAPE_LAYER)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    ld->output_blobs[0] = *ld->input_blobs[0];

    hr = CNN_RESHAPE_Reshape(&reshape_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_RESHAPE_CreateModel(const char *hyperparams,
                                const char *param_blobs,
                                LAYER_MODEL *ld,
                                CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
                                void      **handle)
{
    int            hr;
    RESHAPE_MODEL *reshape_model;

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

    reshape_model = (RESHAPE_MODEL *)CNN_alloc_buffer(&mem_buf[0],
                                                      CNN_SIZE_ALIGN(sizeof(RESHAPE_MODEL)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(reshape_model);

    hr = CNN_RESHAPE_init_model(hyperparams, param_blobs, ld, reshape_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = reshape_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_RESHAPE_GetModelMemsize(const char    *hyperparams,
                                    const char    *param_blobs,
                                    LAYER_MODEL    *ld,
                                    VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(RESHAPE_MODEL)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_RESHAPE_Forward(void       *handle,
                            LAYER_DATA *ld)
{
    CNN_RESHAPE_Reshape(handle, ld);
    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_RESHAPE_Forward_Cuda_Opt(RESHAPE_LAYER *reshape_layer,
                                     LAYER_DATA    *ld)
{
    int                  i;
    int                  temp           = -1;
    int                  count_size_in  = 1;
    int                  count_size_out = 1;
    CNN_BLOB            *output         = &ld->output_blobs[0];
    CNN_BLOB            *input          = ld->input_blobs[0];
    BLOB_DATA_FORMAT     format         = input->format;
    HRESULT              hr;
    cudaError_t          err;

    hr = CNN_RESHAPE_Reshape(reshape_layer, ld);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_RESHAPE_Reshape", hr);

    return HIK_VCA_LIB_S_OK;
}

#endif
