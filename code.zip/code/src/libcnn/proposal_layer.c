/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: proposal_layer.c
* �ļ���ʶ: PROPOSAL_LAYER_C
* ժ    Ҫ: PROPOSAL��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-17
* ��    ע:
*
* �ļ�����: proposal_layer.c
* �ļ���ʶ: PROPOSAL_LAYER_C
* ժ    Ҫ: PROPOSAL��ĺ���ʵ��
*
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "cnn_basic_kernel.h"
#include "cnn_cuda_error.h"
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

#endif  //CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "proposal_layer.h"
#include "proposal_layer_cuda.h"
#include "_ipgs_sort.h"
#include "rpnlayer.h"

//#define  CNN_PROPOSAL_NVOPT             // ʹ��nvidia�ṩ��proposal�Ż�

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: proposal_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_compute_in_out_shape(PROPOSAL_LAYER *proposal_layer,
                                          LAYER_DATA     *ld)
{
    int n;                             // batch num

    HKA_CHECK_PTR(proposal_layer);
    HKA_CHECK_PTR(ld);

    HKA_CHECK_ERROR(ld->input_blobs_num != 3, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[1]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[2]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    n = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].ndims    = 4;
    ld->output_blobs[0].type     = CNN_DT_FLT32;
    ld->output_blobs[0].shape[3] = 1;
    ld->output_blobs[0].shape[2] = 1;
    ld->output_blobs[0].shape[1] = 5;                                        // index x1 y1 x2 y2
    ld->output_blobs[0].shape[0] = n * proposal_layer->model->post_nms_topN; // n images

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Reshape(void       *handle,
                             LAYER_DATA *ld)
{
    
    int     i;
    HRESULT hr;

    hr = CNN_PROPOSAL_compute_in_out_shape((PROPOSAL_LAYER *)handle, ld);
    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, "CNN_PROPOSAL_compute_in_out_shape error", hr);

    for (i = 0; i < ld->input_blobs[0]->ndims; i++)
    {
        if (ld->input_blobs[0]->shape[i] != ld->input_blobs[1]->shape[i])
        {
            if (i == 1)
            {
                if (ld->input_blobs[0]->shape[i] * 2 != ld->input_blobs[1]->shape[i])
                {
                    return HIK_VCA_CNN_MODEL_ERROR;
                }
            }
            else
            {
                return HIK_VCA_CNN_MODEL_ERROR;
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_init_model(const char     *hyperparams,
                                const char     *param_blobs,
                                LAYER_MODEL     *ld,
                                PROPOSAL_MODEL *proposal_model)
{
    int r, i, j;

    const char feat_stride[]   = "stride";
    const char pre_nms_topN[]  = "pre_nms_top_n";
    const char post_nms_topN[] = "post_nms_top_n";

    const char nms_thresh[]    = "nms_thresh";
    const char anchor_scales[] = "anchor_scales";

    const char *ptr = NULL;
    int         K;
    int         w;
    int         ii;

    HKA_CHECK_PTR(proposal_model);

    proposal_model->feat_stride   = 16;
    proposal_model->pre_nms_topN  = 6000;
    proposal_model->post_nms_topN = 300;
    proposal_model->nms_thresh    = 0.7;

    ptr = strstr(hyperparams, feat_stride);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(feat_stride) + 1, "%d", &proposal_model->feat_stride);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if (proposal_model->feat_stride < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, pre_nms_topN);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(pre_nms_topN) + 1, "%d", &proposal_model->pre_nms_topN);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if (proposal_model->pre_nms_topN < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, post_nms_topN);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(post_nms_topN) + 1, "%d", &proposal_model->post_nms_topN);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((proposal_model->post_nms_topN < 0) || (proposal_model->post_nms_topN > proposal_model->pre_nms_topN))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, nms_thresh);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(nms_thresh) + 1, "%f", &proposal_model->nms_thresh);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((proposal_model->nms_thresh < 0) || (proposal_model->nms_thresh > 1))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, anchor_scales);
    HKA_CHECK_PTR(ptr);
    proposal_model->anchor_scales_num = 0;
    i = 1;
    do
    {
        // ע��Ҫдһ����� anchor���ܳ���10��
        r = sscanf(ptr + strlen(anchor_scales) + i, "%d", &proposal_model->anchor_scales[proposal_model->anchor_scales_num]);
        if (r == 1)
        {
            HKA_CHECK_ERROR(proposal_model->anchor_scales[proposal_model->anchor_scales_num] <= 0, HIK_VCA_CNN_MODEL_ERROR);
            // i��ƫ����
            i += (2 + (int)log10(proposal_model->anchor_scales[proposal_model->anchor_scales_num]));
            proposal_model->anchor_scales_num++;
        }
    } while (1 == r);

    HKA_CHECK_ERROR((0 == proposal_model->anchor_scales_num), HIK_VCA_CNN_MODEL_ERROR);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��anchor
* ��  ��:


* ����ֵ: ��
***************************************************************************************************/
static void CNN_Proposal_init_anchor(PROPOSAL_LAYER         *proposal_layer,
                                     LAYER_DATA             *ld)
{
    int                     i, j, p, q, s, A;
    CNN_BLOB			    *input_score    = ld->input_blobs[0];          //����score����
    float                   *temp           = NULL;

    int                     feat_stride = proposal_layer->model->feat_stride;
    int                     height          = input_score->shape[2];
    int                     width           = input_score->shape[3];

    //��һ���жϣ���С���ܳ���MAX_SIZE
    int                     K               = width * height;

    int                     *shifts         = NULL;
    int                     *shift_x        = NULL;
    int                     *shift_y        = NULL;

    int                     shifts_height   = K;
    int                     shifts_width    = 4;

    //anchors
    float                   *anchors        = NULL;

    int                     anchors_size_temp = proposal_layer->temp_data.anchors_size;

    float                   ratios[3]       = { 0.5, 1, 2 };                            //ÿ���anchor����
    int                     num_anchor;

    temp                                    = proposal_layer->temp_data.temp;

    shifts                                  = (int*)temp;
    shift_x                                 = (int*)temp + 4 * K;
    shift_y                                 = (int*)temp + 4 * K + width;
    anchors                                 = proposal_layer->temp_data.anchors;

    //Enumerate all shifts
	for (i = 0; i < width; i++)
	{
		*(shift_x + i) = i * proposal_layer->model->feat_stride;
	}
	for (i = 0; i < height; i++)
	{
        *(shift_y + i) = i * proposal_layer->model->feat_stride;
	}

	for (i = 0; i < shifts_height; i++)
	{
		for (j = 0; j < shifts_width; j++)
		{
			//����ܱ�2����
			if ((j % 2) == 0)
			{
				*(shifts + i * shifts_width + j) = *(shift_x + i % width);
			}
			else
			{
				*(shifts + i * shifts_width + j) = *(shift_y + i / width);
			}
		}
	}

	//����anchor
    CNN_PROPOSAL_generate_anchors(feat_stride, ratios, proposal_layer->model->anchor_scales, proposal_layer->model->anchor_scales_num, &proposal_layer->anchor); //*****
	num_anchor = (proposal_layer->anchor.scales_num * 3);   //anchorһ��������

	A = num_anchor;
	
	for (p = 0; p < K; p++)
	{
		for (i = 0; i < A; i++)
		{
			for (j = 0; j < 4; j++)
			{
				*(anchors + p * A * 4 + i * 4 + j) = *(proposal_layer->anchor.data + i * 4 + j) + *(shifts + p * 4 + j);  //***
			}
		}
	}

}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_init_layer(LAYER_DATA     *ld,
    PROPOSAL_LAYER *proposal_layer)
{
    int     r, j;
    HRESULT hr;

    const char *ptr = NULL;
    int         K;
    int         c, w, h;

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(proposal_layer);

    proposal_layer->min_size = proposal_layer->model->feat_stride;

    hr = CNN_PROPOSAL_Reshape(proposal_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // im_info = (float*)ld->input_blobs[2]->data;
    // ����temp_anchors�Ĵ�С
    c = ld->input_blobs[0]->shape[1];
    h = ld->input_blobs[0]->shape[2];
    w = ld->input_blobs[0]->shape[3];
    K = h * w;
    proposal_layer->temp_data.anchors_size = (proposal_layer->model->anchor_scales_num * 3) * K * 4;

    proposal_layer->temp_data.temp_size = CNN_SIZE_ALIGN(5 * K + w + h);
    proposal_layer->temp_data.temp_size += CNN_SIZE_ALIGN(c * K * 2);
    proposal_layer->temp_data.temp_size += CNN_SIZE_ALIGN(c * K);

    return HIK_VCA_LIB_S_OK;
}



/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Create(LAYER_DATA *ld,
                            CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                            void      **handle)
{
    int             hr;
    PROPOSAL_LAYER *proposal_layer;

    int nms_table_size;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#endif

    proposal_layer = (PROPOSAL_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                        CNN_SIZE_ALIGN(sizeof(PROPOSAL_LAYER)),
                                                        CNN_MEM_ALIGN_SIZE,
                                                        1);
    HKA_CHECK_MEMOUT(proposal_layer);

    proposal_layer->model = (PROPOSAL_MODEL*)ld->layer_model->model_handle;

    hr = CNN_PROPOSAL_init_layer(ld, proposal_layer);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
     ld->output_blobs[0].data = CNN_alloc_buffer(cpu_data_buf,
                                                 CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float),
                                                 CNN_MEM_ALIGN_SIZE,
                                                 0);
     CNN_CHECK_ERROR(ld->output_blobs[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     CNN_CHECK_ERROR(ld->output_blobs[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     proposal_layer->temp_data.temp = (float *)CNN_alloc_buffer(cpu_data_buf,
                                                       proposal_layer->temp_data.temp_size * sizeof(float),
                                                       CNN_MEM_ALIGN_SIZE,
                                                       0);
     CNN_CHECK_ERROR(proposal_layer->temp_data.temp == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     proposal_layer->temp_data.anchors = (float *)CNN_alloc_buffer(cpu_data_buf,
                                                          proposal_layer->temp_data.anchors_size * sizeof(float),
                                                          CNN_MEM_ALIGN_SIZE,
                                                          0);
     CNN_CHECK_ERROR(proposal_layer->temp_data.anchors == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     ld->output_blobs[0].data_gpu       = NULL;
     ld->output_blobs[0].data_gpu_fp16  = NULL;

     if (gpu_data_buf)
     {
        ld->output_blobs[0].data_gpu = CNN_alloc_buffer(gpu_data_buf,
                                                        CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float),
                                                        CNN_MEM_ALIGN_SIZE,
                                                        0);
        CNN_CHECK_ERROR(ld->output_blobs[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
     }

#ifdef CNN_CUDA_OPT
      /*----------------------------------------------nms���--------------------------------------*/
     nms_table_size = (proposal_layer->model->pre_nms_topN + PROPOSAL_BLOCK_SIZE - 1) / PROPOSAL_BLOCK_SIZE * sizeof(long long);
     proposal_layer->nms_remv = (long long *)CNN_alloc_buffer(cpu_data_buf,
                                                 CNN_SIZE_ALIGN(nms_table_size),
                                                 CNN_MEM_ALIGN_SIZE,
                                                 0);
     CNN_CHECK_ERROR(proposal_layer->nms_remv == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     nms_table_size *= proposal_layer->model->pre_nms_topN;
     proposal_layer->nms_table = (long long *)CNN_alloc_buffer(cpu_data_buf,
                                                  CNN_SIZE_ALIGN(nms_table_size),
                                                  CNN_MEM_ALIGN_SIZE,
                                                  0);
     CNN_CHECK_ERROR(proposal_layer->nms_table == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     proposal_layer->nms_keep = (int *)CNN_alloc_buffer(cpu_data_buf,
         CNN_SIZE_ALIGN(proposal_layer->model->post_nms_topN * sizeof(int)),
                                                 CNN_MEM_ALIGN_SIZE,
                                                 0);
     CNN_CHECK_ERROR(proposal_layer->nms_keep == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
     /*-------------------------------------------------------------------------------------------*/

    //�����ϲ�box�����CPU�ڴ�
    proposal_layer->prev_out[0].data = CNN_alloc_buffer(cpu_data_buf, 
        CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[1]) * sizeof(float)), 
        CNN_MEM_ALIGN_SIZE, 
        0);
    CNN_CHECK_ERROR(proposal_layer->prev_out[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->prev_out[0].data_gpu        = NULL;
    proposal_layer->prev_out[0].data_gpu_fp16   = NULL;
    proposal_layer->prev_out[0].type            = CNN_DT_FLT32;

    //�����ϲ�score�����CPU�ڴ�
    proposal_layer->prev_out[1].data            = CNN_alloc_buffer(cpu_data_buf, 
                                                                   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[0]) * sizeof(float)), 
                                                                   CNN_MEM_ALIGN_SIZE, 
                                                                   0);
    CNN_CHECK_ERROR(proposal_layer->prev_out[1].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->prev_out[1].data_gpu        = NULL;
    proposal_layer->prev_out[1].data_gpu_fp16   = NULL;
    proposal_layer->prev_out[1].type            = CNN_DT_FLT32;

    proposal_layer->proposal_gpu                = (float*)CNN_alloc_buffer(gpu_data_buf,
        CNN_SIZE_ALIGN(proposal_layer->model->pre_nms_topN * sizeof(float) * 4),
                                                                   CNN_CUDA_MEM_ALIGNMENT,
                                                                   0);
    CNN_CHECK_ERROR(proposal_layer->proposal_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     proposal_layer->nms_table_gpu          = (long long *)CNN_alloc_buffer(gpu_data_buf,
                                                               CNN_SIZE_ALIGN(nms_table_size),
                                                               CNN_CUDA_MEM_ALIGNMENT,
                                                               0);
     CNN_CHECK_ERROR(proposal_layer->nms_table_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

#ifdef CNN_PROPOSAL_NVOPT
     //proposal_layer->workspace_dev = (float*)CNN_alloc_buffer(gpu_data_buf,
     //                CNN_SIZE_ALIGN(proposal_layer->model->pre_nms_topN * sizeof(float)* 4),
     //                CNN_CUDA_MEM_ALIGNMENT,
     //                0);
     //CNN_CHECK_ERROR(proposal_layer->proposal_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
#endif

#endif

    if (ld->input_blobs[1]->type == CNN_DT_FLT16)
    {
        //�����ϲ������GPU�ڴ�(fp32),���ڽ�fp16��GPU�ڴ�ת��fp32, prev_out[0]��box
        proposal_layer->prev_out[0].data_gpu = CNN_alloc_buffer(gpu_data_buf,
                                                                CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)),
                                                                VCA_MEM_ALIGN_128BYTE,
                                                                0);
        CNN_CHECK_ERROR(proposal_layer->prev_out[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

        //prev_out[1]����Ҫ����ڴ棬��Ϊprev_out[1]��softmax�������softmaxʼ����fp32����

        proposal_layer->input_bbox_unzip = CNN_alloc_buffer(gpu_data_buf,
                                                            CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(short)),
                                                            CNN_CUDA_MEM_ALIGNMENT,
                                                            0);
        CNN_CHECK_ERROR(proposal_layer->input_bbox_unzip == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    }

	*handle = proposal_layer;

    proposal_layer->input_height    = ld->input_blobs[1]->shape[2];
    proposal_layer->input_width     = ld->input_blobs[1]->shape[3];
    CNN_Proposal_init_anchor(proposal_layer, ld);

	return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_GetMemsize(LAYER_DATA *ld,
								VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
	int				hr, temp_size;
	PROPOSAL_LAYER  proposal_layer;
    int             nms_table_size;

    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2     *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2     *gpu_data_tab   = &mem_tab[2];

#ifdef CNN_PROPOSAL_NVOPT
    size_t rproi_workspace;
#endif

    HKA_CHECK_PTR(ld);

	memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    proposal_layer.model = (PROPOSAL_MODEL *)ld->layer_model->model_handle;

	hr = CNN_PROPOSAL_init_layer(ld, &proposal_layer);    
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    temp_size = proposal_layer.temp_data.anchors_size + proposal_layer.temp_data.temp_size;

    CNN_BASE_SetMemTab(cpu_handle_tab, 
                       CNN_SIZE_ALIGN(sizeof(PROPOSAL_LAYER)), 
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab,
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float)), 
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(proposal_layer.temp_data.anchors_size * sizeof(float)), 
                       VCA_MEM_ALIGN_128BYTE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(proposal_layer.temp_data.temp_size * sizeof(float)), 
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

#ifdef CNN_CUDA_OPT
    //nms_remv
    nms_table_size  = (proposal_layer.model->pre_nms_topN + PROPOSAL_BLOCK_SIZE - 1) / PROPOSAL_BLOCK_SIZE * sizeof(long long);
    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size),
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    //nms_table
    nms_table_size *= proposal_layer.model->pre_nms_topN;
    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size), 
                       VCA_MEM_ALIGN_128BYTE,
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    //nms_keep
    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(proposal_layer.model->post_nms_topN * sizeof(int)), 
                       VCA_MEM_ALIGN_128BYTE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);
    
    CNN_BASE_SetMemTab(gpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0])), 
                       VCA_MEM_ALIGN_128BYTE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_GPU);

    CNN_BASE_SetMemTab(gpu_data_tab,
                       gpu_data_tab->size + 
                       CNN_SIZE_ALIGN(proposal_layer.model->pre_nms_topN * sizeof(float) * 4),
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_GPU);

    CNN_BASE_SetMemTab(gpu_data_tab, 
                       gpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size), 
                       VCA_MEM_ALIGN_128BYTE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_GPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[1]) * sizeof(float)), 
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[0]) * sizeof(float)), 
                       VCA_MEM_ALIGN_128BYTE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);
#endif

    if (ld->input_blobs[1]->type == CNN_DT_FLT16)
    {
        //�����ϲ������GPU�ڴ�(fp32),���ڽ�fp16��GPU�ڴ�ת��fp32, prev_out[0]��box
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           gpu_data_tab->size + 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)) + 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(short)),   // ����unzip box data
                           VCA_MEM_ALIGN_128BYTE, 
                           VCA_MEM_PERSIST,
                           VCA_MEM_PLAT_GPU);


    }

#ifdef CNN_PROPOSAL_NVOPT
    //rproi_workspace = RPROIInferenceFusedWorkspaceSize(ld->input_blobs[1]->shape[0],
    //                                                   proposal_layer.model->anchor_scales_num * 3,
    //                                                   ld->input_blobs[1]->shape[2],
    //                                                   ld->input_blobs[1]->shape[3],
    //                                                   proposal_layer.model->post_nms_topN);
    //CNN_BASE_SetMemTab(gpu_data_tab, 
    //                   gpu_data_tab->size + CNN_SIZE_ALIGN(rproi_workspace),
    //                   VCA_MEM_ALIGN_128BYTE, 
    //                   VCA_MEM_PERSIST,
    //                   VCA_MEM_PLAT_GPU);
#endif

	return HIK_VCA_LIB_S_OK;
}


HRESULT CNN_PROPOSAL_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);    

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(PROPOSAL_MODEL)), VCA_MEM_ALIGN_128BYTE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_PROPOSAL_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    int                      hr, i;
    PROPOSAL_MODEL          *proposal_model;
    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];

    proposal_model = (PROPOSAL_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(PROPOSAL_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(proposal_model);
    
    hr = CNN_PROPOSAL_init_model(hyperparams, param_blobs, ld, proposal_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = proposal_model;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Forward(void       *handle,
                             LAYER_DATA *ld)
{
    int             i, j, p, q, A, n;
    PROPOSAL_LAYER *proposal_layer = (PROPOSAL_LAYER *)handle;

    CNN_BLOB *input_score = ld->input_blobs[0];                            // ����score����
    CNN_BLOB *input_bbox  = ld->input_blobs[1];                            // ����bbox����
    CNN_BLOB  temp_blob1, temp_blob2;
    CNN_BLOB *perim_score = &temp_blob1;
    CNN_BLOB *perim_bbox  = &temp_blob2;

    const CNN_BLOB *im_info = ld->input_blobs[2];                          // ͼƬ����

    CNN_BLOB *output_roi = &ld->output_blobs[0];                           // ���blobs
    CNN_BLOB  proposals;

    float *temp_anchors = NULL;
    float *temp         = NULL;

    // ������Щ����init������
    // ÿ���anchor����  //���֮����Էŵ���������ȥ
    float  ratios[3]   = { 0.5, 1, 2 };
    int    feat_stride = proposal_layer->model->feat_stride;
    int    num_anchor;
    int    min_size      = proposal_layer->min_size;
    int    pre_num_topN  = proposal_layer->model->pre_nms_topN;
    int    post_num_topN = proposal_layer->model->post_nms_topN;
    float  nms_thresh    = proposal_layer->model->nms_thresh;
    int    half_c;
    float *score;
    float *bbox_deltas;
    // im_size 0 1 scale 3 ����Ϊ��ͳһ������float��ʽ
    // float *im_info_data = (float*)im_info->data;
    int height = input_score->shape[2];
    int width  = input_score->shape[3];
    // ��С���ܳ���MAX_SIZE
    int K = width * height;

    int *shifts  = NULL;
    int *shift_x = NULL;
    int *shift_y = NULL;

    int shifts_height = K;
    int shifts_width  = 4;

    // anchors
    float *anchors = NULL;
    int    anchors_size[2];

    // bbox_deltas_trans
    float *bbox_deltas_trans = NULL;
    // scores
    float *scores = NULL;

    // ����Ϊforward�ı��� ��ʾbatch�ڵ�ͼ������
    int im_num = input_score->shape[0];

    int input_score_shape[4];
    int input_bbox_shape[4];

    int anchors_size_temp = proposal_layer->temp_data.anchors_size;

    // ��temp_data���ӵ�layer�����ṹ����
    temp_anchors = proposal_layer->temp_data.anchors;
    temp         = proposal_layer->temp_data.temp;

    shifts  = (int *)temp;
    shift_x = (int *)temp + 4 * K;
    shift_y = (int *)temp + 4 * K + width;
    anchors = temp_anchors;
    // ����ԭ��shape
    memcpy(input_score_shape, input_score->shape, 4 * sizeof(int));
    memcpy(input_bbox_shape, input_bbox->shape, 4 * sizeof(int));

    /********Enumerate all shifts*********************/
    for (i = 0; i < width; i++)
    {
        *(shift_x + i) = i * proposal_layer->model->feat_stride;
    }
    for (i = 0; i < height; i++)
    {
        *(shift_y + i) = i * proposal_layer->model->feat_stride;
    }

    for (i = 0; i < shifts_height; i++)
    {
        for (j = 0; j < shifts_width; j++)
        {
            // ����ܱ�2����
            if (0 == (j % 2))
            {
                *(shifts + i * shifts_width + j) = *(shift_x + i % width);
            }
            else
            {
                *(shifts + i * shifts_width + j) = *(shift_y + i / width);
            }
        }
    }
    /*******************************************************/

    // ����anchor
    CNN_PROPOSAL_generate_anchors(feat_stride, ratios, proposal_layer->model->anchor_scales,
        proposal_layer->model->anchor_scales_num, &proposal_layer->anchor);
    num_anchor = (proposal_layer->anchor.scales_num * 3);   // anchorһ��������
    // ����proposals
    A = num_anchor;
    for (p = 0; p < K; p++)
    {
        for (i = 0; i < A; i++)
        {
            for (j = 0; j < 4; j++)
            {
                *(anchors + p * A * 4 + i * 4 + j) =
                    *(proposal_layer->anchor.data + i * 4 + j) + *(shifts + p * 4 + j);
            }
        }
    }
    anchors_size[0] = K * A;
    anchors_size[1] = 4;
    // ����shifts,shift_x,shift_y������

    // ѭ��im_num��ͼƬ
    output_roi->shape[0] = 0;
    for (n = 0; n < im_num; n++)
    {
        memcpy(perim_score->shape, input_score_shape, 4 * sizeof(int));
        memcpy(perim_bbox->shape, input_bbox_shape, 4 * sizeof(int));
        perim_score->shape[0] = 1;
        perim_bbox->shape[0]  = 1;

        // input_scoreһ���λ�ã���Ϊǰһ����neg���ʣ���һ����pos���ʣ���һ��Ϊ��������Ҫ
        half_c = perim_score->shape[1]
                 * perim_score->shape[2]
                 * perim_score->shape[3] / 2;
        // ������Ҫ��score����ʼλ��
        perim_score->data = (void *)((float *)input_score->data + n * 2 * half_c);        // ��Ҫ�����n��batch n��0��ʼ
        score             = (float *)perim_score->data + half_c;
        // bbox���޶�ƫ��ֵ
        perim_bbox->data = (void *)((float *)input_bbox->data + n * 4 * half_c);
        bbox_deltas      = (float *)perim_bbox->data;

        // bbox_deltas
        bbox_deltas_trans = temp;  // ��Ҫ�ߴ�4*A*W*H

        // for (i = 0; i < input_bbox->shape[0]; i++)
        for (i = 0; i < perim_bbox->shape[0]; i++)
        {
            for (j = 0; j < perim_bbox->shape[2]; j++)
            {
                for (p = 0; p < perim_bbox->shape[3]; p++)
                {
                    for (q = 0; q < perim_bbox->shape[1]; q++)
                    {
                        *(bbox_deltas_trans + i * perim_bbox->shape[2] * perim_bbox->shape[3] * perim_bbox->shape[1]
                          + j * perim_bbox->shape[3] * perim_bbox->shape[1]
                          + p * perim_bbox->shape[1] + q) =
                            *(bbox_deltas + i * perim_bbox->shape[2] * perim_bbox->shape[3] * perim_bbox->shape[1]
                              + q * perim_bbox->shape[2] * perim_bbox->shape[3]
                              + j * perim_bbox->shape[3] + p);
                    }
                }
            }
        }
        j = perim_bbox->shape[1] * perim_bbox->shape[2] * perim_bbox->shape[3];   // input_bbox->shape[0]
        memcpy(bbox_deltas, bbox_deltas_trans, j * sizeof(float));

        perim_bbox->shape[0] = 1;
        perim_bbox->shape[1] = 1;
        perim_bbox->shape[2] = j >> 2;
        perim_bbox->shape[3] = 4;

        // scores
        scores = temp;

        // for (i = 0; i < input_score->shape[0]; i++)
        for (i = 0; i < perim_score->shape[0]; i++)
        {
            for (j = 0; j < perim_score->shape[2]; j++)
            {
                for (p = 0; p < perim_score->shape[3]; p++)
                {
                    for (q = 0; q < (perim_score->shape[1] >> 1); q++)
                    {
                        *(scores + i * perim_score->shape[2] * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                          + j * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                          + p * (perim_score->shape[1] >> 1) + q) =
                            *(score + i * perim_score->shape[2] * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                              + q * perim_score->shape[2] * perim_score->shape[3]
                              + j * perim_score->shape[3] + p);
                    }
                }
            }
        }
        j = ((perim_score->shape[1]) * (perim_score->shape[2]) * (perim_score->shape[3])) >> 1;   // (input_score->shape[0]) *
        memcpy((score - half_c), scores, j * sizeof(float));

        perim_score->shape[0] = 1;
        perim_score->shape[1] = 1;
        perim_score->shape[2] = j;
        perim_score->shape[3] = 1;

        proposals.shape[0] = 1;
        proposals.shape[1] = 1;
        proposals.shape[2] = perim_score->shape[2];
        proposals.shape[3] = 4;

        proposals.data = (void *)(temp);

        // ����proposals
        // CNN_PROPOSAL_bbox_transform_inv(anchors, anchors_size, input_bbox, &proposals);
        CNN_PROPOSAL_bbox_transform_inv(anchors, anchors_size, bbox_deltas, &proposals);
        // �Գ���ͼ���Ե�Ĳ��ֽ��вü�
        CNN_PROPOSAL_clip_boxes(im_info, &proposals);
        // ȥ����С��proposal

        // input_score������û���
        CNN_PROPOSAL_filter_boxes((int)((float)min_size * (*((float *)im_info->data + 2))), &proposals, perim_score);

        // �����¸�Ϊ���ú�������frcnnout_layerһ��ʹ��
        // ��������ȡpre_num_topN��
        CNN_PROPOSAL_argsort(pre_num_topN, &proposals, perim_score);
        // ��nms
        CNN_PROPOSAL_nms(post_num_topN, &proposals, perim_score, nms_thresh);
        // ���
        for (i = 0; i < proposals.shape[2]; i++)
        {
            // *((float*)output_roi->data + 4 * ld->output_blobs[0].shape[2]) = i;//adjust in 3.6
            *((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)n;
            memcpy(((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1),
                   (float *)proposals.data + 4 * i,
                   4 * sizeof(float));
        }
        output_roi->shape[0] += proposals.shape[2];
    }
    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

#if 0
/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Forward_Cuda_Opt(PROPOSAL_LAYER         *proposal_layer,
	                                  LAYER_DATA             *ld)
{

	int                     i, s, j, p, q, A;
	CNN_BLOB			    *input_score        = ld->input_blobs[0];          //����score����
    CNN_BLOB			    *input_bbox		    = ld->input_blobs[1];          //����bbox����
	const CNN_BLOB          *im_info            = ld->input_blobs[2];          //ͼƬ����

	CNN_BLOB                *output_roi         = &ld->output_blobs[0];        //���blobs
	CNN_BLOB                proposals;
    float                   *temp_anchors       = NULL;
    float                   *temp               = NULL;

    HRESULT                 hr;
    BLOB_DATA_TYPE          type;
    cudaError_t             err;

    CNN_BLOB                bbox_deltas_blob    = *input_bbox;
    CNN_BLOB                scores_blob         = *input_score;

    float                   score_value;
    int                     index;

    type                                        = input_bbox->type;

    OPT_PROFILE_TIME_BY_EVENT_START(13);

    if (type == CNN_DT_FLT16)
    {
        input_bbox->data_gpu    = proposal_layer->prev_out[0].data_gpu;
        hr                      = cnn_blob_half2float(input_bbox);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);
    }

    err = cudaMemcpy(proposal_layer->prev_out[0].data, input_bbox->data_gpu, sizeof(float) * CNN_BLOB_GetDataNum(input_bbox), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    input_bbox->data            = proposal_layer->prev_out[0].data;

    bbox_deltas_blob            = *input_bbox;
    scores_blob                 = *input_score;

    //������Щ����init������
	float                   ratios[3]           = { 0.5, 1, 2 };                            //ÿ���anchor����
	int                     feat_stride         = proposal_layer->feat_stride;
	int                     num_anchor;
	int                     min_size            = proposal_layer->min_size;
	int                     pre_num_topN        = proposal_layer->pre_nms_topN;
	int                     post_num_topN       = proposal_layer->post_nms_topN;
	float                   nms_thresh          = proposal_layer->nms_thresh;
	//����Ϊforward�ı���

	//input_scoreһ���λ�ã���Ϊǰһ����neg���ʣ���һ����pos���ʣ���һ��Ϊ��������Ҫ
	int half_c = input_score->shape[1] *
		         input_score->shape[2] *
			     input_score->shape[3] / 2;

	//������Ҫ��score����ʼλ��
	float *score        = (float*)input_score->data + half_c;

	//bbox���޶�ƫ��ֵ
	float *bbox_deltas  = (float*)input_bbox->data;

	int height          = input_score->shape[2];
	int width           = input_score->shape[3];
	
	//��һ���жϣ���С���ܳ���MAX_SIZE
	int K               = width * height;

	//anchors
	float       *anchors        = NULL;
	int         anchors_size[2];

	//bbox_deltas_trans
	float       *bbox_deltas_trans;
	//scores
	float       *scores         = NULL;
    float       kth_score;

    int  anchors_size_temp = proposal_layer->temp_data.anchors_size;

    temp_anchors    = proposal_layer->temp_data.anchors;
    temp            = proposal_layer->temp_data.temp;
    anchors         = temp_anchors;

	num_anchor = (proposal_layer->anchor.scales_num * 3);   //anchorһ��������

	A = num_anchor;
	
	anchors_size[0] = K * A;
	anchors_size[1] = 4;

	//����shifts,shift_x,shift_y������
	//bbox_deltas

    int                 n = input_bbox->shape[0];
    int                 c = input_bbox->shape[1];
    int                 h = input_bbox->shape[2];
    int                 w = input_bbox->shape[3];

    memcpy(temp, score, half_c * sizeof(float));
    kth_score           = temp[_IPGS_QuickSelect_32f(temp, 0, half_c - 1, half_c - pre_num_topN)];

    bbox_deltas_trans   = temp;                                     //��Ҫ�ߴ�4*A*W*H
    scores              = temp + CNN_SIZE_ALIGN(n * h * w * c);

    for (i = 0; i < n; i++)
    {
        s       = 0;
        index   = 0;
        for (j = 0; j < h; j++)
        {
            for (p = 0; p < w; p++)
            {
                for (q = 0; q < c / 4; q++)
                {
                    score_value = score[i * h * w * (c >> 2) + q * h * w + j * w + p];
                    if (score_value > kth_score)
                    {
                        //bbox_delta_trans: n * h * w * c, bbox_deltas: n * c * h * w;
                        //index              = i * h * w * c + (q << 2) * h * w + j * w + p;
                        index                    = (i * c + (q << 2)) * h * w + j * w + p;
                        bbox_deltas_trans[s]     = bbox_deltas[index];
                        bbox_deltas_trans[s + 1] = bbox_deltas[index + h * w];
                        bbox_deltas_trans[s + 2] = bbox_deltas[index + h * w + h * w];
                        bbox_deltas_trans[s + 3] = bbox_deltas[index + h * w + h * w + h * w];
                        scores[s >> 2]           = score[i * h * w * (c >> 2) + q * h * w + j * w + p];
                    }
                    else
                    {
                        scores[s >> 2] = 0.0f;
                    }
                    s += 4;
                }
            }
        }
    }

	memcpy(bbox_deltas, bbox_deltas_trans, n * c * h * w * sizeof(float));

    bbox_deltas_blob.shape[0] = 1;
    bbox_deltas_blob.shape[1] = 1;
    bbox_deltas_blob.shape[2] = n * c * h * w >> 2;
    bbox_deltas_blob.shape[3] = 4;

    n = input_score->shape[0];
    c = input_score->shape[1] >> 1;
    h = input_score->shape[2];
    w = input_score->shape[3];

	memcpy(input_score->data, scores, n * c * h * w * sizeof(float));

    scores_blob.shape[0] = 1;
    scores_blob.shape[1] = 1;
    scores_blob.shape[2] = n * c * h * w;
    scores_blob.shape[3] = 1;

    proposals.shape[0] = 1;
    proposals.shape[1] = 1;
    proposals.shape[2] = bbox_deltas_blob.shape[2];
    proposals.shape[3] = 4;

    proposals.data = temp;

    //����proposals
    //CNN_PROPOSAL_bbox_transform_inv(anchors, anchors_size, &bbox_deltas_blob, &proposals);
    CNN_PROPOSAL_bbox_transform_inv_opt(im_info, 
                                        anchors, 
                                        anchors_size, 
                                        pre_num_topN, 
                                        &bbox_deltas_blob, 
                                        &proposals, 
                                        (float *)input_score->data, 
                                        kth_score);

    //CNN_PROPOSAL_clip_boxes(im_info, &proposals);

    //ȥ����С��proposal
    //filter_boxes((int)((float)min_size * *((float *)im_info->data + 2)), &proposals, &scores_blob);
    CNN_PROPOSAL_filter_boxes_opt((int)((float)min_size * *((float *)im_info->data + 2)), &proposals, &scores_blob, kth_score);

    /*--------------------------------------------------------------------------------------------*/

	//��������ȡpre_num_topN��
	//CNN_PROPOSAL_argsort(pre_num_topN, &proposals, &scores_blob);
    cnn_proposal_argsort_cuda(pre_num_topN, &proposals, &scores_blob);

    CNN_PROPOSAL_nms(post_num_topN, &proposals, &scores_blob, nms_thresh);

    //���
	for (i = 0; i < proposals.shape[2]; i++)
	{
		//*((float*)output_roi->data + 4 * ld->output_blobs[0].shape[2]) = i;//adjust in 3.6
		*((float*)output_roi->data + 5 * i) = (float)0;
		memcpy(((float*)output_roi->data + 5 * i + 1), (float*)proposals.data + 4 * i, 4 * sizeof(float));
	}	

	output_roi->shape[0] = proposals.shape[2];
    OPT_PROFILE_TIME_BY_EVENT_STOP(13, "proposal", 1, 1);

    return HIK_VCA_LIB_S_OK;
}
#endif

/***************************************************************************************************
* ��  ��: �ҵ���Ҫ������proposal
* ��  ��: 
*         keep_out               - O ������Proposal��Index
*         num_out                - O ������Proposal������
*         boxes_gpu              - I ���GPU������
*         nms_table              - I �жϿ�����ص��Ƿ񳬹���ֵ�ı�
*         nms_table              - I �жϿ�����ص��Ƿ񳬹���ֵ�ı�(GPU������)
*         nms_remv               - O ��Ҫȥ���Ŀ�
*         boxex_num              - I nmsǰȫ����ĸ���
*         post_nms_topN          - I nms����ౣ���Ŀ�ĸ���
*         nms_overlap_thresh     - I nms��ֵ
* ����ֵ: ��
***************************************************************************************************/
 HRESULT cnn_proposal_keep_proposal(int                      *keep_out, 
                                    int                      *num_out, 
                                    const float              *boxes_gpu, 
                                    unsigned long long       *nms_table,
                                    unsigned long long       *nms_table_gpu,
                                    unsigned long long       *nms_remv,
                                    int                      boxes_num,
                                    int                      post_nms_topN,
                                    float                    nms_overlap_thresh)
{
    HRESULT             hr;
    cudaError_t         err;
    const int           col_blocks      = (boxes_num + PROPOSAL_BLOCK_SIZE - 1) / PROPOSAL_BLOCK_SIZE;
    int                 nms_table_size  = boxes_num * col_blocks * sizeof(long long);
    int                 num_to_keep     = 0;
    int                 i, j;
    unsigned long long *p;
    int                 nblock;
    int                 inblock;

    if (boxes_num == 0)
    {
        *num_out = 0;
        return HIK_VCA_LIB_S_OK;
    }

    //OPT_PROFILE_TIME_BY_EVENT_START(11);
    hr = cnn_proposal_init_nms_table_cuda(boxes_num, nms_overlap_thresh, boxes_gpu, nms_table_gpu);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_proposal_init_nms_table_cuda", hr);

    //OPT_PROFILE_TIME_BY_EVENT_STOP(11, "nms", 1, 1);

    err = cudaMemcpy(nms_table, nms_table_gpu, nms_table_size, cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    memset(nms_remv, 0, col_blocks * sizeof(long long));

    for (i = 0; i < boxes_num; i++) 
    {
        //nblock  = i / PROPOSAL_BLOCK_SIZE;
        //inblock = i % PROPOSAL_BLOCK_SIZE;

        nblock  = i >> 6;
        inblock = i & 0x3f;

        if (!(nms_remv[nblock] & (1ULL << inblock)) && (num_to_keep < post_nms_topN)) 
        {
            keep_out[num_to_keep++] = i;
            p = &nms_table[0] + i * col_blocks;

            for (j = nblock; j < col_blocks; j++) 
            {
                nms_remv[j] |= p[j];
            }
           
        }
    }

    *num_out = num_to_keep;

    return HIK_VCA_LIB_S_OK;
} 



#ifndef CNN_PROPOSAL_NVOPT  //ʹ��gpu���
/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Forward_Cuda_Opt(PROPOSAL_LAYER         *proposal_layer,
	                                  LAYER_DATA             *ld)
{
    int                     i, s, j, p, q, A, bn;
    CNN_BLOB			   *input_score   = ld->input_blobs[0];           //����score����
    CNN_BLOB			   *input_bbox    = ld->input_blobs[1];           //����bbox����
    const CNN_BLOB         *im_info       = ld->input_blobs[2];           //ͼƬ����
    CNN_BLOB               *output_roi    = &ld->output_blobs[0];         //���blobs
    CNN_BLOB                proposals;
    float                  *temp_anchors  = NULL;
    float                  *temp          = NULL;
    HRESULT                 hr;
    BLOB_DATA_TYPE          type;
    cudaError_t             err;
    float                   score_value;
    int                     index;
    int                     plane_size;
    float                  *proposal_gpu  = proposal_layer->proposal_gpu;
    int                     num_anchor;
    int                     min_size      = proposal_layer->min_size;
    int                     pre_num_topN  = proposal_layer->model->pre_nms_topN;
    int                     post_num_topN = proposal_layer->model->post_nms_topN;
    float                   nms_thresh    = proposal_layer->model->nms_thresh;
    int                     half_c;
    float                  *score;
    float                  *bbox_deltas;
    int                     height, width;
    int                     K;
    float                  *anchors       = NULL;
    float                  *scores        = NULL;
    int                     anchors_size[2];
    float                  *bbox_deltas_trans;
    float                   kth_score;
    char                   *nms_table;
    int                     anchors_size_temp;
    int                     nms_keep_num;
    int                     keep_index;
    int                     n, c, h, w;
    float                  *input_box_data;
    float                  *input_score_data;
    int                     score_num;
    BLOB_DATA_FORMAT        format        = input_bbox->format;

#if 0
    cudaDeviceSynchronize();
    OPT_PROFILE_TIME_BY_EVENT_START(1011);
#endif

    if (format == CNN_FORMAT_NCHW_ZIP)
    {
#ifdef ARCH_SUPPORT_FP16
         hr = CNN_unzip_and_unpad(input_bbox->data_gpu_fp16, 
                                  proposal_layer->input_bbox_unzip, 
                                  input_bbox->shape[0],
                                  input_bbox->shape[1],
                                  input_bbox->shape[2],
                                  input_bbox->shape[3],
                                  input_bbox->pad.pad_h,
                                  input_bbox->pad.pad_w);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_unzip_and_unpad", hr);

        err = cudaMemcpy(input_bbox->data_gpu_fp16, 
                         proposal_layer->input_bbox_unzip, 
                         CNN_BLOB_GetDataNum(input_bbox) * sizeof(short),
                         cudaMemcpyDeviceToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
#endif
    }

    type = input_bbox->type;

    if (type == CNN_DT_FLT16)
    {
        input_bbox->data_gpu    = proposal_layer->prev_out[0].data_gpu;
        hr                      = cnn_blob_half2float(input_bbox);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);
    }

    err = cudaMemcpy(proposal_layer->prev_out[1].data,
                     input_score->data_gpu,
                     sizeof(float) * CNN_BLOB_GetDataNum(input_score),
                     cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    err = cudaMemcpy(proposal_layer->prev_out[0].data,
                     input_bbox->data_gpu,
                     sizeof(float) * CNN_BLOB_GetDataNum(input_bbox),
                     cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));


    input_score->data           = proposal_layer->prev_out[1].data;
    input_box_data              = proposal_layer->prev_out[0].data;

    if ((proposal_layer->input_height != input_bbox->shape[2]) || (proposal_layer->input_width != input_bbox->shape[3]))
    {
        proposal_layer->input_height    = input_bbox->shape[2];
        proposal_layer->input_width     = input_bbox->shape[3];
        CNN_Proposal_init_anchor(proposal_layer, ld);
    }

	//input_scoreһ���λ�ã���Ϊǰһ����neg���ʣ���һ����pos���ʣ���һ��Ϊ��������Ҫ
    half_c                      = input_score->shape[1] *
                                  input_score->shape[2] *
                                  input_score->shape[3] / 2;

	//bbox���޶�ƫ��ֵ

	height                      = input_score->shape[2];
	width                       = input_score->shape[3];
	
	//��һ���жϣ���С���ܳ���MAX_SIZE
	K                           = width * height;
    nms_table                   = proposal_layer->nms_table;
    anchors_size_temp           = proposal_layer->temp_data.anchors_size;
    temp_anchors                = proposal_layer->temp_data.anchors;
    temp                        = proposal_layer->temp_data.temp;
    anchors                     = temp_anchors;
	num_anchor                  = (proposal_layer->anchor.scales_num * 3);   //anchorһ��������
	A                           = num_anchor;
	anchors_size[0]             = K * A;
	anchors_size[1]             = 4;
    output_roi->shape[0]        = 0;

    for (bn = 0; bn < input_score->shape[0]; bn++)
    {
        c           = input_bbox->shape[1];
        h           = input_bbox->shape[2];
        w           = input_bbox->shape[3];
        bbox_deltas = (float*)input_box_data + bn * input_bbox->shape[1] * input_bbox->shape[2] * input_bbox->shape[3];

        //������Ҫ��score����ʼλ��
        score = (float*)input_score->data + bn * h * w * c / 2 + half_c;
        memcpy(temp, score, half_c * sizeof(float));
        kth_score = temp[_IPGS_QuickSelect_32f(temp,
                                               0,
                                               half_c - 1,
                                               (half_c - pre_num_topN) <= 0 ? 1 : half_c - pre_num_topN)];

        bbox_deltas_trans   = temp;                                     //��Ҫ�ߴ�4*A*W*H
        scores              = temp + CNN_SIZE_ALIGN(h * w * c);
        plane_size          = h * w;
        s                   = 0;
        index               = 0;


        for (j = 0; j < h; j++)
        {
            for (p = 0; p < w; p++)
            {
                for (q = 0; q < (c >> 2); q++)
                {
                    score_value = score[q * h * w + j * w + p];
                    if (score_value > kth_score)
                    {
                        index                    = (q << 2) * plane_size + j * w + p;
                        bbox_deltas_trans[s]     = bbox_deltas[index];
                        bbox_deltas_trans[s + 1] = bbox_deltas[index + plane_size];
                        bbox_deltas_trans[s + 2] = bbox_deltas[index + plane_size + plane_size];
                        bbox_deltas_trans[s + 3] = bbox_deltas[index + plane_size + plane_size + plane_size];
                        scores[s >> 2] = score[q * plane_size + j * w + p];
                    }
                    else
                    {
                        scores[s >> 2] = 0.0f;
                    }
                    s += 4;
                }
            }
        }

        memcpy(bbox_deltas, bbox_deltas_trans, h * w * c * sizeof(float));

        proposals.shape[0]  = 1;
        proposals.shape[1]  = 1;
        proposals.shape[2]  = h * w * c >> 2;
        proposals.shape[3]  = 4;

        proposals.data      = temp;

        c   = input_score->shape[1] >> 1;
        h   = input_score->shape[2];
        w   = input_score->shape[3];

        memcpy((float *)input_score->data + bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
                scores,
                h * w * c * sizeof(float));

         //����proposals
        CNN_PROPOSAL_bbox_transform_inv_opt(im_info, 
                                            anchors, 
                                            anchors_size, 
                                            pre_num_topN, 
                                            bbox_deltas,
                                            &proposals, 
                                            (float *)input_score->data +    
                                            bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
                                            kth_score);

        //ȥ����С��proposal
        CNN_PROPOSAL_filter_boxes_opt((int)((float)min_size * *((float *)im_info->data + 2)),
                                      &proposals, 
                                      (float *)input_score->data +
                                      bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
                                      &score_num,
                                      kth_score);

        //��������ȡpre_num_topN��
        cnn_proposal_argsort_cuda(pre_num_topN, 
                                  &proposals,
                                  (float *)input_score->data +
                                  bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
                                  score_num,
                                  &score_num);

        err = cudaMemcpy(proposal_gpu, proposals.data, proposals.shape[2] * sizeof(float) * 4, cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

        //����
        hr = cnn_proposal_keep_proposal(proposal_layer->nms_keep, 
                                        &nms_keep_num, 
                                        proposal_layer->proposal_gpu, 
                                        proposal_layer->nms_table, 
                                        proposal_layer->nms_table_gpu, 
                                        proposal_layer->nms_remv,
                                        proposals.shape[2], 
                                        proposal_layer->model->post_nms_topN,
                                        nms_thresh);
                                        //1.0);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_proposal_keep_proposal", hr);

        proposals.shape[2]      = nms_keep_num;

        //���
        for (i = 0; i < proposals.shape[2]; i++)
        {
            *((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)bn;
            keep_index = proposal_layer->nms_keep[i];

            memcpy(((float*)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1),
                    (float*)proposals.data + 4 * keep_index,
                    4 * sizeof(float));
        }
        if (proposals.shape[2] % 2)
        {
            proposals.shape[2] -= proposals.shape[2] % 2;
        }
        output_roi->shape[0] += proposals.shape[2];

    }

    //printf("roi num cnn: %d\n", output_roi->shape[0]);

#if 0
    for (i = 0; i < output_roi->shape[0]; i++)
    {
        printf("roi: %f %f %f %f\n", *((float *)output_roi->data + 5 * i + 1),
                                     *((float *)output_roi->data + 5 * i + 2),
                                     *((float *)output_roi->data + 5 * i + 3),
                                     *((float *)output_roi->data + 5 * i + 4));
    }
#endif

#if 0
    OPT_PROFILE_TIME_BY_EVENT_STOP(1011, "proposal", 1, 1);
#endif

    return HIK_VCA_LIB_S_OK;
}

#else

extern HRESULT CNN_PROPOSAL_Forward_NV_Opt(PROPOSAL_LAYER *proposal_layer, LAYER_DATA *ld);

/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Forward_Cuda_Opt(PROPOSAL_LAYER         *proposal_layer,
	                                  LAYER_DATA             *ld)
{
    return CNN_PROPOSAL_Forward_NV_Opt(proposal_layer, ld);
}

#endif


#if 0 //���ú��ڴ��ֱ�ӵ���CPU,����汾���ŵ�����
/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_Forward_Cuda_Opt(PROPOSAL_LAYER         *proposal_layer,
	                                  LAYER_DATA             *ld)
{
    BLOB_DATA_TYPE          type;
    cudaError_t             err;
    CNN_BLOB                *input_bbox  = ld->input_blobs[1];
    CNN_BLOB                *input_score = ld->input_blobs[0];

    HRESULT                 hr;

    type = input_bbox->type;

    if (type == CNN_DT_FLT16)
    {
        input_bbox->data_gpu    = proposal_layer->prev_out[0].data_gpu;
        hr                      = cnn_blob_half2float(input_bbox);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);
    }

    err = cudaMemcpy(proposal_layer->prev_out[1].data, input_score->data_gpu, sizeof(float) * CNN_BLOB_GetDataNum(input_score), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    err = cudaMemcpy(proposal_layer->prev_out[0].data, input_bbox->data_gpu, sizeof(float) * CNN_BLOB_GetDataNum(input_bbox), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    input_bbox->data            = proposal_layer->prev_out[0].data;
    input_score->data           = proposal_layer->prev_out[1].data;

    CNN_PROPOSAL_Forward(proposal_layer, ld);

    return HIK_VCA_LIB_S_OK;
}
#endif

#endif  //CNN_CUDA_OPT
