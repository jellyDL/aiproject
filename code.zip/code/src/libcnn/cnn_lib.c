/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: cnn_lib.c
* �ļ���ʶ: CNN_LIB_C
* ժ    Ҫ: ͨ��CNN�㷨���
*
* ��ǰ�汾: 3.0.0
* ��    ��: ̷����
* ��    ��: 2016-10-8
* ��    ע: �������ܣ�
*          1���µ�ģ��ת�����߽�prototxt�е����ֱ�����bin�ļ��У�������Ӷ����ֵĽ���
*
* ��ǰ�汾: 2.1.0
* ��    ��: ̷����
* ��    ��: 2016-5-31
* ��    ע: �������ܣ�
*          1��һ�δ���֮�󣬿����ò�ͬ��С���������process��
*          2��faster-rcnn��ش���֧��֧��ͬʱ�������ͼƬ���м�⡣
*          3���޸Ľӿڣ���model�Ĵ���������������Զ��̸߳��á�
*
* ��ǰ�汾: 2.0.0
* ��    ��: ̷����
* ��    ��: 2016-1-29
* ��    ע: һ��ȫ�µ��㷨�⣬֧�����¹��ܣ�
*        1��֧�����������޻�ͼ������ṹ��CNN��ܣ�
*        2��֧��conv��pool��fully connected��softmax��lrn��concat������
*           ��֧��googlenet-v1��googlenet-v2��vgg�����Ƶ��������ͣ������ڷ������ȡ������
*        3��֧��deconvolution������֧��Ŀ��ָ
*        4��֧��faster-rcnn����ʵ��Ŀ���⣻
*
* ��ʷ�汾: 1.1.1
* ��    ��: ����
* ��    ��: 2015-12-31
* ��    ע: �޸Ľӿ�HIKCNN_get_model_info��ֱ�Ӵ�ģ��������ȡģ����Ϣ
*
* ��ʷ�汾: 1.1.1
* ��    ��: ����
* ��    ��: 2015-12-16
* ��    ע: �ع�cnn�㷨�����������ڴ����ģ��޸Ľӿڣ�֧�����ָ���������������������ȡ
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN

#include "cnn_redef.h"
#include "cnnfp16_lib.h"

#define     HKA_CNN_PARAM               HKA_CNNFP16_PARAM
#define     HKA_CNN_MODEL_PARAM         HKA_CNNFP16_MODEL_PARAM   
#define     HKA_CNN_FORWARD_IN_INFO     HKA_CNNFP16_FORWARD_IN_INFO
#define     HKA_CNN_FORWARD_OUT_INFO    HKA_CNNFP16_FORWARD_OUT_INFO
#define     HIK_CNN_BLOB_MAX_DIM        HIK_CNNFP16_BLOB_MAX_DIM
#define     PROC_TYPE_FORWARD           PROCFP16_TYPE_FORWARD
#define     HIKCNN_LibInfo              HIKCNNFP16_LibInfo
#define     HKA_CNN_BLOB_TYPE           HKA_CNNFP16_BLOB_TYPE
#define     HKA_DT_FLT32                HKA_DTFP16_FLT32
#define     HKA_DT_UINT8                HKA_DTFP16_UINT8
#define     HKA_DT_FLT16                HKA_DTFP16_FLT16

#else
#include "cnn_lib.h"
#endif
#include <string.h>
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "cnn_basic_kernel.h"
#endif
#include "net.h"
#include "cnn_half.h"

#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

#ifdef CNN_NNPACK_OPT
#include"nnpack.h" 
#endif


#ifdef _HIK_DECRYPT
extern int HIK_GetKeyResult();
#ifdef LINUX
#define HIKENCR_S_OK 1
#endif // LINUX
#endif // _HIK_DECRYPT

#ifdef _HIK_DECRYPT_LINUX_X64
extern int HIK_GetKeyResult();
#endif

static HKA_S32 CNN_get_crypt_flag(HKA_U08 *data)
{
    if ((data[0] == 0xff) && (data[1] == 0xff) && (data[2] == 0xff) && (data[3] == 0xff))
    {
        return 1; // encrypted
    }
    if ((data[0] == 0) && (data[1] == 0) && (data[2] == 0) && (data[3] == 0))
    {
        return 0; // decrypted
    }

    return 2;     // no flag info and not encrypt
}

char *CNN_model_decrypt(HKA_U08 *model_data,
                        int      model_data_size)
{
    HKA_S32 i;
    HKA_U08 x;
    HKA_S32 flag = CNN_get_crypt_flag(model_data);

    if (2 == flag)
    {
        return (char *)model_data; // no flag info and not encrypt
    }
    else if (1 == flag)
    {
        // decrypt

        for (i = 0; i < model_data_size; i++)
        {
            x             = model_data[i];
            model_data[i] = ((x << 3) & 0xff) | (x >> 5);
        }
        memset(model_data, 0, 4); // set decrypted flag
    }

    return (char *)(model_data + 4);
}

HRESULT CNN_check_in_blob_shape(HKA_CNN_PARAM *params_info,
                                NET_MODEL     *net_model)
{
    int i;
printf("CNN_check_in_blob_shape\n\n");
    HKA_CHECK_ERROR(params_info->in_blob_num <= 0, HIK_VCA_LIB_KEY_PARAM_ERR);
printf("111 %d %d %d %d\n",
	params_info->in_blob_shape[i][0],params_info->in_blob_shape[i][1],
	params_info->in_blob_shape[i][2],params_info->in_blob_shape[i][3]);
    for (i = 0; i < params_info->in_blob_num; i++)
    {
        HKA_CHECK_ERROR(params_info->in_blob_shape[i][0] <= 0, HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(params_info->in_blob_shape[i][1] <= 0, HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(params_info->in_blob_shape[i][2] <= 0, HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(params_info->in_blob_shape[i][3] <= 0, HIK_VCA_LIB_KEY_PARAM_ERR);
    }
printf("222\n");
	printf("BBB  %d %d %d %d %d %d\n",
		params_info->in_blob_shape[0][1], net_model->mean_blob.shape[1],
		params_info->in_blob_shape[0][2], net_model->mean_blob.shape[2],
		params_info->in_blob_shape[0][3], net_model->mean_blob.shape[3]);


    if (2 == net_model->mean_val_or_file)
    {
        HKA_CHECK_ERROR(params_info->in_blob_shape[0][1] != net_model->mean_blob.shape[1],
                        HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(params_info->in_blob_shape[0][2] != net_model->mean_blob.shape[2],
                        HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(params_info->in_blob_shape[0][3] != net_model->mean_blob.shape[3],
                        HIK_VCA_LIB_KEY_PARAM_ERR);
    }
printf("BBB  %d %d %d %d %d %d\n",
	params_info->in_blob_shape[0][1], net_model->mean_blob.shape[1],
	params_info->in_blob_shape[0][2], net_model->mean_blob.shape[2],
	params_info->in_blob_shape[0][3], net_model->mean_blob.shape[3]);
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡ���ܿ�������ڴ��С
* ��  ��: params_info            - I ģ����ز�����Ϣ
*         mem_tab               - O �ڴ������ 0:cpu handle, 1:cpu model, 2:gpu model
* ����ֵ: ����״̬��
***************************************************************************************************/
HRESULT HIKCNN_GetModelMemSize(HKA_CNN_MODEL_PARAM *params_info,
                               VCA_MEM_TAB_V2       mem_tab[HIK_CNN_MEM_TAB_NUM])
{
    HRESULT   hr;
    NET_MODEL net;
    char     *ptr;
    int       blob_data_size;
    size_t    size;
printf("A0\n");
    HKA_CHECK_ERROR(NULL == params_info, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info->model_data, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(params_info->model_datasize <= 0, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(NULL == mem_tab, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(HIK_CNN_MEM_TAB_NUM != MODEL_MEM_TAB_NUM, HIK_VCA_CNN_MODEL_ERROR);
	
printf("A1\n");

    memset(mem_tab, 0, sizeof(VCA_MEM_TAB_V2) * MODEL_MEM_TAB_NUM);

    ptr = CNN_model_decrypt(params_info->model_data, params_info->model_datasize);
	
printf("A2\n");

    // ��ȡnameֵ
    hr = CNN_NET_LoadName(&net, ptr, &ptr);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ��ȡscaleֵ
    hr = CNN_NET_LoadScale(&net, ptr, &ptr);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ��ȡ��ֵ��������Ĵ洢�ռ�
    hr = CNN_NET_LoadMean(&net, ptr, &ptr, 0);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

printf("A3\n");

    hr = CNN_NET_InitModel(ptr, &net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

printf("A4\n");

    hr = CNN_NET_GetModelMemsize(&net, mem_tab);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    size = CNN_SIZE_ALIGN(sizeof(NET_MODEL));

printf("A5\n");

    // ��ֵ���ݷ���mem_tab[0]���棬�̶���cpu�ϼ���ֵ
    if (net.mean_val_or_file != 0)
    {
        blob_data_size = CNN_BLOB_GetDataSize(&net.mean_blob);
        size          += CNN_SIZE_ALIGN(blob_data_size);
    }

    mem_tab[0].size     += size;
    mem_tab[0].alignment = HKA_MAX(CNN_MEM_ALIGN_SIZE, mem_tab[0].alignment);

    mem_tab[0].plat = VCA_MEM_PLAT_CPU;
    mem_tab[1].plat = VCA_MEM_PLAT_CPU;
    mem_tab[2].plat = VCA_MEM_PLAT_GPU;

    // ��ֵGPU�ڴ�
#ifdef CNN_CUDA_OPT
    if (net.mean_val_or_file != 0)
    {
        mem_tab[2].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&net.mean_blob) * sizeof(float));
    }
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �������ܿ��ڴ�
* ��  ��: params_info            - I ������Ϣ
*         mem_tab                - I �ڴ������
*         handle                 - O ���ܿ���
* ����ֵ: ����״̬��
***************************************************************************************************/
HRESULT HIKCNN_CreateModel(HKA_CNN_MODEL_PARAM *params_info,
                           VCA_MEM_TAB_V2       mem_tab[HIK_CNN_MEM_TAB_NUM],
                           void               **handle)
{
    HRESULT    hr;
    int        blob_data_size;
    NET_MODEL *net;
    char      *ptr, *dummy;
    CNN_BUF    mem_buf[LAYER_MEM_TAB_NUM];

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_model_buf  = &mem_buf[1];
    CNN_BUF *gpu_model_buf  = &mem_buf[2];

#ifdef CNN_CUDA_OPT
    cudaError_t err;
#endif

#ifdef ARCH_SUPPORT_FP16
    VCA_MEM_TAB_V2  model_mem_tab[MODEL_MEM_TAB_NUM];
#endif

    HKA_CHECK_ERROR(NULL == handle, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info->model_data, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(params_info->model_datasize <= 0, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(NULL == mem_tab, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR((NULL == mem_tab[0].base) && (NULL == mem_tab[1].base) && (NULL == mem_tab[2].base), HIK_VCA_LIB_E_PTR_NULL);

    HKA_CHECK_ERROR(HIK_CNN_MEM_TAB_NUM != MODEL_MEM_TAB_NUM, HIK_VCA_CNN_MODEL_ERROR);


#ifdef _HIK_DECRYPT
    // ����������ɫ������ܹ�
#ifdef LINUX
    hr = HIK_GetKeyResult();
    if (hr != HIKENCR_S_OK)
    {
        return NULL;
    }
#else
    HIK_GetKeyResult();
#endif // LINUX
#endif // _HIK_DECRYPT

#ifdef _HIK_TX1_CHECK
    //if (check_tx1_vaild_opt() == 0)
    if (check_tx1_vaild() == 0)
    {
        exit(0);
    }
#endif

#ifdef _HIK_DECRYPT_LINUX_X64
    HIK_GetKeyResult();
#endif

#ifndef CNN_CUDA_OPT
    gpu_model_buf = NULL;
#else
    cpu_model_buf = NULL;
#endif

    memset(mem_buf, 0, sizeof(CNN_BUF) * LAYER_MEM_TAB_NUM);

    /*--------------------------------------------------------------------------------*/
    /*  mem_tab[0] -> cpu handle size      */
    /*  mem_tab[1] -> cpu model size       */
    /*  mem_tab[2] -> gpu model size       */
    /*---------------------------------------------------------------------------------*/
    cnn_set_mem_buf(cpu_handle_buf, mem_tab[0].base, (char *)(mem_tab[0].base) + mem_tab[0].size, mem_tab[0].base);
    cnn_set_mem_buf(cpu_model_buf, mem_tab[1].base, (char *)(mem_tab[1].base) + mem_tab[1].size, mem_tab[1].base);
    cnn_set_mem_buf(gpu_model_buf, mem_tab[2].base, (char *)(mem_tab[2].base) + mem_tab[2].size, mem_tab[2].base);

    net = (NET_MODEL *)CNN_alloc_buffer(cpu_handle_buf, CNN_SIZE_ALIGN(sizeof(NET_MODEL)), CNN_MEM_ALIGN_SIZE, 1);
    HKA_CHECK_MEMOUT(net);

    ptr = CNN_model_decrypt(params_info->model_data, params_info->model_datasize);

    // ��ȡnameֵ
    hr = CNN_NET_LoadName(net, ptr, &ptr);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ��ȡscaleֵ
    hr = CNN_NET_LoadScale(net, ptr, &ptr);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ��ȡ��ֵ��������Ĵ洢�ռ�
    hr = CNN_NET_LoadMean(net, ptr, &dummy, 0);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    if (net->mean_val_or_file != 0)
    {
        // ����ֵ���ݷ���ռ�,��ֵ���ݷ���mem_tab[0]����
        blob_data_size      = CNN_BLOB_GetDataSize(&net->mean_blob);
        net->mean_blob.data = CNN_alloc_buffer(cpu_handle_buf,
                                               CNN_SIZE_ALIGN(blob_data_size),
                                               CNN_MEM_ALIGN_SIZE,
                                               1);
        HKA_CHECK_MEMOUT(net->mean_blob.data);

        // ���ؾ�ֵ����
        hr = CNN_NET_LoadMean(net, ptr, &ptr, 1);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

#ifdef CNN_CUDA_OPT
        //����GPU��ֵ�ڴ�
        net->mean_blob.data_gpu = CNN_alloc_buffer(gpu_model_buf, 
                                                   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&net->mean_blob) * sizeof(float)),
                                                   CNN_CUDA_MEM_ALIGNMENT,
                                                   0);
        CNN_CHECK_ERROR(net->mean_blob.data_gpu == NULL, "NULL ptr", HIK_VCA_LIB_E_PTR_NULL);

        // ����ֵ���ݴ�CPU����GPU
        err = cudaMemcpy(net->mean_blob.data_gpu, 
                         net->mean_blob.data, 
                         CNN_BLOB_GetDataNum(&net->mean_blob) * sizeof(float), 
                         cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));
#endif
    }

    hr = CNN_NET_InitModel(ptr, net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
printf("CC0\n");
#ifdef ARCH_SUPPORT_FP16
    hr = CNN_NET_GetModelMemsize(net, model_mem_tab);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    net->fp16_workspace = (void *)CNN_alloc_buffer(gpu_model_buf,
                                                   net->max_weight_size * sizeof(float) / sizeof(cnn_half),
                                                   CNN_MEM_ALIGN_SIZE,
                                                   0);
    CNN_CHECK_ERROR(net->fp16_workspace == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);
#endif
	printf("CC1\n");

    hr = CNN_NET_CreateModel(net, mem_buf);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
	printf("CC2\n");

    *handle = net;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡ���ܿ�������ڴ��С
* ��  ��: params_info            - I ������Ϣ
*         mem_tab               - O �ڴ������ 0:cpu handle, 1:cpu model, 2:cpu blob data
                                              3:gpu model,  4:gpu blob data
* ����ֵ: ����״̬��
***************************************************************************************************/
HRESULT HIKCNN_GetMemSize(HKA_CNN_PARAM *params_info,
                          VCA_MEM_TAB_V2 mem_tab[HIK_CNN_MEM_TAB_NUM])
{
    int       i;
    HRESULT   hr;
    NET       net;
    size_t    size;
    CNN_BLOB *oblob;

    HKA_CHECK_ERROR(NULL == params_info, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == mem_tab,     HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info->model_handle, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(params_info->in_blob_num > HIK_CNN_MAX_IN_BLOB, HIK_VCA_LIB_KEY_PARAM_ERR);
    hr = CNN_check_in_blob_shape(params_info, params_info->model_handle);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    HKA_CHECK_ERROR(HIK_CNN_MEM_TAB_NUM != MODEL_MEM_TAB_NUM, HIK_VCA_CNN_MODEL_ERROR);

    net.in_blob_num = params_info->in_blob_num;

    memcpy(net.in_blob_shape, params_info->in_blob_shape, sizeof(params_info->in_blob_shape));

    memset(mem_tab, 0, sizeof(VCA_MEM_TAB_V2) * LAYER_MEM_TAB_NUM);

    net.blob_num = params_info->out_blob_num;

    memcpy(net.out_blob_info,
           params_info->out_blob_info,
           sizeof(params_info->out_blob_info[0]) * HIK_CNN_MAX_OUT_BLOB);
printf("000\n");

    hr = CNN_NET_Init(params_info->model_handle, &net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

printf("111\n");

    hr = CNN_NET_GetMemsize(&net, mem_tab);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
printf("222\n");
    mem_tab[0].size += CNN_SIZE_ALIGN(sizeof(NET));

    // Ϊ��������GPU�ڴ�
#ifdef CNN_CUDA_OPT
    net.layers[0].output_blobs[0].pad.pad_h = net.net_model->net_pad.pad_h;
    net.layers[0].output_blobs[0].pad.pad_w = net.net_model->net_pad.pad_w;
    mem_tab[2].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net.layers[0].output_blobs[0]) * sizeof(float));
#ifdef ARCH_SUPPORT_FP16
    mem_tab[2].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net.layers[0].output_blobs[0]) * sizeof(cnn_half));
#endif
	// ����Ϊucharʱ�����ת����
	mem_tab[2].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net.layers[0].output_blobs[0]) * sizeof(unsigned char));
#endif

    // Ϊ��Ҫ����Ĳ����CPU�ڴ�
#ifdef CNN_CUDA_OPT
    for (i = 0; i < net.blob_num; i++)
    {
        oblob = CNN_NET_GetBlob(&net,
                                net.out_blob_info[i].layer_idx,
                                net.out_blob_info[i].blob_idx);

        mem_tab[1].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(oblob) * sizeof(float));

#ifdef ARCH_SUPPORT_FP16
        // fp16�汾��Ҫ��������fp32�ڴ棬���ڽ�fp16ת����fp32, Ȼ�󿽱���cpu�ˡ�
        mem_tab[2].size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(oblob) * sizeof(float));
#endif
    }
#endif

printf("222\n");

    mem_tab[0].alignment = HKA_MAX(CNN_MEM_ALIGN_SIZE, mem_tab[0].alignment);
    mem_tab[1].alignment = HKA_MAX(CNN_MEM_ALIGN_SIZE, mem_tab[1].alignment);
    mem_tab[2].alignment = HKA_MAX(CNN_MEM_ALIGN_SIZE, mem_tab[2].alignment);

    mem_tab[0].plat = VCA_MEM_PLAT_CPU;
    mem_tab[1].plat = VCA_MEM_PLAT_CPU;
    mem_tab[2].plat = VCA_MEM_PLAT_GPU;

    return HIK_VCA_LIB_S_OK;
}

#ifdef ARCH_SUPPORT_FP16
/***************************************************************************************************
* ��  ��: ����fp16ת��fp32ʱ��GPU�ڴ��С
* ��  ��: params_info            - I ������Ϣ
*         mem_tab               - O �ڴ������ 
* ����ֵ: ����״̬��
***************************************************************************************************/
static HRESULT CNN_get_output_size(HKA_CNN_PARAM    *params_info,
                                   VCA_MEM_TAB_V2   *mem_tab)
{
    HRESULT   hr, i;
    NET       net;
    size_t    size;
    CNN_BLOB *oblob;
    VCA_MEM_TAB_V2     net_mem_tab[LAYER_MEM_TAB_NUM];

    HKA_CHECK_ERROR(NULL == params_info, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info->model_handle, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(params_info->in_blob_num > HIK_CNN_MAX_IN_BLOB, HIK_VCA_LIB_KEY_PARAM_ERR);
    hr = CNN_check_in_blob_shape(params_info, params_info->model_handle);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    HKA_CHECK_ERROR(HIK_CNN_MEM_TAB_NUM != MODEL_MEM_TAB_NUM, HIK_VCA_CNN_MODEL_ERROR);

    net.in_blob_num = params_info->in_blob_num;

    memcpy(net.in_blob_shape, params_info->in_blob_shape, sizeof(params_info->in_blob_shape));

    memset(mem_tab, 0, sizeof(VCA_MEM_TAB_V2));

    net.blob_num = params_info->out_blob_num;

    memcpy(net.out_blob_info,
        params_info->out_blob_info,
        sizeof(params_info->out_blob_info[0]) * HIK_CNN_MAX_OUT_BLOB);

    hr = CNN_NET_Init(params_info->model_handle, &net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    hr = CNN_NET_GetMemsize(&net, net_mem_tab);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    mem_tab->size = 0;

    // Ϊ��Ҫ����Ĳ����CPU�ڴ�
    for (i = 0; i < net.blob_num; i++)
    {
        oblob = CNN_NET_GetBlob(&net,
                                net.out_blob_info[i].layer_idx,
                                net.out_blob_info[i].blob_idx);

        mem_tab->size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(oblob) * sizeof(float));
    }

    mem_tab->alignment  = CNN_MEM_ALIGN_SIZE;
    mem_tab->plat       = VCA_MEM_PLAT_GPU;

    return HIK_VCA_LIB_S_OK;
}
#endif

/***************************************************************************************************
* ��  ��: �������ܿ��ڴ�
* ��  ��: params_info            - I ������Ϣ
*         mem_tab                - I �ڴ������
*         handle                 - O ���ܿ���
* ����ֵ: ����״̬��
***************************************************************************************************/
HRESULT HIKCNN_Create(HKA_CNN_PARAM *params_info,
                      VCA_MEM_TAB_V2 mem_tab[HIK_CNN_MEM_TAB_NUM],
                      void         **handle)
{
    HRESULT   hr;
    int       i;
    NET      *net;
    CNN_BUF   mem_buf[LAYER_MEM_TAB_NUM];
    CNN_BLOB *oblob;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

    CNN_BUF output_buf;

    VCA_MEM_TAB_V2 tmp_mem_tab[HIK_CNN_MEM_TAB_NUM];

#ifdef CNN_NNPACK_OPT
	enum nnp_status init_status;
#endif

#ifdef ARCH_SUPPORT_FP16
    VCA_MEM_TAB_V2          output_mem_tab;
    void                    *input_data_fp16;
#endif

#ifdef CNN_CUDA_OPT
    cudaError_t             err;
    void                    *input_data;
	void					*input_transfer_data;
#endif

    HKA_CHECK_ERROR(NULL == handle, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == params_info->model_handle, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR(NULL == mem_tab, HIK_VCA_LIB_E_PTR_NULL);
    HKA_CHECK_ERROR((NULL == mem_tab[0].base) && (NULL == mem_tab[1].base) && (NULL == mem_tab[2].base), HIK_VCA_LIB_E_PTR_NULL);
#ifdef CNN_CUDA_OPT
    HKA_CHECK_ERROR(NULL == params_info->cuda_handle, HIK_VCA_LIB_E_PTR_NULL);
#endif // CNN_CUDA_OPT
    HKA_CHECK_ERROR(params_info->in_blob_num > HIK_CNN_MAX_IN_BLOB, HIK_VCA_LIB_KEY_PARAM_ERR);
    hr = CNN_check_in_blob_shape(params_info, params_info->model_handle);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    HKA_CHECK_ERROR(HIK_CNN_MEM_TAB_NUM != MODEL_MEM_TAB_NUM, HIK_VCA_CNN_MODEL_ERROR);

#ifdef CNN_NNPACK_OPT
	init_status = nnp_initialize();
	if (init_status != nnp_status_success) 
	{		
		return CNN_NNPACK_ERROR_CODE_BASE + (int)init_status;
	}
#endif

#ifdef _HIK_DECRYPT
    // ����������ɫ������ܹ�
#ifdef LINUX
    hr = HIK_GetKeyResult();
    if (hr != HIKENCR_S_OK)
    {
        return NULL;
    }
#else
    HIK_GetKeyResult();
#endif // LINUX
#endif // _HIK_DECRYPT

#ifdef _HIK_TX1_CHECK
     //if (check_tx1_vaild_opt() == 0)
     if (check_tx1_vaild() == 0)
     {
         exit(0);
     }
#endif

#ifdef _HIK_DECRYPT_LINUX_X64
     HIK_GetKeyResult();
#endif

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#endif

    memset(mem_buf, 0, sizeof(CNN_BUF) * LAYER_MEM_TAB_NUM);

    /*--------------------------------------------------------------------------------*/
    /*  mem_tab[0] -> cpu handle size     */
    /*  mem_tab[1] -> cpu data size       */
    /*  mem_tab[2] -> gpu data size       */
    /*---------------------------------------------------------------------------------*/
    cnn_set_mem_buf(cpu_handle_buf, mem_tab[0].base, (char *)(mem_tab[0].base) + mem_tab[0].size, mem_tab[0].base);
    cnn_set_mem_buf(cpu_data_buf,   mem_tab[1].base, (char *)(mem_tab[1].base) + mem_tab[1].size, mem_tab[1].base);
    cnn_set_mem_buf(gpu_data_buf,   mem_tab[2].base, (char *)(mem_tab[2].base) + mem_tab[2].size, mem_tab[2].base);

    net = (NET *)CNN_alloc_buffer(cpu_handle_buf, CNN_SIZE_ALIGN(sizeof(NET)), CNN_MEM_ALIGN_SIZE, 1);
    HKA_CHECK_MEMOUT(net);

#ifdef ARCH_SUPPORT_FP16
    // ���㽫�����fp16ת��fp32��Ҫ�����ڴ�
    hr = CNN_get_output_size(params_info, &output_mem_tab);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ����ڴ��������ʱ��fp16ת��fp32
    output_buf.start = (void *)CNN_alloc_buffer(gpu_data_buf,
                                                output_mem_tab.size,
                                                CNN_MEM_ALIGN_SIZE,
                                                0);
    CNN_CHECK_ERROR(output_buf.start == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);

    output_buf.end     = (char *)output_buf.start + output_mem_tab.size;
    output_buf.cur_pos = output_buf.start;
#endif

#ifdef CNN_CUDA_OPT
    CNN_CHECK_ERROR(params_info->cuda_handle == NULL, "params_info->cuda_handle is NULL", HIK_VCA_LIB_E_PTR_NULL);
    hr = CNN_create_cuda_handle(&net->cuda_handle, params_info->cuda_handle, gpu_data_buf);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
#endif

    // ��¼������Ϣ
    net->in_blob_num = params_info->in_blob_num;
    memcpy(net->in_blob_shape, params_info->in_blob_shape, sizeof(params_info->in_blob_shape));

    net->blob_num = params_info->out_blob_num;
    memcpy(net->out_blob_info, params_info->out_blob_info,
           sizeof(params_info->out_blob_info[0]) * HIK_CNN_MAX_OUT_BLOB);

    hr = CNN_NET_Init(params_info->model_handle, net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

#ifdef CNN_CUDA_OPT
    //���������ڴ�
    net->layers[0].output_blobs[0].pad.pad_h = net->net_model->net_pad.pad_h;
    net->layers[0].output_blobs[0].pad.pad_w = net->net_model->net_pad.pad_w;
    input_data = CNN_alloc_buffer(gpu_data_buf,
                                  CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net->layers[0].output_blobs[0]) * sizeof(float)),
                                  CNN_CUDA_MEM_ALIGNMENT,
                                  0);
    CNN_CHECK_ERROR(input_data == NULL, "NULL ptr", HIK_VCA_LIB_E_PTR_NULL);
#ifdef ARCH_SUPPORT_FP16
    //���������ڴ�(fp16)
    input_data_fp16 = CNN_alloc_buffer(gpu_data_buf,
                                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net->layers[0].output_blobs[0]) * sizeof(cnn_half)),
                                       CNN_CUDA_MEM_ALIGNMENT,
                                       0);
    CNN_CHECK_ERROR(input_data_fp16 == NULL, "NULL ptr", HIK_VCA_LIB_E_PTR_NULL);
#endif
	// ������������ת���ڴ�
	input_transfer_data = CNN_alloc_buffer(gpu_data_buf,
										   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&net->layers[0].output_blobs[0]) * sizeof(unsigned char)),
										   CNN_CUDA_MEM_ALIGNMENT,
										   0);
	CNN_CHECK_ERROR(input_transfer_data == NULL, "NULL ptr", HIK_VCA_LIB_E_PTR_NULL);
#endif

    hr = CNN_NET_Create(net, mem_buf);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // Ϊ��Ҫ����Ĳ����CPU�ڴ棬�粻��Ҫ�������ֻ����GPU�ڴ�
    // ����ڴ�������ڴ����ģ��
#ifdef CNN_CUDA_OPT
    // ���������0��blob��gpuָ��
    net->layers[0].output_blobs[0].data_gpu = input_data;
	// ������������ת���ڴ�ָ��
	net->in_transer_data_gpu = input_transfer_data;
#ifdef ARCH_SUPPORT_FP16
    net->layers[0].output_blobs[0].data_gpu_fp16 = input_data_fp16;
#endif

    for (i = 0; i < net->blob_num; i++)
    {
        oblob = CNN_NET_GetBlob(net, net->out_blob_info[i].layer_idx, net->out_blob_info[i].blob_idx);
        CNN_CHECK_ERROR(NULL == oblob, "CNN_NET_GetBlob", HIK_VCA_LIB_KEY_PARAM_ERR);

        memcpy(&net->out_blob[i], oblob, sizeof(CNN_BLOB));

        // �����blobʼ����fp32
        net->out_blob[i].type = CNN_DT_FLT32;

        net->out_blob[i].data =
            CNN_alloc_buffer(cpu_data_buf,
                             CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&net->out_blob[i])),
                             CNN_MEM_ALIGN_SIZE,
                             0);
        CNN_CHECK_ERROR(NULL == net->out_blob[i].data, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

#ifdef ARCH_SUPPORT_FP16
        net->out_blob[i].data_gpu =
            CNN_alloc_buffer(&output_buf,
                             CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&net->out_blob[i])),
                             CNN_CUDA_MEM_ALIGNMENT,
                             0);
        CNN_CHECK_ERROR(NULL == net->out_blob[i].data_gpu, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
#endif

        net->out_blob[i].data_gpu_fp16 = NULL;
    }
#endif

    *handle = net;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_sub_mean(CNN_BLOB *data,
                     CNN_BLOB *mean,
                     int       mean_value_or_file,
                     float     scale)
{
    int    batch_idx, c, i, n;
    float  m;
    float *data_ptr;
    float *mean_ptr;

    // only support float32
    HKA_CHECK_ERROR(mean->type != CNN_DT_FLT32, HIK_VCA_CNN_MODEL_ERROR);

    n = data->shape[2] * data->shape[3];

    if (1 == mean_value_or_file)
    {
        HKA_CHECK_ERROR(mean->shape[2] * mean->shape[3] != 1, HIK_VCA_CNN_MODEL_ERROR);
        HKA_CHECK_ERROR(mean->shape[1] != data->shape[1], HIK_VCA_CNN_MODEL_ERROR);

        for (batch_idx = 0; batch_idx < data->shape[0]; batch_idx++)
        {
            for (c = 0; c < data->shape[1]; c++)
            {
                data_ptr = CNN_BLOB_GetPtr(data, batch_idx, c, 0, 0);
                m        = ((float *)mean->data)[c];

                for (i = 0; i < n; i++)
                {
                    data_ptr[i] = (data_ptr[i] - m) * scale;
                }
            }
        }
    }
    else if (2 == mean_value_or_file)
    {
        HKA_CHECK_ERROR((data->shape[1] != mean->shape[1]), HIK_VCA_CNN_MODEL_ERROR);
        HKA_CHECK_ERROR((data->shape[2] != mean->shape[2]), HIK_VCA_CNN_MODEL_ERROR);
        HKA_CHECK_ERROR((data->shape[3] != mean->shape[3]), HIK_VCA_CNN_MODEL_ERROR);

        for (batch_idx = 0; batch_idx < data->shape[0]; batch_idx++)
        {
            for (c = 0; c < data->shape[1]; c++)
            {
                data_ptr = CNN_BLOB_GetPtr(data, batch_idx, c, 0, 0);
                mean_ptr = CNN_BLOB_GetPtr(mean, 0, c, 0, 0);

                for (i = 0; i < n; i++)
                {
                    data_ptr[i] = (data_ptr[i] - mean_ptr[i]) * scale;
                }
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_data_scale(CNN_BLOB *data,
                       float     scale)
{
    int    i, n;
    float *data_ptr;

    n = CNN_BLOB_GetDataNum(data);

    data_ptr = CNN_BLOB_GetPtr(data, 0, 0, 0, 0);

    for (i = 0; i < n; i++)
    {
        data_ptr[i] *= scale;
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �����������
* ��  ��: 
*         proc_out               - O ���������Ϣ
*         net                    - I ����handle
* ����ֵ: ����״̬��
***************************************************************************************************/
static HRESULT CNN_proc_output(HKA_CNN_FORWARD_OUT_INFO *proc_out, NET *net)
{
    int             bi, i;
    CNN_BLOB       *oblob;
    HRESULT         ret;
    const char     *out_layer_type;
#ifdef CNN_CUDA_OPT
    cudaError_t     err;
#endif // CNN_CUDA_OPT

    proc_out->blob_num = 0;

    for (bi = 0; bi < net->blob_num; bi++)
    {
        oblob = CNN_NET_GetBlob(net,
                                net->out_blob_info[bi].layer_idx,
                                net->out_blob_info[bi].blob_idx);
        HKA_CHECK_ERROR(NULL == oblob, HIK_VCA_LIB_KEY_PARAM_ERR);

        // �����Ϊȫ���ӡ�softmax������
        out_layer_type = CNN_NET_GetLayerType(net, net->out_blob_info[bi].layer_idx);
        CNN_CHECK_ERROR(out_layer_type == NULL, "CNN_NET_GetLayerType", HIK_VCA_LIB_E_PTR_NULL);

#ifdef CNN_CUDA_OPT
        // GPU�汾Ҳ�п���ĳЩ����CPU����, ����frout��
        if (oblob->data)
        {
            proc_out->output_blob[bi].data = oblob->data;
        }
        else if (oblob->data_gpu)
        {
            if (oblob->format == CNN_FORMAT_NCHW)
            {
                //printf("oblob->format == CNN_FORMAT_NCHW\n");
                err = cudaMemcpy(net->out_blob[bi].data,
                                 oblob->data_gpu,
                                 CNN_BLOB_GetDataSize(&net->out_blob[bi]),
                                 cudaMemcpyDeviceToHost);
                CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));

                proc_out->output_blob[bi].data = net->out_blob[bi].data;
            }
            else if (oblob->format == CNN_FORMAT_NCHW_ZIP)
            {
                //printf("oblob->format == CNN_FORMAT_NCHW_ZIP\n");
                err = cudaMemcpy(net->out_blob[bi].data,
                                 oblob->data_gpu,
                                 CNN_BLOB_GetDataSize(&net->out_blob[bi]),
                                 cudaMemcpyDeviceToHost);
                CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));

                proc_out->output_blob[bi].data = net->out_blob[bi].data;
            }
            else
            {
                CNN_CHECK_ERROR(1, "format not support", HIK_VCA_LIB_KEY_PARAM_ERR);
            }
        }
        else if (oblob->data_gpu_fp16)
        {
            if (oblob->format == CNN_FORMAT_NCHW)
            {
                //printf("oblob->data_gpu_fp16 oblob->format == CNN_FORMAT_NCHW\n");
                ret = cnn_half2float(oblob->data_gpu_fp16, net->out_blob[bi].data_gpu, CNN_BLOB_GetDataNum(oblob));
                CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != ret, "cnn_float2half failed", ret);
            }
            else if (oblob->format == CNN_FORMAT_NCHW_ZIP)
            {
#ifdef ARCH_SUPPORT_FP16
                //printf("oblob->data_gpu_fp16 oblob->format == CNN_FORMAT_NCHW_ZIP\n");

                if (strcmp(out_layer_type, "InnerProduct") == 0)
                {
                    ret = cnn_half2float(oblob->data_gpu_fp16, net->out_blob[bi].data_gpu, CNN_BLOB_GetDataNum(oblob));
                    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != ret, "cnn_float2half failed", ret);
                }
                else
                {
                    // ����net->out_blob[bi].data_gpu�� ��Ϊunzip��unpad�����
                    ret = CNN_unzip_and_unpad(oblob->data_gpu_fp16, 
                                              net->out_blob[bi].data_gpu,
                                              oblob->shape[0],
                                              oblob->shape[1],
                                              oblob->shape[2],
                                              oblob->shape[3],
                                              oblob->pad.pad_h,
                                              oblob->pad.pad_w);
                    CNN_CHECK_ERROR(ret != HIK_VCA_LIB_S_OK, "CNN_unzip_and_unpad", ret);

                    err = cudaMemcpy(oblob->data_gpu_fp16, 
                                     net->out_blob[bi].data_gpu, 
                                     CNN_BLOB_GetDataNum(oblob) * sizeof(short), 
                                     cudaMemcpyDeviceToDevice);
                    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

                    ret = cnn_half2float(oblob->data_gpu_fp16, net->out_blob[bi].data_gpu, CNN_BLOB_GetDataNum(oblob));
                    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != ret, "cnn_float2half failed", ret);
                }
#endif
            }
            else
            {
                CNN_CHECK_ERROR(1, "format not support", HIK_VCA_LIB_KEY_PARAM_ERR);
            }

            err = cudaMemcpy(net->out_blob[bi].data,
                             net->out_blob[bi].data_gpu,
                             CNN_BLOB_GetDataSize(&net->out_blob[bi]),
                             cudaMemcpyDeviceToHost);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));

            proc_out->output_blob[bi].data = net->out_blob[bi].data;
        }
#else
        proc_out->output_blob[bi].data = oblob->data;
#endif
        proc_out->output_blob[bi].type = CNN_DT_FLT32;

        for (i = 0; i < HIK_CNN_BLOB_MAX_DIM; i++)
        {
            proc_out->output_blob[bi].shape[i] = oblob->shape[i];
        }

        proc_out->blob_num++;
    }

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_proc_forward(HKA_VOID *handle,
                         HKA_VOID *in_buf,
                         int       in_buf_size,
                         HKA_VOID *out_buf,
                         int       out_buf_size)
{
    int                 i, bi, ret;
    CNN_BLOB            blob;
    CNN_BLOB           *oblob;
    HRESULT             hr;
    HKA_CNN_BLOB_TYPE   data_type;
    BLOB_DATA_FORMAT    format;

#ifdef CNN_CUDA_OPT
	void				*transfer_data_gpu;
	cudaError_t			err;
#endif
    NET                      *net      = (NET *)handle;
    HKA_CNN_FORWARD_IN_INFO  *proc_in  = (HKA_CNN_FORWARD_IN_INFO *)in_buf;
    HKA_CNN_FORWARD_OUT_INFO *proc_out = (HKA_CNN_FORWARD_OUT_INFO *)out_buf;

    HKA_CHECK_ERROR(in_buf_size  != (int)sizeof(HKA_CNN_FORWARD_IN_INFO),  HIK_VCA_LIB_KEY_PARAM_ERR);
    HKA_CHECK_ERROR(out_buf_size != (int)sizeof(HKA_CNN_FORWARD_OUT_INFO), HIK_VCA_LIB_KEY_PARAM_ERR);
    HKA_CHECK_ERROR(proc_in->in_blob_num != net->in_blob_num,              HIK_VCA_LIB_KEY_PARAM_ERR);

#ifdef CNN_PROFILE_LAYER
    OPT_PROFILE_TIME_BY_EVENT_START(1023);
#endif

    for (i = 0; i < net->in_blob_num; i++)
    {
        HKA_CHECK_ERROR(proc_in->in_blob[i].shape[0] > net->in_blob_shape[i][0],  HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(proc_in->in_blob[i].shape[1] > net->in_blob_shape[i][1],  HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(proc_in->in_blob[i].shape[2] > net->in_blob_shape[i][2],  HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(proc_in->in_blob[i].shape[3] > net->in_blob_shape[i][3],  HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(NULL == proc_in->in_blob[i].data,                         HIK_VCA_LIB_E_PTR_NULL);
    }

	// ����blob���ڼ�ȥ��ֵ������scale
	data_type = proc_in->in_blob[0].type;
	blob.data = proc_in->in_blob[0].data;
#ifdef CNN_CUDA_OPT

	transfer_data_gpu  = net->in_transer_data_gpu;
	blob.data_gpu	   = net->layers[0].output_blobs[0].data_gpu;
	blob.data_gpu_fp16 = net->layers[0].output_blobs[0].data_gpu_fp16;

	// ��Ϊfp32,���������ݿ�����data_gpu,���򿽱���transfer_data
	if (HKA_DT_FLT32 == data_type)
	{
		// ���ڴ�ֱ�Ӷ�������padding
		err = cudaMemcpy(blob.data_gpu,
						 blob.data,
						 proc_in->in_blob[0].shape[0] *
						 proc_in->in_blob[0].shape[1] *
						 proc_in->in_blob[0].shape[2] *
						 proc_in->in_blob[0].shape[3] *
						 sizeof(float),
						 cudaMemcpyHostToDevice);
		CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
	}
	else if (HKA_DT_UINT8 == data_type)
	{
		err = cudaMemcpy(transfer_data_gpu,
						 blob.data,
						 proc_in->in_blob[0].shape[0] *
						 proc_in->in_blob[0].shape[1] *
						 proc_in->in_blob[0].shape[2] *
						 proc_in->in_blob[0].shape[3] *
						 sizeof(unsigned char),
						 cudaMemcpyHostToDevice);
		CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
	}
  
#else
	CNN_CHECK_ERROR(data_type == HKA_DT_UINT8, "data_type unsupport", HIK_VCA_LIB_KEY_PARAM_ERR);
#endif

	blob.type = data_type;
	blob.ndims = 4;
	for (i = 0; i < blob.ndims; i++)
	{
		blob.shape[i] = proc_in->in_blob[0].shape[i];
	}

#ifndef CNN_CUDA_OPT
	if (0 != net->net_model->mean_val_or_file)
	{
		hr = CNN_sub_mean(&blob,
			&net->net_model->mean_blob,
			net->net_model->mean_val_or_file,
			net->net_model->scale);
		HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
	}
	else if (net->net_model->scale != 1.0f)
	{
		hr = CNN_data_scale(&blob, net->net_model->scale);
		HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
	}
#else

    //�ж����������Ƿ�ΪZIP
    if ((net->net_model->support_zip == 1)
        && (net->layers[0].output_blobs[0].shape[0] % 2 == 0))
    {
        format = CNN_FORMAT_NCHW_ZIP;
    }
    else
    {
        format = CNN_FORMAT_NCHW;
    }

    if (CNN_FORMAT_NCHW == format)
    {
        //  ʹ��GPU����ֵ��scale�������fp16�汾�����ٽ�����ת����fp16 
        if (0 != net->net_model->mean_val_or_file)
        {
            hr = CNN_sub_mean_cuda(&blob,
                                   transfer_data_gpu,
                                   &net->net_model->mean_blob,
                                   net->net_model->mean_val_or_file,
                                   net->net_model->scale);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_sub_mean_cuda", hr);
        }
        else if (net->net_model->scale != 1.0f)
        {
            hr = CNN_data_scale_cuda(&blob, transfer_data_gpu, net->net_model->scale);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_data_scale_cuda", hr);
        }
        else
        {
        #ifndef ARCH_SUPPORT_FP16
            if (data_type == HKA_DT_UINT8)
            {
                hr = CNN_data_uchar2float_cuda(&blob, (unsigned char *)transfer_data_gpu);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_data_uchar2float_cuda", hr);
            }
        #else
            if (data_type == HKA_DT_FLT32)
            {
                hr = cnn_blob_float2half(&blob);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);
            }
            else if (data_type == HKA_DT_UINT8)
            {
                hr = cnn_blob_uchar2half((unsigned char *)transfer_data_gpu, &blob);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_uchar2half", hr);
            }    
        #endif
        }
    }
    else if (CNN_FORMAT_NCHW_ZIP == format)
    {
        if (0 != net->net_model->mean_val_or_file)
        {
            hr = CNN_mean_zip_pad_cuda(&blob,
                                       transfer_data_gpu,
                                       &net->net_model->mean_blob,
                                       net->net_model->mean_val_or_file,
                                       net->net_model->scale,
                                       net->layers[0].output_blobs[0].pad.pad_h,
                                       net->layers[0].output_blobs[0].pad.pad_w);
        }
        else if (net->net_model->scale != 1.0f)
        {
            hr = CNN_scale_zip_pad_cuda(&blob,
                                        transfer_data_gpu,
                                        net->net_model->scale,
                                        net->layers[0].output_blobs[0].pad.pad_h,
                                        net->layers[0].output_blobs[0].pad.pad_w);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_data_scale_cuda", hr);
        }
        else
        {
            hr = CNN_type_zip_pad_cuda(&blob,
                                       transfer_data_gpu,
                                       net->layers[0].output_blobs[0].pad.pad_h,
                                       net->layers[0].output_blobs[0].pad.pad_w);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_type_zip_pad_cuda", hr);
        }
    }

#endif

#ifdef CNN_PROFILE_LAYER
    OPT_PROFILE_TIME_BY_EVENT_STOP(1023, "others", 1, 1);
#endif

    hr = CNN_NET_Forward(net, proc_in);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    //OPT_PROFILE_TIME_BY_EVENT_START(100);

    hr = CNN_proc_output(proc_out, net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    //OPT_PROFILE_TIME_BY_EVENT_STOP(100, "CNN_proc_output", 1, 1);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ���ܿ�������
* ��  ��: handle                 - I �㷨����
*         proc_type              - I ��������
*         in_buf                 - I �㷨�����뻺��
*         in_buf_size            - I ���뻺���С
*         out_buf                - O �㷨���������
*         out_buf_size           - I ��������С
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT HIKCNN_Process(HKA_VOID *handle,
                       HKA_S32   proc_type,
                       HKA_VOID *in_buf,
                       int       in_buf_size,
                       HKA_VOID *out_buf,
                       int       out_buf_size)
{
    HRESULT hr;

#ifdef _HIK_LIMITED_PROCESS
    static int process_count = 0;
#endif

    HKA_CHECK_PTR(handle);
    HKA_CHECK_PTR(in_buf);
    HKA_CHECK_PTR(out_buf);

#ifdef _HIK_LIMITED_PROCESS
    if (process_count == 5000)
    {
        exit(0);      // ֱ���˳�����              
    }
    else
    {
        ++process_count;
    }
#endif

#ifdef _HIK_LIMITED_TIME
    HIKOPT_GetKeyResult();
#endif

    switch (proc_type)
    {
    case PROC_TYPE_FORWARD:
        {
            hr = CNN_proc_forward(handle, in_buf, in_buf_size, out_buf, out_buf_size);
            HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

            break;
        }

    default:
        {
            return HIK_VCA_LIB_KEY_PARAM_ERR;
        }
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ȡ�㷨���һЩ��Ϣ
* ��  ��:
*               net     - I  ����handle
*               info    - O  �㷨���һЩ��Ϣ
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT HIKCNN_LibInfo(HKA_VOID *handle, HKA_VOID *info)
{
    NET          *net      = handle;
    CNN_LIB_INFO *net_info = info;

    CNN_CHECK_ERROR(handle == NULL, "net == NULL", HIK_VCA_LIB_E_PTR_NULL);
    CNN_CHECK_ERROR(info   == NULL, "info == NULL", HIK_VCA_LIB_E_PTR_NULL);

    memset(net_info, 0, sizeof(CNN_LIB_INFO));

#ifdef CNN_CUDA_OPT
    net_info->support_zip           = net->net_model->support_zip;
#endif

    return HIK_VCA_LIB_S_OK;
}
