/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: frout_layer.c
* �ļ���ʶ: FROUT_LAYER_C
* ժ    Ҫ: frout��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-17
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif // CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "frout_layer.h"

#ifdef CNN_PROFILE_LAYER
#include "opt_profile.h"
#endif

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: frout_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_compute_in_out_shape(FROUT_LAYER *frout_layer,
                                       LAYER_DATA  *ld)
{
    HKA_CHECK_ERROR(ld->input_blobs_num != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[1]->ndims != 2, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[2]->ndims != 2, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[3]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR((ld->input_blobs[0]->shape[0] != ld->input_blobs[1]->shape[0]) ||
                    ((ld->input_blobs[1]->shape[0]) != ld->input_blobs[2]->shape[0]), 
                    HIK_VCA_CNN_MODEL_ERROR);


    ld->output_blobs[0].ndims    = 4;
    ld->output_blobs[0].type     = CNN_DT_FLT32;
    ld->output_blobs[0].shape[3] = 1;
    ld->output_blobs[0].shape[2] = 1;
    ld->output_blobs[0].shape[1] = 7;       // cls_result score x1 y1 x2 y2  index
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_Reshape(void       *handle,
                          LAYER_DATA *ld)
{
    return CNN_FROUT_compute_in_out_shape((FROUT_LAYER *)handle, ld);
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_init_model(const char  *hyperparams,
                             const char  *param_blobs,
                             LAYER_MODEL  *ld,
                             FROUT_MODEL *frout_model)
{
    int        r, i;
    HRESULT    hr;
    const char nms_thresh[] = "nms_thresh";                  //
    const char conf_thresh[] = "conf_thresh";                 //

    const char *ptr;

    ptr = strstr(hyperparams, nms_thresh);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(nms_thresh) + 1, "%f", &frout_model->nms_thresh);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((frout_model->nms_thresh < 0) || (frout_model->nms_thresh > 1))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, conf_thresh);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(conf_thresh) + 1, "%f", &frout_model->conf_thresh);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((frout_model->conf_thresh < 0) || (frout_model->conf_thresh > 1))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_Create(LAYER_DATA *ld,
                         CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                         void      **handle)
{
    FROUT_LAYER *frout_layer;
    HRESULT      hr;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

    frout_layer = (FROUT_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                  CNN_SIZE_ALIGN(sizeof(FROUT_LAYER)),
                                                  CNN_MEM_ALIGN_SIZE,
                                                  1);
    HKA_CHECK_MEMOUT(frout_layer);

    frout_layer->model = ld->layer_model->model_handle;

    hr = CNN_FROUT_Reshape(&frout_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    ld->output_blobs[0].data = CNN_alloc_buffer(cpu_data_buf,
                                                CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float),
                                                CNN_MEM_ALIGN_SIZE,
                                                0);
    CNN_CHECK_ERROR(ld->output_blobs[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

#ifdef CNN_CUDA_OPT
    frout_layer->prev_out[0].data = CNN_alloc_buffer(cpu_data_buf,
                                                     CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(float),
                                                     CNN_MEM_ALIGN_SIZE,
                                                     0);
    CNN_CHECK_ERROR(frout_layer->prev_out[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    frout_layer->prev_out[0].data_gpu      = NULL;
    frout_layer->prev_out[0].data_gpu_fp16 = NULL;

    frout_layer->prev_out[1].data = 
        CNN_alloc_buffer(cpu_data_buf,
                         CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)),
                         CNN_MEM_ALIGN_SIZE,
                         0);
    CNN_CHECK_ERROR(frout_layer->prev_out[1].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    frout_layer->prev_out[1].data_gpu      = NULL;
    frout_layer->prev_out[1].data_gpu_fp16 = NULL;
#endif

    if (ld->input_blobs[2]->type == CNN_DT_FLT16)
    {
        frout_layer->prev_out[0].data_gpu =
            CNN_alloc_buffer(gpu_data_buf,
                             CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(float)),
                             CNN_MEM_ALIGN_SIZE,
                             0);
        CNN_CHECK_ERROR(frout_layer->prev_out[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

        frout_layer->unzip_input_box =
            CNN_alloc_buffer(gpu_data_buf,
                             CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(short)),
                             CNN_MEM_ALIGN_SIZE,
                             0);
        CNN_CHECK_ERROR(frout_layer->prev_out[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }

    *handle = frout_layer;
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_GetMemsize(LAYER_DATA    *ld,
                             VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    int         hr;
    FROUT_LAYER frout_layer;

    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2 *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *gpu_data_tab   = &mem_tab[2];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    frout_layer.model = ld->layer_model->model_handle;

    hr = CNN_FROUT_Reshape(&frout_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    CNN_BASE_SetMemTab(cpu_handle_tab, 
                       CNN_SIZE_ALIGN(sizeof(FROUT_LAYER)),
                       (VCA_MEM_ALIGNMENT)CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0])),
                       (VCA_MEM_ALIGNMENT)CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

#ifdef CNN_CUDA_OPT
    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(float)), 
                       (VCA_MEM_ALIGNMENT)CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, 
                       cpu_data_tab->size + 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)), 
                       (VCA_MEM_ALIGNMENT)CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);
#endif

    if (ld->input_blobs[2]->type == CNN_DT_FLT16)
    {
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(float)) + 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(short)), // ����unzip�Ҳ���pad��box�ڴ�
                           CNN_CUDA_MEM_ALIGNMENT, 
                           VCA_MEM_PERSIST,
                           VCA_MEM_PLAT_GPU);
    }
	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer��model
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_CreateModel(const char *hyperparams,
                              const char *param_blobs,
                              LAYER_MODEL *ld,
                              CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
                              void      **handle)
{
    FROUT_MODEL *frout_model;
    HRESULT      hr;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    frout_model = (FROUT_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
                                                  CNN_SIZE_ALIGN(sizeof(FROUT_MODEL)),
                                                  CNN_MEM_ALIGN_SIZE,
                                                  1);
    HKA_CHECK_MEMOUT(frout_model);

    hr = CNN_FROUT_init_model(hyperparams, param_blobs, ld, frout_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = frout_model;
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer��model���ڴ��С
* ��  ��: hyperparams            - I ������
*         param_blobs            - I ����
*         ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FROUT_GetModelMemsize(const char    *hyperparams,
                                  const char    *param_blobs,
                                  LAYER_MODEL    *ld,
                                  VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    int         hr;

    VCA_MEM_TAB_V2 *cpu_handle_tab = mem_tab;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(FROUT_MODEL)), (VCA_MEM_ALIGNMENT)CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}





/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FROUT_Forward(void       *handle,
                          LAYER_DATA *ld)
{
    int          i, j, n, c, k;
    FROUT_LAYER *frout_layer = (FROUT_LAYER *)handle;
    // bottom[0] (rois)     : n x 5   //0 index
    // bottom[1] (cls_prob) : n x c
    // bottom[2] (bbox_pred): n x 4c
    // bottom[3] (im_info)  : 1 x 3 (h, w, im_scale)
    const int num_boxes   = ld->input_blobs[0]->shape[0];  // n  300
    const int num_classes = ld->input_blobs[1]->shape[1];  // c

    float *cls_prob   = (float *)ld->input_blobs[1]->data;
    float *box_deltas = (float *)ld->input_blobs[2]->data;
    float *im_info    = (float *)ld->input_blobs[3]->data;

    int   im_height = (int)im_info[0];
    int   im_width  = (int)im_info[1];
    float im_scale  = im_info[2];

    float *rpn_boxes = (float *)ld->input_blobs[0]->data;
    float *boxes     = rpn_boxes;

    float        *cls_prob_temp   = NULL;
    float        *box_deltas_temp = NULL;
    unsigned char mark[300];
    int           roi_num_percls[30]; // ÿ������ ��30��

    float  temp;
    int    sum_temp = 0;
    int    sum;
    float *out_data = (float *)ld->output_blobs[0].data;
    // �����Ա���ԭshape
    CNN_BLOB rois_per;
    CNN_BLOB prob_per;
    CNN_BLOB bbox_per;
    // SHAPE_UNIT_TYPE in0s1;
    // float out[300][7];

    int num_boxes_perimg;
    int index;
    int num_boxes_curpos = 0;
    int index_max;

    ld->output_blobs[0].shape[0] = 0;


    //for (i = 0; i < 20; i++)
    //{
    //    printf("%f %f\n", cls_prob[i * 2], 
    //                            cls_prob[i * 2 + 1]);
    //}


    if (im_scale <= 0)
    {
        return  HIK_VCA_LIB_KEY_PARAM_ERR;
    }

    if (0 == ld->input_blobs[0]->shape[0])
    {
        return HIK_VCA_LIB_S_OK;
    }

    // ȱ��ѭ��
    index_max = (int)(boxes[5 * (ld->input_blobs[0]->shape[0] - 1)]);

    // Step 1: project rois to original image

    for (index = 0; index <= index_max; index++)
    {
        num_boxes_perimg = 0;

        for (n = num_boxes_curpos; n < num_boxes; n++)
        {
            // ���index equel�����
            if (rpn_boxes[n * 5] == index)
            {
                num_boxes_perimg++;
                for (c = 0; c < 4; c++)
                {
                    boxes[num_boxes_curpos * 5 + (n - num_boxes_curpos) * 4 + c] = rpn_boxes[n * 5 + c + 1] / im_scale;
                }
            }
            else
            {
                rois_per.data     = (void *)(boxes + num_boxes_curpos * 5);
                prob_per.data     = (void *)(cls_prob + num_boxes_curpos * num_classes);
                bbox_per.data     = (void *)(box_deltas + num_boxes_curpos * 4 * num_classes);
                num_boxes_curpos += num_boxes_perimg;

                break;
            }
            if (n == num_boxes - 1)
            {
                rois_per.data     = (void *)(boxes + num_boxes_curpos * 5);
                prob_per.data     = (void *)(cls_prob + num_boxes_curpos * num_classes);
                bbox_per.data     = (void *)(box_deltas + num_boxes_curpos * 4 * num_classes);
                num_boxes_curpos += num_boxes_perimg;
                break;
            }
        }

        memcpy(rois_per.shape, ld->input_blobs[0]->shape, 4 * sizeof(int));
        memcpy(prob_per.shape, ld->input_blobs[1]->shape, 4 * sizeof(int));
        memcpy(bbox_per.shape, ld->input_blobs[2]->shape, 4 * sizeof(int));
        rois_per.shape[0] = num_boxes_perimg;
        rois_per.shape[1] = 4;
        prob_per.shape[0] = num_boxes_perimg;
        bbox_per.shape[0] = num_boxes_perimg;

        // Step 2: apply inverse bbox transform
        fbbox_transform_inv(&rois_per, &bbox_per, &bbox_per, num_boxes_perimg, num_classes);

        // Step 3: clip boxes
        fclip_boxes(ld->input_blobs[3], &bbox_per, num_boxes_perimg, num_classes);

        // Step 4: NMS

        // get the num_boxes_perimg of this img

        // 4.1 selecting the best result of each roi, filting the background rois and the low confidence rois
        cls_prob_temp   = (float *)prob_per.data;
        box_deltas_temp = (float *)bbox_per.data;

        for (i = 0; i < num_boxes_perimg; i++)
        {
            c = 0;
            for (j = 1; j < num_classes; j++)
            {
                if (cls_prob_temp[j] > cls_prob_temp[c])
                {
                    c = j;
                }
            }

            if (cls_prob_temp[c] > frout_layer->model->conf_thresh)
            {
                mark[i] = c;
            }
            else
            {
                mark[i] = 0;
            }
            cls_prob_temp   += num_classes;
            box_deltas_temp += num_classes * 4;
        }
        // 4.2 deleting the background rois and the low confidence rois ��ȥ0����
        for (i = 1; i < num_classes; i++)
        {
            c               = 0;
            cls_prob_temp   = (float *)prob_per.data + i;
            box_deltas_temp = (float *)bbox_per.data + i * 4;
            for (j = 0; j < num_boxes_perimg; j++)
            {
                if (mark[j] == i)
                {
                    cls_prob_temp[c * num_classes]           = cls_prob_temp[j * num_classes];
                    box_deltas_temp[c * num_classes * 4]     = box_deltas_temp[j * num_classes * 4];
                    box_deltas_temp[c * num_classes * 4 + 1] = box_deltas_temp[j * num_classes * 4 + 1];
                    box_deltas_temp[c * num_classes * 4 + 2] = box_deltas_temp[j * num_classes * 4 + 2];
                    box_deltas_temp[c * num_classes * 4 + 3] = box_deltas_temp[j * num_classes * 4 + 3];
                    c++;
                }
            }
            roi_num_percls[i] = c;  // �������Чroi��
        }

        // 4.3 sort
        for (i = 1; i < num_classes; i++)
        {
            cls_prob_temp   = (float *)prob_per.data + i;
            box_deltas_temp = (float *)bbox_per.data + i * 4;
            for (j = 0; j < roi_num_percls[i]; j++)
            {
                for (c = j + 1; c < roi_num_percls[i]; c++)
                {
                    if (cls_prob_temp[c * num_classes] > cls_prob_temp[j * num_classes])
                    {
                        temp = cls_prob_temp[j * num_classes];
                        cls_prob_temp[j * num_classes] = cls_prob_temp[c * num_classes];
                        cls_prob_temp[c * num_classes] = temp;

                        for (k = 0; k < 4; k++)
                        {
                            temp = box_deltas_temp[j * num_classes * 4 + k];
                            box_deltas_temp[j * num_classes * 4 + k] = box_deltas_temp[c * num_classes * 4 + k];
                            box_deltas_temp[c * num_classes * 4 + k] = temp;
                        }
                    }
                }
            }
        }
        // 4.4 nms_perclasses
        for (i = 1; i < num_classes; i++)
        {
            cls_prob_temp   = (float *)prob_per.data + i;
            box_deltas_temp = (float *)bbox_per.data + i * 4;
            if (roi_num_percls[i] > 0)
            {
                fnms(box_deltas_temp, cls_prob_temp, (roi_num_percls + i), num_classes, frout_layer->model->nms_thresh);
                //fnms(box_deltas_temp, cls_prob_temp, (roi_num_percls + i), num_classes, 1.0);
            }
        }
        // 4.5����һ������Ŀ�����
        c   = 0;
        sum = 0;

        for (i = 1; i < num_classes; i++)
        {
            cls_prob_temp   = (float *)prob_per.data + i;
            box_deltas_temp = (float *)bbox_per.data + i * 4;
            for (j = 0; j < roi_num_percls[i]; j++)
            {
                out_data[c + sum_temp * 7]     = i;
                out_data[c + sum_temp * 7 + 1] = cls_prob_temp[j * num_classes];
                out_data[c + sum_temp * 7 + 2] = box_deltas_temp[j * num_classes * 4];
                out_data[c + sum_temp * 7 + 3] = box_deltas_temp[j * num_classes * 4 + 1];
                out_data[c + sum_temp * 7 + 4] = box_deltas_temp[j * num_classes * 4 + 2];
                out_data[c + sum_temp * 7 + 5] = box_deltas_temp[j * num_classes * 4 + 3];
                out_data[c + sum_temp * 7 + 6] = index;
                c += 7;
            }
            sum += roi_num_percls[i];
        }
        ld->output_blobs[0].shape[0] += sum;
        sum_temp = ld->output_blobs[0].shape[0];
    }

    return HIK_VCA_LIB_S_OK;
}


#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FROUT_Forward_Cuda_Opt(FROUT_LAYER       *frout_layer,
	                               LAYER_DATA        *ld)
{
    cudaError_t             err;
    void                    *temp1 = ld->input_blobs[2]->data;
    void                    *temp2 = ld->input_blobs[1]->data;

#ifdef CNN_PROFILE_LAYER
    OPT_PROFILE_TIME_BY_EVENT_START(1111);
#endif

	if (ld->input_blobs[2]->type == CNN_DT_FLT16)
    {
        ld->input_blobs[2]->data_gpu = frout_layer->prev_out[0].data_gpu;
        cnn_blob_half2float(ld->input_blobs[2]);
    }

    //input_blob[2] -> box
    err = cudaMemcpy(frout_layer->prev_out[0].data, 
                     ld->input_blobs[2]->data_gpu, 
                     CNN_BLOB_GetDataNum(ld->input_blobs[2]) * sizeof(float), 
                     cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    //input_blob[1] -> prob
    err = cudaMemcpy(frout_layer->prev_out[1].data, 
                     ld->input_blobs[1]->data_gpu, 
                     CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float), 
                     cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    ld->input_blobs[2]->data    = frout_layer->prev_out[0].data;
    ld->input_blobs[1]->data    = frout_layer->prev_out[1].data;
    
    //���ú��ڴ��ֱ�ӵ���CPU��forward
    CNN_FROUT_Forward(frout_layer, ld);

    ld->input_blobs[2]->data = temp1;
    ld->input_blobs[1]->data = temp2;

#ifdef CNN_PROFILE_LAYER
    OPT_PROFILE_TIME_BY_EVENT_STOP(1111, "FROUT", 1, 1);
#endif
    return HIK_VCA_LIB_S_OK;
}
#endif // CNN_CUDA_OPT
