/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: cnn_common.c
* �ļ���ʶ: CNN_COMMON_C
* ժ    Ҫ: 
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-01-30
* ��    ע: 
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <stdlib.h>
#include <memory.h>
#include <math.h>
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "cnn_cuda_config.h"
#endif
#include <assert.h>
#include "cnn_half.h"
#include "blob.h"

#include "cnn_common.h"

/***************************************************************************************************
* ��  ��: �ڻ���ivs_buf�з���һ���СΪsize, align���ֽڶ�����ڴ��
* ��  ��: ivs_buf                - I/O ��������ṹ��
*         size                   - I   �����ڴ�Ĵ�С
*         alignment              - I   �ڴ�Ķ��뷽ʽ
*         clean                  - I   �Ƿ�����
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
void *CNN_alloc_buffer(CNN_BUF          *ivs_buf,
                       unsigned int      size,
                       VCA_MEM_ALIGNMENT alignment,
                       unsigned int      clean)
{
    int          align = (int)alignment;
    void        *buf;
    unsigned int free_size;

    assert(0 != align);
    assert(0 == ((align - 1) & align)); // �ж��Ƿ�ֻ��1��bitΪ1

    /* �����п����ڴ���ʼλ�� */
    buf = (void *)(((size_t)ivs_buf->cur_pos + (align - 1)) & (~(align - 1)));

    /* ���㻺���еĿ���ռ��С */
    free_size = (char *)ivs_buf->end - (char *)buf;

    /*�ռ䲻�������ؿ�ָ��*/
    if (free_size < size)
    {
        buf = NULL;
    }
    else
    {
        /* ��շ����ڴ� */
        if (clean)
        {
            memset(buf, 0, size);
        }

        /* ���¿���ָ��λ�� */
        ivs_buf->cur_pos = (void *)((char *)buf + size);
    }

    return buf;
}


/***************************************************************************************************
* ��  ��: �ڻ���ivs_buf�з���һ���СΪsize, align���ֽڶ�����ڴ��
* ��  ��: 
*         buf_cpu                - I/O ��������ṹ��(CPU)
*         buf_gpu                - I/O ��������ṹ��(GPU)
*         size                   - I   �����ڴ�Ĵ�С
*         alignment              - I   �ڴ�Ķ��뷽ʽ
*         clean                  - I   �Ƿ����㣬0������,  1����
*         copy                   - I   �Ƿ񿽱���0������,  1����
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
HRESULT cnn_alloc_blob_buffer(CNN_BLOB              *blob,
                              CNN_BUF               *buf_cpu,
                              CNN_BUF               *buf_gpu,
                              VCA_MEM_ALIGNMENT      alignment_cpu,
                              VCA_MEM_ALIGNMENT      alignment_gpu,
                              void                  *fp16_workspace)
{
    size_t                size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(blob));

    if (buf_cpu)
    {
        blob->data  = CNN_alloc_buffer(buf_cpu, size, alignment_cpu, 0);
        CNN_CHECK_ERROR(blob->data == NULL, "CNN_alloc_buffer for cpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
    }
    else
    {
        blob->data  = NULL;
    }

    if (buf_gpu)
    {
#ifdef ARCH_SUPPORT_FP16
        blob->data_gpu_fp16         = CNN_alloc_buffer(buf_gpu, size, alignment_gpu, 0);
        CNN_CHECK_ERROR(blob->data_gpu_fp16 == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
        blob->data_gpu              = NULL;
#else
        blob->data_gpu              = CNN_alloc_buffer(buf_gpu, size, alignment_gpu, 0);
        CNN_CHECK_ERROR(blob->data_gpu == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);

        blob->data_gpu_fp16         = NULL;
#endif
    }
    else
    {
        blob->data_gpu              = NULL;
        blob->data_gpu_fp16         = NULL;
    }
    return HIK_VCA_LIB_S_OK;
}



/***************************************************************************************************
* ��  ��: �ڻ���ivs_buf�з���һ���СΪsize, align���ֽڶ�����ڴ��
* ��  ��:
*         buf_cpu                - I/O ��������ṹ��(CPU)
*         buf_gpu                - I/O ��������ṹ��(GPU)
*         size                   - I   �����ڴ�Ĵ�С
*         alignment              - I   �ڴ�Ķ��뷽ʽ
*         fp16_workspace         - I   ����cuda�Ķ����ڴ�
*         blob_data_type         - I   �������ʱ����blob_data_type���е���
* ����ֵ: ������
***************************************************************************************************/
HRESULT cnn_alloc_blob_buffer_optional(CNN_BLOB         *blob,
	                          CNN_BUF          *buf_cpu,
							  CNN_BUF          *buf_gpu,
							  VCA_MEM_ALIGNMENT alignment_cpu,
							  VCA_MEM_ALIGNMENT alignment_gpu,
							  void             *fp16_workspace,
							  BLOB_DATA_TYPE    blob_data_type)
{
	size_t                size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(blob));
	if (buf_cpu)
	{
		blob->data = CNN_alloc_buffer(buf_cpu, size, alignment_cpu, 0);
		CNN_CHECK_ERROR(blob->data == NULL, "CNN_alloc_buffer for cpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
	}
	else
	{
		blob->data = NULL;
	}
	if (buf_gpu)
	{
#ifdef ARCH_SUPPORT_FP16
	    if (CNN_DT_FLT32 ==blob_data_type)
	    {
	    	blob->data_gpu = CNN_alloc_buffer(buf_gpu, size, alignment_gpu, 0);
	    	CNN_CHECK_ERROR(blob->data_gpu == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
	    	blob->data_gpu_fp16 = NULL;
	    }
	    else
	    {
	    	blob->data_gpu_fp16 = CNN_alloc_buffer(buf_gpu, size, alignment_gpu, 0);
	    	CNN_CHECK_ERROR(blob->data_gpu_fp16 == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
	    	blob->data_gpu = NULL;
	    }
#else
		blob->data_gpu = CNN_alloc_buffer(buf_gpu, size, alignment_gpu, 0);
		CNN_CHECK_ERROR(blob->data_gpu == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
		blob->data_gpu_fp16 = NULL;
#endif
	}
	else
	{
		blob->data_gpu = NULL;
		blob->data_gpu_fp16 = NULL;
	}
	return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: cpu�ڴ���gpu�ڴ滥����
* ��  ��: 
*         blob                   -I/O      blob
*         dir                    -I         direction
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
HRESULT cnn_copy_blob_between_gpu(CNN_BLOB              *blob,
                                  CNN_MEM_COPY_DIR       dir)
{
    cudaError_t err;
    if (blob->data && blob->data_gpu)
    {
        if (dir == CNN_MEM_COPY_HOST_TO_DEIVICE)
        {
            err = cudaMemcpy(blob->data_gpu, blob->data, CNN_BLOB_GetDataSize(blob), cudaMemcpyHostToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));
        }
        else if (dir == CNN_MEM_COPY_DEVICE_TO_HOST)
        {
            err = cudaMemcpy(blob->data, blob->data_gpu, CNN_BLOB_GetDataSize(blob), cudaMemcpyDeviceToHost);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));
        }
        else
        {
            return HIK_VCA_LIB_KEY_PARAM_ERR;
        }
        return HIK_VCA_LIB_S_OK;
    }
    else
    {
        return HIK_VCA_LIB_S_OK;
    }

    return HIK_VCA_LIB_S_OK;
}


#endif

/***************************************************************************************************
* ��  ��: ��ʼ��blob��data����
* ��  ��: 
*         blob                   -I/O      blob
*         dir                    -I         direction
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
HRESULT cnn_init_blob(CNN_BLOB              *blob,
                      void                  *data)
{
#ifdef CNN_CUDA_OPT
    cudaError_t err;
#endif
    HRESULT     hr;

    if (blob->data_gpu && data)
    {
#ifdef CNN_CUDA_OPT
        err = cudaMemcpy(blob->data_gpu, data, CNN_BLOB_GetDataNum(blob) * sizeof(float), cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));
#endif  // CNN_CUDA_OPT
    }
    else if (blob->data && data)
    {
        memcpy(blob->data, data, CNN_BLOB_GetDataNum(blob) * sizeof(float));
    }

#ifdef CNN_CUDA_OPT
    if (blob->data_gpu && blob->data_gpu_fp16)
    {
        hr = cnn_blob_float2half(blob);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);
    }
#endif  // CNN_CUDA_OPT
    

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: blob half to float��half�����ݱ����Ѿ�����
* ��  ��: 
*         blob                   -I/O      blob
* ����ֵ: ������
***************************************************************************************************/
HRESULT cnn_blob_half2float(CNN_BLOB              *blob)
{
    int         ret;
    int         num = CNN_BLOB_GetDataNum(blob);

    if (blob->data_gpu && blob->data_gpu_fp16)
    {
        return cnn_half2float(blob->data_gpu_fp16, blob->data_gpu, num);
    }
    return HIK_VCA_LIB_KEY_PARAM_ERR;
}

/***************************************************************************************************
* ��  ��: blob float to half��float�����ݱ����Ѿ�����
* ��  ��:
*         blob                   -I/O      blob
* ����ֵ: ������
***************************************************************************************************/
HRESULT cnn_blob_float2half(CNN_BLOB              *blob)
{
    int         ret;
    int         num = CNN_BLOB_GetDataNum(blob);
    if (blob->data_gpu && blob->data_gpu_fp16)
    {
        return cnn_float2half(blob->data_gpu, blob->data_gpu_fp16, num);
    }
    return HIK_VCA_LIB_KEY_PARAM_ERR;
}

/***************************************************************************************************
* ��  ��: data uchar to half��uchar�����ݱ����Ѿ�����
* ��  ��:
*         data                   -I/O      data
* ����ֵ: ������
***************************************************************************************************/
HRESULT cnn_blob_uchar2half(unsigned char *data, CNN_BLOB *blob)
{
	int         num = CNN_BLOB_GetDataNum(blob);
	if (data && blob->data_gpu_fp16)
	{
		return cnn_uchar2half(data, blob->data_gpu_fp16, num);
	}
	return HIK_VCA_LIB_KEY_PARAM_ERR;
}

#endif // CNN_CUDA_OPT


/***************************************************************************************************
* ��  ��: ����memory buffer
* ��  ��:
*         buf                   - O      ����
*         start                 - I      ������ʼ��ַ
*         end                   - I      ���������ַ
*         cur                   - I      ���浱ǰ��ַ
* ����ֵ: ������
***************************************************************************************************/
void cnn_set_mem_buf(CNN_BUF *buf, void  *start, void *end, void *cur)
{
    if (buf)
    {
        buf->start      = start;
        buf->end        = end;
        buf->cur_pos    = cur;
    }
}


/***************************************************************************************************
* ��  ��: ����ת��
* ��  ��:
*         dst                 - O      Ŀ�����
*         src                 - I      Դ����
*         h                   - I      Դ�����
*         w                   - I      Դ�����
* ����ֵ: ������
***************************************************************************************************/
void CNN_matrix_rotate(void *dst, void *src, int h, int w, BLOB_DATA_TYPE type)
{
    int i, j;
    for (i = 0; i < w; i++)
    {
        for (j = 0; j < h; j++)
        {
            if (type == CNN_DT_FLT32)
            {
                *((float *)dst + i * h + j) = *((float *)src + j * w + i);
            }
            else if (type == CNN_DT_FLT16)
            {
                *((cnn_half *)dst + i * h + j) = *((cnn_half *)src + j * w + i);
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: ���start1-sstop1��һ���ڴ��Ƿ���start2-stop2��һ���ڴ��н���
* ��  ��:
*         dst                 - O      Ŀ�����
*         src                 - I      Դ����
*         h                   - I      Դ�����
*         w                   - I      Դ�����
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
int CNN_check_mem_overlap(char *start1, char *stop1, char *start2, char *stop2)
{
    int ret = 0;

    if ((start1 == start2) || (stop1 == stop2))
    {
        return 1;
    }

    if (start1 < start2)
    {
        if (stop1 < stop2)
        {
            return 0;
        }
        return 1;
    }

    if (start2 < start1)
    {
        if (stop2 < stop1)
        {
            return 0;
        }
        return 1;
    }

    return 0;
}

/***************************************************************************************************
* ��  ��: ����Kernel size����pad size
* ��  ��:
*         kernel_size                   - I      kernel size
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
int CNN_get_pad(int kernel_size)
{
    return kernel_size / 2;
}


/***************************************************************************************************
* ��  ��: ����pad��Ĵ�С
* ��  ��:
*         size                   - I      ԭʼsize
*         pad_size1              - I      һ�ߵ�pad size
*         pad_size2              - I      ��һ��pad size
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
int CNN_get_padded_size(int size, int pad_size1, int pad_size2)
{
    return pad_size1 + size + pad_size2;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ��zip������ݽ���pad
* ��  ��:
*         src                    - I      src data
*         dst                    - O      dst data
*         batch                  - I      batch size
*         channel                - I      channel
*         height                 - I      height
*         width                  - I      width
*         pad_h                  - I      pad_h
*         pad_w                  - I      pad_w
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
HRESULT CNN_pad_zip_data(float *src, 
                         float *dst, 
                         int batch, 
                         int channel, 
                         int height, 
                         int width, 
                         int pad_h, 
                         int pad_w)
{
    int             dst_w_pitch = pad_w * 2 + width;
    int             dst_h_pitch = pad_h * 2 + height;
    int             c;
    float           *dst_ptr, *src_ptr;
    cudaError_t     err;

    for (c = 0; c < channel * batch; c++)
    {
        dst_ptr = c * dst_h_pitch * dst_w_pitch + dst;
        src_ptr = c * height * width + src;

        err = cudaMemcpy2D(dst_ptr + pad_h * dst_w_pitch + pad_w,
                           dst_w_pitch * sizeof(float),
                           src_ptr,
                           width * sizeof(float),
                           width * sizeof(float),
                           height,
                           cudaMemcpyDeviceToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy2D", CNN_convert_cudart_error_code(err));
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��zip������ݽ���unpad
* ��  ��:
*         src                    - I      src data
*         dst                    - O      dst data
*         batch                  - I      batch size
*         channel                - I      channel
*         height                 - I      height
*         width                  - I      width
*         pad_h                  - I      pad_h
*         pad_w                  - I      pad_w
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
HRESULT CNN_unpad_zip_data(float    *src, 
                           float    *dst, 
                           int      batch, 
                           int      channel, 
                           int      height, 
                           int      width, 
                           int      pad_h, 
                           int      pad_w)
{
    int             src_w_pitch = pad_w * 2 + width;
    int             src_h_pitch = pad_h * 2 + height;
    int             c;
    float           *dst_ptr, *src_ptr;
    cudaError_t     err;

    for (c = 0; c < channel * batch; c++)
    {
        dst_ptr = c * height * width + dst;
        src_ptr = c * src_h_pitch * src_w_pitch + src;
        
        err = cudaMemcpy2D(dst_ptr,
                           width * sizeof(float),
                           src_ptr + pad_h * src_w_pitch + pad_w,
                           src_w_pitch * sizeof(float),
                           width * sizeof(float),
                           height,
                           cudaMemcpyDeviceToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy2D", CNN_convert_cudart_error_code(err));
    }

    return HIK_VCA_LIB_S_OK;
}




/***************************************************************************************************
* ��  ��: ��zip��pad������ݽ���unpad��unzip
* ��  ��:
*         src                    - I      src data
*         dst                    - O      dst data
*         batch                  - I      batch size
*         channel                - I      channel
*         height                 - I      height
*         width                  - I      width
*         pad_h                  - I      pad_h
*         pad_w                  - I      pad_w
* ����ֵ: 1->�н�����0->��
***************************************************************************************************/
HRESULT CNN_unpad_unzip(float    *src, 
                        float    *dst, 
                        int      batch, 
                        int      channel, 
                        int      height, 
                        int      width, 
                        int      pad_h, 
                        int      pad_w)
{
    int             src_w_pitch = pad_w * 2 + width;
    int             src_h_pitch = pad_h * 2 + height;
    int             c;
    float           *dst_ptr, *src_ptr;
    cudaError_t     err;

    for (c = 0; c < channel * batch; c++)
    {
        dst_ptr = c * height * width + dst;
        src_ptr = c * src_h_pitch * src_w_pitch + src;
        
        err = cudaMemcpy2D(dst_ptr,
                           width * sizeof(float),
                           src_ptr + pad_h * src_w_pitch + pad_w,
                           src_w_pitch * sizeof(float),
                           width * sizeof(float),
                           height,
                           cudaMemcpyDeviceToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy2D", CNN_convert_cudart_error_code(err));
    }

    return HIK_VCA_LIB_S_OK;
}

#endif // CNN_CUDA_OPT