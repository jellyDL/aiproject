/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: fully_connected_layer.c
* �ļ���ʶ: FULLY_CONNECTED_LAYER_C
* ժ    Ҫ: fully_connected��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-02
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN

#include <string.h>
#include <stdio.h>
#ifdef CNN_CUDA_OPT
#include <cublas_v2.h>
#include <cudnn.h>
#include "convolution_layer_cuda.h"
#include "cnn_cudablas.h"
#include "cnn_basic_kernel.h"
#endif // CNN_CUDA_OPT
#ifdef MKL_OPT
#include "mkl_cblas.h"
#else
#include "cblas.h"
#endif // MKL_OPT
#include "fully_connected_layer.h"
#include "cnn_common.h"
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif //OPT_TIMER

#ifdef CNN_NNPACK_OPT
#include"nnpack.h"
#endif


#define FC_INPUT_UNPAD_UNZIP_DATA   0      // ����unpad��unzip�����ڴ�
#define FC_OUTPUT_ZIP_PAD_DATA      1      // ����pad��zip����ڴ�

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: fc_layer               - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_compute_in_out_shape(FULLY_CONNECTED_LAYER *fc_layer,
                                                LAYER_DATA            *ld)
{
    int i = 0;
    int inner_size;
    int weight_num;

    HKA_CHECK_ERROR(ld->input_blobs_num != 1,       HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims <= 1, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1,      HIK_VCA_CNN_MODEL_ERROR);

    if (fc_layer->model->axis < 0)
    {
        fc_layer->model->axis += ld->input_blobs[0]->ndims;
    }

    weight_num = CNN_BLOB_GetTotal(&fc_layer->model->param_blobs[0], 0, CNN_BLOB_MAX_DIM);
    inner_size = CNN_BLOB_GetTotal(ld->input_blobs[0], fc_layer->model->axis, CNN_BLOB_MAX_DIM);
    HKA_CHECK_ERROR(inner_size * fc_layer->model->num_outputs != weight_num, HIK_VCA_CNN_MODEL_ERROR);

    ld->output_blobs[0].ndims = fc_layer->model->axis + 1;
    ld->output_blobs[0].type  = cnn_get_blob_type();
    for (i = 0; i < CNN_BLOB_MAX_DIM; i++)
    {
        if (i < fc_layer->model->axis)
        {
            ld->output_blobs[0].shape[i] = ld->input_blobs[0]->shape[i];
        }
        else if (i == fc_layer->model->axis)
        {
            ld->output_blobs[0].shape[i] = fc_layer->model->num_outputs;
        }
        else
        {
            ld->output_blobs[0].shape[i] = 1;
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_Reshape(void       *handle,
                                   LAYER_DATA *ld)
{
    int                    i;
    HRESULT                hr;
    FULLY_CONNECTED_LAYER *fc_layer = (FULLY_CONNECTED_LAYER *)handle;

    hr = CNN_FULLYCONNECTED_compute_in_out_shape(fc_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    if (fc_layer->model->bias)
    {
        fc_layer->bias_ones_blob.ndims    = 4;
        fc_layer->bias_ones_blob.type     = cnn_get_blob_type();
        fc_layer->bias_ones_blob.shape[0] = 1;
        fc_layer->bias_ones_blob.shape[1] = 1;
        fc_layer->bias_ones_blob.shape[2] = 1;
        for (i = 0; i < fc_layer->model->axis; i++)
        {
            fc_layer->bias_ones_blob.shape[2] *= ld->output_blobs[0].shape[i];
        }
        fc_layer->bias_ones_blob.shape[3] = 1;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_init_model(const char            *hyperparams,
                                      const char            *param_blobs,
                                      LAYER_MODEL            *ld,
                                      FULLY_CONNECTED_MODEL *fc_model)
{
    int         r;
    HRESULT     hr;
    const char  nout[] = "num_output";
    const char  bt[]   = "bias_term";
    const char  axis[] = "axis";
    const char *ptr;

    ptr = strstr(hyperparams, nout);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(nout) + 1, "%d", &fc_model->num_outputs);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

    fc_model->bias = 1;
    if (ptr = strstr(hyperparams, bt))
    {
        r = sscanf(ptr + strlen(bt) + 1, "%d", &fc_model->bias);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    fc_model->axis = 1;
    if (ptr = strstr(hyperparams, axis))
    {
        r = sscanf(ptr + strlen(axis) + 1, "%d", &fc_model->axis);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    hr = CNN_BASE_GetParamBlobs(param_blobs, fc_model->param_blobs, FC_LAYER_MAX_PARAM_BLOB_NUM, cnn_get_blob_type(), 0);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_Create(LAYER_DATA *ld,
                                  CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                                  void      **handle)
{
    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];
    CNN_BUF                 *cpu_data_buf   = &mem_buf[1];
    CNN_BUF                 *gpu_data_buf   = &mem_buf[2];
    FULLY_CONNECTED_LAYER   *fc_layer;

    size_t                   mem_size;
    int                      hr;

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#else
    cpu_data_buf = NULL;
#endif

    fc_layer = (FULLY_CONNECTED_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                         sizeof(FULLY_CONNECTED_LAYER),
                                                         CNN_MEM_ALIGN_SIZE,
                                                         1);
    HKA_CHECK_MEMOUT(fc_layer);

    fc_layer->model = ld->layer_model->model_handle;

    hr = CNN_FULLYCONNECTED_Reshape(fc_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

#ifdef ARCH_SUPPORT_FP16
    mem_size = CNN_BLOB_GetDataSize(&ld->input_blobs[0]);
    ld->layer_reserved_mem[FC_INPUT_UNPAD_UNZIP_DATA].data  = CNN_alloc_buffer(gpu_data_buf, 
                                                                               mem_size,
                                                                               CNN_CUDA_MEM_ALIGNMENT, 
                                                                               0);
    CNN_CHECK_ERROR(ld->layer_reserved_mem[FC_INPUT_UNPAD_UNZIP_DATA].data == NULL, 
                    "memory out", 
                    HIK_VCA_LIB_E_MEM_OUT);

#endif

    if (fc_layer->model->bias)
    {
        hr = cnn_alloc_blob_buffer(&fc_layer->bias_ones_blob,
                                   cpu_handle_buf,
                                   NULL,                       // GPU����Ҫ����ڴ�
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

        hr = CNN_BLOB_InitOneBiasBlob(&fc_layer->bias_ones_blob);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_init_one_bias_blob failed", hr);
    }

    *handle = fc_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_GetMemsize(LAYER_DATA    *ld,
                                      VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    int                   hr;
    FULLY_CONNECTED_LAYER fc_layer;
    size_t                size;

    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2 *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *gpu_data_tab   = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_data_tab = NULL;
#else
    cpu_data_tab = NULL;
#endif
    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    fc_layer.model = ld->layer_model->model_handle;

    hr = CNN_FULLYCONNECTED_Reshape(&fc_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    size  = CNN_SIZE_ALIGN(sizeof(FULLY_CONNECTED_LAYER));
    size += fc_layer.model->bias ? CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&fc_layer.bias_ones_blob)) : 0;
    CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
   
    size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0]));
    CNN_BASE_SetMemTab(cpu_data_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0]));
    CNN_BASE_SetMemTab(gpu_data_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

#ifdef ARCH_SUPPORT_FP16
    size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(ld->input_blobs[0]));
    CNN_BASE_SetMemTab(gpu_data_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
#endif

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ʼ��blob��data����
* ��  ��: 
*         blob                   -I/O      blob
*         data                   -I        ����
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_init_blob(CNN_BLOB              *blob,
                                     void                  *data)
{
#ifdef CNN_CUDA_OPT
    cudaError_t err;
#endif
    HRESULT     hr;

    if (blob->data_gpu && data)
    {
#ifdef CNN_CUDA_OPT
        err = cudaMemcpy((char *)blob->data_gpu + CNN_BLOB_GetDataNum(blob) * sizeof(float), 
                         data, 
                         CNN_BLOB_GetDataNum(blob) * sizeof(float), 
                         cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));

        hr = CNN_matrix_rotate_cuda(blob->data_gpu,
                                    (char *)blob->data_gpu + CNN_BLOB_GetDataNum(blob) * sizeof(float),
                                    blob->shape[0],
                                    blob->shape[1],
                                    CNN_DT_FLT32);
        CNN_CHECK_ERROR(err != cudaSuccess, "CNN_matrix_rotate_cuda", CNN_convert_cudart_error_code(err));
#endif  // CNN_CUDA_OPT
    }
    else if (blob->data && data)
    {
        memcpy(blob->data, data, CNN_BLOB_GetDataNum(blob) * sizeof(float));
    }

#ifdef CNN_CUDA_OPT
    if (blob->data_gpu && blob->data_gpu_fp16)
    {
        hr = cnn_blob_float2half(blob);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);
    }
#endif  // CNN_CUDA_OPT

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_FULLYCONNECTED_GetModelMemsize(const char       *hyperparams, 
                                           const char       *param_blobs, 
                                           LAYER_MODEL      *ld, 
                                           VCA_MEM_TAB_V2    mem_tab[MODEL_MEM_TAB_NUM])
{
    int                   hr;
    int                   bi;
    int                   param_blob_num;
    FULLY_CONNECTED_MODEL fc_model;
    size_t                size;

    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2     *cpu_model_tab  = &mem_tab[1];
    VCA_MEM_TAB_V2     *gpu_model_tab  = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_model_tab = NULL;
#else
    cpu_model_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    hr = CNN_FULLYCONNECTED_init_model(hyperparams, param_blobs, ld, &fc_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    CNN_BASE_SetMemTab(cpu_handle_tab, 
                       CNN_SIZE_ALIGN(sizeof(FULLY_CONNECTED_MODEL)),
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    param_blob_num = (0 == fc_model.bias ? 1 : FC_LAYER_MAX_PARAM_BLOB_NUM);

    size = 0;
    for (bi = 0; bi < param_blob_num; bi++)
    {
        size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&fc_model.param_blobs[bi]));
    }

    CNN_BASE_SetMemTab(cpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    //����ϵ������ת��
    size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&fc_model.param_blobs[0]));              

    CNN_BASE_SetMemTab(gpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �ڻ���ivs_buf�з���һ���СΪsize, align���ֽڶ�����ڴ��
* ��  ��: 
*         buf_cpu                - I/O ��������ṹ��(CPU)
*         buf_gpu                - I/O ��������ṹ��(GPU)
*         size                   - I   �����ڴ�Ĵ�С
*         alignment              - I   �ڴ�Ķ��뷽ʽ
*         clean                  - I   �Ƿ����㣬0������,  1����
*         copy                   - I   �Ƿ񿽱���0������,  1����
* ����ֵ: (void*)����õ��ڴ�λ��ָ��
***************************************************************************************************/
static HRESULT CNN_FULLYCONNECTED_alloc_blob_buffer(CNN_BLOB              *blob,
                                                    CNN_BUF               *buf_cpu,
                                                    CNN_BUF               *buf_gpu,
                                                    size_t                alignment_cpu,
                                                    size_t                alignment_gpu,
                                                    void                  *fp16_workspace)
{
    size_t                size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(blob));

    if (buf_cpu)
    {
        blob->data  = CNN_alloc_buffer(buf_cpu, size, alignment_cpu, 0);
        CNN_CHECK_ERROR(blob->data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }
    else
    {
        blob->data  = NULL;
    }

    if (buf_gpu)
    {
#ifdef ARCH_SUPPORT_FP16
        blob->data_gpu_fp16         = CNN_alloc_buffer(buf_gpu, size * 2, alignment_gpu, 0);
        CNN_CHECK_ERROR(blob->data_gpu_fp16 == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
        blob->data_gpu              = NULL;
#else
        blob->data_gpu              = CNN_alloc_buffer(buf_gpu, size * 2, alignment_gpu, 0);
        CNN_CHECK_ERROR(blob->data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

        blob->data_gpu_fp16         = NULL;
#endif  // ARCH_SUPPORT_FP16
    }
    else
    {
        blob->data_gpu              = NULL;
        blob->data_gpu_fp16         = NULL;
    }
    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_FULLYCONNECTED_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    int                     hr;
    int                     bi;
    int                     param_blob_num;
    FULLY_CONNECTED_MODEL  *fc_model;

    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];
    CNN_BUF                 *cpu_model_buf  = &mem_buf[1];
    CNN_BUF                 *gpu_model_buf  = &mem_buf[2];

    //ϵ��������Ҫת��
    BLOB_INIT_FUNCS         blob_init_funcs = {CNN_FULLYCONNECTED_init_blob, cnn_init_blob, cnn_init_blob, cnn_init_blob};

#ifndef CNN_CUDA_OPT
    gpu_model_buf = NULL;
#else
    cpu_model_buf = NULL;
#endif // CNN_CUDA_OPT
    
    fc_model = (FULLY_CONNECTED_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(FULLY_CONNECTED_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(fc_model);

    hr = CNN_FULLYCONNECTED_init_model(hyperparams, param_blobs, ld, fc_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    param_blob_num = (0 == fc_model->bias ? 1 : FC_LAYER_MAX_PARAM_BLOB_NUM);

    for (bi = 0; bi < param_blob_num; bi++)
    {
        if (bi == 0)
        {
            hr = CNN_FULLYCONNECTED_alloc_blob_buffer(&fc_model->param_blobs[bi],
                                   cpu_model_buf,
                                   gpu_model_buf,
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_FULLYCONNECTED_alloc_blob_buffer", hr);
        }
        else
        {
            hr = cnn_alloc_blob_buffer(&fc_model->param_blobs[bi],
                                       cpu_model_buf,
                                       gpu_model_buf,
                                       CNN_MEM_ALIGN_SIZE,
                                       CNN_CUDA_MEM_ALIGNMENT,
                                       NULL);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);
        }
#ifdef ARCH_SUPPORT_FP16
        fc_model->param_blobs[bi].data_gpu = ld->fp16_workspace;
#endif // ARCH_SUPPORT_FP16
    }

    hr = CNN_BASE_GetParamBlobs(param_blobs, 
                                fc_model->param_blobs,
                                FC_LAYER_MAX_PARAM_BLOB_NUM, 
                                cnn_get_blob_type(),
                                blob_init_funcs);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = fc_model;

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_NNPACK_OPT
/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_Forward_Nnpack(void       *handle,
                                LAYER_DATA *ld)
{
    int                    i;
    int                    M, N, K;
    FULLY_CONNECTED_LAYER *fc_layer = (FULLY_CONNECTED_LAYER *)handle;

	enum nnp_status hr;

    void     *blob_data;
    CNN_BLOB *input_blob  = ld->input_blobs[0];
    CNN_BLOB *weight_blob = &fc_layer->model->param_blobs[0];
    CNN_BLOB *bias_blob   = &fc_layer->model->param_blobs[1];

    M = 1;

    for (i = 0; i < fc_layer->model->axis; i++)
    {
        M *= input_blob->shape[i];
    }

    K = 1;
    for ( ; i < input_blob->ndims; i++)
    {
        K *= input_blob->shape[i];
    }

    N = fc_layer->model->num_outputs;

    blob_data = CNN_BLOB_GetPtr(input_blob, 0, 0, 0, 0);

	if (M == 1)
	{
		hr = nnp_fully_connected_inference(K, N, input_blob->data, weight_blob->data, ld->output_blobs[0].data, NULL);
		if (hr != nnp_status_success)
		{
			return CNN_NNPACK_ERROR_CODE_BASE + (int)hr;
		}
		if (fc_layer->model->bias)
		{

            M = fc_layer->bias_ones_blob.shape[2];
            K = 1;
            cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, M,
						N, K, 1.0f, fc_layer->bias_ones_blob.data, K, bias_blob->data, N, 1.0f,
						ld->output_blobs[0].data, N);

		}		
	}
	else
	{

		CNN_FULLYCONNECTED_Forward(fc_layer,ld);

	}
    return HIK_VCA_LIB_S_OK;
}
#endif

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_Forward(void       *handle,
                                   LAYER_DATA *ld)
{
    int                    i;
    int                    M, N, K;
    FULLY_CONNECTED_LAYER *fc_layer = (FULLY_CONNECTED_LAYER *)handle;

    void     *blob_data;
    CNN_BLOB *input_blob  = ld->input_blobs[0];
    CNN_BLOB *weight_blob = &fc_layer->model->param_blobs[0];
    CNN_BLOB *bias_blob   = &fc_layer->model->param_blobs[1];

    M = 1;

    for (i = 0; i < fc_layer->model->axis; i++)
    {
        M *= input_blob->shape[i];
    }

    K = 1;
    for ( ; i < input_blob->ndims; i++)
    {
        K *= input_blob->shape[i];
    }

    N = fc_layer->model->num_outputs;

    blob_data = CNN_BLOB_GetPtr(input_blob, 0, 0, 0, 0);

#ifndef CNN_CUDA_OPT
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasTrans, M,
                N, K, 1.0f, input_blob->data, K, weight_blob->data, K, 0.f,
                ld->output_blobs[0].data, N);
#endif

    if (fc_layer->model->bias)
    {
#ifndef CNN_CUDA_OPT
        M = fc_layer->bias_ones_blob.shape[2];
        K = 1;
        cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, M,
                    N, K, 1.0f, fc_layer->bias_ones_blob.data, K, bias_blob->data, N, 1.0f,
                    ld->output_blobs[0].data, N);
#endif
    }

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: cublas���������C = A * B',���о����д�, A: M * K, B: N * K
*         cublasʹ�õľ�����밴�д�,��Ҫ���þ�����˵�����
* ��  ��:
*         cnn_cublas_handle             - I   cnn cublas handle
*         A                             - I   A
*         B                             - I   B
*         bias                          - I   bias
*         C                             - O   C
*         M                             - I   M   A�����С M * K
*         K                             - I   K
*         N                             - I   N����B�����С N *��K
*         add_bias                      - I   �Ƿ��ƫ��
* ����ֵ: ��
***************************************************************************************************/
static HRESULT cnn_sgemm_cublas(CNN_CUDA_HANDLE          *cnn_cuda_handle,
                                float_t                  *A,
                                float_t                  *B,
                                float_t                  *bias,
                                float_t                  *C,
                                BLOB_DATA_TYPE            type,
                                int                       M,
                                int                       K,
                                int                       N,
                                int                       add_bias)
{
    cublasHandle_t   cublas_handle  = cnn_cuda_handle->cublas_handle.cublas_handle;
    cudnnDataType_t  data_type      = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;
    int              alpha          = (type == CNN_DT_FLT32) ? 0x3f800000 : 0x00003c00;
    float            beta           = 0.0f;
    cublasStatus_t   cublas_status;
    HRESULT          hr;

    cublasStatus_t  (*gemm_func)(cublasHandle_t,
                                 cublasOperation_t,
                                 cublasOperation_t,
                                 int,
                                 int,
                                 int,
                                 const float*, 
                                 const float*,
                                 int,
                                 const float*,
                                 int,
                                 const float*,  
                                 float*,
                                 int);

    if (M == 1)                         //������������
    {
        if (data_type == CUDNN_DATA_FLOAT)
        {
            cublas_status = cublasSgemv(cublas_handle, CUBLAS_OP_N, N, K, (float *)&alpha, B, N, A, 1, &beta, C, 1);
            CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "cublasSgemv failed", CNN_convert_cublas_error_code(cublas_status));
        }
        else if (data_type == CUDNN_DATA_HALF)
        {
            hr = CNN_BLAS_hgemv((const void *)B, (const void *)A, (const void *)bias, (void *)C, N, K, add_bias);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_BLAS_hgemv failed", hr);
            return HIK_VCA_LIB_S_OK;
        }
        else
        {
            printf("data type not support %s %d\n", __FILE__, __LINE__);
            return HIK_VCA_LIB_KEY_PARAM_ERR;
        }
        goto L1;
    }

    //����cublasSgemvû�ж�Ӧ��cublasHgemv������������������Ҳ���þ����������˵Ľӿ�
    if (data_type == CUDNN_DATA_FLOAT)
    {
        gemm_func = cublasSgemm;
    }
    else
    {
#ifdef ARCH_SUPPORT_FP16
        gemm_func = cublasHgemm;
#else
        return HIK_VCA_LIB_KEY_PARAM_ERR;
#endif
    }

    cublas_status = gemm_func(cublas_handle,
                              CUBLAS_OP_N,
                              CUBLAS_OP_N,
                              N,
                              M,
                              K,
                              (float *)&alpha,
                              B,              //B->weight
                              N,
                              A,              //A->input
                              K,
                              &beta,
                              C,
                              N);
    CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "gemm_func failed", CNN_convert_cublas_error_code(cublas_status));

L1:
    if (add_bias)
    {
        hr = CNN_CONV_addbias_cuda(C, bias, 1, N, M, type);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_addbias_cuda", hr);
    }
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: FCǰ�򴫲�(CUDA��)
* ��  ��: 
*         fc_layer                 - I   fc layer
*         ld                       - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_FULLYCONNECTED_Forward_Cuda_Opt(FULLY_CONNECTED_LAYER       *fc_layer,
                                            LAYER_DATA                  *ld)
{
    int                      i, M, N, K;
    HRESULT                  hr;
    cudaError_t              err;
    CNN_CUDA_HANDLE          *cnn_cuda_handle   = ld->cuda_handle;

    CNN_BLOB                *input_blob         = ld->input_blobs[0];
    CNN_BLOB                *weight_blob        = &fc_layer->model->param_blobs[0];
    CNN_BLOB                *bias_blob          = &fc_layer->model->param_blobs[1];
    CNN_BLOB                *output_blob        = &ld->output_blobs[0];

    void                    *input_data         = input_blob->data_gpu;
    void                    *weight_data        = weight_blob->data_gpu;
    void                    *bias_data          = bias_blob->data_gpu;
    void                    *output_data        = output_blob->data_gpu;

    BLOB_DATA_TYPE          type                = input_blob->type;
    BLOB_DATA_FORMAT        format              = input_blob->format;


#ifdef ARCH_SUPPORT_FP16
    void                    *input_unpad_unzip  = ld->layer_reserved_mem[FC_INPUT_UNPAD_UNZIP_DATA].data;
#endif

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "format not support", CNN_CUDA_NOT_IMPLEMENT);

    if (type == CNN_DT_FLT16)
    {
        input_data  = input_blob->data_gpu_fp16;
        weight_data = weight_blob->data_gpu_fp16;
        bias_data   = bias_blob->data_gpu_fp16;
        output_data = output_blob->data_gpu_fp16;
    }

    for (M = 1, i = 0; i < fc_layer->model->axis; i++)
    {
        M *= input_blob->shape[i];
    }

    for (K = 1; i < input_blob->ndims; i++)
    {
        K *= input_blob->shape[i];
    }

    N = fc_layer->model->num_outputs;

    if (format == CNN_FORMAT_NCHW_ZIP)
    {
        //printf("src_pad: %d %d dst_pad: %d %d\n", input_blob->pad.pad_h, input_blob->pad.pad_w, output_blob->pad.pad_h, output_blob->pad.pad_w);
#ifdef ARCH_SUPPORT_FP16
        hr = CNN_unzip_and_unpad(input_data, 
                                 input_unpad_unzip, 
                                 input_blob->shape[0],
                                 input_blob->shape[1],
                                 input_blob->shape[2],
                                 input_blob->shape[3],
                                 input_blob->pad.pad_h,
                                 input_blob->pad.pad_w);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_unzip_and_unpad", hr);

        err = cudaDeviceSynchronize();
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaDeviceSynchronize", CNN_convert_cudart_error_code(err));
        err = cudaGetLastError();
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaGetLastError", CNN_convert_cudart_error_code(err));

        hr = cnn_sgemm_cublas(cnn_cuda_handle, 
                              input_unpad_unzip,
                              weight_data, 
                              bias_data,
                              output_data,
                              type,
                              M,
                              K,
                              N,
                              fc_layer->model->bias);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_sgemm_cublas", hr);

        err = cudaDeviceSynchronize();
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaDeviceSynchronize", CNN_convert_cudart_error_code(err));
        err = cudaGetLastError();
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaGetLastError", CNN_convert_cudart_error_code(err));

#else
        CNN_CHECK_ERROR(1, "CNN_unzip_and_unpad", hr);
#endif
    }
    else
    {
        //printf("M N K : %d %d %d\n", M, N, K);
        hr = cnn_sgemm_cublas(cnn_cuda_handle, 
                              input_data,
                              weight_data, 
                              bias_data,
                              output_data,
                              type,
                              M,
                              K,
                              N,
                              fc_layer->model->bias);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_sgemm_cublas", hr);
    }

    return HIK_VCA_LIB_S_OK;
}

#endif // CNN_CUDA_OPT