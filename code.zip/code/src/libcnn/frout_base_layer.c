/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: frout_layer.c
* �ļ���ʶ: FROUT_LAYER_C
* ժ    Ҫ: frout��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-17
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN

#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif // CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "frout_base_layer.h"


/***************************************************************************************************
* ��  ��: ����predboxes
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
void fbbox_transform_inv(CNN_BLOB   *boxes,
						 CNN_BLOB   *deltas,
						 CNN_BLOB   *pred_boxes,
						 int        num_boxes,
						 int        num_classes)
{
	float *boxes_data  = (float*)boxes->data;
	float *deltas_data = (float*)deltas->data;
	float *pred_data   = (float*)pred_boxes->data;

	int i,j;
	float temp_f[12];
	float *widths = temp_f;
	float *heights = temp_f + 1;
	float *ctr_x = temp_f + 2;
	float *ctr_y = temp_f + 3;
	float *dx = temp_f + 4;
	float *dy = temp_f + 5;
	float *dw = temp_f + 6;
	float *dh = temp_f + 7;

	float *pred_ctr_x = temp_f + 8;
	float *pred_ctr_y = temp_f + 9;
	float *pred_w = temp_f + 10;
	float *pred_h = temp_f + 11;

	if (boxes->shape[0] == 0)
	{
		pred_boxes->shape[0] = 1;
		pred_boxes->shape[1] = 4;
		memset(pred_boxes->data, 0, sizeof(float)* 4);
		return;
	}

	for (i = 0; i < num_boxes; i++)
	{
		for (j = 0; j < num_classes;j++)
		{
			*widths = *(boxes_data + 2) - *(boxes_data) + 1.0;
			*heights = *(boxes_data + 3) - *(boxes_data + 1) + 1.0;
			*ctr_x = *(boxes_data) + 0.5 * *widths;
			*ctr_y = *(boxes_data + 1) + 0.5 * *heights;

			*dx = *(deltas_data);
			*dy = *(deltas_data + 1);
			*dw = *(deltas_data + 2);
			*dh = *(deltas_data + 3);

			*pred_ctr_x = *dx * (*widths) + *ctr_x;
			*pred_ctr_y = *dy * (*heights) + *ctr_y;
			*pred_w = expf(*dw) * (*widths);
			*pred_h = expf(*dh) * (*heights);

			*(pred_data) = *pred_ctr_x - 0.5 * (*pred_w);
			*(pred_data + 1) = *pred_ctr_y - 0.5 * (*pred_h);
			*(pred_data + 2) = *pred_ctr_x + 0.5 * (*pred_w);
			*(pred_data + 3) = *pred_ctr_y + 0.5 * (*pred_h);

			deltas_data += 4;
			pred_data   += 4;
		}
		boxes_data += 4;
	}
}


/***************************************************************************************************
* ��  ��: �Գ���ͼ���Ե�Ŀ���в���
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
void fclip_boxes(const CNN_BLOB    *im_info,
                 CNN_BLOB		  *boxes,
                 const int         num_boxes,
                 const int         num_classes)
{
    //ע�������������float �����Ҳ��float����Ҫ�����Ƿ���Ҫ���Ϊint
    int i;
    float *boxes_data = (float*)boxes->data;
    float *im_info_data = (float*)im_info->data;


    for (i = 0; i < (num_boxes * num_classes); i++)
    {
        *(boxes_data + i * 4)     = HKA_MAX(HKA_MIN(*(boxes_data + i * 4), *(im_info_data + 1) - 1), 0);
        *(boxes_data + i * 4 + 1) = HKA_MAX(HKA_MIN(*(boxes_data + i * 4 + 1), *(im_info_data)-1), 0);
        *(boxes_data + i * 4 + 2) = HKA_MAX(HKA_MIN(*(boxes_data + i * 4 + 2), *(im_info_data + 1) - 1), 0);
        *(boxes_data + i * 4 + 3) = HKA_MAX(HKA_MIN(*(boxes_data + i * 4 + 3), *(im_info_data)-1), 0);
    }
}



/***************************************************************************************************
* ��  ��: ɾ��nms��ȥֵ
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
void fnms_filter_boxes(float   *bbox,
					  float   *prob,
	                  int     *pred_num,
					  int     cls_num)
{
	int i, j, num = 0;
	//����ǿת����int ���廹Ҫ�μ�����pythonԴ�����������Ŀ��Ƿ���int ����float
	for (i = 0; i < *pred_num; i++)
	{
		if (*(prob + i * cls_num) != 10)
		{
			for (j = 0; j < 4; j++)
			{
				*(bbox + num * cls_num * 4 + j) = *(bbox + i * cls_num * 4 + j);

			}
			*(prob + num * cls_num) = *(prob + i * cls_num);
			num++;
		}
	}
	*pred_num = num;
}






/***************************************************************************************************
* ��  ��: NMS
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
void fnms(float   *bbox,
		  float   *prob,
		  int     *pred_num,
		  int     cls_num,
		  float   nms_thresh)
{
	
	int i, j, k;
	float areas, areas_comp;
	float xx[4];   //�Աȿ�Ĳ���
	float w, h, inter, ovr;
	
	i = 0;


	//for (i = 0; i < pred_num; i++)
	do
	{
		areas = (*(bbox + cls_num * i * 4 + 2) - *(bbox + cls_num * i * 4) + 1) *
			    (*(bbox + cls_num * i * 4+ 3) - *(bbox + cls_num * i * 4 + 1) + 1);
		for (j = i + 1; j < *pred_num; j++)
		{
			if (prob[j * cls_num] != 10)
			{
				xx[0] = (float)HKA_MAX(*(bbox + cls_num * i * 4), *(bbox + cls_num * j * 4));
				xx[1] = (float)HKA_MAX(*(bbox + cls_num * i * 4 + 1), *(bbox + cls_num * j * 4 + 1));
				xx[2] = (float)HKA_MIN(*(bbox + cls_num * i * 4 + 2), *(bbox + cls_num * j * 4 + 2));
				xx[3] = (float)HKA_MIN(*(bbox + cls_num * i * 4 + 3), *(bbox + cls_num * j * 4 + 3));
				w = HKA_MAX(0, xx[2] - xx[0] + 1);
				h = HKA_MAX(0, xx[3] - xx[1] + 1);
				inter = w * h;
				areas_comp = (*(bbox + cls_num * j * 4 + 2) - *(bbox + cls_num * j * 4) + 1) 
					         * (*(bbox + cls_num * j * 4 + 3) - *(bbox + cls_num * j * 4 + 1) + 1);
				ovr = inter / (areas + areas_comp - inter);
				if (ovr > nms_thresh)
				{
					prob[j * cls_num] = 10;
				}
			}
		}

		//ȡ����һ������ȥֵ
		for (k = i + 1; k < *pred_num; k++)
		{
			if (prob[k * cls_num] != 10)
			{
				i = k;
				break;
			}
			if (k == (*pred_num - 1))
			{
				i = k;
				break;
			}
		}
		if (i == (*pred_num - 1))
		{
			break;
		}
	} while (i < *pred_num);

	//nms�˳�
	fnms_filter_boxes(bbox, prob, pred_num, cls_num);


}
