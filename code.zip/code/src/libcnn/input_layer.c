/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: input_layer.c
* �ļ���ʶ: INPUT_LAYER_C
* ժ    Ҫ: �����ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-01
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <string.h>
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "cnn_basic_kernel.h"
#endif
#include "input_layer.h"
#include "hka_types.h"
#include "cnn_half.h"
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_INP_Reshape(void       *handle,
                        LAYER_DATA *ld)
{
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_INP_Create(LAYER_DATA *ld,
                       CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                       void      **handle)
{
    HRESULT                hr;
    INPUT_LAYER           *inp_layer;

    CNN_BUF                 *cpu_handle_buf       = &mem_buf[0];
    CNN_BUF                 *cpu_data_buf         = NULL;               //input�㲻��ҪCPU�ڴ�
    CNN_BUF                 *gpu_data_buf         = &mem_buf[2];

#ifndef CNN_CUDA_OPT
    gpu_data_buf    = NULL;
#endif

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

    inp_layer = (INPUT_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(INPUT_LAYER)), CNN_MEM_ALIGN_SIZE, 1);
    HKA_CHECK_MEMOUT(inp_layer);

    inp_layer->model = ld->layer_model->model_handle;

#ifdef ARCH_SUPPORT_FP16
    inp_layer->input_zip_data = CNN_alloc_buffer(gpu_data_buf, 
                                                 sizeof(short) * CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]), 
                                                 CNN_CUDA_MEM_ALIGNMENT, 
                                                 0);
    CNN_CHECK_ERROR(inp_layer->input_zip_data == NULL, "CNN_alloc_buffer failed", HIK_VCA_LIB_E_MEM_OUT);
#endif
    *handle = inp_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_INP_GetMemsize(LAYER_DATA *ld,
                           VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2     *gpu_data_tab   = &mem_tab[2];

#ifndef CNN_CUDA_OPT
    gpu_data_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(INPUT_LAYER)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

#ifdef ARCH_SUPPORT_FP16
    CNN_BASE_SetMemTab(gpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]) * sizeof(short)), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_GPU);
#endif

    return HIK_VCA_LIB_S_OK;
}


HRESULT CNN_INP_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    INPUT_MODEL           *inp_model;

    CNN_BUF                 *cpu_handle_buf = mem_buf;
    
    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

    inp_model = (INPUT_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(INPUT_MODEL)), CNN_MEM_ALIGN_SIZE, 1);
    HKA_CHECK_MEMOUT(inp_model);

    *handle = inp_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_INP_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(INPUT_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_INP_Forward(void       *handle,
                        LAYER_DATA *ld)
{
    return HIK_VCA_LIB_S_OK;
}


#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�(CUDA��)
* ��  ��: 
*         input_layer            - I   input_layer handle
*         ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_INP_Forward_Cuda_Opt(INPUT_LAYER    *input_layer,
                                 LAYER_DATA     *ld)
{
    cudaError_t         err;
    BLOB_DATA_TYPE      type;
    BLOB_DATA_FORMAT    format;
    HRESULT             hr;

    type                = ld->output_blobs[0].type;
    format              = ld->output_blobs[0].format;

    OPT_PROFILE_TIME_BY_EVENT_START(111);

#if 0  //ZIP��PAD �ŵ� CNN_proc_forward Ԥ������
    if (type == CNN_DT_FLT16)
    {
        if (format == CNN_FORMAT_NCHW_ZIP)
        {
#ifdef ARCH_SUPPORT_FP16
            //printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++zip\n");
            hr = CNN_zip_and_pad(ld->output_blobs[0].data_gpu_fp16, 
                                  input_layer->input_zip_data, 
                                  ld->output_blobs[0].shape[0],
                                  ld->output_blobs[0].shape[1],
                                  ld->output_blobs[0].shape[2],
                                  ld->output_blobs[0].shape[3],
                                  ld->output_blobs[0].pad.pad_h,
                                  ld->output_blobs[0].pad.pad_w);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_zip_and_pad", hr);

            err = cudaMemcpy(ld->output_blobs[0].data_gpu_fp16, 
                             input_layer->input_zip_data, 
                             CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0]),
                             cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cudaMemcpy", CNN_convert_cudart_error_code(err));
#endif
        }
    }
#endif

    OPT_PROFILE_TIME_BY_EVENT_STOP(111, "INPUT", 1, 1);

    return HIK_VCA_LIB_S_OK;
}

#endif // CNN_CUDA_OPT