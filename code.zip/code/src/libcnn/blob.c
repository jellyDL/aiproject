/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: blob.c
* �ļ���ʶ: BLOB_C
* ժ    Ҫ: BLOB��صĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-01-30
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif

#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif

#include <string.h>
#include <stdlib.h>
#include "blob.h"
#include "vca_common.h"
#include "vca_error_code.h"
#include "cnn_half.h"
#include "cnn_common.h"

// ÿ���������͵��ڴ��С
const int data_type_size[CNN_DT_NUM] = { 1, 4, 2 };

/***************************************************************************************************
* ��  ��: ��ȡBLOB�����ݵĸ���
* ��  ��: blob                   - I BLOBָ��
* ����ֵ: ���ݸ���
***************************************************************************************************/
int CNN_BLOB_GetDataNum(CNN_BLOB *blob)
{
    return blob->shape[0] * blob->shape[1] * blob->shape[2] * blob->shape[3];
}

/***************************************************************************************************
* ��  ��: ��ȡBLOB pad֮�� ���ݵĸ���
* ��  ��: blob                   - I BLOBָ��
* ����ֵ: ���ݸ���
***************************************************************************************************/
int CNN_BLOB_GetDataNum_padded(CNN_BLOB *blob)
{
    return blob->shape[0] * 
           blob->shape[1] * 
           CNN_get_padded_size(blob->shape[2], blob->pad.pad_h, blob->pad.pad_h) * 
           CNN_get_padded_size(blob->shape[3], blob->pad.pad_w, blob->pad.pad_w);
}

/***************************************************************************************************
* ��  ��: ��ȡBLOB��������ռ�ڴ�Ĵ�С
* ��  ��: blob                   - I BLOBָ��
* ����ֵ: ������ռ�ڴ�Ĵ�С
***************************************************************************************************/
int CNN_BLOB_GetDataSize(CNN_BLOB *blob)
{
    if ((blob->type >= CNN_DT_UINT8) && (blob->type < CNN_DT_NUM))
    {
        return blob->shape[0] * blob->shape[1] * blob->shape[2] * blob->shape[3] * data_type_size[blob->type];
    }

    return 0;
}

/***************************************************************************************************
* ��  ��: ��ȡBLOB��������ռ�ڴ�Ĵ�С
* ��  ��: blob                   - I BLOBָ��
* ����ֵ: ������ռ�ڴ�Ĵ�С
***************************************************************************************************/
int CNN_BLOB_GetDataSize_padded(CNN_BLOB *blob)
{
    if ((blob->type >= CNN_DT_UINT8) && (blob->type < CNN_DT_NUM))
    {
        return CNN_BLOB_GetDataNum_padded(blob) * data_type_size[blob->type];
    }

    return 0;
}


/***************************************************************************************************
* ��  ��: ��ȡ�ض�λ�õ�ָ��
* ��  ��: blob                   - I BLOBָ��
*         n                      - I n
*         c                      - I c
*         h                      - I h
*         w                      - I w
* ����ֵ: �ض�λ�õ�ָ��
***************************************************************************************************/
void *CNN_BLOB_GetPtr(CNN_BLOB *blob,
                      int       n,
                      int       c,
                      int       h,
                      int       w)
{
    int offset = n * blob->shape[1] * blob->shape[2] * blob->shape[3]
                 + c * blob->shape[2] * blob->shape[3]
                 + h * blob->shape[3]
                 + w;

    return (void *)((char *)blob->data + offset * data_type_size[blob->type]);
}

/***************************************************************************************************
* ��  ��: ��ά��start_axis��ά��end_axis�����������ݿ������������end_axis
* ��  ��: blob                   - I BLOBָ��
*         start_axis             - I ��ʼά��
*         end_axis               - I ����ά��
* ����ֵ: ���ݿ����
***************************************************************************************************/
int CNN_BLOB_GetTotal(const CNN_BLOB *blob,
                      int             start_axis,
                      int             end_axis)
{
    int i;
    int size = 0;

    if (start_axis < 0)
    {
        start_axis += blob->ndims;
    }

    if (end_axis > blob->ndims)
    {
        end_axis = blob->ndims;
    }
    else if (end_axis < 0)
    {
        end_axis += blob->ndims;
    }

    if ((0 <= start_axis) && (start_axis <= end_axis) && (end_axis <= blob->ndims))
    {
        size = 1;
        for (i = start_axis; i < end_axis; i++)
        {
            size *= blob->shape[i];
        }
    }

    return size;
}

/***************************************************************************************************
* ��  ��: ��ʼ����ƫ����ת���ɾ����blob
* ��  ��:
*         blob                   - I BLOBָ��
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_BLOB_InitOneBiasBlob(CNN_BLOB *blob)
{
    int     i;
    float   *data = (float *)blob->data;

#ifndef CNN_CUDA_OPT
    if (blob->type != CNN_DT_FLT32)
    {
        return HIK_VCA_LIB_KEY_PARAM_ERR;
    }
    for (i = 0; i < CNN_BLOB_GetDataNum(blob); i++)
    {
        data[i] = 1.0f;
    }
#endif
    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ȡblob��������(float��half)
* ��  ��:
* ����ֵ: ��
***************************************************************************************************/
BLOB_DATA_TYPE  cnn_get_blob_type()
{

#ifdef ARCH_SUPPORT_FP16
    return CNN_DT_FLT16;
#else
    return CNN_DT_FLT32;
#endif

}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ��ӡ����
* ��  ��:
*               out         - O          ����ļ�
*               data        - I          ����
*               n           - I          ���ݳ���
* ����ֵ: ��
***************************************************************************************************/
void CNN_print_data(FILE *out, float *data, int n)
{
    int i;
    for (i = 0; i < n; i++)
    {
        fprintf(out, "%f ", data[i]);
    }
    fprintf(out, "\n");
}

/***************************************************************************************************
* ��  ��: ��ӡblob
* ��  ��:
*               out         - O          ����ļ�
*               blob        - I          ����blob
* ����ֵ: ��
***************************************************************************************************/
void CNN_print_blob(FILE *out, CNN_BLOB *blob)
{
    int     length            = CNN_BLOB_GetDataNum(blob);
    float   *data             = (float *)blob->data;
    float   *data_gpu         = (float *)blob->data_gpu;
    float   *data_temp;
    float   *data_gpu_temp;
    float   *data_gpu_fp16    = (float *)blob->data_gpu_fp16;   

    fprintf(out, "prinf_blob----------------------------\n");

    if (data)
    {
        fprintf(out, "prinf_blob data----------------------------\n");
        CNN_print_data(out, data, length);
    }

    if (data_gpu)
    {
        fprintf(out, "prinf_blob data_gpu----------------------------\n");
        data_temp = (float *)malloc(length * sizeof(float));
        cudaMemcpy(data_temp, data_gpu, length * sizeof(float), cudaMemcpyDeviceToHost);
        CNN_print_data(out, data_temp, length);
        free(data_temp);
    }

    if (data_gpu_fp16)
    {
        fprintf(out, "prinf_blob data_gpu_fp16----------------------------\n");
        cudaMalloc(&data_gpu_temp, length * sizeof(float));
        cnn_half2float((cnn_half *)data_gpu_fp16, data_gpu_temp, length);
        data_temp = (float *)malloc(length * sizeof(float));
        cudaMemcpy(data_temp, data_gpu_temp, length * sizeof(float), cudaMemcpyDeviceToHost);
        CNN_print_data(out, data_temp, length);
        free(data_temp);
        cudaFree(data_gpu_temp);
    }

}

/***************************************************************************************************
* ��  ��: ��ӡblob
* ��  ��:
*               out         - O          ����ļ�
*               blob        - I          ����blob
* ����ֵ: ��
***************************************************************************************************/
void CNN_print_blob_shape(FILE *out, char *str, CNN_BLOB *blob)
{
    fprintf(out, "%s blob shape: %d %d %d %d\n", str, blob->shape[0], blob->shape[1], blob->shape[2], blob->shape[3]);
}

/***************************************************************************************************
* ��  ��: ��blob�ĸ�ʽ����ת���ɶ�Ӧ���ַ���
* ��  ��:
*               format      - I          blob��ʽ
* ����ֵ: ��
***************************************************************************************************/
const char *CNN_blob_format_str(BLOB_DATA_FORMAT format)
{
    switch (format)
    {
    case CNN_FORMAT_NCHW:
        return "CNN_FORMAT_NCHW";
    case CNN_FORMAT_NCHW_ZIP:
        return "CNN_FORMAT_NCHW_ZIP";
    default:
        return "";
    }
}

/***************************************************************************************************
* ��  ��: �ж�blob��format�Ƿ�֧��
* ��  ��:
*               format      - I          blob��ʽ
* ����ֵ: 1->֧�֣� 0->��֧��
***************************************************************************************************/
int CNN_blob_format_support(BLOB_DATA_FORMAT format)
{
    if (format == CNN_FORMAT_NCHW)
    {
        return 1;
    }

    if (format == CNN_FORMAT_NCHW_ZIP)
    {
        return 1;
    }

    return 0;
}

size_t CNN_pad_hw_size(int n, int c, int h, int w, int pad_h, int pad_w)
{
    int h_dst = h + pad_h * 2;
    int w_dst = w + pad_w * 2;

    return n * c * h_dst * w_dst;
}

size_t CNN_blob_pad_size(CNN_BLOB *blob, int pad_h, int pad_w)
{
    int n = blob->shape[0] / 2;
    int c = blob->shape[1];
    int h = blob->shape[2];
    int w = blob->shape[3];

    return CNN_pad_hw_size(n, c, h, w, pad_h, pad_w);
}


#endif