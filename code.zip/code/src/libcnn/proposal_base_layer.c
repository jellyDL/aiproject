/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: proposal_base_layer.c
* �ļ���ʶ: PROPOSAL_BASE_LAYER_C
* ժ    Ҫ: PROPOSAL��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-17
* ��    ע:
*
* �ļ�����: proposal_base_layer.c
* �ļ���ʶ: PROPOSAL_BASE_LAYER_C
* ժ    Ҫ: PROPOSAL��ĺ���ʵ��
*
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN

#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif  //CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "proposal_base_layer.h"
#include "_ipgs_sort.h"



#define FILTERED_SCORE 10
/***************************************************************************************************
* ��  ��: bbox�������ת��������
* ��  ��: anchor                          - I ê�����ݼ�
*         anchor_size                     - I ê��ߴ�
*         bbox_deltas                     - I ê��-bbox��׼��ת������
*         proposal                        - O ê��������꼯
* ����ֵ: ��
***************************************************************************************************/
void CNN_PROPOSAL_bbox_transform_inv(float    *anchors,
    int       anchor_size[2],
    float    *bbox_data,
    CNN_BLOB *proposal)
{
    // Ҫע��proposal�������Ӧ��Ϊfloat���ڶ�������ʱ��Ҫע��
    float *proposal_data = (float *)proposal->data;
    float *deltas = bbox_data; // (float*)bbox_deltas->data;
    int    i;
    float  temp_f[12];
    float *widths = temp_f;
    float *heights = temp_f + 1;
    float *ctr_x = temp_f + 2;
    float *ctr_y = temp_f + 3;
    float *dx = temp_f + 4;
    float *dy = temp_f + 5;
    float *dw = temp_f + 6;
    float *dh = temp_f + 7;

    float *pred_ctr_x = temp_f + 8;
    float *pred_ctr_y = temp_f + 9;
    float *pred_w = temp_f + 10;
    float *pred_h = temp_f + 11;

    if (0 == anchor_size[0])
    {
        proposal->shape[0] = 1;
        proposal->shape[1] = 4;
        memset(proposal->data, 0, sizeof(float)* 4);
        return;
    }
    // ֮�������ȫΪfloat��ע��ת��

    for (i = 0; i < anchor_size[0]; i++)
    {
        //widths[0] = anchors[i * 4 + 2] - anchors[i * 4] + 1.0;
        *widths = *(anchors + i * 4 + 2) - *(anchors + i * 4) + 1.0;
        *heights = *(anchors + i * 4 + 3) - *(anchors + i * 4 + 1) + 1.0;
        *ctr_x = *(anchors + i * 4) + 0.5 * (*widths);
        *ctr_y = *(anchors + i * 4 + 1) + 0.5 * (*heights);

        *dx = *(deltas + i * 4);
        *dy = *(deltas + i * 4 + 1);
        *dw = *(deltas + i * 4 + 2);
        *dh = *(deltas + i * 4 + 3);

        *pred_ctr_x = (*dx) * (*widths) + (*ctr_x);
        *pred_ctr_y = (*dy) * (*heights) + (*ctr_y);
        *pred_w = exp(*dw) * (*widths);
        *pred_h = exp(*dh) * (*heights);

        *(proposal_data + i * 4) = *pred_ctr_x - 0.5 * (*pred_w);
        *(proposal_data + i * 4 + 1) = *pred_ctr_y - 0.5 * (*pred_h);
        *(proposal_data + i * 4 + 2) = *pred_ctr_x + 0.5 * (*pred_w);
        *(proposal_data + i * 4 + 3) = *pred_ctr_y + 0.5 * (*pred_h);
    }
}



#if 0
/***************************************************************************************************
* ��  ��: bbox�������ת��������
* ��  ��: anchor                          - I ê�����ݼ�
*         anchor_size                     - I ê��ߴ�
*         bbox_deltas                     - I ê��-bbox��׼��ת������
*         proposal                        - O ê��������꼯
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_bbox_transform_inv_opt(const CNN_BLOB      *im_info,
                                            const float         *anchors,
                                            int                 anchor_size[2],
                                            int                 pre_top_n,
                                            float               *deltas,
                                            CNN_BLOB            *proposal,
                                            const float         *score,
                                            float               kth_score)
{
    //Ҫע��proposal�������Ӧ��Ϊfloat���ڶ�������ʱ��Ҫע��
    float   *proposal_data  = (float*)proposal->data;
    int     i;
    float   *im_info_data   = (float*)im_info->data;
    float   img_height      = im_info_data[0] - 1.0f;
    float   img_width       = im_info_data[1] - 1.0f;
    float   widths, heights;
    float   dx, dy, dw, dh;
    float   pred_ctr_x, pred_ctr_y, pred_w, pred_h;

    if (anchor_size[0] == 0)
    {
        proposal->shape[0] = 1;
        proposal->shape[1] = 4;
        memset(proposal->data, 0, sizeof(float)* 4);
        return HIK_VCA_LIB_S_OK;
    }
    //֮�������ȫΪfloat��ע��ת��

    for (i = 0; i < anchor_size[0]; i++)
    {
        if (score[i] > kth_score)
        {
            widths  = anchors[i * 4 + 2] - anchors[i * 4] + 1.0f;
            heights = anchors[i * 4 + 3] - anchors[i * 4 + 1] + 1.0f;

            dx = deltas[i * 4];
            dy = deltas[i * 4 + 1];
            dw = deltas[i * 4 + 2];
            dh = deltas[i * 4 + 3];

            pred_ctr_x = (dx + 0.5f) * widths + anchors[i * 4];
            pred_ctr_y = (dy + 0.5f) * heights + anchors[i * 4 + 1];
            pred_w = expf(dw) * widths;
            pred_h = expf(dh) * heights;

            //�Գ���ͼ���Ե�Ĳ��ֽ��вü�
            proposal_data[i * 4]     = HKA_MAX(HKA_MIN(pred_ctr_x - 0.5f * pred_w, img_width), 0.0f);
            proposal_data[i * 4 + 1] = HKA_MAX(HKA_MIN(pred_ctr_y - 0.5f * pred_h, img_height), 0.0f);
            proposal_data[i * 4 + 2] = HKA_MAX(HKA_MIN(pred_ctr_x + 0.5f * pred_w, img_width), 0.0f);
            proposal_data[i * 4 + 3] = HKA_MAX(HKA_MIN(pred_ctr_y + 0.5f * pred_h, img_height), 0.0f);
        }
    }
    return HIK_VCA_LIB_S_OK;
}

#else

/***************************************************************************************************
* ��  ��: bbox�������ת��������
* ��  ��: anchor                          - I ê�����ݼ�
*         anchor_size                     - I ê��ߴ�
*         bbox_deltas                     - I ê��-bbox��׼��ת������
*         proposal                        - O ê��������꼯
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_bbox_transform_inv_opt(const CNN_BLOB      *im_info,
                                            const float         *anchors,
                                            int                 anchor_size[2],
                                            int                 pre_top_n,
                                            float               *deltas,
                                            CNN_BLOB            *proposal,
                                            const float         *score,
                                            float               kth_score)
{
    //Ҫע��proposal�������Ӧ��Ϊfloat���ڶ�������ʱ��Ҫע��
    float   *proposal_data  = (float*)proposal->data;
    int     i;
    float   *im_info_data   = (float*)im_info->data;
    float   img_height      = im_info_data[0] - 1.0f;
    float   img_width       = im_info_data[1] - 1.0f;
    float   widths, heights;
    float   dx, dy, dw, dh;
    float   pred_ctr_x, pred_ctr_y, pred_w, pred_h;

    if (anchor_size[0] == 0)
    {
        proposal->shape[0] = 1;
        proposal->shape[1] = 4;
        memset(proposal->data, 0, sizeof(float)* 4);
        return HIK_VCA_LIB_S_OK;
    }
    //֮�������ȫΪfloat��ע��ת��

    for (i = 0; i < anchor_size[0]; i++)
    {
        if (score[i] > kth_score)
        {
            widths  = anchors[i * 4 + 2] - anchors[i * 4] + 1.0f;
            heights = anchors[i * 4 + 3] - anchors[i * 4 + 1] + 1.0f;

            dx = deltas[i * 4];
            dy = deltas[i * 4 + 1];
            dw = deltas[i * 4 + 2];
            dh = deltas[i * 4 + 3];

            pred_ctr_x = (dx + 0.5f) * widths  + anchors[i * 4]    ;
            pred_ctr_y = (dy + 0.5f) * heights + anchors[i * 4 + 1];
            pred_w = expf(dw) * widths;
            pred_h = expf(dh) * heights;

            //�Գ���ͼ���Ե�Ĳ��ֽ��вü�
            proposal_data[i * 4]     = HKA_MAX(HKA_MIN(pred_ctr_x - 0.5f * pred_w, img_width), 0.0f);
            proposal_data[i * 4 + 1] = HKA_MAX(HKA_MIN(pred_ctr_y - 0.5f * pred_h, img_height), 0.0f);
            proposal_data[i * 4 + 2] = HKA_MAX(HKA_MIN(pred_ctr_x + 0.5f * pred_w, img_width), 0.0f);
            proposal_data[i * 4 + 3] = HKA_MAX(HKA_MIN(pred_ctr_y + 0.5f * pred_h, img_height), 0.0f);
        }
    }
    return HIK_VCA_LIB_S_OK;
}
#endif


/***************************************************************************************************
* ��  ��: �Գ���ͼ���Ե�Ŀ���в���
* ��  ��: im_info                 - I   ͼ���ʼ��Ϣ
*         proposals               - I/O ê��������꼯
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_clip_boxes(const CNN_BLOB      *im_info,
    CNN_BLOB		    *proposals)
{
    int     i;
    float   *proposals_data = (float*)proposals->data;
    float   *im_info_data = (float*)im_info->data;
    int     img_height = (int)im_info_data[0];
    int     img_width = (int)im_info_data[1];

    for (i = 0; i < proposals->shape[2]; i++)
    {
        proposals_data[i * 4] = HKA_MAX(HKA_MIN(proposals_data[i * 4], img_width - 1), 0);
        proposals_data[i * 4 + 1] = HKA_MAX(HKA_MIN(proposals_data[i * 4 + 1], img_height - 1), 0);
        proposals_data[i * 4 + 2] = HKA_MAX(HKA_MIN(proposals_data[i * 4 + 2], img_width - 1), 0);
        proposals_data[i * 4 + 3] = HKA_MAX(HKA_MIN(proposals_data[i * 4 + 3], img_height - 1), 0);
    }
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ɾ����С��
* ��  ��: min_size               - I    ��Сֵ
*         proposals              - I/O  ê����������
*         scores                 - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_filter_boxes(int	   min_size,
    CNN_BLOB   *proposals,
    CNN_BLOB   *scores)
{
    int i, j, num = 0;
    float ws, hs;
    float *proposals_data = (float*)proposals->data;
    float *scores_data = (float*)scores->data;
    for (i = 0; i < proposals->shape[2]; i++)
    {
        ws = *(proposals_data + i * 4 + 2) - *(proposals_data + i * 4) + 1;
        hs = *(proposals_data + i * 4 + 3) - *(proposals_data + i * 4 + 1) + 1;
        if ((ws >= min_size) && (hs >= min_size))
        {
            for (j = 0; j < 4; j++)
            {
                *(proposals_data + num * 4 + j) = *(proposals_data + i * 4 + j);
            }
            *(scores_data + num) = *(scores_data + i);

            num++;
        }
    }
    proposals->shape[2] = num;
    scores->shape[2] = num;
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ɾ����С��
* ��  ��: min_size               - I    ��Сֵ
*         proposals              - I/O  ê����������
*         scores                 - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_filter_boxes_opt(int	     min_size,
    CNN_BLOB   *proposals,
    float      *scores_data,
    int        *score_num_filtered,
    float      kth_score)
{
    int         i, j, num = 0;
    float       ws, hs;
    float       *proposals_data = (float*)proposals->data;

    for (i = 0; i < proposals->shape[2]; i++)
    {
        ws = *(proposals_data + i * 4 + 2) - *(proposals_data + i * 4) + 1;
        hs = *(proposals_data + i * 4 + 3) - *(proposals_data + i * 4 + 1) + 1;

        if ((ws >= min_size) && (hs >= min_size) && (scores_data[i] > kth_score))
        {
            for (j = 0; j < 4; j++)
            {
                *(proposals_data + num * 4 + j) = *(proposals_data + i * 4 + j);
            }
            *(scores_data + num) = *(scores_data + i);

            num++;
        }
    }
    proposals->shape[2] = num;
    *score_num_filtered = num;
    return HIK_VCA_LIB_S_OK;
}

#if 1
/***************************************************************************************************
* ��  ��: ����score��������
* ��  ��: pre_num_topN            - I    ������ȡ��
*         proposals               - I/O  ê����������
*         scores                  - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_argsort(int		    pre_num_topN,
    CNN_BLOB       *proposals,
    CNN_BLOB       *scores)
{

    //����Ҫ���ǿ��ܵ�����pre-num_topN�� ���Բ�����for ����while
    int i, j, k, max_id = 0;
    float max_s;
    float temp;
    float *scores_data = (float*)scores->data;
    float *proposals_data = (float*)proposals->data;
    if (scores->shape[2] < pre_num_topN)
    {
        pre_num_topN = scores->shape[2];
    }

    for (i = 0; i < pre_num_topN; i++)
    {
        //�����������ֵ
        max_s = scores_data[i];
        max_id = i;
        for (j = i + 1; j < scores->shape[2]; j++)
        {
            if (scores_data[j] > max_s)
            {
                max_s = scores_data[j];
                max_id = j;
            }
        }
        //if there is a bigger one
        if (max_id != i)
        {
            temp = scores_data[i];
            scores_data[i] = scores_data[max_id];
            scores_data[max_id] = temp;
            for (k = 0; k < 4; k++)
            {
                temp = *(proposals_data + i * 4 + k);
                *(proposals_data + i * 4 + k) = *(proposals_data + max_id * 4 + k);
                *(proposals_data + max_id * 4 + k) = temp;
            }
        }

        //printf("list%d:%f\n", i,scores_data[i]);
    }
    proposals->shape[2] = pre_num_topN;
    scores->shape[2] = pre_num_topN;
    return HIK_VCA_LIB_S_OK;
}
#endif



/***************************************************************************************************
* ��  ��: ɾ��nms��ȥֵ
* ��  ��: post_num_topN              - I    nms�������ȡ���������
*         proposals                  - I/O  ê����������
*         scores                     - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_nms_filter_boxes(int	     post_num_topN,
    CNN_BLOB   *proposals,
    CNN_BLOB   *scores)
{
    int i, j, num = 0;
    float *proposals_data = (float*)proposals->data;
    float *scores_data = (float*)scores->data;
    for (i = 0; i < proposals->shape[2]; i++)
    {
        if (*(scores_data + i) != FILTERED_SCORE)
        {
            for (j = 0; j < 4; j++)
            {
                *(proposals_data + num * 4 + j) = *(proposals_data + i * 4 + j);

            }
            *(scores_data + num) = *(scores_data + i);
            num++;
        }
        if (num == post_num_topN)
        {
            break;
        }
    }
    proposals->shape[2] = num;
    scores->shape[2] = num;
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ɾ��nms��ȥֵ
* ��  ��: post_num_topN              - I    nms�������ȡ���������
*         proposals                  - I/O  ê����������
*         scores                     - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_nms_filter_boxes_opt(int	        post_num_topN,
    CNN_BLOB      *proposals,
    CNN_BLOB      *scores)
{
    int i, j, num = 0;
    float *proposals_data = (float*)proposals->data;
    float *scores_data = (float*)scores->data;

    for (i = 0; i < proposals->shape[2]; i++)
    {
        if (*(scores_data + i) != FILTERED_SCORE)
        {
            for (j = 0; j < 4; j++)
            {
                *(proposals_data + num * 4 + j) = *(proposals_data + i * 4 + j);

            }
            *(scores_data + num) = *(scores_data + i);
            num++;
        }
        if (num == post_num_topN)
        {
            break;
        }
    }
    proposals->shape[2] = num;
    scores->shape[2] = num;
    return HIK_VCA_LIB_S_OK;
}



/***************************************************************************************************
* ��  ��: ɾ��nms��ȥֵ
* ��  ��: post_num_topN              - I    nms�������ȡ���������
*         proposals                  - I/O  ê����������
*         scores                     - I/O  ê����Ӧ���Ŷ�
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_nms_filter_boxes_opt2(int	         nms_keep_num,
    float         *proposals_data,
    float         *scores_data,
    int           *nms_keep)
{
    int     i, j;
    int     index;

    for (i = 0; i < nms_keep_num; i++)
    {
        index = nms_keep[i];
        for (j = 0; j < 4; j++)
        {
            *(proposals_data + i * 4 + j) = *(proposals_data + index * 4 + j);
        }
        *(scores_data + i) = *(scores_data + index);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: NMS
* ��  ��: post_num_topN              - I    nms�������ȡ���������
*         proposals                  - I/O  ê����������
*         scores                     - I/O  ê����Ӧ���Ŷ�
*         nms_thresh                 - I    nms��ֵ
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_nms(int		    post_num_topN,
    CNN_BLOB       *proposals,
    CNN_BLOB       *scores,
    float          nms_thresh)
{
    int     i, j, k, num;
    float   areas, areas_comp;
    float   xx[4];   //�Աȿ�Ĳ���
    float   w, h, inter;
    float   *scores_data = (float*)scores->data;
    float   *proposals_data = (float*)proposals->data;

    float   areas_x0, areas_x1, areas_x2, areas_x3;

    if (scores->shape[2] < post_num_topN)
    {
        post_num_topN = scores->shape[2];
    }

    num = 0;
    i = 0;

    //��numȡ����300������i�Ѿ��������һ��scoresʱ���˳�
    while ((num < post_num_topN) && (i < scores->shape[2] - 1))
    {
        areas_x0 = proposals_data[4 * i + 0];
        areas_x1 = proposals_data[4 * i + 1];
        areas_x2 = proposals_data[4 * i + 2];
        areas_x3 = proposals_data[4 * i + 3];

        areas = (areas_x2 - areas_x0 + 1) * (areas_x3 - areas_x1 + 1);

        for (j = i + 1; j < scores->shape[2]; j++)
        {
            if (scores_data[j] != FILTERED_SCORE)
            {
                xx[0] = HKA_MAX(areas_x0, *(proposals_data + 4 * j));
                xx[2] = HKA_MIN(areas_x2, *(proposals_data + 4 * j + 2));

                w = HKA_MAX(0, xx[2] - xx[0] + 1);

                if (w == 0)
                {
                    continue;
                }

                xx[1] = HKA_MAX(areas_x1, *(proposals_data + 4 * j + 1));
                xx[3] = HKA_MIN(areas_x3, *(proposals_data + 4 * j + 3));

                h = HKA_MAX(0, xx[3] - xx[1] + 1);

                if (h == 0)
                {
                    continue;
                }

                inter = w * h;
                areas_comp = (proposals_data[4 * j + 2] - proposals_data[4 * j] + 1) * (proposals_data[4 * j + 3] - proposals_data[4 * j + 1] + 1);
                scores_data[j] = (inter > (nms_thresh * (areas + areas_comp - inter))) ? FILTERED_SCORE : scores_data[j];
            }
        }
        //ȡ����һ������ȥֵ
        for (k = i + 1; k < scores->shape[2]; k++)
        {
            if (scores_data[k] != FILTERED_SCORE)
            {
                i = k;
                break;
            }
            if (k == (scores->shape[2] - 1))
            {
                i = k;
                break;
            }
        }
        num++;
    }

    //nms�˳�
    CNN_PROPOSAL_nms_filter_boxes(post_num_topN, proposals, scores);

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: NMS
* ��  ��: post_num_topN              - I    nms�������ȡ���������
*         proposals                  - I/O  ê����������
*         scores                     - I/O  ê����Ӧ���Ŷ�
*         nms_thresh                 - I    nms��ֵ
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_nms_opt(int		    post_num_topN,
    CNN_BLOB       *proposals,
    CNN_BLOB       *scores,
    float          nms_thresh)
{
    int     i, j, num;
    float   areas, areas_comp;
    float   xx[4];   //�Աȿ�Ĳ���
    float   w, h, inter;
    float   *scores_data = (float*)scores->data;
    float   *proposals_data = (float*)proposals->data;
    int     next_i;

    float   areas_x0, areas_x1, areas_x2, areas_x3;

    if (scores->shape[2] < post_num_topN)
    {
        post_num_topN = scores->shape[2];
    }

    num = 0;
    i = 0;

    //��numȡ����300������i�Ѿ��������һ��scoresʱ���˳�
    while ((num < post_num_topN) && (i < scores->shape[2] - 1))
    {
        areas_x0 = proposals_data[4 * i + 0];
        areas_x1 = proposals_data[4 * i + 1];
        areas_x2 = proposals_data[4 * i + 2];
        areas_x3 = proposals_data[4 * i + 3];

        areas = (areas_x2 - areas_x0 + 1) * (areas_x3 - areas_x1 + 1);
        next_i = -1;

        for (j = i + 1; j < scores->shape[2]; j++)
        {
            if (scores_data[j] != FILTERED_SCORE)
            {
                xx[0] = HKA_MAX(areas_x0, *(proposals_data + 4 * j));
                xx[2] = HKA_MIN(areas_x2, *(proposals_data + 4 * j + 2));

                w = HKA_MAX(0, xx[2] - xx[0] + 1);

                if (0 == w)
                {
                    next_i = (next_i == -1) ? j : next_i;
                    continue;
                }

                xx[1] = HKA_MAX(areas_x1, *(proposals_data + 4 * j + 1));
                xx[3] = HKA_MIN(areas_x3, *(proposals_data + 4 * j + 3));

                h = HKA_MAX(0, xx[3] - xx[1] + 1);

                if (h == 0)
                {
                    next_i = (next_i == -1) ? j : next_i;
                    continue;
                }

                inter = w * h;
                areas_comp = (*(proposals_data + 4 * j + 2) - *(proposals_data + 4 * j + 0) + 1) * (*(proposals_data + 4 * j + 3) - *(proposals_data + 4 * j + 1) + 1);

                if (inter > (nms_thresh * (areas + areas_comp - inter)))
                {
                    //10��������һ�ε�����Ҫ��ȥ�Ŀ������
                    scores_data[j] = FILTERED_SCORE;
                }
                else
                {
                    next_i = (next_i == -1) ? j : next_i;
                }
            }
        }

        //ȡ����һ������ȥֵ
        i = (next_i == -1) ? (scores->shape[2] - 1) : next_i;

        num++;
    }

    //nms�˳�
    CNN_PROPOSAL_nms_filter_boxes_opt(post_num_topN, proposals, scores);

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ����ê�����
* ��  ��: base_size                 - I ��׼�ߴ�
*         ratios                    - I ê����״����
*         scales                    - I ê��߶�����
*         scales_num                - I ��߶Ȳ���
*         anchor                    - O ���ɵ�ê�㼯
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_generate_anchors(int		base_size,
    float		ratios[3],
    int        scales[10],
    int        scales_num,
    ANCHOR     *anchor)
{
    int i, j;
    float param_anchor[4];								    //w h x_ctr y_ctr �� �� �����ĵ� �����ĵ�
    int size;
    float size_ratios;
    float ws, hs;
    float base_anchor[4] = { 0, 0, ((float)base_size - 1.0), ((float)base_size - 1.0) };      //��׼��
    float ori_anchor[3][4];                                   //��׼�߶�ê���
    float *data = anchor->data;

    param_anchor[0] = base_anchor[2] - base_anchor[0] + 1.0;
    param_anchor[1] = base_anchor[3] - base_anchor[1] + 1.0;
    param_anchor[2] = base_anchor[0] + 0.5 * (param_anchor[0] - 1.0);
    param_anchor[3] = base_anchor[1] + 0.5 * (param_anchor[1] - 1.0);
    size = (int)(param_anchor[0] * param_anchor[1]);            //�õ���׼��size
    for (i = 0; i < 3; i++)
    {
        size_ratios = (float)size / ratios[i];
        ws = HKA_ROUND(sqrt(size_ratios));
        hs = HKA_ROUND(ws * ratios[i]);
        ori_anchor[i][0] = param_anchor[2] - 0.5 * (ws - 1);
        ori_anchor[i][1] = param_anchor[3] - 0.5 * (hs - 1);
        ori_anchor[i][2] = param_anchor[2] + 0.5 * (ws - 1);
        ori_anchor[i][3] = param_anchor[3] + 0.5 * (hs - 1);        //�����ԭʼ��׼size��3����ͬ��״��anchor�Ĵ�С���������
    }

    anchor->scales_num = scales_num;                                //��scales_num��ֵ

#if 1
    //����anchor
    for (i = 0; i < 3; i++)
    {
        param_anchor[0] = ori_anchor[i][2] - ori_anchor[i][0] + 1;
        param_anchor[1] = ori_anchor[i][3] - ori_anchor[i][1] + 1;
        param_anchor[2] = ori_anchor[i][0] + 0.5 * (param_anchor[0] - 1);
        param_anchor[3] = ori_anchor[i][1] + 0.5 * (param_anchor[1] - 1);

        for (j = 0; j < scales_num; j++)
        {
            ws = param_anchor[0] * scales[j];
            hs = param_anchor[1] * scales[j];

            *(data + (i * scales_num + j) * 4)     = param_anchor[2] - 0.5 * (ws - 1);
            *(data + (i * scales_num + j) * 4 + 1) = param_anchor[3] - 0.5 * (hs - 1);
            *(data + (i * scales_num + j) * 4 + 2) = param_anchor[2] + 0.5 * (ws - 1);
            *(data + (i * scales_num + j) * 4 + 3) = param_anchor[3] + 0.5 * (hs - 1);        //�����ԭʼ��׼size��3����ͬ��״��anchor�Ĵ�С���������
        }
    }
#else

    //����anchor
    for (i = 0; i < 3; i++)
    {
        param_anchor[0] = ori_anchor[i][2] - ori_anchor[i][0] + 1;
        param_anchor[1] = ori_anchor[i][3] - ori_anchor[i][1] + 1;
        param_anchor[2] = ori_anchor[i][0] + 0.5 * (param_anchor[0] - 1);
        param_anchor[3] = ori_anchor[i][1] + 0.5 * (param_anchor[1] - 1);

        for (j = 0; j < scales_num; j++)
        {
            ws = param_anchor[0] * scales[j];
            hs = param_anchor[1] * scales[j];

            *(data + (i * scales_num + j) * 4)     = param_anchor[2];
            *(data + (i * scales_num + j) * 4 + 1) = param_anchor[3];
            *(data + (i * scales_num + j) * 4 + 2) = ws;
            *(data + (i * scales_num + j) * 4 + 3) = hs;        //�����ԭʼ��׼size��3����ͬ��״��anchor�Ĵ�С���������
        }
    }

#endif
    //printf("gen anchors...........\n");

    //����anchor
    //for (i = 0; i < 3; i++)
    //{
    //    for (j = 0; j < scales_num; j++)
    //    {
    //        printf("%f %f %f %f\n", *(data + (i * scales_num + j) * 4),
    //                                *(data + (i * scales_num + j) * 4 + 1),
    //                                *(data + (i * scales_num + j) * 4 + 2),
    //                                *(data + (i * scales_num + j) * 4 + 3));
    //    }
    //}

    return HIK_VCA_LIB_S_OK;
}
