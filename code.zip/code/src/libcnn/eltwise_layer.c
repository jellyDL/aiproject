/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: eltwise_layer.h
* �ļ���ʶ: ELTWISE_LAYER_H
* ժ    Ҫ: eltwise��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-21
* ��    ע:
**************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "eltwise_layer_cuda.h"
#endif
#include <string.h>
#include <float.h>
#include <stdio.h>
#include "eltwise_layer.h"
#include "cnn_half.h"
#include "bn_layer.h"

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ELTWISE_Reshape(void       *handle,
                            LAYER_DATA *ld)
{
    int              i;
    int              axis_id;
    SHAPE_UNIT_TYPE *ref_shape, *cur_shape;
    ELTWISE_LAYER   *eltwise_layer = (ELTWISE_LAYER *)handle;

    // ��������blob��shape����һ��
    ref_shape = ld->input_blobs[0]->shape;
    for (i = 1; i < ld->input_blobs_num; i++)
    {
        cur_shape = ld->input_blobs[i]->shape;
        if ((ld->input_blobs[i]->type != ld->input_blobs[0]->type)
            || (ld->input_blobs[i]->ndims != ld->input_blobs[0]->ndims))
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }

        for (axis_id = 0; axis_id < ld->input_blobs[i]->ndims; axis_id++)
        {
            if (ref_shape[axis_id] != cur_shape[axis_id])
            {
                return HIK_VCA_CNN_MODEL_ERROR;
            }
        }
    }

    ld->output_blobs[0].ndims    = ld->input_blobs[0]->ndims;
    ld->output_blobs[0].type     = cnn_get_blob_type();
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].shape[1] = ld->input_blobs[0]->shape[1];
    ld->output_blobs[0].shape[2] = ld->input_blobs[0]->shape[2];
    ld->output_blobs[0].shape[3] = ld->input_blobs[0]->shape[3];

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ELTWISE_init_model(const char    *hyperparams,
                         const char    *param_blobs,
                         LAYER_MODEL    *ld,
                         ELTWISE_MODEL *eltwise_model)
{
    int              i, r, n;
    const char       operation[] = "operation";
    const char       coeff[]     = "coeff";
	char             str_tmp[16];
    const char      *ptr;
    SHAPE_UNIT_TYPE *ref_shape, *cur_shape;
    int              axis_id;

    HKA_CHECK_ERROR(ld->input_blobs_num <= 1, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    eltwise_model->op = ELTWISE_OP_SUM;
    if ((NULL != hyperparams) && (ptr = strstr(hyperparams, operation)))
    {
        r = sscanf(ptr + strlen(operation) + 1, "%d", &eltwise_model->op);

		if (r == 0)
		{
			r = sscanf(ptr + strlen(operation) + 1, "%3s", &str_tmp);
		}
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

		if (!strcmp(str_tmp, "SUM"))
		{
			eltwise_model->op = ELTWISE_OP_SUM;
		}
		else if (!strcmp(str_tmp, "MAX"))
		{
			eltwise_model->op = ELTWISE_OP_MAX;
		};
    }
    HKA_CHECK_ERROR(((ELTWISE_OP_SUM != eltwise_model->op) && (ELTWISE_OP_MAX != eltwise_model->op)), HIK_VCA_CNN_MODEL_ERROR);

    for (i = 0; i < ld->input_blobs_num; i++)
    {
        eltwise_model->coeff[i] = 1.f;
    }
    if ((NULL != hyperparams) && (ptr = strstr(hyperparams, coeff)))
    {
        ptr += strlen(coeff) + 1;
        for (i = 0; i < ld->input_blobs_num; i++)
        {
            r = sscanf(ptr, "%f%n", &eltwise_model->coeff[i], &n);
            HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
            ptr += n + 1; // ÿ�����ֺ����и����ţ����Լ�1
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ELTWISE_Create(LAYER_DATA *ld,
                           CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                           void      **handle)
{
    HRESULT                 hr;
    ELTWISE_LAYER           *eltwise_layer;

    CNN_BUF                 *cpu_handle_buf       = mem_buf;
    CNN_BUF                 *cpu_data_buf         = mem_buf + 1;
    CNN_BUF                 *gpu_data_buf         = mem_buf + 2;

#ifdef CNN_CUDA_OPT
    cudaError_t             err;
#endif

#ifndef CNN_CUDA_OPT
    gpu_data_buf    = NULL;
#else
    cpu_data_buf    = NULL;
#endif

    eltwise_layer = (ELTWISE_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                      CNN_SIZE_ALIGN(sizeof(ELTWISE_LAYER)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(eltwise_layer);

    eltwise_layer->model = ld->layer_model->model_handle;

    hr = CNN_ELTWISE_Reshape(eltwise_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    *handle = eltwise_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ELTWISE_GetMemsize(LAYER_DATA *ld,
                               VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT         hr;
    ELTWISE_LAYER   eltwise_layer;

    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
    VCA_MEM_TAB_V2     *cpu_data_tab   = mem_tab + 1;
    VCA_MEM_TAB_V2     *gpu_data_tab   = mem_tab + 2;

#ifndef CNN_CUDA_OPT
    gpu_data_tab                    = NULL; 
#else
    cpu_data_tab                    = NULL; 
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    eltwise_layer.model = ld->layer_model->model_handle;

    hr = CNN_ELTWISE_Reshape(&eltwise_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(ELTWISE_LAYER)),
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(gpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_GPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_ELTWISE_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    HRESULT                 hr;
    ELTWISE_MODEL           *eltwise_model;

    CNN_BUF                 *cpu_handle_buf = mem_buf;
    CNN_BUF                 *gpu_model_buf  = mem_buf + 2;

#ifdef CNN_CUDA_OPT
    cudaError_t             err;
#endif

#ifndef CNN_CUDA_OPT
    gpu_model_buf = NULL;
#endif

    eltwise_model = (ELTWISE_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(ELTWISE_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(eltwise_model);

    hr = CNN_ELTWISE_init_model(hyperparams, param_blobs, ld, eltwise_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
            
#ifdef CNN_CUDA_OPT

    if (gpu_model_buf && eltwise_model->op == ELTWISE_OP_SUM)
    {
        int ret;

        eltwise_model->coeff_gpu = CNN_alloc_buffer(gpu_model_buf, CNN_SIZE_ALIGN(MAX_INPUT_BLOBS * sizeof(float)), CNN_CUDA_MEM_ALIGNMENT, 0);
        CNN_CHECK_ERROR(eltwise_model->coeff_gpu == NULL, "CNN_alloc_buffer for cpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);

        eltwise_model->coeff_gpu_fp16 = CNN_alloc_buffer(gpu_model_buf, CNN_SIZE_ALIGN(MAX_INPUT_BLOBS * sizeof(cnn_half)), CNN_CUDA_MEM_ALIGNMENT, 0);
        CNN_CHECK_ERROR(eltwise_model->coeff_gpu_fp16 == NULL, "CNN_alloc_buffer for cpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);

        err = cudaMemcpy(eltwise_model->coeff_gpu, eltwise_model->coeff, sizeof(float) * MAX_INPUT_BLOBS, cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy failed", CNN_convert_cudart_error_code(err));
#ifdef ARCH_SUPPORT_FP16
        ret = cnn_float2half(eltwise_model->coeff_gpu, eltwise_model->coeff_gpu_fp16, MAX_INPUT_BLOBS);
        CNN_CHECK_ERROR(ret != HIK_VCA_LIB_S_OK, "cnn_float2half", ret);
#endif
    }

#endif // CNN_CUDA_OPT

    *handle = eltwise_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_ELTWISE_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT         hr;
    ELTWISE_MODEL   eltwise_model;

    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
    VCA_MEM_TAB_V2     *cpu_model_tab = mem_tab + 1;
    VCA_MEM_TAB_V2     *gpu_model_tab = mem_tab + 2;

#ifndef CNN_CUDA_OPT
    gpu_model_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    hr = CNN_ELTWISE_init_model(hyperparams, param_blobs, ld, &eltwise_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(ELTWISE_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    if (eltwise_model.op == ELTWISE_OP_SUM)
    {
        CNN_BASE_SetMemTab(gpu_model_tab,
            CNN_SIZE_ALIGN(MAX_INPUT_BLOBS * sizeof(float)) + CNN_SIZE_ALIGN(MAX_INPUT_BLOBS * sizeof(cnn_half)),
            CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    }
    
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_ELTWISE_Forward(void       *handle,
                            LAYER_DATA *ld)
{
    int            i, bi;
    int            blob_data_num, blob_data_size;
    float         *top_data;
    float         *bottom_data;
    float          coeff;
    ELTWISE_LAYER *eltwise_layer = (ELTWISE_LAYER *)handle;

    if (CNN_DT_FLT32 == ld->output_blobs[0].type)
    {
        top_data       = CNN_BLOB_GetPtr(&ld->output_blobs[0], 0, 0, 0, 0);
        blob_data_num  = CNN_BLOB_GetDataNum(&ld->output_blobs[0]);
        blob_data_size = CNN_BLOB_GetDataSize(&ld->output_blobs[0]);

        memset(top_data, 0, blob_data_size);

        switch (eltwise_layer->model->op)
        {
        case ELTWISE_OP_SUM:
            {
                for (bi = 0; bi < ld->input_blobs_num; bi++)
                {
                    coeff       = eltwise_layer->model->coeff[bi];
                    bottom_data = CNN_BLOB_GetPtr(ld->input_blobs[bi], 0, 0, 0, 0);
                    for (i = 0; i < blob_data_num; i++)
                    {
                        top_data[i] += coeff * bottom_data[i];
                    }
                }
                break;
            }
        case ELTWISE_OP_MAX:
            {
                for (i = 0; i < blob_data_num; i++)
                {
                    top_data[i] = FLT_MIN;
                }
                for (bi = 0; bi < ld->input_blobs_num; bi++)
                {
                    bottom_data = CNN_BLOB_GetPtr(ld->input_blobs[bi], 0, 0, 0, 0);
                    for (i = 0; i < blob_data_num; i++)
                    {
                        top_data[i] = HKA_MAX(top_data[i], bottom_data[i]);
                    }
                }
                break;
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: 
*         ELTWISE_LAYER          - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_ELTWISE_Forward_Cuda_Opt(ELTWISE_LAYER       *eltwise_layer,
                                     LAYER_DATA          *ld)
{
    HRESULT              hr, i;
    float               *in_data[MAX_INPUT_BLOBS];
    float               *out_data;
    float               *coef;

    void                *bn_scale;
    void                *bn_bias;
    void                *last_out;

    int                  do_flag = eltwise_layer->do_bn_relu;
                         
    cudaError_t          err;
    int                  ret;
    BN_LAYER             *bn_layer = eltwise_layer->bn_layer;
    BLOB_DATA_TYPE       type      = ld->output_blobs[0].type;
    BLOB_DATA_FORMAT     format    = ld->output_blobs[0].format;
    CNN_BLOB            *out_blob  = &ld->output_blobs[0];

    int                  n          = out_blob->shape[0];
    int                  c          = out_blob->shape[1];
    int                  h          = out_blob->shape[2];
    int                  w          = out_blob->shape[3];
    int                  in_pad_h = ld->input_blobs[0]->pad.pad_h;
    int                  in_pad_w = ld->input_blobs[0]->pad.pad_w;

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "format not support", CNN_CUDA_NOT_IMPLEMENT);
//printf("##### ELTWISE   op=%d  %d %d %d %d \n",
	//eltwise_layer->model->op, n,c,h,w);
    if (bn_layer)
    {
        if (type == CNN_DT_FLT32)
        {
            bn_scale = bn_layer->model->param_blobs[0].data_gpu;
            bn_bias  = bn_layer->model->param_blobs[1].data_gpu;
            last_out   = eltwise_layer->bn_out_blob.data_gpu;
        }
        else
        {
            bn_scale = bn_layer->model->param_blobs[0].data_gpu_fp16;
            bn_bias  = bn_layer->model->param_blobs[1].data_gpu_fp16;
            last_out   = eltwise_layer->bn_out_blob.data_gpu_fp16;
        }
    }
   
    for (i = 0; i < ld->input_blobs_num; i++)
    {
        //printf("%d %d\n", in_pad_h, ld->input_blobs[i]->pad.pad_h);
        if (format == CNN_FORMAT_NCHW_ZIP)
        {
            CNN_CHECK_ERROR(((in_pad_h != ld->input_blobs[i]->pad.pad_h) || (in_pad_w != ld->input_blobs[i]->pad.pad_w)),
                            "(in_pad_h != ld->input_blobs[i]->pad.pad_h) || (in_pad_w != ld->input_blobs[i]->pad.pad_w)",
                            CNN_CUDA_NOT_IMPLEMENT);
        }
        in_data[i]  = (type == CNN_DT_FLT32) ? ld->input_blobs[i]->data_gpu : ld->input_blobs[i]->data_gpu_fp16;
    }
   
    coef     = (type == CNN_DT_FLT32) ? eltwise_layer->model->coeff_gpu : eltwise_layer->model->coeff_gpu_fp16;
    out_data = (type == CNN_DT_FLT32) ? out_blob->data_gpu : out_blob->data_gpu_fp16;

    switch (eltwise_layer->model->op)
    {
    case ELTWISE_OP_SUM:
        if (format == CNN_FORMAT_NCHW)
        {
            hr = cnn_eltwise_sum_forward_cuda(in_data, 
                                              out_data, 
                                              coef, 
                                              do_flag,
                                              bn_scale,
                                              bn_bias,
                                              last_out,
                                              ld->output_blobs[0].shape[0],
                                              ld->output_blobs[0].shape[1],
                                              ld->output_blobs[0].shape[2] * ld->output_blobs[0].shape[3],
                                              ld->input_blobs_num, 
                                              type);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_eltwise_sum_forward_cuda", hr);
        }
        else if (format == CNN_FORMAT_NCHW_ZIP)
	    {
#ifdef ARCH_SUPPORT_FP16
            hr = cnn_eltwise_sum_forward_cuda_zip(in_data,
                                                  out_data,
	                                              coef,
	                                              n,
	                                              c,
	                                              h,
	                                              w,
	                                              ld->input_blobs_num,
	                                              type,
                                                  ld->input_blobs[0]->pad.pad_h,
                                                  ld->output_blobs[0].pad.pad_h);
	        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_eltwise_sum_forward_cuda_zip", hr);
#else
            CNN_CHECK_ERROR(1, "not implement", CNN_CUDA_NOT_IMPLEMENT);
#endif
	}
        break;
    case ELTWISE_OP_MAX:
        if (format == CNN_FORMAT_NCHW)
        {
            hr = cnn_eltwise_max_forward_cuda(in_data,
                                              out_data, 
                                              do_flag,
                                              bn_scale,
                                              bn_bias,
                                              last_out,
                                              ld->output_blobs[0].shape[0],
                                              ld->output_blobs[0].shape[1],
                                              ld->output_blobs[0].shape[2] * ld->output_blobs[0].shape[3],
                                              ld->input_blobs_num, 
                                              type);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_eltwise_max_forward_cuda", hr);
        }
        else if (format == CNN_FORMAT_NCHW_ZIP)
        {
#ifdef ARCH_SUPPORT_FP16
            hr = cnn_eltwise_max_forward_cuda_zip(in_data, 
                                                  out_data, 
                                                  ld->output_blobs[0].shape[0], 
                                                  ld->output_blobs[0].shape[1],
                                                  ld->output_blobs[0].shape[2],
                                                  ld->output_blobs[0].shape[3],
                                                  ld->input_blobs_num, 
                                                  type, 
                                                  ld->input_blobs[0]->pad.pad_h,
                                                  ld->output_blobs[0].pad.pad_h);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_eltwise_forward_cuda_zip", hr);
#else
            CNN_CHECK_ERROR(1, "not implement", CNN_CUDA_NOT_IMPLEMENT);
#endif
        }
        
        break;
    default:
        CNN_CHECK_ERROR(1, "eltwise layer only support sum and max", CNN_CUDA_NOT_IMPLEMENT);
    }

    return HIK_VCA_LIB_S_OK;
}

#endif
