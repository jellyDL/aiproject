/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: convolution_layer.c
* �ļ���ʶ: CONVOLUTION_LAYER_C
* ժ    Ҫ: conv��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-03
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

#include <string.h>
#include <stdio.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#endif // CNN_CUDA_OPT
#include "convolution_layer.h"
#ifdef MKL_OPT
#include "mkl_cblas.h"
#else
#include "cblas.h"
#endif
#include "blob.h"
#ifdef CNN_NNPACK_OPT
#include"nnpack.h" 
#endif
#include "conv3D_cuda_unopt.h"

#define CNN_CONVERT_ASYMCONV2FP32    // ���Գƾ����Ƿ�ת����FP32����

// CNN_CONV_init_model��������
extern HRESULT CNN_CONV_init_model(const char*, const char*, LAYER_MODEL*, CONVOLUTION_MODEL*);

/***************************************************************************************************
* ��  ��: �ж����ξ����Ƿ����ͬʱ��
* ��  ��: 
*         model             - I   layer model
*         model_ref         - I   ����model��model_ref�ж����ξ����Ƿ����ͬʱ��
*         ret               - O   1: ���� 0: ������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_CONV_fusion(LAYER_MODEL *layer, LAYER_MODEL *layer_ref, int *ret)
{
    int                i;
    HRESULT            hr;
    CONVOLUTION_MODEL  model;
    CONVOLUTION_MODEL  model_ref;
    const char        *unsupport_next_type[] = {"RpnProposal", 
                                                "Reshape", 
                                                "FrcnOutput",
                                                0};
    char             **next_type_ptr         = unsupport_next_type;

    *ret = 0;

    hr = CNN_CONV_init_model(layer->hyperparams,
                             layer->param_blobs,
                             NULL,
                             &model);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_init_model", hr);

    hr = CNN_CONV_init_model(layer_ref->hyperparams,
                             layer_ref->param_blobs,
                             NULL,
                             &model_ref);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_init_model", hr);

    if ((model.ker_h    == model_ref.ker_h)    && 
        (model.ker_h    == model_ref.ker_h)    &&
        (model.stride_h == model_ref.stride_h) &&
        (model.stride_w == model_ref.stride_w) &&
        (model.pad_h    == model_ref.pad_h)    &&
        (model.pad_w    == model_ref.pad_w)    &&
        (model.bias     == model_ref.bias))           // ����������ReLU !!
    {
        *ret = 1;
    }

    do 
    {
        // ����һ����������һ������unsupport_next_type�Ͳ���fusion,
        // ��Ϊ��Щ�㲻֧�ִ�PAD������
        for (i = 0; i < layer->layer_output.out_num; i++)
        {
            if ((layer->layer_output.layer_type[i]) &&
                (strcmp(layer->layer_output.layer_type[i], *next_type_ptr) == 0))
            {
                *ret = 0;
            }
            if ((layer_ref->layer_output.layer_type[i]) &&
                (strcmp(layer_ref->layer_output.layer_type[i], *next_type_ptr) == 0))
            {
                *ret = 0;
            }
        }
       
    } while (*++next_type_ptr);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: �ж��Ƿ�Ϊ1x1�ľ�����ͬʱҪ��pad��stride�ֱ�Ϊ0��1
* ��  ��: conv_layer             - I ��layer�ľ��
* ����ֵ: 1: ��1x1�ľ�����0����
***************************************************************************************************/
int CNN_CONV_is1x1(const CONVOLUTION_LAYER *conv_layer)
{
    return ((conv_layer->model->ker_h == 1) && (conv_layer->model->ker_w == 1)
        && (1 == conv_layer->model->stride_h) && (1 == conv_layer->model->stride_w)
        && (0 == conv_layer->model->pad_h) && (0 == conv_layer->model->pad_w));
}

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: conv_layer             - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_compute_in_out_shape(CONVOLUTION_LAYER *conv_layer,
                                      LAYER_DATA        *ld)
{
    HKA_CHECK_ERROR(ld->input_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    conv_layer->model->inp_h  = ld->input_blobs[0]->shape[2];
    conv_layer->model->inp_w  = ld->input_blobs[0]->shape[3];
    conv_layer->model->inp_cn = ld->input_blobs[0]->shape[1];

    conv_layer->model->out_h  = (conv_layer->model->inp_h + 2 * conv_layer->model->pad_h - conv_layer->model->ker_h) / conv_layer->model->stride_h + 1;
    conv_layer->model->out_w  = (conv_layer->model->inp_w + 2 * conv_layer->model->pad_w - conv_layer->model->ker_w) / conv_layer->model->stride_w + 1;
    conv_layer->model->out_cn = conv_layer->model->num_output;

    conv_layer->model->top_h  = conv_layer->model->out_h;
    conv_layer->model->top_w  = conv_layer->model->out_w;
    conv_layer->model->top_cn = conv_layer->model->out_cn;

    ld->output_blobs[0].ndims    = 4;
    ld->output_blobs[0].type     = cnn_get_blob_type();
    ld->output_blobs[0].shape[3] = conv_layer->model->out_w;
    ld->output_blobs[0].shape[2] = conv_layer->model->out_h;
    ld->output_blobs[0].shape[1] = conv_layer->model->out_cn;
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_Reshape(void       *handle,
                         LAYER_DATA *ld)
{
    HRESULT            hr;
    CONVOLUTION_LAYER *conv_layer = (CONVOLUTION_LAYER *)handle;

    hr = CNN_CONV_compute_in_out_shape(conv_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    conv_layer->model->out_group_cn = conv_layer->model->out_cn / conv_layer->model->group;
    conv_layer->model->inp_group_cn = conv_layer->model->inp_cn / conv_layer->model->group;
    conv_layer->model->ksize        = conv_layer->model->inp_group_cn * conv_layer->model->ker_h * conv_layer->model->ker_w;

    conv_layer->col_blob.ndims    = 4;
    conv_layer->col_blob.type     = CNN_DT_FLT32;                //���type GPU���ã�����
    conv_layer->col_blob.shape[0] = 1;
    conv_layer->col_blob.shape[1] = 1;
    conv_layer->col_blob.shape[2] = conv_layer->model->ksize;
    conv_layer->col_blob.shape[3] = conv_layer->model->out_h * conv_layer->model->out_w;
    conv_layer->col_blob.pad.pad_h = 0;
    conv_layer->col_blob.pad.pad_w = 0;

    conv_layer->bias_ones_blob.ndims    = 4;
    conv_layer->bias_ones_blob.type     = CNN_DT_FLT32;                 //���type GPU���ã�����
    conv_layer->bias_ones_blob.shape[0] = 1;    
    conv_layer->bias_ones_blob.shape[1] = 1;
    conv_layer->bias_ones_blob.shape[2] = 1;
    conv_layer->bias_ones_blob.shape[3] = conv_layer->model->top_h * conv_layer->model->top_w;
    conv_layer->bias_ones_blob.pad.pad_h = 0;
    conv_layer->bias_ones_blob.pad.pad_w = 0;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ʵ��im2col
* ��  ��: data_im                - I ��������
*         channels               - I ����ͨ����
*         height                 - I ����߶�
*         width                  - I �������
*         kernel_h               - I �����˸߶�
*         kernel_w               - I �����˿���
*         pad_h                  - I ��ֱ����pad��С
*         pad_w                  - I ˮƽ����pad��С
*         stride_h               - I ��ֱ������������
*         stride_w               - I ˮƽ������������
*         data_col               - O im2col�����
* ����ֵ: ��
***************************************************************************************************/
void CNN_CONV_im2col(const float *data_im,
                     int          channels,
                     int          height,
                     int          width,
                     int          kernel_h,
                     int          kernel_w,
                     int          pad_h,
                     int          pad_w,
                     int          stride_h,
                     int          stride_w,
                     float       *data_col)
{
    int c, h, w;
    int height_col   = (height + 2 * pad_h - kernel_h) / stride_h + 1;
    int width_col    = (width + 2 * pad_w - kernel_w) / stride_w + 1;
    int channels_col = channels * kernel_h * kernel_w;

    for (c = 0; c < channels_col; ++c)
    {
        int w_offset = c % kernel_w;
        int h_offset = (c / kernel_w) % kernel_h;
        int c_im     = c / kernel_h / kernel_w;
        for (h = 0; h < height_col; ++h)
        {
            for (w = 0; w < width_col; ++w)
            {
                int h_im = h * stride_h - pad_h + h_offset;
                int w_im = w * stride_w - pad_w + w_offset;
                if ((h_im >= 0) && (h_im < height) && (w_im >= 0) && (w_im < width))
                {
                    data_col[(c * height_col + h) * width_col + w] =
                        data_im[(c_im * height + h_im) * width + w_im];
                }
                else
                {
                    data_col[(c * height_col + h) * width_col + w] = 0;
                }
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         conv_model             - I/O ��layer��ģ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_init_model(const char        *hyperparams,
                            const char        *param_blobs,
                            LAYER_MODEL        *ld,
                            CONVOLUTION_MODEL *conv_model)
{
    int         r;
    int         param_blob_num;
    HRESULT     hr;
    const char  nout[] = "num_output";
    const char  bt[]   = "bias_term";
    const char  gp[]   = "group";
    const char *ptr;

    hr = CNN_BASE_GetKernelParams(hyperparams,
                                  &conv_model->ker_w, &conv_model->ker_h,
                                  &conv_model->pad_w, &conv_model->pad_h,
                                  &conv_model->stride_w, &conv_model->stride_h);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    ptr = strstr(hyperparams, nout);
    HKA_CHECK_ERROR(NULL == ptr, HIK_VCA_CNN_MODEL_ERROR);
    r = sscanf(ptr + strlen(nout) + 1, "%d", &conv_model->num_output);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

    conv_model->bias = 1;
    if (ptr = strstr(hyperparams, bt))
    {
        r = sscanf(ptr + strlen(bt) + 1, "%d", &conv_model->bias);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    conv_model->group = 1;
    if (ptr = strstr(hyperparams, gp))
    {
        r = sscanf(ptr + strlen(gp) + 1, "%d", &conv_model->group);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    param_blob_num = (0 == conv_model->bias ? 1 : CONV_LAYER_MAX_PARAM_BLOB_NUM);
    hr = CNN_BASE_GetParamBlobs(param_blobs, conv_model->param_blobs, param_blob_num, cnn_get_blob_type(), 0);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);    
    
    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �жϾ����Ƿ�Ҫת����fp32(fp16��֧��)
* ��  ��:
*           conv_layer   -I ������handle
* ����ֵ: 1: ��Ҫת����0: ����Ҫת��
***************************************************************************************************/
static int CNN_CONV_convert2fp32(CONVOLUTION_MODEL *model)
{
    int     ret;
    int     kernel_h, kernel_w;
    int     max_kernel_size;

    kernel_h = model->ker_h;
    kernel_w = model->ker_w;

    if ((kernel_h == kernel_w) && (kernel_h == 2))          // 2x2����fp16��֧��
    {
        return 1;
    }

    if (kernel_h == kernel_w)
    {
        return 0;
    }

    max_kernel_size = HKA_MAX(kernel_h, kernel_w);

    if (max_kernel_size % 2)                               // ���ԳƵľ���fp16��֧��
    {
        return 1;
    }

    return 0;
}

/***************************************************************************************************
* ��  ��: ����3D����Mem tab
* ��  ��:
*         ld                     - I     layer data
*         mem_tab                - O     memory table
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_CONV_conv3d_create(int height, 
                                      int width, 
                                      CNN_BUF *mem_buf,
                                      void **handle)
{
#ifdef ARCH_SUPPORT_FP16

    HRESULT                 hr;

    HIK3DCONV_LIB_MEM_PARAM mem_param = {width, height};
    HIK3DCONV_LIB_MEM_TAB   conv3d_mem_tab[HIK3DCONV_LIB_MEM_TAB_NUM];

    hr = HIK3DCONV_LIB_GetMemSize(&mem_param, conv3d_mem_tab);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "HIK3DCONV_LIB_GetMemSize", hr);

    conv3d_mem_tab[0].base = CNN_alloc_buffer(mem_buf + 0, 
                                              conv3d_mem_tab[0].size, 
                                              CNN_MEM_ALIGN_SIZE, 
                                              0);
    CNN_CHECK_ERROR(conv3d_mem_tab[0].base == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT)

    conv3d_mem_tab[1].base = CNN_alloc_buffer(mem_buf + 2, 
                                              conv3d_mem_tab[1].size, 
                                              CNN_CUDA_MEM_ALIGNMENT, 
                                              0);
    CNN_CHECK_ERROR(conv3d_mem_tab[1].base == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT)

    hr = HIK3DCONV_LIB_Create(&mem_param, conv3d_mem_tab, handle);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "HIK3DCONV_LIB_GetMemSize", hr);

#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_Create(LAYER_DATA *ld,
                        CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                        void      **handle)
{
    HRESULT                hr;
    CONVOLUTION_LAYER     *conv_layer;
    
    CNN_BUF               *cpu_handle_buf       = mem_buf;
    CNN_BUF               *cpu_data_buf         = mem_buf + 1;
    CNN_BUF               *gpu_data_buf         = mem_buf + 2;
    
#ifndef CNN_CUDA_OPT
    gpu_data_buf    = NULL;
#else
    cpu_data_buf    = NULL;
#endif

    conv_layer = (CONVOLUTION_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                       CNN_SIZE_ALIGN(sizeof(CONVOLUTION_LAYER)),
                                                       CNN_MEM_ALIGN_SIZE,
                                                       1);
    HKA_CHECK_MEMOUT(conv_layer);

    conv_layer->model = ld->layer_model->model_handle;
        
    hr = CNN_CONV_Reshape(conv_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    if (conv_layer->model->bias)
    {
        hr = cnn_alloc_blob_buffer(&conv_layer->bias_ones_blob,
                                   cpu_handle_buf,
                                   NULL,
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);

        CNN_BLOB_InitOneBiasBlob(&conv_layer->bias_ones_blob);
    }

#ifdef CNN_CONCAT_OPT
    if (0 == ld->layer_model->feed_to_concat[0])
    {
#endif
    hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);
#ifdef CNN_CONCAT_OPT
    }
#endif

#ifdef ARCH_SUPPORT_FP16
    if (CNN_CONV_convert2fp32(conv_layer->model))
    {
        conv_layer->input_gpu = CNN_alloc_buffer(gpu_data_buf,
                                                 CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[0]) * sizeof(float)),
                                                 CNN_CUDA_MEM_ALIGNMENT,
                                                 0);
        CNN_CHECK_ERROR(conv_layer->input_gpu == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);

        conv_layer->output_gpu = CNN_alloc_buffer(gpu_data_buf,
                                                  CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]) * sizeof(float)),
                                                  CNN_CUDA_MEM_ALIGNMENT,
                                                  0);
        CNN_CHECK_ERROR(conv_layer->output_gpu == NULL, "CNN_alloc_buffer for gpu blob data failed", HIK_VCA_LIB_E_MEM_OUT);
    }
#endif

    conv_layer->col_blob.data = NULL;
    if (!CNN_CONV_is1x1(conv_layer))
    {
        hr = cnn_alloc_blob_buffer(&conv_layer->col_blob,
                                   cpu_data_buf,
                                   NULL,
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);
    }
    
#ifdef ARCH_SUPPORT_FP16
    hr = CNN_CONV_conv3d_create(ld->input_blobs[0]->shape[2], 
                                ld->input_blobs[0]->shape[3], 
                                mem_buf, 
                                &conv_layer->conv3d_handle);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_conv3d_create", hr);
#endif

    *handle = conv_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����3D����Mem tab
* ��  ��:
*         ld                     - I     layer data
*         cnn_mem_tab            - O     cnn memory table
* ����ֵ: ״̬��
***************************************************************************************************/
static HRESULT CNN_CONV_set_conv3d_mem(int height, int width, VCA_MEM_TAB_V2 cnn_mem_tab[])
{

#ifdef ARCH_SUPPORT_FP16
    HRESULT                 hr;
    HIK3DCONV_LIB_MEM_PARAM mem_param = {width, height};
    HIK3DCONV_LIB_MEM_TAB   conv3d_mem_tab[HIK3DCONV_LIB_MEM_TAB_NUM];

    hr = HIK3DCONV_LIB_GetMemSize(&mem_param, conv3d_mem_tab);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "HIK3DCONV_LIB_GetMemSize", hr);

    cnn_mem_tab[0].size += CNN_SIZE_ALIGN(conv3d_mem_tab[0].size);
    cnn_mem_tab[2].size += CNN_SIZE_ALIGN(conv3d_mem_tab[1].size);
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_GetMemsize(LAYER_DATA *ld,
                            VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT           hr;
    size_t            size;
    CONVOLUTION_LAYER conv_layer;

    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
    VCA_MEM_TAB_V2     *cpu_data_tab   = mem_tab + 1;
    VCA_MEM_TAB_V2     *gpu_data_tab   = mem_tab + 2;

#ifndef CNN_CUDA_OPT
    gpu_data_tab                    = NULL; 
#else
    cpu_data_tab                    = NULL; 
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    conv_layer.model = ld->layer_model->model_handle;

    hr = CNN_CONV_Reshape(&conv_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    size = CNN_SIZE_ALIGN(sizeof(CONVOLUTION_LAYER));
    size += conv_layer.model->bias ? CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&conv_layer.bias_ones_blob)) : 0;
    CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    size = 0;
#ifdef CNN_CONCAT_OPT
    if (0 == ld->layer_model->feed_to_concat[0])
    {
#endif
        size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0]));
#ifdef CNN_CONCAT_OPT
    }
#endif
    CNN_BASE_SetMemTab(gpu_data_tab, size, CNN_CUDA_MEM_ALIGNMENT, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

#ifdef ARCH_SUPPORT_FP16
    if (CNN_CONV_convert2fp32(conv_layer.model))
    {
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           size + 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(ld->input_blobs[0]) * sizeof(float)) + 
                           CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum_padded(&ld->output_blobs[0]) * sizeof(float)),
                           CNN_CUDA_MEM_ALIGNMENT, 
                           VCA_MEM_PERSIST, 
                           VCA_MEM_PLAT_GPU);
    }
#endif

    if (!CNN_CONV_is1x1(&conv_layer))
    {
        size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&conv_layer.col_blob));
    }
    CNN_BASE_SetMemTab(cpu_data_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

#ifdef ARCH_SUPPORT_FP16
    hr = CNN_CONV_set_conv3d_mem(ld->input_blobs[0]->shape[2], ld->input_blobs[0]->shape[3], mem_tab);
    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, "CNN_CONV_set_conv3d_mem", hr);
#endif

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ����layer��model
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_CreateModel(const char *hyperparams,
                             const char *param_blobs,
                             LAYER_MODEL *ld,
                             CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
                             void      **handle)
{
    int                    bi;
    int                    param_blob_num;
    HRESULT                hr;
    CONVOLUTION_MODEL     *conv_model;

    CNN_BUF               *cpu_handle_buf = &mem_buf[0];
    CNN_BUF               *cpu_model_buf  = &mem_buf[1];
    CNN_BUF               *gpu_model_buf  = &mem_buf[2];

    BLOB_INIT_FUNCS       blob_init_funcs = {cnn_init_blob, cnn_init_blob, cnn_init_blob, cnn_init_blob};

#ifndef CNN_CUDA_OPT
    gpu_model_buf = NULL;
#else
    cpu_model_buf = NULL;
#endif

    conv_model = (CONVOLUTION_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
                                                       CNN_SIZE_ALIGN(sizeof(CONVOLUTION_MODEL)),
                                                       CNN_MEM_ALIGN_SIZE,
                                                       1);
    HKA_CHECK_MEMOUT(conv_model);

    hr = CNN_CONV_init_model(hyperparams, param_blobs, ld, conv_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    param_blob_num = (0 == conv_model->bias ? 1 : CONV_LAYER_MAX_PARAM_BLOB_NUM);

    for (bi = 0; bi < param_blob_num; bi++)
    {
        hr = cnn_alloc_blob_buffer(&conv_model->param_blobs[bi],
                                   cpu_model_buf,
                                   gpu_model_buf,
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);

#ifdef ARCH_SUPPORT_FP16
        if (CNN_CONV_convert2fp32(conv_model))
        {
            conv_model->param_blobs[bi].data_gpu = CNN_alloc_buffer(gpu_model_buf, 
                                                                    CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&conv_model->param_blobs[bi]) * sizeof(float)),
                                                                    CNN_CUDA_MEM_ALIGNMENT, 
                                                                    0);
            CNN_CHECK_ERROR(conv_model->param_blobs[bi].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_PTR_NULL);
        }
        else
        {
            conv_model->param_blobs[bi].data_gpu = ld->fp16_workspace;
        }
#endif
    }

    hr = CNN_BASE_GetParamBlobs(param_blobs, conv_model->param_blobs, param_blob_num, cnn_get_blob_type(), blob_init_funcs);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);    

    *handle = conv_model;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer��model���ڴ��С
* ��  ��: hyperparams            - I ������
*         param_blobs            - I ����
*         ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONV_GetModelMemsize(const char *hyperparams,
                                 const char *param_blobs,
                                 LAYER_MODEL *ld,
                                 VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT           hr;
    int               bi;
    int               param_blob_num;
    size_t            size;
    CNN_BLOB         *param_blob;
    CONVOLUTION_MODEL conv_model;

    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
    VCA_MEM_TAB_V2     *cpu_model_tab  = mem_tab + 1;
    VCA_MEM_TAB_V2     *gpu_model_tab  = mem_tab + 2;

#ifndef CNN_CUDA_OPT
    gpu_model_tab = NULL;
#else
    cpu_model_tab = NULL;
#endif
    
    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    hr = CNN_CONV_init_model(hyperparams, param_blobs, ld, &conv_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    size = CNN_SIZE_ALIGN(sizeof(CONVOLUTION_MODEL));
    CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    size = 0;
    param_blob_num = (0 == conv_model.bias ? 1 : CONV_LAYER_MAX_PARAM_BLOB_NUM);
    for (bi = 0; bi < param_blob_num; bi++)
    {
        param_blob = &conv_model.param_blobs[bi];
        size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(param_blob));
    }

    //���û�ж���CNN_CUDA_OPT����gpu_model_tabΪNULL,�ú���ʲôҲ����
    CNN_BASE_SetMemTab(gpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
#ifdef ARCH_SUPPORT_FP16
    if (CNN_CONV_convert2fp32(&conv_model))
    {
        CNN_BASE_SetMemTab(gpu_model_tab, size + size * 2, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    }
#endif

    CNN_BASE_SetMemTab(cpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ������� C = A x B
* ��  ��:
*         A                   - I  A����
*         B                   - I  B����
*         C                   - C  C����
*         M                   - I  A�� M x K
*         N                   - I  B:  K x N
*         K                   - I  C:  M x N
* ����ֵ: ��
***************************************************************************************************/
static void cnn_simple_sgemm(float *A,
                             float *B,
                             float *C,
                             int    M,
                             int    N,
                             int    K)
{
    int i, j, s;

    for (i = 0; i < M; i++)
    {
        for (j = 0; j < N; j++)
        {
            C[i * N + j] = 0;
            for (s = 0; s < K; s++)
            {
                C[i * N + j] += A[i * K + s] * B[s * N + j];
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: ��ƫ����
* ��  ��: 
*         data                   - I/O �������
*         bias                   - I   ƫ��
*         h                      - I   ��
*         w                      - I   ��
*         c                      - I   ͨ����
* ����ֵ: ��
***************************************************************************************************/
static void cnn_simple_add_bias(float *data,
                                float *bias,
                                int    h,
                                int    w,
                                int    c)
{
    int i, j, s;

    for (s = 0; s < c; s++)
    {
        for (i = 0; i < h; i++)
        {
            for (j = 0; j < w; j++)
            {
                data[s * h * w + i * w + j] += bias[s];
            }
        }
    }
}

#ifdef CNN_NNPACK_OPT
/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONV_Forward_Nnpack(void       *handle,
                      LAYER_DATA *ld)
{
    int                n, g;
    int                M, N, K;
    CONVOLUTION_LAYER *conv_layer = (CONVOLUTION_LAYER *)handle;
	enum nnp_status hr;

    void     *input_blob_data, *output_blob_data;
    CNN_BLOB *input_blob  = ld->input_blobs[0];
    CNN_BLOB *output_blob = &ld->output_blobs[0];
    CNN_BLOB *weight_blob = &conv_layer->model->param_blobs[0];
    CNN_BLOB *bias_blob   = &conv_layer->model->param_blobs[1];
 
	pthreadpool_t threadpool = NULL;
	const struct nnp_size input_size		 = { input_blob->shape[3], input_blob->shape[2] };
	const struct nnp_padding input_padding   = { conv_layer->model->pad_h, conv_layer->model->pad_w, conv_layer->model->pad_h, conv_layer->model->pad_w };
	const struct nnp_size kernel_size	     = { conv_layer->model->ker_w, conv_layer->model->ker_h };
	const struct nnp_size output_subsampling = { conv_layer->model->stride_w, conv_layer->model->stride_h };//NNPACKֻ֧��stride = 1

	int input_nhwsize = input_blob->shape[0] * input_blob->shape[2] * input_blob->shape[3];
	enum nnp_convolution_transform_strategy transform_strategy = nnp_convolution_transform_strategy_tuple_based;

	if ((1 == conv_layer->model->stride_w) && (1 == conv_layer->model->stride_h) && (3 == conv_layer->model->ker_w) && (3 == conv_layer->model->ker_h) && (input_blob->shape[0] > 1) && (input_blob->shape[1] > 1) && (input_nhwsize > 640))
	{

		hr = nnp_convolution_output(nnp_convolution_algorithm_wt8x8,
													input_blob->shape[0],
													input_blob->shape[1],
													conv_layer->model->num_output,
													input_size,
													input_padding,
													kernel_size,
													input_blob->data,
													weight_blob->data,
													bias_blob->data,
													output_blob->data,
													threadpool,
													NULL);
		if (hr != nnp_status_success)
		{
			return CNN_NNPACK_ERROR_CODE_BASE + (int)hr;
		}
			
	}
	else if ((1 == conv_layer->model->stride_w) && (1 == conv_layer->model->stride_h) && (3 == conv_layer->model->ker_w) && (3 == conv_layer->model->ker_h) && (1 == input_blob->shape[0]) && (input_blob->shape[1] > 1) && (input_nhwsize > 300))
	{
		hr =  nnp_convolution_inference(nnp_convolution_algorithm_wt8x8,
													    transform_strategy,
														input_blob->shape[1],
														conv_layer->model->num_output,
														input_size,
														input_padding,
														kernel_size,
														output_subsampling,
														input_blob->data, 
														weight_blob->data,
														bias_blob->data,
														output_blob->data,
														threadpool,
														NULL);
		if (hr != nnp_status_success)
		{
			return CNN_NNPACK_ERROR_CODE_BASE + (int)hr;
		}
	}
	else
	{
		CNN_CONV_Forward(conv_layer, ld);
				
	}

    return HIK_VCA_LIB_S_OK;

}
#endif
/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONV_Forward(void       *handle,
                      LAYER_DATA *ld)
{
    int                n, g;
    int                M, N, K;
    CONVOLUTION_LAYER *conv_layer = (CONVOLUTION_LAYER *)handle;

    void     *input_blob_data, *output_blob_data;
    CNN_BLOB *input_blob  = ld->input_blobs[0];
    CNN_BLOB *output_blob = &ld->output_blobs[0];
    CNN_BLOB *weight_blob = &conv_layer->model->param_blobs[0];
    CNN_BLOB *bias_blob   = &conv_layer->model->param_blobs[1];
    
    for (n = 0; n < input_blob->shape[0]; n++)
    {
        for (g = 0; g < conv_layer->model->group; g++)
        {
            input_blob_data  = CNN_BLOB_GetPtr(input_blob, n, 0, 0, 0);
            output_blob_data = CNN_BLOB_GetPtr(output_blob, n, 0, 0, 0);
            if (CNN_CONV_is1x1(conv_layer))
            {
                conv_layer->col_blob.data = input_blob_data;
            }
            else
            {
                CNN_CONV_im2col(input_blob_data,
                                input_blob->shape[1],
                                input_blob->shape[2],
                                input_blob->shape[3],
                                conv_layer->model->ker_h,
                                conv_layer->model->ker_w,
                                conv_layer->model->pad_h,
                                conv_layer->model->pad_w,
                                conv_layer->model->stride_h,
                                conv_layer->model->stride_w,
                                conv_layer->col_blob.data);
            }

            M = weight_blob->shape[0];
            N = conv_layer->col_blob.shape[3];
            K = weight_blob->shape[1] * weight_blob->shape[2] * weight_blob->shape[3];

#ifndef CNN_CUDA_OPT
            cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, M,
                        N, K, 1.0f, weight_blob->data, K, conv_layer->col_blob.data, N, 0.f,
                        output_blob_data, N);
#endif

            if (conv_layer->model->bias)
            {
#ifndef CNN_CUDA_OPT
                M = CNN_BLOB_GetDataNum(bias_blob);
                N = conv_layer->bias_ones_blob.shape[3];
                K = 1;
                cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, M,
                            N, K, 1.0f, bias_blob->data, K, conv_layer->bias_ones_blob.data, N, 1.f,
                            output_blob_data, N);
#endif
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}



#ifdef CNN_CUDA_OPT

#ifndef CNN_PROFILE_LAYER

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: 
*         cnn_cudnn_handle       - I  cudnn handle
*         in_data                - I  �ò������
*         weight_data            - I  ������ϵ��
*         bias_data              - I  ƫ����
*         out_data               - O  ���
*         in_n                   - I  ����n
*         in_c                   - I  ����c
*         in_h                   - I  ����h
*         in_w                   - I  ����w
*         out_n                  - I  ���n
*         out_c                  - I  ���c
*         out_h                  - I  ���h
*         out_w                  - I  ���w
*         ksize_h                - I  ������height
*         ksize_w                - I  ������width
*         stride_h               - I  ��������h����
*         stride_w               - I  ��������w����
*         pad_h                  - I  ��������h����
*         pad_w                  - I  ��������w����
*         add_bias               - I  �Ƿ��ƫ��
* ����ֵ: ��
***************************************************************************************************/
static HRESULT cnn_conv_forward_cudnn(CNN_CUDNN_HANDLE   *cnn_cudnn_handle,
                                      float_t            *in_data,
                                      float_t            *weight_data,
                                      float_t            *bias_data,
                                      float_t            *out_data,
                                      BLOB_DATA_TYPE      type,
                                      int                 in_n,
                                      int                 in_c,
                                      int                 in_h,
                                      int                 in_w,
                                      int                 out_n,
                                      int                 out_c,
                                      int                 out_h,
                                      int                 out_w,
                                      int                 ksize_h,
                                      int                 ksize_w,
                                      int                 stride_h,
                                      int                 stride_w,
                                      int                 pad_h,
                                      int                 pad_w,
                                      int                 add_bias,
                                      int                 is_relu)
{
    int                             in_dim[4]          = {in_n, in_c, in_h, in_w};
    int                             out_dim[4]         = {out_n, out_c, out_h, out_w};

    int                             filter_dim[4]      = {out_c, in_c, ksize_h, ksize_w};
    int                             pad[2]             = {pad_h, pad_w};
    int                             stride[2]          = {stride_h, stride_w};
//     int                             stride_in[4]       = {in_c * in_h * in_w, in_h * in_w, in_w, 1};
//     int                             stride_out[4]      = {out_c * out_h * out_w, out_h * out_w, out_w, 1};
    int                             upscale[2]         = {1, 1};

    cudnnHandle_t                   cudnn_handle       = cnn_cudnn_handle->cudnn_handle;
    cudnnFilterDescriptor_t         filter_desc        = cnn_cudnn_handle->filterDesc;
    cudnnConvolutionDescriptor_t    conv_desc          = cnn_cudnn_handle->convDesc;
    cudnnTensorDescriptor_t         src_tensor_desc    = cnn_cudnn_handle->srcTensorDesc;
    cudnnTensorDescriptor_t         dst_tensor_desc    = cnn_cudnn_handle->dstTensorDesc;
    cudnnTensorDescriptor_t         bias_tensor_desc   = cnn_cudnn_handle->biasTensorDesc;
    cudnnTensorFormat_t             tensor_format      = CUDNN_TENSOR_NCHW;                   //Ŀǰֻ֧�������ڴ����з�ʽ
    cudnnDataType_t                 data_type          = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;
    cudnnConvolutionFwdAlgo_t       conv_algo;
    float                           alpha              = 1.0f;
    float                           beta               = 0.0f;   

    void                            *workspace         = cnn_cudnn_handle->cudnn_mem;
    size_t                          workspace_size     = 0;
    size_t                          max_workspace_size = cnn_cudnn_handle->cudnn_mem_size;
    cudnnStatus_t                   cudnn_sts;

    int                             output_n, output_c, output_h, output_w;
    HRESULT                         hr;
    int                             i;
    cudaError_t                     err;

    /*------------------------------����tensor��ͬcudnnSetTensor4dDescriptor-----------------------------------
    cudnn_sts = cudnnSetTensorNdDescriptor(src_tensor_desc, data_type, 4, in_dim, stride_in);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnSetTensorNdDescriptor(dst_tensor_desc, data_type, 4, out_dim, stride_out);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnSetFilterNdDescriptor(filter_desc, data_type, 4, filter_dim);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetFilterNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
    ----------------------------------------------------------------------------------------------------------*/

    cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc, tensor_format, data_type, in_n, in_c, in_h, in_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

    cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc, tensor_format, data_type, out_n, out_c, out_h, out_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if (CUDNN_VERSION >= 5000)
    cudnn_sts = cudnnSetFilter4dDescriptor(filter_desc, data_type, tensor_format, out_c, in_c, ksize_h, ksize_w);
#else
    cudnn_sts = cudnnSetFilter4dDescriptor(filter_desc, data_type, out_c, in_c, ksize_h, ksize_w);
#endif
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetFilter4dDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if (CUDNN_VERSION >= 4000)
    cudnn_sts = cudnnSetConvolutionNdDescriptor(conv_desc, 2, pad, stride, upscale, CUDNN_CROSS_CORRELATION, data_type);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetConvolutionNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
#else
    printf("only support CUDNN_V4 or later\n");
    return HIK_VCA_LIB_KEY_PARAM_ERR;
#endif

#if 0
    cudnn_sts = cudnnGetConvolution2dForwardOutputDim(conv_desc, src_tensor_desc, filter_desc, &output_n, &output_c, &output_h, &output_w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolution2dForwardOutputDim failed", CNN_convert_cudnn_error_code(cudnn_sts));
    printf("%d %d %d %d %d %d %d %d\n", output_n, output_c, output_h, output_w, out_n, out_c, out_h, out_w);

     printf("in_n: %d, in_c: %d, in_h: %d, in_w: %d, out_n: %d, out_c: %d, out_h: %d, out_w: %d, kernel_size: %d, pad: %d, stride: %d\n", 
            in_n, in_c, in_h, in_w, out_n, 
            out_c, out_h, out_w, 
            ksize_h, pad_h, stride_h);

     printf("%d, %d, %d, %d %d, %d, %d, \n", in_h, in_w, in_c, ksize_h, ksize_w, out_c, stride_h);
#endif

#ifndef CNN_CONVERT_ASYMCONV2FP32
    if ((ksize_h != ksize_w) && (data_type == CNN_DT_FLT16))
#else
    if(0)
#endif
    {
        conv3D_cuda_unopt(in_data, 
                          weight_data, 
                          out_data, 
                          bias_data, 
                          in_n, 
                          in_c, 
                          in_h, 
                          in_w, 
                          out_c, 
                          out_w, 
                          out_h,
                          ksize_w,
                          ksize_h,
                          pad_w,
                          pad_h,
                          stride_w,
                          stride_h,
                          0,
                          0);
        err = cudaGetLastError();
        CNN_CHECK_ERROR(err != cudaSuccess, "conv3D_cuda_unopt", CNN_convert_cudart_error_code(err));
    }
    else
    {
        if (type == CNN_DT_FLT16)
        {
            conv_algo = CUDNN_CONVOLUTION_FWD_ALGO_IMPLICIT_PRECOMP_GEMM;           //ֻ�����ַ���֧��fp16
        }
        else
        {
            //��ȡʵ��3D�����ķ���
            cudnn_sts = cudnnGetConvolutionForwardAlgorithm(cudnn_handle,
                                                            src_tensor_desc,
                                                            filter_desc,
                                                            conv_desc,
                                                            dst_tensor_desc,
                                                            CUDNN_CONVOLUTION_FWD_SPECIFY_WORKSPACE_LIMIT,
                                                            max_workspace_size,
                                                            &conv_algo);
            CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolutionForwardAlgorithm failed", CNN_convert_cudnn_error_code(cudnn_sts));
        }

        //��ȡcudnn������ʱ��Ҫ�Ķ����ڴ��С
        cudnn_sts = cudnnGetConvolutionForwardWorkspaceSize(cudnn_handle, 
                                                            src_tensor_desc,
                                                            filter_desc,
                                                            conv_desc,
                                                            dst_tensor_desc,
                                                            conv_algo,
                                                             &workspace_size);
         
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolutionForwardWorkspaceSize failed", CNN_convert_cudnn_error_code(cudnn_sts));
        
        //�ж�cudnn����Ҫ���ڴ��Ƿ��ʵ�ʷ���Ĵ�
        if (workspace_size > max_workspace_size)
        {
            printf("Error: cudnnConvolutionForward_Kernel requires more workspace (%g MB) than pre-allocated (%g MB) memory\n",
                    workspace_size / 1024.f / 1024.f, max_workspace_size / 1024.f / 1024.f);
            return HIK_VCA_LIB_KEY_PARAM_ERR;
        }

        //����cudnnʵ��3D�����ĺ���
        cudnn_sts = cudnnConvolutionForward(cudnn_handle, 
                                            &alpha,
                                            src_tensor_desc,
                                            in_data,
                                            filter_desc,
                                            weight_data,
                                            conv_desc,
                                            conv_algo,
                                            workspace,
                                            workspace_size,
                                            &beta,
                                            dst_tensor_desc,
                                            out_data);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnConvolutionForward failed", CNN_convert_cudnn_error_code(cudnn_sts));
    }

    //�Ƿ���Ҫ��ƫ����
    if(1 == add_bias)
    {
        hr = CNN_CONV_relu_bias_cuda(out_data,
                                     out_data,
                                     bias_data,
                                     type,
                                     out_h * out_w,
                                     out_c,
                                     out_n,
                                     is_relu);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_relu_bias_cuda", hr);
    }
    else // �Ƿ���Ҫ��relu 
    {
        if (is_relu)
        {
            hr = CNN_CONV_relu_cuda(out_data,
                                    out_data,
                                    type,
                                    out_h * out_w,
                                    out_c,
                                    out_n);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_relu_cuda", hr);
        }
    }

    return HIK_VCA_LIB_S_OK;
}

#else

extern int conv_timer_id;
extern int do_conv;
extern int conv_switch;

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: 
*         cnn_cudnn_handle       - I  cudnn handle
*         in_data                - I  �ò������
*         weight_data            - I  ������ϵ��
*         bias_data              - I  ƫ����
*         out_data               - O  ���
*         in_n                   - I  ����n
*         in_c                   - I  ����c
*         in_h                   - I  ����h
*         in_w                   - I  ����w
*         out_n                  - I  ���n
*         out_c                  - I  ���c
*         out_h                  - I  ���h
*         out_w                  - I  ���w
*         ksize_h                - I  ������height
*         ksize_w                - I  ������width
*         stride_h               - I  ��������h����
*         stride_w               - I  ��������w����
*         pad_h                  - I  ��������h����
*         pad_w                  - I  ��������w����
*         add_bias               - I  �Ƿ��ƫ��
* ����ֵ: ��
***************************************************************************************************/
static HRESULT cnn_conv_forward_cudnn(CNN_CUDNN_HANDLE   *cnn_cudnn_handle,
                                      float_t            *in_data,
                                      float_t            *weight_data,
                                      float_t            *bias_data,
                                      float_t            *out_data,
                                      BLOB_DATA_TYPE      type,
                                      int                 in_n,
                                      int                 in_c,
                                      int                 in_h,
                                      int                 in_w,
                                      int                 out_n,
                                      int                 out_c,
                                      int                 out_h,
                                      int                 out_w,
                                      int                 ksize_h,
                                      int                 ksize_w,
                                      int                 stride_h,
                                      int                 stride_w,
                                      int                 pad_h,
                                      int                 pad_w,
                                      int                 add_bias,
                                      int                 is_relu)
{
    int                             in_dim[4]          = {in_n, in_c, in_h, in_w};
    int                             out_dim[4]         = {out_n, out_c, out_h, out_w};

    int                             filter_dim[4]      = {out_c, in_c, ksize_h, ksize_w};
    int                             pad[2]             = {pad_h, pad_w};
    int                             stride[2]          = {stride_h, stride_w};
//     int                             stride_in[4]       = {in_c * in_h * in_w, in_h * in_w, in_w, 1};
//     int                             stride_out[4]      = {out_c * out_h * out_w, out_h * out_w, out_w, 1};
    int                             upscale[2]         = {1, 1};

    cudnnHandle_t                   cudnn_handle       = cnn_cudnn_handle->cudnn_handle;
    cudnnFilterDescriptor_t         filter_desc        = cnn_cudnn_handle->filterDesc;
    cudnnConvolutionDescriptor_t    conv_desc          = cnn_cudnn_handle->convDesc;
    cudnnTensorDescriptor_t         src_tensor_desc    = cnn_cudnn_handle->srcTensorDesc;
    cudnnTensorDescriptor_t         dst_tensor_desc    = cnn_cudnn_handle->dstTensorDesc;
    cudnnTensorDescriptor_t         bias_tensor_desc   = cnn_cudnn_handle->biasTensorDesc;
    cudnnTensorFormat_t             tensor_format      = CUDNN_TENSOR_NCHW;                   //Ŀǰֻ֧�������ڴ����з�ʽ
    cudnnDataType_t                 data_type          = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;
    cudnnConvolutionFwdAlgo_t       conv_algo;
    float                           alpha              = 1.0f;
    float                           beta               = 0.0f;   

    void                            *workspace         = cnn_cudnn_handle->cudnn_mem;
    size_t                          workspace_size     = 0;
    size_t                          max_workspace_size = cnn_cudnn_handle->cudnn_mem_size;
    cudnnStatus_t                   cudnn_sts;

    int                             output_n, output_c, output_h, output_w;
    HRESULT                         hr;
    int                             i;
    cudaError_t                     err;

    if (do_conv || conv_switch)
    {

        /*------------------------------����tensor��ͬcudnnSetTensor4dDescriptor-----------------------------------
        cudnn_sts = cudnnSetTensorNdDescriptor(src_tensor_desc, data_type, 4, in_dim, stride_in);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

        cudnn_sts = cudnnSetTensorNdDescriptor(dst_tensor_desc, data_type, 4, out_dim, stride_out);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

        cudnn_sts = cudnnSetFilterNdDescriptor(filter_desc, data_type, 4, filter_dim);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetFilterNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
        ----------------------------------------------------------------------------------------------------------*/

        cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc, tensor_format, data_type, in_n, in_c, in_h, in_w);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

        cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc, tensor_format, data_type, out_n, out_c, out_h, out_w);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if (CUDNN_VERSION >= 5000)
        cudnn_sts = cudnnSetFilter4dDescriptor(filter_desc, data_type, tensor_format, out_c, in_c, ksize_h, ksize_w);
#else
        cudnn_sts = cudnnSetFilter4dDescriptor(filter_desc, data_type, out_c, in_c, ksize_h, ksize_w);
#endif
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetFilter4dDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if (CUDNN_VERSION >= 4000)
        cudnn_sts = cudnnSetConvolutionNdDescriptor(conv_desc, 2, pad, stride, upscale, CUDNN_CROSS_CORRELATION, data_type);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetConvolutionNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
#else
        printf("only support CUDNN_V4 or later\n");
        return HIK_VCA_LIB_KEY_PARAM_ERR;
#endif

#if 0
        cudnn_sts = cudnnGetConvolution2dForwardOutputDim(conv_desc, src_tensor_desc, filter_desc, &output_n, &output_c, &output_h, &output_w);
        CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolution2dForwardOutputDim failed", CNN_convert_cudnn_error_code(cudnn_sts));
        printf("%d %d %d %d %d %d %d %d\n", output_n, output_c, output_h, output_w, out_n, out_c, out_h, out_w);

         printf("in_n: %d, in_c: %d, in_h: %d, in_w: %d, out_n: %d, out_c: %d, out_h: %d, out_w: %d, kernel_size: %d, pad: %d, stride: %d\n", 
                in_n, in_c, in_h, in_w, out_n, 
                out_c, out_h, out_w, 
                ksize_h, pad_h, stride_h);

         printf("%d, %d, %d, %d %d, %d, %d, \n", in_h, in_w, in_c, ksize_h, ksize_w, out_c, stride_h);
#endif

#ifndef CNN_CONVERT_ASYMCONV2FP32
        if ((ksize_h != ksize_w) && (data_type == CNN_DT_FLT16))
#else
        if(0)
#endif
        {
            conv3D_cuda_unopt(in_data, 
                              weight_data, 
                              out_data, 
                              bias_data, 
                              in_n, 
                              in_c, 
                              in_h, 
                              in_w, 
                              out_c, 
                              out_w, 
                              out_h,
                              ksize_w,
                              ksize_h,
                              pad_w,
                              pad_h,
                              stride_w,
                              stride_h,
                              0,
                              0);
            err = cudaGetLastError();
            CNN_CHECK_ERROR(err != cudaSuccess, "conv3D_cuda_unopt", CNN_convert_cudart_error_code(err));
        }
        else
        {
            if (type == CNN_DT_FLT16)
            {
                conv_algo = CUDNN_CONVOLUTION_FWD_ALGO_IMPLICIT_PRECOMP_GEMM;           //ֻ�����ַ���֧��fp16
            }
            else
            {
                //��ȡʵ��3D�����ķ���
                cudnn_sts = cudnnGetConvolutionForwardAlgorithm(cudnn_handle,
                                                                src_tensor_desc,
                                                                filter_desc,
                                                                conv_desc,
                                                                dst_tensor_desc,
                                                                CUDNN_CONVOLUTION_FWD_SPECIFY_WORKSPACE_LIMIT,
                                                                max_workspace_size,
                                                                &conv_algo);
                CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolutionForwardAlgorithm failed", CNN_convert_cudnn_error_code(cudnn_sts));
            }

            //��ȡcudnn������ʱ��Ҫ�Ķ����ڴ��С
            cudnn_sts = cudnnGetConvolutionForwardWorkspaceSize(cudnn_handle, 
                                                            src_tensor_desc,
                                                            filter_desc,
                                                            conv_desc,
                                                            dst_tensor_desc,
                                                            conv_algo,
                                                             &workspace_size);
         
            CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnGetConvolutionForwardWorkspaceSize failed", CNN_convert_cudnn_error_code(cudnn_sts));
        
            //�ж�cudnn����Ҫ���ڴ��Ƿ��ʵ�ʷ���Ĵ�
            if (workspace_size > max_workspace_size)
            {
                printf("Error: cudnnConvolutionForward_Kernel requires more workspace (%g MB) than pre-allocated (%g MB) memory\n",
                        workspace_size / 1024.f / 1024.f, max_workspace_size / 1024.f / 1024.f);
                return HIK_VCA_LIB_KEY_PARAM_ERR;
            }

            //����cudnnʵ��3D�����ĺ���
            cudnn_sts = cudnnConvolutionForward(cudnn_handle, 
                                                &alpha,
                                                src_tensor_desc,
                                                in_data,
                                                filter_desc,
                                                weight_data,
                                                conv_desc,
                                                conv_algo,
                                                workspace,
                                                workspace_size,
                                                &beta,
                                                dst_tensor_desc,
                                                out_data);
            CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnConvolutionForward failed", CNN_convert_cudnn_error_code(cudnn_sts));
        }
    }

    if (!do_conv || conv_switch)
    {
        //�Ƿ���Ҫ��ƫ����
        if(1 == add_bias)
        {
            hr = CNN_CONV_relu_bias_cuda(out_data,
                                         out_data,
                                         bias_data,
                                         type,
                                         out_h * out_w,
                                         out_c,
                                         out_n,
                                         is_relu);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_relu_bias_cuda", hr);
        }
        else // �Ƿ���Ҫ��relu 
        {
            if (is_relu)
            {
                hr = CNN_CONV_relu_cuda(out_data,
                                        out_data,
                                        type,
                                        out_h * out_w,
                                        out_c,
                                        out_n);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_CONV_relu_cuda", hr);
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}
#endif


#ifdef ARCH_SUPPORT_FP16
/***************************************************************************************************
* ��  ��: ���ݾ�����Ϣ��ȡʵ�־����ķ�ʽ
* ��  ��:
*         batch_size             - I  ����batch_size
*         channel                - I  ����channel
*         height                 - I  ����height
*         width                  - I  ����width
*         stride_h               - I  height stride
*         stride_w               - I  width stride
*         conv_h                 - I  ������height
*         conv_w                 - I  ������width
*         conv_num               - I  �����˸���
* ����ֵ: ����ʵ�ַ�ʽ
***************************************************************************************************/
static HIK3DCONV_LIB_KINDS CNN_CONV_get_conv_kind(int       batch_size,
                                                  int       channel,
                                                  int       height,
                                                  int       width,
                                                  int       stride_h,
                                                  int       stride_w,
                                                  int       conv_h,
                                                  int       conv_w,
                                                  int       conv_num)
{
    if (conv_num % 128 == 0)
    {
        return HIK3DCONV_LIB_CUASM_ALGIN128;
    }

    if (conv_num % 64 == 0) 
    {
        return HIK3DCONV_LIB_CUASM_ALGIN64;
    }

    if ((128 - conv_num % 128) <= (64 - conv_num % 64))
    {
        return HIK3DCONV_LIB_CUASM_ALGIN128;
    }
    else
    {
        return HIK3DCONV_LIB_CUASM_ALGIN64;
    }
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��:
*         config                 - O  �������ò����ṹ��
*         in_n                   - I  ����n
*         in_c                   - I  ����c
*         in_h                   - I  ����h
*         in_w                   - I  ����w
*         ksize_h                - I  ������height
*         ksize_w                - I  ������width
*         stride_h               - I  ��������h����
*         stride_w               - I  ��������w����
*         in_pad_h               - I  ����height pad 
*         in_pad_w               - I  ����width pad
*         out_pad_h              - I  ���height pad
*         out_pad_w              - I  ���width pad
*         do_bias                - I  �Ƿ��ƫ��
*         do_relu                - I  �Ƿ���relu
* ����ֵ: ��
***************************************************************************************************/
static void CNN_CONV_set_3dconv_config(HIK3DCONV_LIB_CONFIG  *config,
                                       int                   in_n, 
                                       int                   in_c, 
                                       int                   in_h, 
                                       int                   in_w, 
                                       int                   kernel_num, 
                                       int                   kernel_h, 
                                       int                   kernel_w, 
                                       int                   stride_h, 
                                       int                   stride_w, 
                                       int                   in_pad_h, 
                                       int                   in_pad_w,
                                       int                   out_pad_h,
                                       int                   out_pad_w,
                                       int                   zero_pad_h,
                                       int                   zero_pad_w,
                                       int                   do_bias,
                                       int                   do_relu)
{
    HIK3DCONV_LIB_KINDS   conv_kind;

    conv_kind = CNN_CONV_get_conv_kind(in_n, 
                                       in_c,
                                       in_h,
                                       in_w,
                                       stride_h,
                                       stride_w,
                                       kernel_h,
                                       kernel_w,
                                       kernel_num);

    config->i_dim.n = in_n;
    config->i_dim.c = in_c;
    config->i_dim.h = in_h;
    config->i_dim.w = in_w;
         
    config->k_dim.n = kernel_num;
    config->k_dim.c = in_c;
    config->k_dim.h = kernel_h;
    config->k_dim.w = kernel_w;
        
    config->stride_h = stride_h;
    config->stride_w = stride_w;
         
    config->i_pad_h    = in_pad_h;
    config->i_pad_w    = in_pad_w;
    config->o_pad_h    = out_pad_h;
    config->o_pad_w    = out_pad_w;
    config->zero_pad_h = zero_pad_h;
    config->zero_pad_w = zero_pad_w;

    config->is_bias = do_bias;
    config->is_relu = do_relu;
         
    config->kind    = conv_kind;
}
#endif



/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�(CUDA�汾)
* ��  ��:
*         conv_layer             -I   layer
*         ld                     -I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONV_Forward_Cuda_Opt(CONVOLUTION_LAYER       *conv_layer,
                                  LAYER_DATA              *ld)
{
    HRESULT              hr;
    float_t             *input_blob_data;
    float_t             *output_blob_data;

    CNN_BLOB            *in_blob            = ld->input_blobs[0];
    CNN_BLOB            *out_blob           = &ld->output_blobs[0];
    CNN_BLOB            *weight_blob        = &conv_layer->model->param_blobs[0];
    CNN_BLOB            *bias_blob          = &conv_layer->model->param_blobs[1];

    void                *in_data            = in_blob->data_gpu;
    void                *weight_data        = weight_blob->data_gpu;
    void                *output_data        = out_blob->data_gpu;
    void                *bias_data          = bias_blob->data_gpu;

    int                  in_n;
    int                  in_c;
    int                  in_h;
    int                  in_w;
                         
    int                  out_n;
    int                  out_c;
    int                  out_h;
    int                  out_w;

    BLOB_DATA_TYPE       type;
    BLOB_DATA_FORMAT     format             = in_blob->format;
    cudaError_t          err;
    float               *pmem;
    int                  i;

    int                  bias               = conv_layer->model->bias;
    int                  pad_zero_h;
    int                  pad_zero_w;
    void               **data_ptr;
    int                  bytes;
    size_t               dst_pitch, src_pitch, width;

#ifdef ARCH_SUPPORT_FP16
    HIK3DCONV_LIB_CONFIG    config;
    HIK3DCONV_LIB_IN_BUF    in_buf;
    HIK3DCONV_LIB_OUT_BUF   out_buf;
#endif

    type                                    = ld->input_blobs[0]->type;
    conv_layer->conv_method                 = CNN_CONV_METHOD_CUDNN;                   

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "not support", CNN_CUDA_NOT_IMPLEMENT);

    bytes  = (type == CNN_DT_FLT16) ? sizeof(short) : sizeof(float);
    bytes *= (format == CNN_FORMAT_NCHW_ZIP) ? 2 : 1;

    in_n  = in_blob->shape[0];
    in_c  = in_blob->shape[1];
    in_h  = in_blob->shape[2];
    in_w  = in_blob->shape[3];

    out_n = out_blob->shape[0];
    out_c = out_blob->shape[1];
    out_h = out_blob->shape[2];
    out_w = out_blob->shape[3];

    if (type == CNN_DT_FLT16)
    {
        in_data     = in_blob->data_gpu_fp16;
        weight_data = weight_blob->data_gpu_fp16;
        output_data = out_blob->data_gpu_fp16;
        bias_data   = bias_blob->data_gpu_fp16;
    }

    if (format == CNN_FORMAT_NCHW)
    {
#ifdef CNN_CONVERT_ASYMCONV2FP32
#ifdef ARCH_SUPPORT_FP16
        if (CNN_CONV_convert2fp32(conv_layer->model))
        {
            in_data     = in_blob->data_gpu;
            weight_data = weight_blob->data_gpu;
            output_data = out_blob->data_gpu;
            bias_data   = bias_blob->data_gpu;

            err = cnn_blob_half2float(weight_blob);
            CNN_CHECK_ERROR(err != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);

            err = cnn_blob_half2float(bias_blob);
            CNN_CHECK_ERROR(err != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);

            in_data = conv_layer->input_gpu;
            output_data = conv_layer->output_gpu;

            err = cnn_half2float(in_blob->data_gpu_fp16, in_data, CNN_BLOB_GetDataNum(in_blob));
            CNN_CHECK_ERROR(err != HIK_VCA_LIB_S_OK, "cnn_half2float", hr);

            type = CNN_DT_FLT32;
        }
#endif  // ARCH_SUPPORT_FP16
#endif  // CNN_CONVERT_ASYMCONV2FP32
    }

    switch (conv_layer->conv_method)
    {
    case CNN_CONV_METHOD_CUDNN:
        //printf("conv pad: %d %d\n", out_blob->pad.pad_h, out_blob->pad.pad_w);

        if (format == CNN_FORMAT_NCHW)
        {
             hr = cnn_conv_forward_cudnn(&ld->cuda_handle->cudnn_handle, 
                                         in_data,
                                         weight_data, 
                                         bias_data,
                                         output_data,
                                         type,
                                         in_n,
                                         in_c,
                                         in_h,
                                         in_w,
                                         out_n,
                                         out_c,
                                         out_h,
                                         out_w,
                                         conv_layer->model->ker_h,
                                         conv_layer->model->ker_w,
                                         conv_layer->model->stride_h,
                                         conv_layer->model->stride_w,
                                         conv_layer->model->pad_h,
                                         conv_layer->model->pad_w,
                                         bias,
                                         conv_layer->is_relu);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_conv_forward_cudnn failed", hr);
        }
        else if (format == CNN_FORMAT_NCHW_ZIP)
        {
            pad_zero_h = (conv_layer->model->pad_h == 0) ? 0 : conv_layer->model->ker_h / 2;
            pad_zero_w = (conv_layer->model->pad_w == 0) ? 0 : conv_layer->model->ker_w / 2;

            if ((conv_layer->model->pad_h == 1) &&
                conv_layer->model->ker_h == 1)
            {
                pad_zero_h = 1;
            }
            if ((conv_layer->model->pad_w == 1) &&
                conv_layer->model->ker_w == 1)
            {
                pad_zero_w = 1;
            }
            
#ifdef ARCH_SUPPORT_FP16
/*
            printf("%d %d %d %d %d %d %d %d %d pad: %d %d %d %d %d %d\n", 
                   in_n, 
                   in_c, 
                   in_h, 
                   in_w, 
                   out_c, 
                   conv_layer->model->ker_h,
                   conv_layer->model->ker_w,
                   conv_layer->model->stride_h,
                   conv_layer->model->stride_w,
                   in_blob->pad.pad_h,
                   in_blob->pad.pad_w,
                   out_blob->pad.pad_h,
                   out_blob->pad.pad_w,
                   pad_zero_h,
                   pad_zero_w
                   );
*/
            CNN_CONV_set_3dconv_config(&config, 
                                       in_n,
                                       in_c,
                                       in_h,
                                       in_w,
                                       out_c,
                                       conv_layer->model->ker_h,
                                       conv_layer->model->ker_w,
                                       conv_layer->model->stride_h,
                                       conv_layer->model->stride_w,
                                       in_blob->pad.pad_h,
                                       in_blob->pad.pad_w,
                                       out_blob->pad.pad_h,
                                       out_blob->pad.pad_w,
                                       pad_zero_h,
                                       pad_zero_w,
                                       conv_layer->model->bias,
                                       conv_layer->is_relu);

            hr = HIK3DCONV_LIB_SetConfig(conv_layer->conv3d_handle,
                                         &config,
                                         sizeof(HIK3DCONV_LIB_CONFIG));
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "HIK3DCONV_LIB_SetConfig", hr);

            in_buf.i_data   = in_data;
            in_buf.k_data   = weight_data;
            in_buf.b_data   = bias_data;
            out_buf.o_data  = output_data;

            hr = HIK3DCONV_LIB_Process(conv_layer->conv3d_handle, 
                                       &in_buf, 
                                       sizeof(HIK3DCONV_LIB_IN_BUF),
                                       &out_buf,
                                       sizeof(HIK3DCONV_LIB_OUT_BUF));
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "HIK3DCONV_LIB_Process", hr);

#else
            CNN_CHECK_ERROR(1, "not implement", CNN_CUDA_NOT_IMPLEMENT);
#endif
        }
        break;

    case CNN_CONV_METHOD_CUBLAS:
        CNN_CHECK_ERROR(1, "not support CNN_CONV_METHOD_CUBLAS", CNN_CUDA_NOT_IMPLEMENT);

    case CNN_CONV_METHOD_CUSTOMIZED:
        CNN_CHECK_ERROR(1, "not support CNN_CONV_METHOD_CUSTOMIZED", CNN_CUDA_NOT_IMPLEMENT);

    default:
        CNN_CHECK_ERROR(1, "not support method", CNN_CUDA_NOT_IMPLEMENT);
    }

    if (format == CNN_FORMAT_NCHW)
    {
#ifdef CNN_CONVERT_ASYMCONV2FP32
#ifdef ARCH_SUPPORT_FP16
        if (CNN_CONV_convert2fp32(conv_layer->model))
        {
            err = cnn_float2half(output_data, out_blob->data_gpu_fp16, CNN_BLOB_GetDataNum(out_blob));
            CNN_CHECK_ERROR(err != HIK_VCA_LIB_S_OK, "cnn_float2half", hr);
            type = CNN_DT_FLT16;
        }
#endif
#endif
    }

    return HIK_VCA_LIB_S_OK;
}


#endif  //CNN_CUDA_OPT
