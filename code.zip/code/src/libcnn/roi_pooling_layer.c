/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: roi_pooling_layer.c
* �ļ���ʶ: ROI_POOLING_LAYER_C
* ժ    Ҫ: roi_pooling��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-16
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#include "roi_pooling_layer_cuda.h"
#include "cnn_half.h"
#endif // CNN_CUDA_OPT
#include "roi_pooling_layer.h"

//#define CNN_ROIPOOLING_NVOPT

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: pooling_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_compute_in_out_shape(ROI_POOLING_LAYER *roi_pooling_layer,
	                                     LAYER_DATA    *ld)
{
	int inp_c, inp_n;
	int out_h, out_w, out_c, out_n;

    HKA_CHECK_PTR(roi_pooling_layer);
    HKA_CHECK_PTR(ld);

	HKA_CHECK_ERROR(ld->input_blobs_num != 2, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(ld->input_blobs[1]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

	inp_c = ld->input_blobs[0]->shape[1];    //����ͨ��
	inp_n = ld->input_blobs[1]->shape[0];    //����roi����

	//���������
    out_h = roi_pooling_layer->model->pooled_h;
	out_w = roi_pooling_layer->model->pooled_w;
	out_c = inp_c;
	out_n = inp_n;

	
	ld->output_blobs[0].ndims     = 4;
	ld->output_blobs[0].type      = cnn_get_blob_type();
	ld->output_blobs[0].shape[3]  = out_w;
	ld->output_blobs[0].shape[2]  = out_h;
	ld->output_blobs[0].shape[1]  = out_c;
	ld->output_blobs[0].shape[0]  = out_n;
#ifdef CNN_ROIPOOLING_CUDA_OPT    
    ld->output_blobs[1].ndims     = 4;
    ld->output_blobs[1].type      = cnn_get_blob_type();
    ld->output_blobs[1].shape[3]  = out_w;
    ld->output_blobs[1].shape[2]  = out_h;
    ld->output_blobs[1].shape[1]  = 2;
    ld->output_blobs[1].shape[0]  = out_n;
    ld->output_blobs[1].pad.pad_h = 0;
    ld->output_blobs[1].pad.pad_w = 0;
                                  
    ld->output_blobs[2].ndims     = 4;
    ld->output_blobs[2].type      = cnn_get_blob_type();;
    ld->output_blobs[2].shape[3]  = out_w;
    ld->output_blobs[2].shape[2]  = out_h;
    ld->output_blobs[2].shape[1]  = out_c;
    ld->output_blobs[2].shape[0]  = out_n;
    ld->output_blobs[2].pad.pad_h = 0;
    ld->output_blobs[2].pad.pad_w = 0;
                                  
    ld->output_blobs[3].ndims     = 4;
    ld->output_blobs[3].type      = cnn_get_blob_type();;
    ld->output_blobs[3].shape[3]  = ld->input_blobs[0]->shape[3];
    ld->output_blobs[3].shape[2]  = ld->input_blobs[0]->shape[2];
    ld->output_blobs[3].shape[1]  = ld->input_blobs[0]->shape[1];
    ld->output_blobs[3].shape[0]  = ld->input_blobs[0]->shape[0];
    ld->output_blobs[3].pad.pad_h = 0;
    ld->output_blobs[3].pad.pad_w = 0;
#endif

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_Reshape(void       *handle,
                            LAYER_DATA *ld)
{
    if (ld->input_blobs[1]->shape[2] != 1 || ld->input_blobs[1]->shape[3] != 1 || ld->input_blobs[1]->shape[1] != 5)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    return CNN_ROIPOOL_compute_in_out_shape((ROI_POOLING_LAYER *)handle, ld);
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         roi_pooling_layer      - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_init_model(const char		*hyperparams,
						  const char		*param_blobs,
                          LAYER_MODEL		*ld,
						  ROI_POOLING_MODEL *roi_pooling_model)
{
	int r;
	const char  pooled_w[] = "pooled_w";
	const char  pooled_h[] = "pooled_h";
	const char  spatial_scale[] = "spatial_scale";
	const char *ptr;
	
    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(roi_pooling_model);

	ptr = strstr(hyperparams, pooled_w);
	HKA_CHECK_PTR(ptr);
	r   = sscanf(ptr + strlen(pooled_w) + 1, "%d", &roi_pooling_model->pooled_w);
	HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

    if (roi_pooling_model->pooled_w < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

	ptr = strstr(hyperparams, pooled_h);
	HKA_CHECK_PTR(ptr);
	r   = sscanf(ptr + strlen(pooled_h) + 1, "%d", &roi_pooling_model->pooled_h);
	HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

    if (roi_pooling_model->pooled_h < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

	ptr = strstr(hyperparams, spatial_scale);
	HKA_CHECK_PTR(ptr);
	r   = sscanf(ptr + strlen(spatial_scale) + 1, "%f", &roi_pooling_model->spatial_scale);
	HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);

    if (roi_pooling_model->spatial_scale < 0.f || roi_pooling_model->spatial_scale > 1.f)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_Create(LAYER_DATA	*ld,
							CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
							void	    **handle)
{
    int                     hr;
    ROI_POOLING_LAYER       *roi_pooling_layer;

    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];
    CNN_BUF                 *cpu_data_buf = &mem_buf[1];
    CNN_BUF                 *gpu_data_buf = &mem_buf[2];

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#else
    cpu_data_buf = NULL;
#endif

    roi_pooling_layer = (ROI_POOLING_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                             CNN_SIZE_ALIGN(sizeof(ROI_POOLING_LAYER)),
                                             CNN_MEM_ALIGN_SIZE,
                                             1);
    HKA_CHECK_MEMOUT(roi_pooling_layer);

    roi_pooling_layer->model = ld->layer_model->model_handle;

    hr = CNN_ROIPOOL_Reshape(roi_pooling_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

#ifdef CNN_ROIPOOLING_CUDA_OPT
    hr = cnn_alloc_blob_buffer(&ld->output_blobs[1],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    hr = cnn_alloc_blob_buffer(&ld->output_blobs[2],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    hr = cnn_alloc_blob_buffer(&ld->output_blobs[3],
                               cpu_data_buf,
                               gpu_data_buf,
                               CNN_MEM_ALIGN_SIZE,
                               CNN_CUDA_MEM_ALIGNMENT,
                               NULL);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);
#endif

    *handle = roi_pooling_layer;
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_GetMemsize(LAYER_DATA *ld,
							   VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
	int				    hr;
	int				    blob_data_size;
	ROI_POOLING_LAYER   roi_pooling_layer;

    VCA_MEM_TAB_V2         *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2         *cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2         *gpu_data_tab   = &mem_tab[2];

    HKA_CHECK_PTR(ld);

#ifndef CNN_CUDA_OPT
    gpu_data_tab                        = NULL; 
#else
    cpu_data_tab                        = NULL; 
#endif

	memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);


    roi_pooling_layer.model = ld->layer_model->model_handle;
    
    hr = CNN_ROIPOOL_Reshape(&roi_pooling_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    CNN_BASE_SetMemTab(cpu_handle_tab, 
                       CNN_SIZE_ALIGN(sizeof(ROI_POOLING_LAYER)), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);
	
#ifndef CNN_ROIPOOLING_CUDA_OPT
    blob_data_size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0]));
#else
    blob_data_size = CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])) +
                     CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[1])) +
                     CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[2])) +
                     CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[3]));
#endif

    CNN_BASE_SetMemTab(gpu_data_tab, 
                       blob_data_size, 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_GPU);

	return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_ROIPOOL_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    int                     hr;
    ROI_POOLING_MODEL       *roi_pooling_model;

    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

    roi_pooling_model = (ROI_POOLING_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(ROI_POOLING_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(roi_pooling_model);

    hr = CNN_ROIPOOL_init_model(hyperparams, param_blobs, ld, roi_pooling_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    *handle = roi_pooling_model;
    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_ROIPOOL_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    int				hr;
    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];
    
    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(ROI_POOLING_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: pooling
* ��  ��: input_data             - I   ��������ͼblob
*         input_list             - I   ����roi�б�
*         output                 - I/O ���blob
*         pooling_layer          - I   �ò�ľ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_ROIPOOL_pooling(CNN_BLOB          *input_data,
                         CNN_BLOB          *input_list,
                         CNN_BLOB          *output,
                         ROI_POOLING_LAYER *pooling_layer)
{
    int n, h, w;
    int num_rois;                         // roi������

    float *list_data;
    float *batch_data;

    float *top_data;
    int    roi_batch_ind;
    int    roi_start_w;
    int    roi_start_h;
    int    roi_end_w;
    int    roi_end_h;
    int    roi_height;
    int    roi_width;

    float bin_size_h;
    float bin_size_w;

    int hstart;
    int wstart;
    int hend;
    int wend;

    int is_empty;
    int pool_index;
    int index;

    int c, ph, pw;

    float pooled_ht = (float)pooling_layer->model->pooled_h;
    float pooled_wt = (float)pooling_layer->model->pooled_w;

    // input_data: ����ͼ����
    // input_list: nms���ԭͼroi���� c = [batch_index x1 y1 x2 y2]  n,c,w,h�� n������ʾroi����
    num_rois         = input_list->shape[0]; // roi������
    output->shape[0] = input_list->shape[0]; // �����ͼ����������Ϊ����ͼ������
    // batch_size = input_data->shape[0];   //����ͼ��������
    // list_bottom_data  = input_list->data;
    // bottom_data = input_data->data;
    top_data = (float *)(output->data);
    // ����ÿһ��roi
    list_data = (float *)CNN_BLOB_GetPtr(input_list, 0, 0, 0, 0);

    for (n = 0; n < num_rois; n++)
    {
        // roi�ĳ�ʼ��ַ����ʼ�����ߣ���β������
        roi_batch_ind = (int)list_data[0];
        roi_start_w   = (int)floorf(list_data[1] * pooling_layer->model->spatial_scale + 0.5);
        roi_start_h   = (int)floorf(list_data[2] * pooling_layer->model->spatial_scale + 0.5);
        roi_end_w     = (int)floorf(list_data[3] * pooling_layer->model->spatial_scale + 0.5);
        roi_end_h     = (int)floorf(list_data[4] * pooling_layer->model->spatial_scale + 0.5);

        // ����roi�ĸߣ���
        roi_height = HKA_MAX(roi_end_h - roi_start_h + 1, 1);
        roi_width  = HKA_MAX(roi_end_w - roi_start_w + 1, 1);

        // ����roi��pooled�ߴ�ĸ߿�����ȣ�����λ��Ӧ��batch_data��ַ
        bin_size_h = (float)roi_height / pooled_ht;
        bin_size_w = (float)roi_width / pooled_wt;
        batch_data = (float *)CNN_BLOB_GetPtr(input_data, roi_batch_ind, 0, 0, 0);

        // channel--height--width˳�����1��roipooling
        for (c = 0; c < input_data->shape[1]; ++c)
        {
            for (ph = 0; ph < pooled_ht; ++ph)
            {
                for (pw = 0; pw < pooled_wt; ++pw)
                {
                    // Compute pooling region for this output unit:
                    //  start (included) = floor(ph * roi_height / pooled_height_)
                    //  end (excluded) = ceil((ph + 1) * roi_height / pooled_height_)
                    hstart = (int)floor(ph * bin_size_h);
                    wstart = (int)floor(pw * bin_size_w);
                    hend   = (int)ceil((ph + 1) * bin_size_h);
                    wend   = (int)ceil((pw + 1) * bin_size_w);

                    hstart = HKA_MIN(HKA_MAX(hstart + roi_start_h, 0), input_data->shape[2]);  // shapeΪn,c,h,w
                    hend   = HKA_MIN(HKA_MAX(hend + roi_start_h, 0), input_data->shape[2]);
                    wstart = HKA_MIN(HKA_MAX(wstart + roi_start_w, 0), input_data->shape[3]);
                    wend   = HKA_MIN(HKA_MAX(wend + roi_start_w, 0), input_data->shape[3]);

                    is_empty = (hend <= hstart) || (wend <= wstart);

                    pool_index = ph * pooling_layer->model->pooled_w + pw;
                    // printf("c = %d,ph = %d, pw = %d", c, ph, pw);
                    top_data[pool_index] = -FLT_MAX;
                    if (is_empty)
                    {
                        top_data[pool_index] = 0;
                    }

                    for (h = hstart; h < hend; h++)
                    {
                        for (w = wstart; w < wend; w++)
                        {
                            index = h * input_data->shape[3] + w;
                            if (batch_data[index] > top_data[pool_index])
                            {
                                top_data[pool_index] = batch_data[index];
                            }
                        }
                    }
                }
            }
            // Increment all data pointers by one channel
            batch_data = (float *)CNN_BLOB_GetPtr(input_data, roi_batch_ind, c + 1, 0, 0);
            top_data   = (float *)CNN_BLOB_GetPtr(output, n, c + 1, 0, 0);
        }

        top_data = (float *)CNN_BLOB_GetPtr(output, n + 1, 0, 0, 0);
        // Increment ROI data pointer
        list_data = (float *)CNN_BLOB_GetPtr(input_list, n + 1, 0, 0, 0);
    }
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_Forward(void       *handle,
						    LAYER_DATA *ld)
{
	ROI_POOLING_LAYER *roi_pooling_layer = (ROI_POOLING_LAYER *)handle;
	CNN_ROIPOOL_pooling(ld->input_blobs[0], ld->input_blobs[1], &ld->output_blobs[0], roi_pooling_layer);
    return HIK_VCA_LIB_S_OK;
}


#ifdef CNN_CUDA_OPT
/***************************************************************************************************
* ��  ��: �õ�ͬһ������ͼ���roi����
* ��  ��:
*         roi_list_data_cur      - I ��ǰroi_listָ��
*         roi_list_data_end      - I roi_listĩβ
* ����ֵ: ������
***************************************************************************************************/
static HRESULT CNN_ROIPOOL_get_roi_num(float     *roi_list_data_cur,
                                       float     *roi_list_data_end)
{
    int         roi_num        = 0;
    float      prev_value     = *roi_list_data_cur;
    
    while (roi_list_data_cur < roi_list_data_end)
    {
        //printf("%f\n", *roi_list_data_cur);
        if (*roi_list_data_cur == prev_value)
        {
            prev_value = *roi_list_data_cur;
            roi_num++;
            roi_list_data_cur += 5;
        }
        else
        {
            break;
        }
    }

    return roi_num;
}

extern HRESULT CNN_ROI_Forward_NV_Opt(ROI_POOLING_LAYER       *roi_pooling_layer,
                                          LAYER_DATA              *ld);

/***************************************************************************************************
* ��  ��: roi pooling��ǰ�򴫲�(CUDA��)
* ��  ��: 
*         roi_pooling_layer      - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_ROIPOOL_Forward_Cuda_Opt(ROI_POOLING_LAYER       *roi_pooling_layer,
						             LAYER_DATA              *ld)
{
#ifdef CNN_ROIPOOLING_NVOPT
    HRESULT hr;
    hr = CNN_ROI_Forward_NV_Opt(roi_pooling_layer, ld);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_ROI_Forward_NV_Opt", hr);
#else
    HRESULT                 hr;
    int                     n;

    CNN_BLOB                *in_blob            = ld->input_blobs[0];
    CNN_BLOB                *out_blob           = &ld->output_blobs[0];
    CNN_BLOB                *roi_list_blob      = ld->input_blobs[1];

#ifdef CNN_ROIPOOLING_CUDA_OPT
    CNN_BLOB                *roi_list_loc       = &ld->output_blobs[1];
    CNN_BLOB                *out_blob_tmp       = &ld->output_blobs[2];
    CNN_BLOB                *in_blob_tmp        = &ld->output_blobs[3];
    void                    *output_data_tmp    = out_blob_tmp->data_gpu;
    void                    *in_data_tmp        = in_blob_tmp->data_gpu;
    void                    *roi_location       = roi_list_loc->data_gpu;
#endif
    void                    *in_data            = in_blob->data_gpu;
    void                    *output_data        = out_blob->data_gpu;
    float                   *roi_list_data      = roi_list_blob->data_gpu;

    float                   *roi_list_data_cur  = roi_list_blob->data;
    float                   *roi_list_data_end  = (int *)roi_list_blob->data + CNN_BLOB_GetDataNum(roi_list_blob);

    BLOB_DATA_TYPE          type;
    cudaError_t             err;
    BLOB_DATA_FORMAT        format = in_blob->format;

    int                     in_elt_num;
    int                     out_elt_num;
    int                     roi_num;
	int						roi_num1;
	int						roi_num2;

    //OPT_PROFILE_TIME_BY_EVENT_START(0);

    out_blob->shape[0]      = roi_list_blob->shape[0];

    type                    = in_blob->type;

    //����proposal���п���
    err = cudaMemcpy(roi_list_blob->data_gpu,
                     roi_list_blob->data, 
                     sizeof(float) * CNN_BLOB_GetDataNum(roi_list_blob), 
                     cudaMemcpyHostToDevice);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    if (type == CNN_DT_FLT16)
    {
        in_data         = in_blob->data_gpu_fp16;
        output_data     = out_blob->data_gpu_fp16;

#ifdef CNN_ROIPOOLING_CUDA_OPT
        output_data_tmp = out_blob_tmp->data_gpu_fp16;
        in_data_tmp     = in_blob_tmp->data_gpu_fp16;
        roi_location    = roi_list_loc->data_gpu_fp16;
#endif
    }

    if (format == CNN_FORMAT_NCHW_ZIP)
    {
        int pad_in = in_blob->pad.pad_w;
        int pad_out = out_blob->pad.pad_w;
        in_elt_num = in_blob->shape[1] * (in_blob->shape[2]+pad_in*2) * (in_blob->shape[3]+pad_in*2);
        out_elt_num = out_blob->shape[1] * (out_blob->shape[2]+pad_out*2) * (out_blob->shape[3]+pad_out*2);
        for (n = 0; n < in_blob->shape[0] / 2; n++) /* ÿ�δ���2֡ */
        {
            roi_num1 = CNN_ROIPOOL_get_roi_num(roi_list_data_cur, roi_list_data_end);
            roi_list_data_cur = roi_list_data_cur + roi_num1 * 5;
            roi_num2 = CNN_ROIPOOL_get_roi_num(roi_list_data_cur, roi_list_data_end);
            roi_list_data_cur = roi_list_data_cur + roi_num2 * 5;

            hr = cnn_roi_max_pooling_forward_cuda_zip(output_data,
                                                 output_data_tmp,
                                                 in_data,
                                                 in_data_tmp,
                                                 in_blob->shape[2],
                                                 in_blob->shape[3],
                                                 in_blob->shape[1],
                                                 roi_pooling_layer->model->spatial_scale,
                                                 roi_list_data,
                                                 roi_location,
                                                 roi_num1,
                                                 roi_num2,
                                                 roi_pooling_layer->model->pooled_h,
                                                 roi_pooling_layer->model->pooled_w,
                                                 CNN_DT_FLT16,
                                                 pad_in,
                                                 pad_out);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_roi_max_pooling_forward_cuda_zip", hr);
    
            roi_list_data = roi_list_data + (roi_num1 + roi_num2) * 5;
            output_data = (char *)output_data + (roi_num1 + roi_num2) * out_elt_num * sizeof(cnn_half);
            in_data = (char *)in_data + 2 * in_elt_num * sizeof(cnn_half);
        }
    }
    else
    {
        in_elt_num      = in_blob->shape[1] * in_blob->shape[2] * in_blob->shape[3];
        out_elt_num     = out_blob->shape[1] * out_blob->shape[2] * out_blob->shape[3];
    
        for (n = 0; n < in_blob->shape[0]; n++)
        {
            roi_num = CNN_ROIPOOL_get_roi_num(roi_list_data_cur, roi_list_data_end);
    
            if (roi_num == 0)
            {
                continue;
            }
    
    #ifndef CNN_ROIPOOLING_CUDA_OPT
            hr = cnn_roi_max_pooling_forward_cuda(output_data,
                                                  in_data, 
                                                  in_blob->shape[2],
                                                  in_blob->shape[3],
                                                  in_blob->shape[1],
                                                  roi_pooling_layer->model->spatial_scale,
                                                  roi_list_data,
                                                  roi_num,
                                                  roi_pooling_layer->model->pooled_h,
                                                  roi_pooling_layer->model->pooled_w,
                                                  type);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_roi_max_pooling_forward_cuda", hr);
    #else
            if ((in_blob->shape[2] <= roi_pooling_layer->model->pooled_h) || 
                (in_blob->shape[3] <= roi_pooling_layer->model->pooled_w))
            {
                hr = cnn_roi_max_pooling_forward_cuda(output_data,
                                                      in_data, 
                                                      in_blob->shape[2],
                                                      in_blob->shape[3],
                                                      in_blob->shape[1],
                                                      roi_pooling_layer->model->spatial_scale,
                                                      roi_list_data,
                                                      roi_num,
                                                      roi_pooling_layer->model->pooled_h,
                                                      roi_pooling_layer->model->pooled_w,
                                                      type);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_roi_max_pooling_forward_cuda", hr);
            }
            else
            {
                if ((roi_pooling_layer->model->pooled_h >= in_blob->shape[2]) || 
                    (roi_pooling_layer->model->pooled_w >= in_blob->shape[3]))
                {
                    hr = cnn_roi_max_pooling_forward_cuda(output_data,
                                                          in_data, 
                                                          in_blob->shape[2],
                                                          in_blob->shape[3],
                                                          in_blob->shape[1],
                                                          roi_pooling_layer->model->spatial_scale,
                                                          roi_list_data,
                                                          roi_num,
                                                          roi_pooling_layer->model->pooled_h,
                                                          roi_pooling_layer->model->pooled_w,
                                                          type);
                    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_roi_max_pooling_forward_cuda", hr);
                }
                else
                {
                    hr = cnn_roi_max_pooling_forward_cuda_faster(output_data,
                                                                 output_data_tmp,
                                                                 in_data,
                                                                 in_data_tmp,
                                                                 in_blob->shape[2],
                                                                 in_blob->shape[3],
                                                                 in_blob->shape[1],
                                                                 roi_pooling_layer->model->spatial_scale,
                                                                 roi_list_data,
                                                                 roi_location,
                                                                 roi_num,
                                                                 roi_pooling_layer->model->pooled_h,
                                                                 roi_pooling_layer->model->pooled_w,
                                                                 type);
                    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_roi_max_pooling_forward_cuda_faster", hr);
                }
            }
    #endif
            output_data        = (char *)output_data   + roi_num * out_elt_num * ((type == CNN_DT_FLT32) ? sizeof(float) : sizeof(cnn_half));
            in_data            = (char *)in_data       + in_elt_num  *  ((type == CNN_DT_FLT32) ? sizeof(float) : sizeof(cnn_half));
            roi_list_data      = roi_list_data         + roi_num * 5;
            roi_list_data_cur  = roi_list_data_cur     + roi_num * 5;
        }
    }

    //OPT_PROFILE_TIME_BY_EVENT_STOP(0, "roipooling", 1, 1);

    return HIK_VCA_LIB_S_OK;
#endif
}


#endif
