/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: proposal_sdp_layer.c
* �ļ���ʶ: PROPOSAL_SDP_LAYER_C
* ժ    Ҫ: PROPOSAL��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ���ܕ�
* ��    ��: 2016-02-17
* ��    ע:
*
* �ļ�����: proposal_sdp_layer.c
* �ļ���ʶ: PROPOSAL_SDP_LAYER_C
* ժ    Ҫ: PROPOSALSDP��ĺ���ʵ��
*
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif // CNN_USED_AS_FRCNN
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif  // CNN_CUDA_OPT
#include <float.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include "proposal_sdp_layer.h"
#include "proposal_layer_cuda.h"
#include "_ipgs_sort.h"

/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: proposal_layer          - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_compute_in_out_shape(PROPOSAL_SDP_LAYER *proposal_sdp_layer,
                                              LAYER_DATA         *ld)
{
    int n;                             // batch num

    HKA_CHECK_PTR(proposal_sdp_layer);
    HKA_CHECK_PTR(ld);

    HKA_CHECK_ERROR(ld->input_blobs_num != 3, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[1]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->input_blobs[2]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(ld->output_blobs_num != 2, HIK_VCA_CNN_MODEL_ERROR);

    n = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].ndims    = 4;
    ld->output_blobs[0].type     = CNN_DT_FLT32;
    ld->output_blobs[0].shape[3] = 1;
    ld->output_blobs[0].shape[2] = 1;
    ld->output_blobs[0].shape[1] = 5;                                            // index x1 y1 x2 y2
    ld->output_blobs[0].shape[0] = n * proposal_sdp_layer->model->post_nms_topN; // n images

    ld->output_blobs[1].ndims    = 4;
    ld->output_blobs[1].type     = CNN_DT_FLT32;
    ld->output_blobs[1].shape[3] = 1;
    ld->output_blobs[1].shape[2] = 1;
    ld->output_blobs[1].shape[1] = 5;                                            // index x1 y1 x2 y2
    ld->output_blobs[1].shape[0] = n * proposal_sdp_layer->model->post_nms_topN; // n images
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_Reshape(void       *handle,
                                 LAYER_DATA *ld)
{
    int     i;
    HRESULT hr;

    hr = CNN_PROPOSAL_SDP_compute_in_out_shape((PROPOSAL_SDP_LAYER *)handle, ld);
    CNN_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, "CNN_PROPOSAL_SDP_compute_in_out_shape error", hr);

    for (i = 0; i < ld->input_blobs[0]->ndims; i++)
    {
        if (ld->input_blobs[0]->shape[i] != ld->input_blobs[1]->shape[i])
        {
            if (i == 1)
            {
                if (ld->input_blobs[0]->shape[i] * 2 != ld->input_blobs[1]->shape[i])
                {
                    return HIK_VCA_CNN_MODEL_ERROR;
                }
            }
            else
            {
                return HIK_VCA_CNN_MODEL_ERROR;
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_init_model(const char         *hyperparams,
                                    const char         *param_blobs,
                                    LAYER_MODEL        *ld,
                                    PROPOSAL_SDP_MODEL *proposal_sdp_model)
{
    int r, i;

    const char feat_stride[]   = "stride";
    const char pre_nms_topN[]  = "pre_nms_top_n";
    const char post_nms_topN[] = "post_nms_top_n";

    const char nms_thresh[]      = "nms_thresh";
    const char anchor_scales[]   = "anchor_scales";
    const char roi_split_param[] = "roi_split_param";

    const char *ptr = NULL;
    int         param_num;

    HKA_CHECK_PTR(proposal_sdp_model);

    proposal_sdp_model->feat_stride    = 16;
    proposal_sdp_model->pre_nms_topN   = 6000;
    proposal_sdp_model->post_nms_topN  = 300;
    proposal_sdp_model->nms_thresh     = 0.7;
    proposal_sdp_model->split_param[0] = 10;
    proposal_sdp_model->split_param[1] = 10;

    ptr = strstr(hyperparams, feat_stride);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(feat_stride) + 1, "%d", &proposal_sdp_model->feat_stride);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if (proposal_sdp_model->feat_stride < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, pre_nms_topN);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(pre_nms_topN) + 1, "%d", &proposal_sdp_model->pre_nms_topN);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if (proposal_sdp_model->pre_nms_topN < 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, post_nms_topN);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(post_nms_topN) + 1, "%d", &proposal_sdp_model->post_nms_topN);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((proposal_sdp_model->post_nms_topN < 0) || (proposal_sdp_model->post_nms_topN > proposal_sdp_model->pre_nms_topN))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, nms_thresh);
    HKA_CHECK_PTR(ptr);
    r = sscanf(ptr + strlen(nms_thresh) + 1, "%f", &proposal_sdp_model->nms_thresh);
    HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    if ((proposal_sdp_model->nms_thresh < 0) || (proposal_sdp_model->nms_thresh > 1))
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    ptr = strstr(hyperparams, anchor_scales);
    HKA_CHECK_PTR(ptr);
    proposal_sdp_model->anchor_scales_num = 0;
    i = 1;
    do
    {
        // anchor���ܳ���10��
        r = sscanf(ptr + strlen(anchor_scales) + i, "%d", &proposal_sdp_model->anchor_scales[proposal_sdp_model->anchor_scales_num]);
        if (r == 1)
        {
            HKA_CHECK_ERROR(proposal_sdp_model->anchor_scales_num > 9, HIK_VCA_CNN_MODEL_ERROR);
            HKA_CHECK_ERROR(proposal_sdp_model->anchor_scales[proposal_sdp_model->anchor_scales_num] <= 0, HIK_VCA_CNN_MODEL_ERROR);
            // i��ƫ����
            i += (2 + (int)log10(proposal_sdp_model->anchor_scales[proposal_sdp_model->anchor_scales_num]));
            proposal_sdp_model->anchor_scales_num++;
        }
    } while (1 == r);

    HKA_CHECK_ERROR((0 == proposal_sdp_model->anchor_scales_num), HIK_VCA_CNN_MODEL_ERROR);

    ptr = strstr(hyperparams, roi_split_param);
    if (ptr)
    {
        param_num = 0;
        i         = 1;
        do
        {
            r = sscanf(ptr + strlen(roi_split_param) + i, "%d", &proposal_sdp_model->split_param[param_num]);
            if (r == 1)
            {
                HKA_CHECK_ERROR(param_num > 1, HIK_VCA_CNN_MODEL_ERROR);
                HKA_CHECK_ERROR(proposal_sdp_model->split_param[param_num] <= 0, HIK_VCA_CNN_MODEL_ERROR);
                i += (2 + (int)log10(proposal_sdp_model->split_param[param_num]));
                param_num++;
            }
        } while (1 == r);
    }
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: ld                     - I/O ��layer������
*         fc_layer               - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_init_layer(LAYER_DATA         *ld,
                                    PROPOSAL_SDP_LAYER *proposal_layer)
{
    HRESULT hr;

    int K;
    int c, w, h;

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(proposal_layer);

    proposal_layer->min_size = proposal_layer->model->feat_stride;

    hr = CNN_PROPOSAL_SDP_Reshape(proposal_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // im_info = (float*)ld->input_blobs[2]->data;
    // ����temp_anchors�Ĵ�С
    c = ld->input_blobs[0]->shape[1];
    h = ld->input_blobs[0]->shape[2];
    w = ld->input_blobs[0]->shape[3];
    K = h * w;
    proposal_layer->temp_data.anchors_size = (proposal_layer->model->anchor_scales_num * 3) * K * 4;

    proposal_layer->temp_data.temp_size  = CNN_SIZE_ALIGN(5 * K + w + h);
    proposal_layer->temp_data.temp_size += CNN_SIZE_ALIGN(c * K * 2);
    proposal_layer->temp_data.temp_size += CNN_SIZE_ALIGN(c * K);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��anchor
* ��  ��:


* ����ֵ: ��
***************************************************************************************************/
static void CNN_Proposal_sdp_init_anchor(PROPOSAL_SDP_LAYER         *proposal_layer,
    LAYER_DATA             *ld)
{
    int                     i, j, p, A;
    CNN_BLOB			    *input_score = ld->input_blobs[0];          //����score����
    float                   *temp = NULL;

    int                     feat_stride = proposal_layer->model->feat_stride;
    int                     height = input_score->shape[2];
    int                     width = input_score->shape[3];

    //��һ���жϣ���С���ܳ���MAX_SIZE
    int                     K = width * height;

    int                     *shifts = NULL;
    int                     *shift_x = NULL;
    int                     *shift_y = NULL;

    int                     shifts_height = K;
    int                     shifts_width = 4;

    //anchors
    float                   *anchors = NULL;
    
    float                   ratios[3] = { 0.5, 1, 2 };                            //ÿ���anchor����
    int                     num_anchor;
    HRESULT                     hr;

    temp = proposal_layer->temp_data.temp;

    shifts = (int*)temp;
    shift_x = (int*)temp + 4 * K;
    shift_y = (int*)temp + 4 * K + width;
    anchors = proposal_layer->temp_data.anchors;

    //Enumerate all shifts
    for (i = 0; i < width; i++)
    {
        *(shift_x + i) = i * proposal_layer->model->feat_stride;
    }
    for (i = 0; i < height; i++)
    {
        *(shift_y + i) = i * proposal_layer->model->feat_stride;
    }

    for (i = 0; i < shifts_height; i++)
    {
        for (j = 0; j < shifts_width; j++)
        {
            //����ܱ�2����
            if ((j % 2) == 0)
            {
                *(shifts + i * shifts_width + j) = *(shift_x + i % width);
            }
            else
            {
                *(shifts + i * shifts_width + j) = *(shift_y + i / width);
            }
        }
    }

    //����anchor
    hr = CNN_PROPOSAL_generate_anchors(feat_stride, ratios, proposal_layer->model->anchor_scales, proposal_layer->model->anchor_scales_num, &proposal_layer->anchor); //*****
    num_anchor = (proposal_layer->anchor.scales_num * 3);   //anchorһ��������

    A = num_anchor;

    for (p = 0; p < K; p++)
    {
        for (i = 0; i < A; i++)
        {
            for (j = 0; j < 4; j++)
            {
                *(anchors + p * A * 4 + i * 4 + j) = *(proposal_layer->anchor.data + i * 4 + j) + *(shifts + p * 4 + j);  //***
            }
        }
    }

}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_Create(LAYER_DATA *ld,
    CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
    void      **handle)
{
    int             hr;
    PROPOSAL_SDP_LAYER *proposal_layer;

    int nms_table_size;   //GPU��Ҫ�õ�

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf = &mem_buf[1];
    CNN_BUF *gpu_data_buf = &mem_buf[2];

    HKA_CHECK_PTR(ld);
    HKA_CHECK_PTR(handle);

#ifndef CNN_CUDA_OPT
    gpu_data_buf = NULL;
#endif

    proposal_layer = (PROPOSAL_SDP_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(PROPOSAL_SDP_LAYER)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(proposal_layer);

    proposal_layer->model = ld->layer_model->model_handle;

    hr = CNN_PROPOSAL_SDP_init_layer(ld, proposal_layer);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    ld->output_blobs[0].data = CNN_alloc_buffer(cpu_data_buf,
        CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(ld->output_blobs[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    ld->output_blobs[1].data = CNN_alloc_buffer(cpu_data_buf,
        CNN_BLOB_GetDataNum(&ld->output_blobs[1]) * sizeof(float),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(ld->output_blobs[1].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->temp_data.temp = CNN_alloc_buffer(cpu_data_buf,
        proposal_layer->temp_data.temp_size * sizeof(float),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(proposal_layer->temp_data.temp == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->temp_data.anchors = CNN_alloc_buffer(cpu_data_buf,
        proposal_layer->temp_data.anchors_size * sizeof(float),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(proposal_layer->temp_data.anchors == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    ld->output_blobs[0].data_gpu = NULL;
    ld->output_blobs[0].data_gpu_fp16 = NULL;
    if (gpu_data_buf)
    {
        ld->output_blobs[0].data_gpu = CNN_alloc_buffer(gpu_data_buf,
            CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float),
            CNN_MEM_ALIGN_SIZE,
            0);
        CNN_CHECK_ERROR(ld->output_blobs[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }
    ld->output_blobs[1].data_gpu = NULL;
    ld->output_blobs[1].data_gpu_fp16 = NULL;
    if (gpu_data_buf)
    {
        ld->output_blobs[1].data_gpu = CNN_alloc_buffer(gpu_data_buf,
            CNN_BLOB_GetDataNum(&ld->output_blobs[1]) * sizeof(float),
            CNN_MEM_ALIGN_SIZE,
            0);
        CNN_CHECK_ERROR(ld->output_blobs[1].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);
    }

#ifdef CNN_CUDA_OPT
    /*----------------------------------------------nms���--------------------------------------*/
    nms_table_size = (proposal_layer->model->pre_nms_topN + PROPOSAL_BLOCK_SIZE - 1) / PROPOSAL_BLOCK_SIZE * sizeof(long long);
    proposal_layer->nms_remv = CNN_alloc_buffer(cpu_data_buf,
        CNN_SIZE_ALIGN(nms_table_size),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(proposal_layer->nms_remv == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    nms_table_size *= proposal_layer->model->pre_nms_topN;
    proposal_layer->nms_table = CNN_alloc_buffer(cpu_data_buf,
        CNN_SIZE_ALIGN(nms_table_size),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(proposal_layer->nms_table == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->nms_keep = CNN_alloc_buffer(cpu_data_buf,
        CNN_SIZE_ALIGN(proposal_layer->model->post_nms_topN * sizeof(int)),
        CNN_MEM_ALIGN_SIZE,
        0);
    CNN_CHECK_ERROR(proposal_layer->nms_keep == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

	proposal_layer->nms_keep_large = CNN_alloc_buffer(cpu_data_buf,
		CNN_SIZE_ALIGN(proposal_layer->model->post_nms_topN * sizeof(int)),
		CNN_MEM_ALIGN_SIZE,
		0);
	CNN_CHECK_ERROR(proposal_layer->nms_keep_large == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

	proposal_layer->nms_keep_small = CNN_alloc_buffer(cpu_data_buf,
		CNN_SIZE_ALIGN(proposal_layer->model->post_nms_topN * sizeof(int)),
		CNN_MEM_ALIGN_SIZE,
		0);
	CNN_CHECK_ERROR(proposal_layer->nms_keep_small == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    /*-------------------------------------------------------------------------------------------*/

    //�����ϲ�box�����CPU�ڴ�
    proposal_layer->prev_out[0].data            = CNN_alloc_buffer(cpu_data_buf, 
        CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)), 
        CNN_MEM_ALIGN_SIZE, 
        0);
    CNN_CHECK_ERROR(proposal_layer->prev_out[0].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->prev_out[0].data_gpu        = NULL;
    proposal_layer->prev_out[0].data_gpu_fp16   = NULL;
    proposal_layer->prev_out[0].type            = CNN_DT_FLT32;

    //�����ϲ�score�����CPU�ڴ�
    proposal_layer->prev_out[1].data            = CNN_alloc_buffer(cpu_data_buf, 
                                                                   CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[0]) * sizeof(float)), 
                                                                   CNN_MEM_ALIGN_SIZE, 
                                                                   0);
    CNN_CHECK_ERROR(proposal_layer->prev_out[1].data == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    proposal_layer->prev_out[1].data_gpu        = NULL;
    proposal_layer->prev_out[1].data_gpu_fp16   = NULL;
    proposal_layer->prev_out[1].type            = CNN_DT_FLT32;

    proposal_layer->proposal_gpu                = CNN_alloc_buffer(gpu_data_buf,
        CNN_SIZE_ALIGN(proposal_layer->model->pre_nms_topN * sizeof(float) * 4),
        CNN_CUDA_MEM_ALIGNMENT,
        0);
    CNN_CHECK_ERROR(proposal_layer->proposal_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

     proposal_layer->nms_table_gpu          = CNN_alloc_buffer(gpu_data_buf,
                                                               CNN_SIZE_ALIGN(nms_table_size),
                                                               CNN_CUDA_MEM_ALIGNMENT,
                                                               0);
     CNN_CHECK_ERROR(proposal_layer->nms_table_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

#endif

    if (ld->input_blobs[1]->type == CNN_DT_FLT16)
    {
		//�����ϲ������GPU�ڴ�(fp32),���ڽ�fp16��GPU�ڴ�ת��fp32, prev_out[0]��box
        proposal_layer->prev_out[0].data_gpu = CNN_alloc_buffer(gpu_data_buf,
                                                                CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)),
                                                                CNN_CUDA_MEM_ALIGNMENT,
                                                                0);
        CNN_CHECK_ERROR(proposal_layer->prev_out[0].data_gpu == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

        //prev_out[1]����Ҫ����ڴ棬��Ϊprev_out[1]��softmax�������softmaxʼ����fp32����

        proposal_layer->input_bbox_unzip = CNN_alloc_buffer(gpu_data_buf,
                                                            CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(short)),
                                                            CNN_CUDA_MEM_ALIGNMENT,
                                                            0);
        CNN_CHECK_ERROR(proposal_layer->input_bbox_unzip == NULL, "CNN_alloc_buffer", HIK_VCA_LIB_E_MEM_OUT);

    }

    *handle = proposal_layer;

    proposal_layer->input_height = ld->input_blobs[1]->shape[2];
    proposal_layer->input_width = ld->input_blobs[1]->shape[3];
    CNN_Proposal_sdp_init_anchor(proposal_layer, ld);

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_GetMemsize(LAYER_DATA *ld,
    VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    int				hr;
    PROPOSAL_SDP_LAYER  proposal_layer;
    int             nms_table_size;

    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2     *cpu_data_tab = &mem_tab[1];
    VCA_MEM_TAB_V2     *gpu_data_tab = &mem_tab[2];

    HKA_CHECK_PTR(ld);

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    proposal_layer.model = ld->layer_model->model_handle;

    hr = CNN_PROPOSAL_SDP_init_layer(ld, &proposal_layer);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(PROPOSAL_SDP_LAYER)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[0]) * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[1]) * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.temp_data.anchors_size * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.temp_data.temp_size * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

#ifdef CNN_CUDA_OPT
    //nms_remv
    nms_table_size  = (proposal_layer.model->pre_nms_topN + PROPOSAL_BLOCK_SIZE - 1) / PROPOSAL_BLOCK_SIZE * sizeof(long long);
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    //nms_table
    nms_table_size *= proposal_layer.model->pre_nms_topN;
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    //nms_keep
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.model->post_nms_topN * sizeof(int)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
	
	//nms_keep_large
	CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.model->post_nms_topN * sizeof(int)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
	
	//nms_keep_small
	CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.model->post_nms_topN * sizeof(int)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(gpu_data_tab, CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(&ld->output_blobs[0])), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    CNN_BASE_SetMemTab(gpu_data_tab, gpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(&ld->output_blobs[1]) * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    CNN_BASE_SetMemTab(gpu_data_tab, gpu_data_tab->size + CNN_SIZE_ALIGN(proposal_layer.model->pre_nms_topN * sizeof(float) * 4), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    CNN_BASE_SetMemTab(gpu_data_tab, gpu_data_tab->size + CNN_SIZE_ALIGN(nms_table_size),                                          CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
    CNN_BASE_SetMemTab(cpu_data_tab, cpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[0]) * sizeof(float)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);
#endif

    if (ld->input_blobs[1]->type == CNN_DT_FLT16)
    {
        //�����ϲ������GPU�ڴ�(fp32),���ڽ�fp16��GPU�ڴ�ת��fp32, prev_out[0]��box
        CNN_BASE_SetMemTab(gpu_data_tab, 
                           gpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(float)) + 
                           gpu_data_tab->size + CNN_SIZE_ALIGN(CNN_BLOB_GetDataNum(ld->input_blobs[1]) * sizeof(short)), 
                           CNN_MEM_ALIGN_SIZE, 
                           VCA_MEM_PERSIST, 
                           VCA_MEM_PLAT_GPU);
    }

    return HIK_VCA_LIB_S_OK;
}


HRESULT CNN_PROPOSAL_SDP_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(PROPOSAL_SDP_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_PROPOSAL_SDP_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    int                      hr;
    PROPOSAL_SDP_MODEL          *proposal_model;
    CNN_BUF                 *cpu_handle_buf = &mem_buf[0];

    proposal_model = (PROPOSAL_SDP_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(PROPOSAL_SDP_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(proposal_model);

    hr = CNN_PROPOSAL_SDP_init_model(hyperparams, param_blobs, ld, proposal_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = proposal_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_PROPOSAL_SDP_SplitProposals_index(int nms_keep_num, float *proposal_data, int *nms_keep, 
	                                          int small_max, int large_min, int *nms_keep_small, int *nms_keep_large, int *small_num, int *large_num)
{
	int   cnt;
	float pp_width, pp_height;
	int   pp_index;
	int   pp_small_cnt, pp_large_cnt, pp_total_cnt;

	memset(nms_keep_small, 0, sizeof(int)* nms_keep_num);
	memset(nms_keep_large, 0, sizeof(int)* nms_keep_num);
	pp_small_cnt = 0;
	pp_large_cnt = 0;
	pp_total_cnt = 0;

	for (cnt = 0; cnt < nms_keep_num; ++cnt)
	{
		pp_index  = nms_keep[cnt];
		pp_width  = fabs(proposal_data[pp_index * 4 + 2] - proposal_data[pp_index * 4]);
		pp_height = fabs(proposal_data[pp_index * 4 + 3] - proposal_data[pp_index * 4 + 1]);

		//СĿ���ж�
		if ((pp_width <= small_max) || (pp_height <= small_max))
		{
			pp_total_cnt++;
			pp_small_cnt++;
			nms_keep_small[pp_small_cnt] = pp_index;
			if (pp_total_cnt >= nms_keep_num)
			{
				break;
			}
		}
		else
		{
			pp_total_cnt++;
			pp_large_cnt++;
			nms_keep_large[pp_large_cnt] = pp_index;
			if (pp_total_cnt >= nms_keep_num)
			{
				break;
			}
		}
	}

	//��ֹһ֧û��proposals
	if (0 == pp_small_cnt)
	{
		pp_small_cnt++;
		pp_large_cnt--;
		nms_keep_small[0] = nms_keep[0];
	}
	if (0 == pp_large_cnt)
	{
		pp_small_cnt--;
		pp_large_cnt++;
		nms_keep_large[0] = nms_keep[0];
	}
	*small_num = pp_small_cnt;
	*large_num = pp_large_cnt;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��proposal���մ�С�ֿ�
* ��  ��: proposals                 - I/O   ԭʼproposals
*         max_size                  - I     ���ߴ�
*         small_size                - I     ��С�ߴ�
* ����ֵ: ��
***************************************************************************************************/
void CNN_PROPOSAL_SDP_SplitProposals(CNN_BLOB    *proposal,
    int         max_size,
    int         small_size,
    CNN_BLOB    *small_proposal,
    CNN_BLOB    *large_proposal,
    int         small_shape,
    int         large_shape,
    int         post_num_topN,
    float       n)
{
    int proposals_num = proposal->shape[2];
    float* proposal_data = (float *)proposal->data;
    float* small_proposal_data = (float *)small_proposal->data;
    float* large_proposal_data = (float *)large_proposal->data;
    float proposals_w, proposals_h;
    int total_proposals_num = 0;
    int small_proposals_num = 0;
    int large_proposals_num = 0;
    int i;
    for (i = 0; i < proposals_num; i++)
    {
        proposals_w = proposal_data[i * 4 + 2] - proposal_data[i * 4];
        proposals_h = proposal_data[i * 4 + 3] - proposal_data[i * 4 + 1];

        //СĿ���ж�
        if ((proposals_w <= max_size) || (proposals_h <= max_size))
        {
            *((float *)small_proposal_data + small_shape * 5 + small_proposals_num * 5) = n;
            memcpy(small_proposal_data + small_shape * 5 + small_proposals_num * 5 + 1, proposal_data + i * 4, 4 * sizeof(float));
            small_proposals_num++;
            total_proposals_num++;
            if (total_proposals_num >= post_num_topN)
                break;
        }
		else
        {
            *((float *)large_proposal_data + large_shape * 5 + large_proposals_num * 5) = n;
            memcpy(large_proposal_data + large_shape * 5 + large_proposals_num * 5 + 1, proposal_data + i * 4, 4 * sizeof(float));
            large_proposals_num++;
            total_proposals_num++;
            if (total_proposals_num >= post_num_topN)
                break;
        }

    }
    small_proposal->shape[2] = small_proposals_num;
    large_proposal->shape[2] = large_proposals_num;

    //��ֹ�����뵼��crash
    if (small_proposals_num == 0)
    {
        *((float *)small_proposal_data + small_shape * 5) = n;
        memcpy(small_proposal_data + small_shape * 5 + 1, proposal_data, 4 * sizeof(float));


        small_proposal->shape[2] = 1;
        large_proposal->shape[2] = (proposals_num - 1);
    }
    if (large_proposals_num == 0)
    {
        *((float *)large_proposal_data + large_shape * 5) = n;
        memcpy(large_proposal_data + large_shape * 5 + 1, proposal_data, 4 * sizeof(float));


        large_proposal->shape[2] = 1;
        small_proposal->shape[2] = (proposals_num - 1);

    }

}





/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_Forward(void       *handle,
    LAYER_DATA *ld)
{	
	int             i, j, p, q, A, n;
    PROPOSAL_SDP_LAYER *proposal_layer = (PROPOSAL_SDP_LAYER *)handle;

    CNN_BLOB *input_score = ld->input_blobs[0];                            // ����score����
    CNN_BLOB *input_bbox = ld->input_blobs[1];                            // ����bbox����
    CNN_BLOB  temp_blob1, temp_blob2;
    CNN_BLOB *perim_score = &temp_blob1;
    CNN_BLOB *perim_bbox = &temp_blob2;

    const CNN_BLOB *im_info = ld->input_blobs[2];                          // ͼƬ����

    CNN_BLOB *output_roi = NULL;
    CNN_BLOB *output_roi_small = &ld->output_blobs[0];                           // ���blobs
    CNN_BLOB  proposals;
    CNN_BLOB  proposals_small;
    CNN_BLOB  proposals_large;

    HRESULT   hr;
    float *temp_anchors = NULL;
    float *temp = NULL;

    // ������Щ����init������
    // ÿ���anchor����  //���֮����Էŵ���������ȥ
    float  ratios[3] = { 0.5, 1, 2 };
    int    feat_stride = proposal_layer->model->feat_stride;
    int    num_anchor;
    int    min_size = proposal_layer->min_size;
    int    pre_num_topN = proposal_layer->model->pre_nms_topN;
    int    post_num_topN = proposal_layer->model->post_nms_topN;
    float  nms_thresh = proposal_layer->model->nms_thresh;
    int    small_max = proposal_layer->model->split_param[0];
    int    large_min = proposal_layer->model->split_param[1];
    int    half_c;
    float *score;
    float *bbox_deltas;
    // im_size 0 1 scale 3 ����Ϊ��ͳһ������float��ʽ
    // float *im_info_data = (float*)im_info->data;
    int height = input_score->shape[2];
    int width = input_score->shape[3];
    // ��С���ܳ���MAX_SIZE
    int K = width * height;

    int *shifts = NULL;
    int *shift_x = NULL;
    int *shift_y = NULL;

    int shifts_height = K;
    int shifts_width = 4;

    // anchors
    float *anchors = NULL;
    int    anchors_size[2];

    // bbox_deltas_trans
    float *bbox_deltas_trans = NULL;
    // scores
    float *scores = NULL;

    // ����Ϊforward�ı��� ��ʾbatch�ڵ�ͼ������
    int im_num = input_score->shape[0];

    int input_score_shape[4];
    int input_bbox_shape[4];

    //int anchors_size_temp = proposal_layer->temp_data.anchors_size;

    output_roi = &ld->output_blobs[1];
    // ��temp_data���ӵ�layer�����ṹ����
    temp_anchors = proposal_layer->temp_data.anchors;
    temp = proposal_layer->temp_data.temp;

    shifts = (int *)temp;
    shift_x = (int *)temp + 4 * K;
    shift_y = (int *)temp + 4 * K + width;
    anchors = temp_anchors;
    // ����ԭ��shape
    memcpy(input_score_shape, input_score->shape, 4 * sizeof(int));
    memcpy(input_bbox_shape, input_bbox->shape, 4 * sizeof(int));

    /********Enumerate all shifts*********************/
    for (i = 0; i < width; i++)
    {
        *(shift_x + i) = i * proposal_layer->model->feat_stride;
    }
    for (i = 0; i < height; i++)
    {
        *(shift_y + i) = i * proposal_layer->model->feat_stride;
    }

    for (i = 0; i < shifts_height; i++)
    {
        for (j = 0; j < shifts_width; j++)
        {
            // ����ܱ�2����
            if (0 == (j % 2))
            {
                *(shifts + i * shifts_width + j) = *(shift_x + i % width);
            }
            else
            {
                *(shifts + i * shifts_width + j) = *(shift_y + i / width);
            }
        }
    }
    /*******************************************************/

    // ����anchor
    hr = CNN_PROPOSAL_generate_anchors(feat_stride, ratios, proposal_layer->model->anchor_scales,
        proposal_layer->model->anchor_scales_num, &proposal_layer->anchor);
    num_anchor = (proposal_layer->anchor.scales_num * 3);   // anchorһ��������
    // ����proposals
    A = num_anchor;
    for (p = 0; p < K; p++)
    {
        for (i = 0; i < A; i++)
        {
            for (j = 0; j < 4; j++)
            {
                *(anchors + p * A * 4 + i * 4 + j) =
                    *(proposal_layer->anchor.data + i * 4 + j) + *(shifts + p * 4 + j);
            }
        }
    }
    anchors_size[0] = K * A;
    anchors_size[1] = 4;
    // ����shifts,shift_x,shift_y������

    // ѭ��im_num��ͼƬ
    output_roi->shape[0] = 0;
    output_roi_small->shape[0] = 0;
    for (n = 0; n < im_num; n++)
    {
        memcpy(perim_score->shape, input_score_shape, 4 * sizeof(int));
        memcpy(perim_bbox->shape, input_bbox_shape, 4 * sizeof(int));
        perim_score->shape[0] = 1;
        perim_bbox->shape[0] = 1;

        // input_scoreһ���λ�ã���Ϊǰһ����neg���ʣ���һ����pos���ʣ���һ��Ϊ��������Ҫ
        half_c = perim_score->shape[1]
            * perim_score->shape[2]
            * perim_score->shape[3] / 2;
        // ������Ҫ��score����ʼλ��
        perim_score->data = (void *)((float *)input_score->data + n * 2 * half_c);        // ��Ҫ�����n��batch n��0��ʼ
        score = (float *)perim_score->data + half_c;
        // bbox���޶�ƫ��ֵ
        perim_bbox->data = (void *)((float *)input_bbox->data + n * 4 * half_c);
        bbox_deltas = (float *)perim_bbox->data;

        // bbox_deltas
        bbox_deltas_trans = temp;  // ��Ҫ�ߴ�4*A*W*H

        // for (i = 0; i < input_bbox->shape[0]; i++)
        for (i = 0; i < perim_bbox->shape[0]; i++)
        {
            for (j = 0; j < perim_bbox->shape[2]; j++)
            {
                for (p = 0; p < perim_bbox->shape[3]; p++)
                {
                    for (q = 0; q < perim_bbox->shape[1]; q++)
                    {
                        *(bbox_deltas_trans + i * perim_bbox->shape[2] * perim_bbox->shape[3] * perim_bbox->shape[1]
                            + j * perim_bbox->shape[3] * perim_bbox->shape[1]
                            + p * perim_bbox->shape[1] + q) =
                            *(bbox_deltas + i * perim_bbox->shape[2] * perim_bbox->shape[3] * perim_bbox->shape[1]
                            + q * perim_bbox->shape[2] * perim_bbox->shape[3]
                            + j * perim_bbox->shape[3] + p);
                    }
                }
            }
        }
        j = perim_bbox->shape[1] * perim_bbox->shape[2] * perim_bbox->shape[3];   // input_bbox->shape[0]
        memcpy(bbox_deltas, bbox_deltas_trans, j * sizeof(float));

        perim_bbox->shape[0] = 1;
        perim_bbox->shape[1] = 1;
        perim_bbox->shape[2] = j >> 2;
        perim_bbox->shape[3] = 4;

        // scores
        scores = temp;

        // for (i = 0; i < input_score->shape[0]; i++)
        for (i = 0; i < perim_score->shape[0]; i++)
        {
            for (j = 0; j < perim_score->shape[2]; j++)
            {
                for (p = 0; p < perim_score->shape[3]; p++)
                {
                    for (q = 0; q < (perim_score->shape[1] >> 1); q++)
                    {
                        *(scores + i * perim_score->shape[2] * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                            + j * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                            + p * (perim_score->shape[1] >> 1) + q) =
                            *(score + i * perim_score->shape[2] * perim_score->shape[3] * (perim_score->shape[1] >> 1)
                            + q * perim_score->shape[2] * perim_score->shape[3]
                            + j * perim_score->shape[3] + p);
                    }
                }
            }
        }
        j = ((perim_score->shape[1]) * (perim_score->shape[2]) * (perim_score->shape[3])) >> 1;   // (input_score->shape[0]) *
        memcpy((score - half_c), scores, j * sizeof(float));

        perim_score->shape[0] = 1;
        perim_score->shape[1] = 1;
        perim_score->shape[2] = j;
        perim_score->shape[3] = 1;

        proposals.shape[0] = 1;
        proposals.shape[1] = 1;
        proposals.shape[2] = perim_score->shape[2];
        proposals.shape[3] = 4;

        proposals.data = (void *)(temp);

        // ����proposals
        // CNN_PROPOSAL_bbox_transform_inv(anchors, anchors_size, input_bbox, &proposals);
        CNN_PROPOSAL_bbox_transform_inv(anchors, anchors_size, bbox_deltas, &proposals);
        // �Գ���ͼ���Ե�Ĳ��ֽ��вü�
        hr = CNN_PROPOSAL_clip_boxes(im_info, &proposals);
        // ȥ����С��proposal

        // input_score������û���
        hr = CNN_PROPOSAL_filter_boxes((int)((float)min_size * (*((float *)im_info->data + 2))), &proposals, perim_score);

        // �����¸�Ϊ���ú�������frcnnout_layerһ��ʹ��
        // ��������ȡpre_num_topN��
        hr = CNN_PROPOSAL_argsort(pre_num_topN, &proposals, perim_score);

        // ��nms
        hr = CNN_PROPOSAL_nms(post_num_topN, &proposals, perim_score, nms_thresh);
        // ���
        proposals_large.data = (float *)output_roi->data;
        proposals_small.data = (float *)output_roi_small->data;
        CNN_PROPOSAL_SDP_SplitProposals(&proposals, small_max, large_min, &proposals_small, &proposals_large, output_roi_small->shape[0], output_roi->shape[0], post_num_topN,(float)n);
        //for (i = 0; i < proposals_large.shape[2]; i++)
        //{
        //    *((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)n;
        //    memcpy(((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1),
        //        (float *)proposals_large.data + 4 * i,
        //        4 * sizeof(float));
        //}
        //for (i = 0; i < proposals_small.shape[2]; i++)
        //{
        //    *((float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i) = (float)n;
        //    memcpy(((float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i + 1),
        //        (float *)proposals_small.data + 4 * i,
        //        4 * sizeof(float));
        //}
        output_roi->shape[0] += proposals_large.shape[2];
        output_roi_small->shape[0] += proposals_small.shape[2];
    }

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT






#if 1  //ʹ��gpu���
/***************************************************************************************************
* ��  ��: proposalǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_PROPOSAL_SDP_Forward_Cuda_Opt(PROPOSAL_SDP_LAYER         *proposal_layer,
    LAYER_DATA             *ld)
{ 
	int                     i, s, j, p, q, A, bn, size;
    CNN_BLOB			    *input_score        = ld->input_blobs[0];          //����score����
    CNN_BLOB			    *input_bbox		    = ld->input_blobs[1];          //����bbox����

    const CNN_BLOB          *im_info            = ld->input_blobs[2];          //ͼƬ����

    CNN_BLOB *output_roi = &ld->output_blobs[1];
    CNN_BLOB *output_roi_small = &ld->output_blobs[0];                           // ���blobs

    //CNN_BLOB                *output_roi         = &ld->output_blobs[0];        //���blobs
    CNN_BLOB                proposals;

    CNN_BLOB  proposals_small;
    CNN_BLOB  proposals_large;

    float                   *temp_anchors       = NULL;
    float                   *temp               = NULL;

    HRESULT                 hr;
    BLOB_DATA_TYPE          type;
    cudaError_t             err;

    float                   score_value;
    int                     index;
    int                     plane_size;

    float                   *proposal_gpu       = proposal_layer->proposal_gpu;

    int                     num_anchor;
    int                     min_size            = proposal_layer->min_size;
    int                     pre_num_topN        = proposal_layer->model->pre_nms_topN;
    int                     post_num_topN       = proposal_layer->model->post_nms_topN;
    float                   nms_thresh          = proposal_layer->model->nms_thresh;
    int                     small_max           = proposal_layer->model->split_param[0];
    int                     large_min           = proposal_layer->model->split_param[1];

    int                     half_c;
    float                   *score;
    float                   *bbox_deltas;
    int                     height, width;
    int                     K;

    float                   *anchors            = NULL;
    float                   *scores             = NULL;

    int                     anchors_size[2];
    float                   *bbox_deltas_trans;
    float                   kth_score;

    int                     anchors_size_temp;
    int                     nms_keep_num;
	int                     nms_keep_small_num;
	int                     nms_keep_large_num;
    int                     keep_index;

    int                     n, c, h, w;

    float                   *input_box_data;
    float                   *input_score_data;

    int                     score_num;
    BLOB_DATA_FORMAT        format  = input_bbox->format;

    //OPT_PROFILE_TIME_START(11);
    if (format == CNN_FORMAT_NCHW_ZIP)
    {
#ifdef ARCH_SUPPORT_FP16
         hr = CNN_unzip_and_unpad(input_bbox->data_gpu_fp16, 
                                  proposal_layer->input_bbox_unzip, 
                                  input_bbox->shape[0],
                                  input_bbox->shape[1],
                                  input_bbox->shape[2],
                                  input_bbox->shape[3],
                                  input_bbox->pad.pad_h,
                                  input_bbox->pad.pad_w);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_unzip_and_unpad", hr);

        err = cudaMemcpy(input_bbox->data_gpu_fp16, 
                         proposal_layer->input_bbox_unzip, 
                         CNN_BLOB_GetDataNum(input_bbox) * sizeof(short),
                         cudaMemcpyDeviceToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));
#endif
    }

    type = input_bbox->type;

    if (type == CNN_DT_FLT16)
    {
        input_bbox->data_gpu    = proposal_layer->prev_out[0].data_gpu;
        hr                      = cnn_blob_half2float(input_bbox);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_half2float", hr);
    }

    err = cudaMemcpy(proposal_layer->prev_out[1].data, input_score->data_gpu, sizeof(float) * CNN_BLOB_GetDataNum(input_score), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    err = cudaMemcpy(proposal_layer->prev_out[0].data, input_bbox->data_gpu, sizeof(float) * CNN_BLOB_GetDataNum(input_bbox), cudaMemcpyDeviceToHost);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

    //input_bbox->data            = proposal_layer->prev_out[0].data;
    //input_box_data              = input_bbox->data;

    input_score->data           = proposal_layer->prev_out[1].data;
    input_box_data              = proposal_layer->prev_out[0].data;

    if ((proposal_layer->input_height != input_bbox->shape[2]) || (proposal_layer->input_width != input_bbox->shape[3]))
    {
        proposal_layer->input_height    = input_bbox->shape[2];
        proposal_layer->input_width     = input_bbox->shape[3];
        CNN_Proposal_sdp_init_anchor(proposal_layer, ld);
    }

    //input_scoreһ���λ�ã���Ϊǰһ����neg���ʣ���һ����pos���ʣ���һ��Ϊ��������Ҫ
    half_c                      = input_score->shape[1] *
        input_score->shape[2] *
        input_score->shape[3] / 2;

    //bbox���޶�ƫ��ֵ

    height                      = input_score->shape[2];
    width                       = input_score->shape[3];

    //��һ���жϣ���С���ܳ���MAX_SIZE
    K                           = width * height;

    anchors_size_temp           = proposal_layer->temp_data.anchors_size;


    temp_anchors                = proposal_layer->temp_data.anchors;
    temp                        = proposal_layer->temp_data.temp;
    anchors                     = temp_anchors;

    num_anchor                  = (proposal_layer->anchor.scales_num * 3);   //anchorһ��������

    A                           = num_anchor;

    anchors_size[0]             = K * A;
    anchors_size[1]             = 4;

    output_roi->shape[0]        = 0;
    output_roi_small->shape[0] = 0;


    for (bn = 0; bn < input_score->shape[0]; bn++)
    {
        c = input_bbox->shape[1];
        h = input_bbox->shape[2];
        w = input_bbox->shape[3];

        bbox_deltas = (float*)input_box_data + bn * input_bbox->shape[1] * input_bbox->shape[2] * input_bbox->shape[3];

        //������Ҫ��score����ʼλ��
        score = (float*)input_score->data + bn * h * w * c / 2 + half_c;
        memcpy(temp, score, half_c * sizeof(float));
        kth_score = temp[_IPGS_QuickSelect_32f(temp, 0, half_c - 1, (half_c - pre_num_topN) <= 0 ? 1 : half_c - pre_num_topN)];

        bbox_deltas_trans   = temp;                                     //��Ҫ�ߴ�4*A*W*H
        scores              = temp + CNN_SIZE_ALIGN(h * w * c);
        plane_size          = h * w;

        s = 0;
        index = 0;

        for (j = 0; j < h; j++)
        {
            for (p = 0; p < w; p++)
            {
                for (q = 0; q < (c >> 2); q++)
                {
                    score_value = score[q * h * w + j * w + p];
                    if (score_value > kth_score)
                    {
                        index                    = (q << 2) * plane_size + j * w + p;
                        bbox_deltas_trans[s]     = bbox_deltas[index];
                        bbox_deltas_trans[s + 1] = bbox_deltas[index + plane_size];
                        bbox_deltas_trans[s + 2] = bbox_deltas[index + plane_size + plane_size];
                        bbox_deltas_trans[s + 3] = bbox_deltas[index + plane_size + plane_size + plane_size];
                        scores[s >> 2] = score[q * plane_size + j * w + p];
                    }
                    else
                    {
                        scores[s >> 2] = 0.0f;
                    }
                    s += 4;
                }
            }
        }

        memcpy(bbox_deltas, bbox_deltas_trans, h * w * c * sizeof(float));

        proposals.shape[0]  = 1;
        proposals.shape[1]  = 1;
        proposals.shape[2]  = h * w * c >> 2;
        proposals.shape[3]  = 4;

        proposals.data      = temp;

        c   = input_score->shape[1] >> 1;
        h   = input_score->shape[2];
        w   = input_score->shape[3];

        //memcpy(input_score->data, scores, h * w * c * sizeof(float));
        memcpy((float *)input_score->data + bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3], scores, h * w * c * sizeof(float));

        //����proposals
        CNN_PROPOSAL_bbox_transform_inv_opt(im_info, 
            anchors, 
            anchors_size, 
            pre_num_topN, 
            bbox_deltas,
            &proposals, 
            (float *)input_score->data + bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
            kth_score);

        //ȥ����С��proposal
        CNN_PROPOSAL_filter_boxes_opt((int)((float)min_size * *((float *)im_info->data + 2)),
            &proposals, 
            (float *)input_score->data + bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
            &score_num,
            kth_score);

        //��������ȡpre_num_topN��
        cnn_proposal_argsort_cuda(pre_num_topN, 
            &proposals,
            (float *)input_score->data + bn * input_score->shape[1] * input_score->shape[2] * input_score->shape[3],
            score_num,
            &score_num);

        err = cudaMemcpy(proposal_gpu, proposals.data, proposals.shape[2] * sizeof(float) * 4, cudaMemcpyHostToDevice);
        CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", CNN_convert_cudart_error_code(err));

        //����
        hr = cnn_proposal_keep_proposal(proposal_layer->nms_keep, 
            &nms_keep_num, 
            proposal_layer->proposal_gpu, 
            proposal_layer->nms_table, 
            proposal_layer->nms_table_gpu, 
            proposal_layer->nms_remv,
            proposals.shape[2], 
            proposal_layer->model->post_nms_topN,
            nms_thresh);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_proposal_keep_proposal", hr);

		//���ݴ�С����proposals_index
		hr = CNN_PROPOSAL_SDP_SplitProposals_index(nms_keep_num, proposals.data, proposal_layer->nms_keep, small_max, large_min,
			                                       proposal_layer->nms_keep_small, proposal_layer->nms_keep_large, &nms_keep_small_num, &nms_keep_large_num);
		CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_PROPOSAL_SDP_SplitProposals", hr);

		//���small
		for (i = 0; i < nms_keep_small_num; i++)
		{
            //printf("+++++++++++++++++++++++++++++++++++++ %x\n", (float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i);
            //printf("+++++++++++++++++++++++++++++++++++++ %x\n", (float *)output_roi_small->data);

			//((float*)output_roi->data)[5 * i + output_roi->shape[0] * 5] = (float)bn;
			*((float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i) = (float)bn;

			keep_index = proposal_layer->nms_keep_small[i];

			memcpy(((float*)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i + 1), (float*)proposals.data + 4 * keep_index, 4 * sizeof(float));
		}
		output_roi_small->shape[0] += nms_keep_small_num;

		//���large
		for (i = 0; i < nms_keep_large_num; i++)
		{
			//((float*)output_roi->data)[5 * i + output_roi->shape[0] * 5] = (float)bn;
			*((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)bn;

			keep_index = proposal_layer->nms_keep_large[i];

			memcpy(((float*)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1), (float*)proposals.data + 4 * keep_index, 4 * sizeof(float));
		}
		output_roi->shape[0] += nms_keep_large_num;

		//cudaMemcpy(output_roi->data, output_roi->data_gpu, sizeof(float)* 5, cudaMemcpyDeviceToHost);

		//         proposals.shape[2]      = nms_keep_num;
// 
// 
//         // ���
//         proposals_large.data = (float *)output_roi->data;
//         proposals_small.data = (float *)output_roi_small->data;
//         CNN_PROPOSAL_SDP_SplitProposals(&proposals, small_max, large_min, &proposals_small, &proposals_large, output_roi_small->shape[0], output_roi->shape[0], post_num_topN,(float)bn);
//         
// // 		for (i = 0; i < proposals_large.shape[2]; i++)
// //         {
// //             *((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)n;
// //             memcpy(((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1),
// //                 (float *)proposals_large.data + 4 * i,
// //                 4 * sizeof(float));
// //         }
// //         for (i = 0; i < proposals_small.shape[2]; i++)
// //         {
// //             *((float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i) = (float)n;
// //             memcpy(((float *)output_roi_small->data + output_roi_small->shape[0] * 5 + 5 * i + 1),
// //                 (float *)proposals_small.data + 4 * i,
// //                 4 * sizeof(float));
// //         }
// 
// 
//         output_roi->shape[0] += proposals_large.shape[2];
//         output_roi_small->shape[0] += proposals_small.shape[2];
// 
//         size = output_roi->shape[0] * output_roi->shape[1] * output_roi->shape[2] * output_roi->shape[3];
//         cudaMemcpy(output_roi->data_gpu, output_roi->data, size * sizeof(float), cudaMemcpyHostToDevice);
//         cudaMemcpy(output_roi_small->data_gpu, output_roi_small->data, size * sizeof(float), cudaMemcpyHostToDevice);
// 



        /*
        //���
        for (i = 0; i < proposals.shape[2]; i++)
        {
        //((float*)output_roi->data)[5 * i + output_roi->shape[0] * 5] = (float)bn;
        *((float *)output_roi->data + output_roi->shape[0] * 5 + 5 * i) = (float)bn;

        keep_index = proposal_layer->nms_keep[i];

        memcpy(((float*)output_roi->data + output_roi->shape[0] * 5 + 5 * i + 1), (float*)proposals.data + 4 * keep_index, 4 * sizeof(float));
        }
        output_roi->shape[0] += proposals.shape[2];

        //printf("proposal: %d\n", proposals.shape[2]);
        //output_roi->shape[0] += (proposals.shape[2] > 250) ? proposals.shape[2] : 0;
        //printf("proposal: %d\n", (proposals.shape[2] > 250) ? proposals.shape[2] : 0);

        */
    }

    output_roi->shape[0]       -= output_roi->shape[0] & 0x1;
    output_roi_small->shape[0] -= output_roi_small->shape[0] & 0x1;

    //OPT_PROFILE_TIME_STOP(11, "nms", 1, 1);

    return HIK_VCA_LIB_S_OK;
}
#endif


#endif  //CNN_CUDA_OPT
