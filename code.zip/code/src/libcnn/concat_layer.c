/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: concat_layer.h
* �ļ���ʶ: CONCAT_LAYER_H
* ժ    Ҫ: concat��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-01
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <float.h>
#include <math.h>
#include <string.h>
#ifdef CNN_CUDA_OPT
#include <cuda_runtime.h>
#endif
#include <stdio.h>
#include "concat_layer.h"
#include "vca_common.h"
#include "net.h"
#include "concat_layer_cuda.h"

#ifdef CNN_CONCAT_OPT
void CNN_CONCAT_set_input_data_ptr(NET        *net,
                                   LAYER_PIN   from,
                                   void       *data,
                                   void       *data_gpu,
                                   void       *data_gpu_fp16)
{
    LAYER_DATA *ld_out = CNN_NET_get_layer_data(net, from.lid);

    ld_out->output_blobs[from.oid].data             = data;
    ld_out->output_blobs[from.oid].data_gpu         = data_gpu;
    ld_out->output_blobs[from.oid].data_gpu_fp16    = data_gpu_fp16;

    if (1 == ld_out->layer_model->in_place)
    {
        // ����in-place�����Ĳ㣬Ҫ�������ϴ��ݵ�����ʵ����blob

        LAYER_PIN   layer_pin = ld_out->layer_model->input_blobs_id[from.oid];

        CNN_CONCAT_set_input_data_ptr(net, layer_pin, data, data_gpu, data_gpu_fp16);
    }
}
#endif

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONCAT_Reshape(void       *handle,
                           LAYER_DATA *ld)
{
    int              i;
    int              axis_id, axis_sum = 0;
    SHAPE_UNIT_TYPE *ref_shape, *cur_shape;
    CONCAT_MODEL *concat_model;
    CONCAT_LAYER *concat_layer = (CONCAT_LAYER *)handle;

#ifdef CNN_CONCAT_OPT
    char            *data                = ld->output_blobs[0].data; 
    char            *data_gpu            = ld->output_blobs[0].data_gpu;
    char            *data_gpu_fp16       = ld->output_blobs[0].data_gpu_fp16;
#endif

    concat_model = concat_layer->model;

    HKA_CHECK_ERROR(ld->input_blobs[0]->ndims != 4, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(concat_model->axis >= ld->input_blobs[0]->ndims, HIK_VCA_CNN_MODEL_ERROR);

    // ���shape�Ƿ�ƥ�䣬������concat֮��Ĵ�С
    ref_shape = ld->input_blobs[0]->shape;
    for (i = 0; i < ld->input_blobs_num; i++)
    {
        cur_shape = ld->input_blobs[i]->shape;
        if ((ld->input_blobs[i]->type != ld->input_blobs[0]->type)
            || (ld->input_blobs[i]->ndims != ld->input_blobs[0]->ndims))
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }

        for (axis_id = 0; axis_id < ld->input_blobs[i]->ndims; axis_id++)
        {
            if ((axis_id != concat_layer->model->axis)
                && (ref_shape[axis_id] != cur_shape[axis_id]))
            {
                return HIK_VCA_CNN_MODEL_ERROR;
            }
        }

        axis_sum += cur_shape[concat_layer->model->axis];
        
#ifdef CNN_CONCAT_OPT
        CNN_CONCAT_set_input_data_ptr(ld->net, ld->layer_model->input_blobs_id[i], data, data_gpu, data_gpu_fp16);

        data            += CNN_BLOB_GetDataNum(ld->input_blobs[i]) * sizeof(float);
        data_gpu        += CNN_BLOB_GetDataNum(ld->input_blobs[i]) * sizeof(float);
        data_gpu_fp16   += CNN_BLOB_GetDataNum(ld->input_blobs[i]) * sizeof(short);
#endif
    }

    ld->output_blobs[0].ndims    = ld->input_blobs[0]->ndims;
    ld->output_blobs[0].type     = ld->input_blobs[0]->type;
    ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];
    ld->output_blobs[0].shape[1] = ld->input_blobs[0]->shape[1];
    ld->output_blobs[0].shape[2] = ld->input_blobs[0]->shape[2];
    ld->output_blobs[0].shape[3] = ld->input_blobs[0]->shape[3];
    ld->output_blobs[0].shape[concat_layer->model->axis] = axis_sum;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONCAT_init_model(const char   *hyperparams,
                        const char   *param_blobs,
                        LAYER_MODEL   *ld,
                        CONCAT_MODEL *concat_model)
{
    int              r;
    const char       axis[] = "axis";
    const char      *ptr;
    int              axis_sum = 0;

    HKA_CHECK_ERROR(ld->input_blobs_num <= 1, HIK_VCA_CNN_MODEL_ERROR);    
    HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

    concat_model->axis = 1;
    if ((NULL != hyperparams) && (ptr = strstr(hyperparams, axis)))
    {
        r = sscanf(ptr + strlen(axis) + 1, "%d", &concat_model->axis);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
        HKA_CHECK_ERROR(concat_model->axis <  0,                HIK_VCA_CNN_MODEL_ERROR);
        HKA_CHECK_ERROR(concat_model->axis >= CNN_BLOB_MAX_DIM, HIK_VCA_CNN_MODEL_ERROR);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONCAT_Create(LAYER_DATA *ld,
                          CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                          void      **handle)
{
    HRESULT       hr;
    CONCAT_LAYER *concat_layer;
    
    CNN_BUF                 *cpu_handle_buf       = mem_buf;
    CNN_BUF                 *cpu_data_buf         = mem_buf + 1;
    CNN_BUF                 *gpu_data_buf         = mem_buf + 2;
    
#ifndef CNN_CUDA_OPT
    gpu_data_buf    = NULL;
#else
    cpu_data_buf    = NULL;
#endif

    concat_layer = (CONCAT_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(CONCAT_LAYER)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(concat_layer);

    concat_layer->model = ld->layer_model->model_handle;

    hr = CNN_CONCAT_Reshape(concat_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
	if (0 == strcmp("rois/concat", ld->layer_model->name))
	{
		hr = cnn_alloc_blob_buffer_optional(&ld->output_blobs[0],
			                                 cpu_data_buf,
			                                 gpu_data_buf,
			                                 CNN_MEM_ALIGN_SIZE,
			                                 CNN_CUDA_MEM_ALIGNMENT,
			                                 NULL,
			                                 ld->output_blobs[0].type);
	}
	else
	{
        hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
                                   cpu_data_buf,
                                   gpu_data_buf,
                                   CNN_MEM_ALIGN_SIZE,
                                   CNN_CUDA_MEM_ALIGNMENT,
                                   NULL);
	}
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer failed", hr);

    *handle = concat_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONCAT_GetMemsize(LAYER_DATA *ld,
                              VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    size_t       size;
    HRESULT      hr;
    CONCAT_LAYER concat_layer;
    
    VCA_MEM_TAB_V2     *cpu_handle_tab  = mem_tab;
    VCA_MEM_TAB_V2     *cpu_data_tab    = mem_tab + 1;
    VCA_MEM_TAB_V2     *gpu_data_tab    = mem_tab + 2;

#ifndef CNN_CUDA_OPT
    gpu_data_tab = NULL;
#else
    cpu_data_tab = NULL;
#endif

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);
    
    concat_layer.model = ld->layer_model->model_handle;
    
    hr = CNN_CONCAT_Reshape(&concat_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    size = CNN_SIZE_ALIGN(sizeof(CONCAT_LAYER));
    CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(cpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_CPU);

    CNN_BASE_SetMemTab(gpu_data_tab, 
                       CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0])), 
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST, 
                       VCA_MEM_PLAT_GPU);

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ����layer��model
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONCAT_CreateModel(const char *hyperparams,
    const char *param_blobs,
    LAYER_MODEL *ld,
    CNN_BUF    mem_buf[MODEL_MEM_TAB_NUM],
    void      **handle)
{
    HRESULT       hr;
    CONCAT_MODEL *concat_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    
    concat_model = (CONCAT_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(CONCAT_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(concat_model);

    hr = CNN_CONCAT_init_model(hyperparams, param_blobs, ld, concat_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    *handle = concat_model;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer��model���ڴ��С
* ��  ��: hyperparams            - I ������
*         param_blobs            - I ����
*         ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_CONCAT_GetModelMemsize(const char *hyperparams,
    const char *param_blobs,
    LAYER_MODEL *ld,
    VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT      hr;
    CONCAT_MODEL concat_model;

    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;

    hr = CNN_CONCAT_init_model(hyperparams, param_blobs, ld, &concat_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    
    memset(mem_tab, 0, sizeof(VCA_MEM_TAB_V2) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, 
                       CNN_SIZE_ALIGN(sizeof(CONCAT_MODEL)), 
                       CNN_MEM_ALIGN_SIZE, 
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);
    
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ʵ��concat����Ŀ�������
* ��  ��: src                    - I Դ
*         block_num              - I Ҫ�����Ŀ������
*         block_size             - I Ҫ�����Ŀ�Ĵ�С
*         dst                    - O Ŀ��
*         dst_block_stride       - I Ŀ���ڴ�ÿ��block֮��������stride
* ����ֵ: ��
***************************************************************************************************/
void CNN_CONCAT_copy(const char *src,
                     int         block_num,
                     int         block_size,
                     char       *dst,
                     int         dst_block_stride)
{
    int i;
    for (i = 0; i < block_num; i++)
    {
        memcpy(dst, src, block_size);
        src += block_size;
        dst += dst_block_stride;
    }
}


#ifdef CNN_CUDA_OPT
/***************************************************************************************************
* ��  ��: ʵ��concat����Ŀ�������(CUDA��)
* ��  ��: 
*         src                    - I Դ
*         block_num              - I Ҫ�����Ŀ������
*         block_size             - I Ҫ�����Ŀ�Ĵ�С
*         dst                    - O Ŀ��
*         dst_block_stride       - I Ŀ���ڴ�ÿ��block֮��������stride
* ����ֵ: ��
***************************************************************************************************/
static HRESULT cnn_concat_copy_cuda(const char *src,
                                    int         block_num,
                                    int         block_size,
                                    char       *dst,
                                    int         dst_block_stride)
{
    int             i;
    cudaError_t     err;

    err = cudaMemcpy2D(dst, 
                       dst_block_stride, 
                       src, 
                       block_size, 
                       block_size, 
                       block_num, 
                       cudaMemcpyDeviceToDevice);
    CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy2D failed", CNN_convert_cudart_error_code(err));

    return HIK_VCA_LIB_S_OK;
}
#endif


/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONCAT_Forward(void       *handle,
                           LAYER_DATA *ld)
{
#ifndef CNN_CONCAT_OPT
    char *src;
    int   block_num;
    int   block_size;
    char *dst;
    int   dst_block_stride;

    int           bi, dimi;
    CONCAT_LAYER *concat_layer = (CONCAT_LAYER *)handle;

    dst = (char *)ld->output_blobs[0].data;

    dst_block_stride = data_type_size[ld->output_blobs[0].type];
    for (dimi = concat_layer->model->axis; dimi < ld->output_blobs[0].ndims; dimi++)
    {
        dst_block_stride *= ld->output_blobs[0].shape[dimi];
    }

    for (bi = 0; bi < ld->input_blobs_num; bi++)
    {
        block_num = 1;
        for (dimi = 0; dimi < concat_layer->model->axis; dimi++)
        {
            block_num *= ld->input_blobs[bi]->shape[dimi];
        }

        block_size = data_type_size[ld->input_blobs[bi]->type];
        for ( ; dimi < ld->input_blobs[bi]->ndims; dimi++)
        {
            block_size *= ld->input_blobs[bi]->shape[dimi];
        }

        src = ld->input_blobs[bi]->data;
        CNN_CONCAT_copy(src, block_num, block_size, dst, dst_block_stride);

        dst += block_size;
    }
#endif

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: concat������ǰ�򴫲�(CUDA��)
* ��  ��: 
*         concat_layer           - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_CONCAT_Forward_Cuda_Opt(CONCAT_LAYER       *concat_layer,
                                    LAYER_DATA         *ld)
{
#ifndef CNN_CONCAT_OPT
    BLOB_DATA_TYPE           type;
    BLOB_DATA_FORMAT         format;
    HRESULT                  hr;
    char                    *src;
    int                      block_num;
    int                      block_size;
    char                    *dst;
    int                      dst_block_stride;
    int                      bi, dimi;
    int                      pad_in;
    int                      pad_out;
    int                      n, c, h, w;

    CNN_BLOB                *out_blob = &ld->output_blobs[0];

    int                     in_n;
    int                     in_c;
    int                     in_h;
    int                     in_w;

    int                     out_n = out_blob->shape[0];
    int                     out_c = out_blob->shape[1];
    int                     out_h = out_blob->shape[2];
    int                     out_w = out_blob->shape[3];
    
    type                = out_blob->type;
    format              = out_blob->format;
    cudaError_t         err;

    dst                 = (type == CNN_DT_FLT32) ? out_blob->data_gpu : out_blob->data_gpu_fp16;
    dst_block_stride    = (type == CNN_DT_FLT32) ? 4 : 2;

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, "format not support", CNN_CUDA_NOT_IMPLEMENT);

    if (format == CNN_FORMAT_NCHW)
    {
        for (dimi = concat_layer->model->axis; dimi < out_blob->ndims; dimi++)
        {
            dst_block_stride *= out_blob->shape[dimi];
        }

        for (bi = 0; bi < ld->input_blobs_num; bi++)
        {
            block_num = 1;
            for (dimi = 0; dimi < concat_layer->model->axis; dimi++)
            {
                block_num *= ld->input_blobs[bi]->shape[dimi];
            }

            block_size = (type == CNN_DT_FLT32) ? 4 : 2;
            for (; dimi < ld->input_blobs[bi]->ndims; dimi++)
            {
                block_size *= ld->input_blobs[bi]->shape[dimi];
            }

            src = ld->input_blobs[bi]->data_gpu;

            if (type == CNN_DT_FLT16)
            {
                src = ld->input_blobs[bi]->data_gpu_fp16;
            }

            hr = cnn_concat_copy_cuda(src, block_num, block_size, dst, dst_block_stride);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_concat_copy_cuda", hr);

            dst += block_size;
        }
    }
    else
    {
        CNN_CHECK_ERROR(((concat_layer->model->axis != 1) &&
                        (concat_layer->model->axis != 0)), 
                        "",
                        CNN_CUDA_NOT_IMPLEMENT);

        if (concat_layer->model->axis == 0)
        {
            for (bi = 0; bi < ld->input_blobs_num; bi++)
            {
#ifdef ARCH_SUPPORT_FP16
                err = cudaMemcpy(dst,
                                 ld->input_blobs[bi]->data_gpu_fp16 ?
                                 ld->input_blobs[bi]->data_gpu_fp16 :
                                 ld->input_blobs[bi]->data_gpu,
                                 ld->input_blobs[bi]->data_gpu_fp16 ?
                                 CNN_BLOB_GetDataNum_padded(ld->input_blobs[bi]) * sizeof(short):
                                 CNN_BLOB_GetDataNum_padded(ld->input_blobs[bi]) * sizeof(float),
                                 cudaMemcpyDeviceToDevice);
#else
                err = cudaMemcpy(dst,
                                 ld->input_blobs[bi]->data_gpu,
                                 CNN_BLOB_GetDataSize_padded(ld->input_blobs[bi]),
                                 cudaMemcpyDeviceToDevice);
#endif
                CNN_CHECK_ERROR(err != cudaSuccess,
                                "cudaMemcpy failed", 
                                CNN_convert_cudart_error_code(err));
                dst += CNN_BLOB_GetDataSize_padded(ld->input_blobs[bi]);
            }
        }
        else if (concat_layer->model->axis == 1)
        {
            pad_in  = out_blob->pad.pad_h;
            pad_out = pad_in;

            dst_block_stride = CNN_pad_hw_size(1, 
                                               out_blob->shape[1],
                                               out_blob->shape[2],
                                               out_blob->shape[3], 
                                               pad_out, 
                                               pad_out) * sizeof(short);
            
            for (bi = 0; bi < ld->input_blobs_num; bi++)
            {
                block_num   = ld->input_blobs[bi]->shape[0];
                block_size  = CNN_pad_hw_size(1, 
                                              ld->input_blobs[bi]->shape[1],
                                              ld->input_blobs[bi]->shape[2], 
                                              ld->input_blobs[bi]->shape[3],
                                              pad_in, 
                                              pad_in) * sizeof(short);

                src = ld->input_blobs[bi]->data_gpu_fp16;

                hr = cnn_concat_copy_cuda(src, block_num / ZIP_NUM, block_size * ZIP_NUM, dst, dst_block_stride * ZIP_NUM);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_concat_copy_cuda", hr);

                dst += block_size * ZIP_NUM;
            }
        }
    }

#endif //CNN_CONCAT_OPT
    return HIK_VCA_LIB_S_OK;
}


#endif // CNN_CUDA_OPT
