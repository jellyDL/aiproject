/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: bn_layer.c
* �ļ���ʶ: BN_LAYER_C
* ժ    Ҫ: BN��ĺ���ʵ��
*
* ��ʼ�汾: 1.0.0
* ��    ��: ��ѩ��
* ��    ��: 2016-06-23
* ��    ע:

* ��ǰ�汾: 1.0.1
* ��    ��: Ѧ����
* ��    ��: 2016-09-12
* ��    ע: ���Ӷ�fp16��֧��

* ��ǰ�汾: 1.0.1
* ��    ��: ������
* ��    ��: 2016-12-06
* ��    ע: ����֧��zip��bn kernel
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif

#include <string.h>
#include <stdio.h>
#include <math.h>

#ifdef CNN_CUDA_OPT
#include "math_functions_cuda.h"
#include <cublas_v2.h>
#endif // CNN_CUDA_OPT
#include "bn_layer.h"

#ifndef CNN_CUDA_OPT
#ifdef MKL_OPT
#include "mkl_cblas.h"
#else
#include "cblas.h"
#endif
#endif

#include "vca_error_code.h"

/***************************************************************************************************
* ��  ��: ��ȡBN�����var_eps
* ��  ��: hyperparams            - I ������ַ�����ʽ�Ĳ�����Ϣ
*         var_eps                - O �˿���
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BN_GetVarEps(const char     *hyperparams,
	                     float          *var_eps)
{
	const char *ptr1, *ptr2;
	const char  vareps[] = "var_eps";
	float tmp;
	int r;


	if (ptr1 = strstr(hyperparams, vareps))
	{
		r = sscanf(ptr1 + strlen(vareps) + 1, "%f", &tmp);
		HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
		*var_eps = tmp;
	}
	//else
	//{
	//	return HIK_VCA_CNN_MODEL_ERROR;
	//}
	return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ����BN������任
* ��  ��: bn_model             - I/O ��layer��ģ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_convert_bn_param(BN_MODEL *bn_model)
{
    int     i;
    float   new_scale;
    float   var_eps = bn_model->var_eps;
    float   *scale;
    float   *shift;
    float   *mean;
    float   *var;
	float 	const_1 = 1.0f;
	float 	const_0 = 0.0f;
    HRESULT hr;

	HKA_CHECK_ERROR(bn_model->param_blob_channels != bn_model->param_blobs[0].shape[1], HIK_VCA_CNN_MODEL_ERROR);

#ifndef CNN_CUDA_OPT
	scale   = (float *)(bn_model->param_blobs[0].data);
	shift   = (float *)(bn_model->param_blobs[1].data);
	mean    = (float *)(bn_model->param_blobs[2].data);
	var     = (float *)(bn_model->param_blobs[3].data);

	for (i = 0; i < bn_model->param_blob_channels; i++)
	{
		new_scale = scale[i] / sqrtf(var[i] + var_eps); //�µĳ߶�ֵ
		scale[i]  = new_scale;
		shift[i] -= mean[i] * new_scale; //�µ�ƫ��

		//����mean ��var,��ֹ�ú����ܶ�γ���
		mean[i] = 0;
		var[i] = 1.0f;
	}
#else
	scale   = (float *)(bn_model->param_blobs[0].data_gpu);
	shift   = (float *)(bn_model->param_blobs[1].data_gpu);
	mean    = (float *)(bn_model->param_blobs[2].data_gpu);
	var     = (float *)(bn_model->param_blobs[3].data_gpu);

	//var ����
	cnn_sqrt_cuda(bn_model->param_blob_channels, var_eps, var);
	//�µĳ߶�
	cnn_div_cuda(bn_model->param_blob_channels, scale, var, scale);

	//sacle*mean = mean
	cnn_mul_cuda(bn_model->param_blob_channels, scale, mean, mean);

	//�µ�shift
	cnn_sub_cuda(bn_model->param_blob_channels, shift, mean, shift);

	//���ú���������Ϊ0��1
	cnn_set_cuda(bn_model->param_blob_channels, 1.0f, var);

	cnn_set_cuda(bn_model->param_blob_channels, 0.0, mean);

#ifdef ARCH_SUPPORT_FP16
    hr = cnn_blob_float2half(&bn_model->param_blobs[0]);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);

    hr = cnn_blob_float2half(&bn_model->param_blobs[1]);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);

    hr = cnn_blob_float2half(&bn_model->param_blobs[2]);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);

    hr = cnn_blob_float2half(&bn_model->param_blobs[3]);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_blob_float2half", hr);
#endif
    
#endif

	return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_init_model(const char *hyperparams,
	                      const char *param_blobs,
	                      LAYER_MODEL *ld,
	                      BN_MODEL *bn_model)
{
	HRESULT     hr;
	CNN_BLOB    *param_blob;
	float var_eps = 1e-4;

	hr = CNN_BN_GetVarEps(hyperparams, &var_eps);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	bn_model->var_eps = var_eps;

	//�������
    hr = CNN_BASE_GetParamBlobs(param_blobs, bn_model->param_blobs, BN_LAYER_MAX_PARAM_BLOB_NUM, cnn_get_blob_type(), 0);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	//��ʼ��ͨ����
	param_blob = &bn_model->param_blobs[0];
	bn_model->param_blob_channels = CNN_BLOB_GetDataNum(param_blob);

	return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �������blob��shape
* ��  ��: conv_layer             - I/O ��layer�ľ��
*         ld                     - I/O ��layer������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_compute_in_out_shape(BN_LAYER            *bn_layer,
	                                LAYER_DATA          *ld)
{
	int i;
	HKA_CHECK_ERROR(ld->input_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);
	//HKA_CHECK_ERROR(ld->input_blobs[0]->ndims <= 4, HIK_VCA_CNN_MODEL_ERROR);
	HKA_CHECK_ERROR(ld->output_blobs_num != 1, HIK_VCA_CNN_MODEL_ERROR);

	ld->output_blobs[0].type = ld->input_blobs[0]->type;
	for (i = 0; i < CNN_BLOB_MAX_DIM; i++)
	{
		ld->output_blobs[0].shape[i] = ld->input_blobs[0]->shape[i];
	}
	ld->output_blobs[0].ndims = 4;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_Reshape(void       *handle,
	                   LAYER_DATA *ld)
{
	HRESULT            hr;
	BN_LAYER *bn_layer = (BN_LAYER *)handle;
	int i;

	hr = CNN_BN_compute_in_out_shape(bn_layer, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	////��ʼ��buffer��С
	//for ( i = 0; i < 2; i++)
	//{
	//	bn_layer->buf_blobs[i].ndims = 4;
	//	bn_layer->buf_blobs[i].type = CNN_DT_FLT32;;
	//	bn_layer->buf_blobs[i].shape[0] = 1;
	//	bn_layer->buf_blobs[i].shape[1] = ld->input_blobs[0]->shape[1];
	//	bn_layer->buf_blobs[i].shape[2] = ld->input_blobs[0]->shape[2];
	//	bn_layer->buf_blobs[i].shape[3] = ld->input_blobs[0]->shape[3];
	//}


	return HIK_VCA_LIB_S_OK;
}

///***************************************************************************************************
//* ��  ��: ��BN�������ʼ����buf_blob��
//* ��  ��:
//*         blob                   - I BLOBָ��
//* ����ֵ: ��
//***************************************************************************************************/
//HRESULT BN_BLOB_InitBufBlob(BN_LAYER  *bn_layer)
//{
//    
//
//	int i,j,idx;
//	BN_MODEL *bn_model = bn_layer->model;
//
//	int channels = bn_layer->buf_blobs[0].shape[1];
//	int data_num_pre_channel = bn_layer->buf_blobs[0].shape[2] * bn_layer->buf_blobs[0].shape[3];
//
//#ifndef CNN_CUDA_OPT
//	float *scale_param = (float *)(bn_model->param_blobs[0].data);
//	float *shift_param = (float *)(bn_model->param_blobs[1].data);
//	float *scale_buf = (float *)(bn_layer->buf_blobs[0].data);
//	float *shift_buf = (float *)(bn_layer->buf_blobs[1].data);
//
//	idx = 0;
//	for ( i = 0; i < channels; i++)
//	{
//		for ( j = 0; j < data_num_pre_channel; j++)
//		{
//			scale_buf[idx] = scale_param[i];
//			shift_buf[idx] = shift_param[i];
//			idx++;
//		}
//	}
//
//#else
//	if (bn_model->param_blobs[0].type == CNN_DT_FLT32)
//	{
//		float *scale_param = (float *)(bn_model->param_blobs[0].data_gpu);
//		float *shift_param = (float *)(bn_model->param_blobs[1].data_gpu);
//		float *scale_buf = (float *)(bn_layer->buf_blobs[0].data_gpu);
//		float *shift_buf = (float *)(bn_layer->buf_blobs[1].data_gpu);
//
//		for (i = 0; i < channels; i++)
//		{
//			//���ú���������Ϊ0��1
//			cnn_set_cuda(data_num_pre_channel, scale_param+i, scale_buf + i*data_num_pre_channel);
//
//			cnn_set_cuda(data_num_pre_channel, shift_param+i, shift_buf + i*data_num_pre_channel);
//		}
//
//
//	}
//
//#endif
//
//	return HIK_VCA_LIB_S_OK;
//}


/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_Create(LAYER_DATA  *ld,
	                  CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
	                  void        **handle)
{
	HRESULT                hr;
	BN_LAYER              *bn_layer;
	int                   i;

	CNN_BUF               *cpu_handle_buf = mem_buf;
	CNN_BUF               *cpu_data_buf   = mem_buf + 1;
	CNN_BUF               *gpu_data_buf   = mem_buf + 2;

#ifndef CNN_CUDA_OPT
	gpu_data_buf = NULL;
#else
	cpu_data_buf = NULL;
#endif

	bn_layer = (BN_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
		                                    CNN_SIZE_ALIGN(sizeof(BN_LAYER)),
		                                    CNN_MEM_ALIGN_SIZE,
		                                    1);
	HKA_CHECK_MEMOUT(bn_layer);

	bn_layer->model = ld->layer_model->model_handle;

	hr = CNN_BN_Reshape(bn_layer, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	hr = cnn_alloc_blob_buffer(&ld->output_blobs[0],
		                       cpu_data_buf,
		                       gpu_data_buf,
		                       CNN_MEM_ALIGN_SIZE,
		                       CNN_CUDA_MEM_ALIGNMENT,
		                       NULL);
	CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);

	*handle = bn_layer;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_GetMemsize(LAYER_DATA    *ld,
	                      VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
	HRESULT           hr;
	size_t            size;
	int i;
	BN_LAYER bn_layer;

	VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
	VCA_MEM_TAB_V2     *cpu_data_tab = mem_tab + 1;
	VCA_MEM_TAB_V2     *gpu_data_tab = mem_tab + 2;

#ifndef CNN_CUDA_OPT
	gpu_data_tab = NULL;
#else
	cpu_data_tab = NULL;
#endif

	memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

	bn_layer.model = ld->layer_model->model_handle;

	hr = CNN_BN_Reshape(&bn_layer, ld);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	size = CNN_SIZE_ALIGN(sizeof(BN_LAYER));
	CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

	size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize_padded(&ld->output_blobs[0]));
	CNN_BASE_SetMemTab(gpu_data_tab, size, CNN_CUDA_MEM_ALIGNMENT, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

	CNN_BASE_SetMemTab(cpu_data_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer��model
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_CreateModel(const char *hyperparams,
	                       const char *param_blobs,
	                       LAYER_MODEL *ld,
	                       CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
	                       void      **handle)
{
	int                    bi;
	HRESULT                hr;
	BN_MODEL               *bn_model;

	CNN_BUF               *cpu_handle_buf   = &mem_buf[0];
	CNN_BUF               *cpu_model_buf    = &mem_buf[1];
	CNN_BUF               *gpu_model_buf    = &mem_buf[2];

    BLOB_INIT_FUNCS        blob_init_funcs  = {cnn_init_blob, cnn_init_blob, cnn_init_blob, cnn_init_blob};


#ifdef ARCH_SUPPORT_FP16
    float                 *fp16_workspace   = ld->fp16_workspace;
#endif

#ifndef CNN_CUDA_OPT
	gpu_model_buf = NULL;
#else
	cpu_model_buf = NULL;
#endif

	bn_model = (BN_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
		                                    CNN_SIZE_ALIGN(sizeof(BN_MODEL)),
		                                    CNN_MEM_ALIGN_SIZE,
		                                    1);
	HKA_CHECK_MEMOUT(bn_model);

	hr = CNN_BN_init_model(hyperparams, param_blobs, ld, bn_model);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	for (bi = 0; bi < BN_LAYER_MAX_PARAM_BLOB_NUM; bi++)
	{
		hr = cnn_alloc_blob_buffer(&bn_model->param_blobs[bi],
			                       cpu_model_buf,
			                       gpu_model_buf,
			                       CNN_MEM_ALIGN_SIZE,
			                       CNN_CUDA_MEM_ALIGNMENT,
			                       NULL);
		CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_alloc_blob_buffer", hr);

#ifdef ARCH_SUPPORT_FP16
        bn_model->param_blobs[bi].data_gpu = fp16_workspace;
        fp16_workspace = (char *)fp16_workspace + CNN_BLOB_GetDataNum(&bn_model->param_blobs[bi]) * sizeof(float);
#endif
	}

    hr = CNN_BASE_GetParamBlobs(param_blobs, bn_model->param_blobs, BN_LAYER_MAX_PARAM_BLOB_NUM, cnn_get_blob_type(), blob_init_funcs);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	//BN�����任
	hr = CNN_BN_convert_bn_param(bn_model);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	*handle = bn_model;

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer��model���ڴ��С
* ��  ��: hyperparams            - I ������
*         param_blobs            - I ����
*         ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_BN_GetModelMemsize(const char    *hyperparams,
	                           const char    *param_blobs,
	                           LAYER_MODEL    *ld,
	                           VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
	CNN_BLOB    *param_blob;
	BN_MODEL    bn_model;
	HRESULT     hr;
	size_t      size;
	int         bi;

	VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;
	VCA_MEM_TAB_V2     *cpu_model_tab  = mem_tab + 1;
	VCA_MEM_TAB_V2     *gpu_model_tab  = mem_tab + 2;

#ifndef CNN_CUDA_OPT
	gpu_model_tab = NULL;
#else
	cpu_model_tab = NULL;
#endif

	memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

	hr = CNN_BN_init_model(hyperparams, param_blobs, ld, &bn_model);
	HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

	size = CNN_SIZE_ALIGN(sizeof(BN_MODEL));
	CNN_BASE_SetMemTab(cpu_handle_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

	size = 0;
	for (bi = 0; bi < BN_LAYER_MAX_PARAM_BLOB_NUM; bi++)
	{
		param_blob = &bn_model.param_blobs[bi];
		size += CNN_SIZE_ALIGN(CNN_BLOB_GetDataSize(param_blob));
	}

	//���û�ж���CNN_CUDA_OPT����gpu_model_tabΪNULL,�ú���ʲôҲ����
	CNN_BASE_SetMemTab(gpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_GPU);

	CNN_BASE_SetMemTab(cpu_model_tab, size, CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

	return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_BN_Forward(void       *handle,
	                   LAYER_DATA *ld)
{
	int         i, bi, ci,ni;
	int         blob_channel_num;           //ͨ������
	int         data_num_pre_channel;   //ÿ��ͨ�������ݸ���
	float       *scale;
	float       *shift;
	BN_LAYER    *bn_layer = (BN_LAYER *)handle;

	ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

	if (CNN_DT_FLT32 == ld->output_blobs[0].type)
	{
		scale = (float *)bn_layer->model->param_blobs[0].data;
		shift = (float *)bn_layer->model->param_blobs[1].data;
		for (bi = 0; bi < ld->output_blobs_num; bi++)
		{
			blob_channel_num = ld->output_blobs[bi].shape[1];
			data_num_pre_channel = ld->output_blobs[bi].shape[2] * ld->output_blobs[bi].shape[3];
			for (ni = 0; ni < ld->output_blobs[bi].shape[0]; ni++)
			{
				float * in_data = (float *)ld->input_blobs[bi]->data + ni * blob_channel_num * data_num_pre_channel; //��ȡ����
				float * ou_data = (float *)ld->output_blobs[bi].data + ni * blob_channel_num * data_num_pre_channel; //��ȡ����
#ifndef CNN_CUDA_OPT
				cblas_ccopy(data_num_pre_channel*blob_channel_num, in_data , 1, ou_data , 1);
                //��ͨ����������
				for (ci = 0; ci < ld->output_blobs[bi].shape[1]; ci++)
				{

					//�˳߶�
					//cblas_ccopy(data_num_pre_channel, in_data + ci*data_num_pre_channel, 1, ou_data + ci*data_num_pre_channel, 1);
					cblas_sscal(data_num_pre_channel, scale[ci], ou_data + ci*data_num_pre_channel, 1);
					//��bias
					for (i = 0; i < data_num_pre_channel; i++)
					{
						ou_data[ci*data_num_pre_channel + i] += shift[ci];
					}

				}
#endif
			}

		}
	}

    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT


#if 0  //by �ղ�
/***************************************************************************************************
* ��  ��: BN��ǰ�򴫲�(CUDA��)
* ��  ��:
*           tanh_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BN_Forward_Cuda_Opt(BN_LAYER         *bn_layer,
	                            LAYER_DATA         *ld)
{
	int         i, bi, ci,ni;
	int         blob_data_num;
	//HRESULT                 hr;
	BLOB_DATA_TYPE          type = ld->output_blobs[0].type;
	CNN_CUDA_HANDLE         *cnn_cuda_handle = ld->cuda_handle;
	cublasStatus_t          cublas_status;
	float       *scale;
	float       *shift;
	int         blob_channel_num;           //ͨ������
	int         data_num_pre_channel;   //ÿ��ͨ�������ݸ���


	ld->output_blobs[0].shape[0] = ld->input_blobs[0]->shape[0];

	//��֧��32λ�汾
	if (CNN_DT_FLT32 == ld->output_blobs[0].type)
	{
		scale = (float *)bn_layer->model->param_blobs[0].data_gpu;
		shift = (float *)bn_layer->model->param_blobs[1].data_gpu;
		for (bi = 0; bi < ld->output_blobs_num; bi++)
		{
			blob_channel_num = ld->output_blobs[bi].shape[1];
			data_num_pre_channel = ld->output_blobs[bi].shape[2] * ld->output_blobs[bi].shape[3];

			for (ni = 0; ni < ld->output_blobs[bi].shape[0]; ni++)
			{
				float * in_data = (float *)ld->input_blobs[bi]->data_gpu + ni * blob_channel_num * data_num_pre_channel; //��ȡ����
				float * ou_data = (float *)ld->output_blobs[bi].data_gpu + ni * blob_channel_num * data_num_pre_channel; //��ȡ����

				cublas_status = cublasScopy_v2(cnn_cuda_handle->cublas_handle.cublas_handle, data_num_pre_channel*blob_channel_num, in_data, 1, ou_data, 1);
				CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "cnn_bn_forward_cuda cublasCcopy_v2 failed", CNN_convert_cublas_error_code(cublas_status));

				cnn_bn_cuda(data_num_pre_channel*blob_channel_num, data_num_pre_channel, scale, shift, ou_data);

				////��ͨ����������
				//for (ci = 0; ci < ld->output_blobs[bi].shape[1]; ci++)
				//{
				//	//�˳߶�
				//	////cublas_status = cublasScopy_v2(cnn_cuda_handle->cublas_handle.cublas_handle, data_num_pre_channel, in_data + ci*data_num_pre_channel, 1, ou_data + ci*data_num_pre_channel, 1);
				//	////CNN_CHECK_ERROR(cublas_status != CUBLAS_STATUS_SUCCESS, "cnn_bn_forward_cuda cublasCcopy_v2 failed", HIK_VCA_CNN_CUDA_ERROR);
				//	//cnn_scale_cuda_old(data_num_pre_channel, scale + ci, ou_data + ci*data_num_pre_channel);
				//	////cnn_scale_cuda(data_num_pre_channel, scale + ci, in_data + ci*data_num_pre_channel, ou_data + ci*data_num_pre_channel);
				//	////��bias
				//	//cnn_add_bias_cuda(data_num_pre_channel, shift + ci, ou_data + ci*data_num_pre_channel);

				//	cnn_scale_bias_cuda(data_num_pre_channel, scale + ci, shift + ci, ou_data + ci*data_num_pre_channel);
				//}
			}
		}
	}



	//CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_normalize_forward_cuda", hr);

	return HIK_VCA_LIB_S_OK;
}
#endif


/***************************************************************************************************
* ��  ��: BN��ǰ����,���ݸ�ʽΪNCHW
* ��  ��:
*         src                  - I      ����
*         dst                  - O      ���ݳ���
*         scale				   - I		scale
*         bias				   - I		bias
*         nc				   - I		NxC
*         hw				   - I		HxW
*         pitch_hw			   - I		pitch_hw
* ����ֵ: ƫ����ȡ���ֵ
***************************************************************************************************/
extern HRESULT CNN_BN_nchw_cuda(const void *src, void *dst, void *scale, void *bias, int n, int c, int hw, int pitch_hw, BLOB_DATA_TYPE type);


/***************************************************************************************************
* ��  �� : BN��ǰ����, ���ݸ�ʽΪCHWN - ZIP
* ��  �� :
*src - I      ����
*         dst - O      ���ݳ���
*         scale - I		scale
*         bias - I		bias
*         n - I		N
*         c - I		C
*         h - I		H
*         w - I		W
*         pad_zip_in - I       ���벹�߳��ȣ������ڲ����ݲ��������㣩
*         pad_zip_out - I       ������߳��ȣ������ڲ����ݲ��������㣩
*         type - I		��������
* ����ֵ: ƫ����ȡ���ֵ
***************************************************************************************************/
extern HRESULT CNN_BN_chwn_zip_cuda(const void *src, void *dst, void *scale, void *bias, 
                                    int n, int c, int h, int w,
                                    int pad_zip_in, int pad_zip_out, BLOB_DATA_TYPE type);

/***************************************************************************************************
* ��  ��: BN��ǰ����,���ݸ�ʽΪNCHW
* ��  ��:
*         src                  - I      ����
*         dst                  - O      ���ݳ���
*         scale				   - I		scale
*         bias				   - I		bias
*         nc				   - I		NxC
*         hw				   - I		HxW
*         pitch_hw			   - I		pitch_hw
* ����ֵ: ƫ����ȡ���ֵ
***************************************************************************************************/
extern  HRESULT CNN_BN_nchw_zip_cuda(const void          *src, 
                                     void                *dst, 
                                     void                *scale, 
                                     void                *bias, 
                                     int                 n,
                                     int                 c, 
                                     int                 hw,
                                     int                 pitch_hw, 
                                     BLOB_DATA_TYPE      type);


/***************************************************************************************************
* ��  ��: BN��ǰ�򴫲�(CUDA��)
* ��  ��:
*           tanh_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_BN_Forward_Cuda_Opt(BN_LAYER            *bn_layer,
                                LAYER_DATA          *ld)
{

    void            *scale;
    void            *bias;
    void            *input;
    void            *output;
    HRESULT          hr;
    int              bi, n, c, h, w;

    BLOB_DATA_FORMAT format = ld->output_blobs[0].format;
    BLOB_DATA_TYPE   type   = ld->output_blobs[0].type;

    scale                = bn_layer->model->param_blobs[0].data_gpu;
    bias                 = bn_layer->model->param_blobs[1].data_gpu;

    CNN_CHECK_ERROR(CNN_blob_format_support(format) == 0, 
                    "blob format not support",
                    HIK_VCA_CNN_MODEL_ERROR);

    CNN_CHECK_ERROR(ld->input_blobs[0]->format != ld->output_blobs[0].format, 
                    "format not the same", 
                    HIK_VCA_LIB_KEY_PARAM_ERR);

    if (type == CNN_DT_FLT16)
    {
        scale   = bn_layer->model->param_blobs[0].data_gpu_fp16;
        bias    = bn_layer->model->param_blobs[1].data_gpu_fp16;
    }

    n       = ld->output_blobs[0].shape[0];
    c       = ld->output_blobs[0].shape[1];
    h       = ld->output_blobs[0].shape[2];
    w       = ld->output_blobs[0].shape[3];

    input   = ld->input_blobs[0]->data_gpu;
    output  = ld->output_blobs[0].data_gpu;

    if (type == CNN_DT_FLT16)
    {
        input  = ld->input_blobs[0]->data_gpu_fp16;
        output = ld->output_blobs[0].data_gpu_fp16;
    }

    if (format == CNN_FORMAT_NCHW)
    {
        hr = CNN_BN_nchw_cuda(input,
                              output,
                              scale, 
                              bias, 
                              n, 
                              c,
                              h * w, 
                              h * w,
                              type);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_BN_nchw_cuda", hr);
    }
    else 
    {
#ifdef ARCH_SUPPORT_FP16
        hr = CNN_BN_chwn_zip_cuda(input,
                                  output,
                                  scale, 
                                  bias, 
                                  n, 
                                  c,
                                  h,
                                  w,
                                  ld->input_blobs[0]->pad.pad_h,
                                  ld->output_blobs[0].pad.pad_h,
                                  type);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_BN_chwn_zip_cuda", hr);
#else
        CNN_CHECK_ERROR(1, "not implement", CNN_CUDA_NOT_IMPLEMENT);
#endif
    }
    return HIK_VCA_LIB_S_OK;
}

#endif  // CNN_CUDA_OPT