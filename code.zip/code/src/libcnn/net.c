/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: net.c
* �ļ���ʶ: NET_C
* ժ    Ҫ: ������صĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-01-31
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include "net.h"
#include "mem_man.h"

#ifdef CNN_CUDA_OPT
#include "cnn_cuda_config.h"
#endif // CNN_CUDA_OPT

#ifdef OPT_TIMER
#include "opt_profile.h"
#endif

#include "cnn_half.h"
#include "input_layer.h"
#include "convolution_layer.h"
#include "pooling_layer.h"
#include "floor_pooling_layer.h"
#include "relu_layer.h"
#include "concat_layer.h"
#include "lrn_layer.h"
#include "dropout_layer.h"
#include "fully_connected_layer.h"
#include "softmax_layer.h"
#include "eltwise_layer.h"
#include "roi_pooling_layer.h"
#include "reshape_layer.h"
#include "proposal_layer.h"
#include "proposal_sdp_layer.h"
#include "hka_types.h"
#include "frout_layer.h"
#include "frout_sdp_layer.h"
#include "blob.h"
#include "tanh_layer.h"
#include "normalize_layer.h"
#include "bn_layer.h"
#include "net_ex.h"
#include "layer_base.h"

#ifdef CNN_PROFILE_LAYER
#define PROFILE_RELU_WITH_BIAS
#define CNN_PROFILE_LAYER_COUNT  100
#endif


void* zip_blob_address[MAX_OUTPUT_BLOBS][2];

#define         NET_CONV_HF_SIZE          (1)      // ��������horizontal fusion��kernel size��

// ��ʼ��LAYER_CONSTRUCTOR�ĺ�
#define NET_REGISTER_LAYER(layer_type,                                                   \
                           layer_get_modelmemsize, layer_createmodel,                    \
                           layer_get_memsize, layer_create, layer_forward,               \
                           layer_reshape, _in_place)                                     \
    {                                                                                    \
        LAYER_CONSTRUCTOR constructor;                                                   \
        if (layer_factory->layer_type_num >= CNN_MAX_LAYER_TYPE)                         \
        {                                                                                \
            return HIK_VCA_LIB_KEY_PARAM_ERR;                                            \
        }                                                                                \
        constructor.type             = # layer_type;                                     \
        constructor.get_modelmemsize = (LayerGetModelMemsizeFunc)layer_get_modelmemsize; \
        constructor.create_model     = (LayerCreateModelFunc)layer_createmodel;          \
        constructor.get_memsize      = (LayerGetMemsizeFunc)layer_get_memsize;           \
        constructor.create           = (LayerCreateFunc)layer_create;                    \
        constructor.forward          = (LayerForwardFunc)layer_forward;                  \
        constructor.reshape          = (LayerReshapeFunc)layer_reshape;                  \
        constructor.in_place         = _in_place;                                        \
        layer_factory->layer_constructor[layer_factory->layer_type_num] = constructor;   \
        layer_factory->layer_type_num++;                                                 \
    }

/***************************************************************************************************
* ��  ��: ��ʼ��layer����
* ��  ��: layer_factory          - O layer����
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_init_layer_factory(LAYER_FACTORY *layer_factory)
{
#ifdef CNN_CUDA_OPT
    LayerForwardFunc inp_forward       = CNN_INP_Forward_Cuda_Opt;
    LayerForwardFunc conv_forward      = CNN_CONV_Forward_Cuda_Opt;
    LayerForwardFunc pool_forward      = CNN_POOL_Forward_Cuda_Opt;
    LayerForwardFunc floor_pool_forward = CNN_FLOOR_POOL_Forward_Cuda_Opt;
    LayerForwardFunc relu_forward      = CNN_RELU_Forward_Cuda_Opt;
    LayerForwardFunc concat_forward    = CNN_CONCAT_Forward_Cuda_Opt;
    LayerForwardFunc lrn_forward       = CNN_LRN_Forward_Cuda_Opt;
    LayerForwardFunc dropout_forward   = CNN_DROPOUT_Forward_Cuda_Opt;
    LayerForwardFunc fc_forward        = CNN_FULLYCONNECTED_Forward_Cuda_Opt;
    LayerForwardFunc softmax_forward   = CNN_SOFTMAX_Forward_Cuda_Opt;
    LayerForwardFunc eltwise_forward   = CNN_ELTWISE_Forward_Cuda_Opt;
    LayerForwardFunc roipool_forward   = CNN_ROIPOOL_Forward_Cuda_Opt;
    LayerForwardFunc reshape_forward   = CNN_RESHAPE_Forward_Cuda_Opt;
    LayerForwardFunc proposal_forward  = CNN_PROPOSAL_Forward_Cuda_Opt;
    LayerForwardFunc proposal_sdp_forward = CNN_PROPOSAL_SDP_Forward_Cuda_Opt;
    LayerForwardFunc frout_forward     = CNN_FROUT_Forward_Cuda_Opt;
    LayerForwardFunc frout_sdp_forward = CNN_FROUT_SDP_Forward_Cuda_Opt;
    LayerForwardFunc tanh_forward      = CNN_TANH_Forward_Cuda_Opt;
    LayerForwardFunc normalize_forward = CNN_NORMALIZE_Forward_Cuda_Opt;
    LayerForwardFunc bn_forward        = CNN_BN_Forward_Cuda_Opt;
#else
    LayerForwardFunc inp_forward        = CNN_INP_Forward;
#ifdef CNN_NNPACK_OPT
    LayerForwardFunc conv_forward       = CNN_CONV_Forward_Nnpack;
#else
	LayerForwardFunc conv_forward       = CNN_CONV_Forward;
#endif
    LayerForwardFunc pool_forward       = CNN_POOL_Forward;
    LayerForwardFunc floor_pool_forward   = CNN_FLOOR_POOL_Forward;
    LayerForwardFunc relu_forward       = CNN_RELU_Forward;
    LayerForwardFunc concat_forward     = CNN_CONCAT_Forward;
    LayerForwardFunc lrn_forward        = CNN_LRN_Forward;
    LayerForwardFunc dropout_forward    = CNN_DROPOUT_Forward;
#ifdef CNN_NNPACK_OPT
    LayerForwardFunc fc_forward         = CNN_FULLYCONNECTED_Forward_Nnpack;
#else
	LayerForwardFunc fc_forward         = CNN_FULLYCONNECTED_Forward;
#endif
    LayerForwardFunc softmax_forward    = CNN_SOFTMAX_Forward;
    LayerForwardFunc eltwise_forward    = CNN_ELTWISE_Forward;
    LayerForwardFunc roipool_forward    = CNN_ROIPOOL_Forward;
    LayerForwardFunc reshape_forward    = CNN_RESHAPE_Forward;
    LayerForwardFunc proposal_forward   = CNN_PROPOSAL_Forward;
    LayerForwardFunc proposal_sdp_forward = CNN_PROPOSAL_SDP_Forward;
    LayerForwardFunc frout_forward      = CNN_FROUT_Forward;
    LayerForwardFunc frout_sdp_forward    = CNN_FROUT_SDP_Forward;
    LayerForwardFunc tanh_forward       = CNN_TANH_Forward;
    LayerForwardFunc normalize_forward  = CNN_NORMALIZE_Forward;
    LayerForwardFunc bn_forward         = CNN_BN_Forward;
#endif

    layer_factory->layer_type_num = 0;

    NET_REGISTER_LAYER(RpnProposal,
                       CNN_PROPOSAL_GetModelMemsize,
                       CNN_PROPOSAL_CreateModel,
                       CNN_PROPOSAL_GetMemsize,
                       CNN_PROPOSAL_Create,
                       proposal_forward,
                       CNN_PROPOSAL_Reshape,
                       0);
    NET_REGISTER_LAYER(RpnProposalSdp,
                       CNN_PROPOSAL_SDP_GetModelMemsize,
                       CNN_PROPOSAL_SDP_CreateModel,
                       CNN_PROPOSAL_SDP_GetMemsize,
                       CNN_PROPOSAL_SDP_Create,
                       proposal_sdp_forward,
                       CNN_PROPOSAL_SDP_Reshape,
                       0);
    NET_REGISTER_LAYER(Input,
                       CNN_INP_GetModelMemsize,
                       CNN_INP_CreateModel,
                       CNN_INP_GetMemsize,
                       CNN_INP_Create,
                       inp_forward,
                       CNN_INP_Reshape,
                       1);
    NET_REGISTER_LAYER(Convolution,
                       CNN_CONV_GetModelMemsize,
                       CNN_CONV_CreateModel,
                       CNN_CONV_GetMemsize,
                       CNN_CONV_Create,
                       conv_forward,
                       CNN_CONV_Reshape,
                       0);
    NET_REGISTER_LAYER(Pooling,
                       CNN_POOL_GetModelMemsize,
                       CNN_POOL_CreateModel,
                       CNN_POOL_GetMemsize,
                       CNN_POOL_Create,
                       pool_forward,
                       CNN_POOL_Reshape,
                       0);
    NET_REGISTER_LAYER(FloorPooling,
                       CNN_FLOOR_POOL_GetModelMemsize,
                       CNN_FLOOR_POOL_CreateModel,
                       CNN_FLOOR_POOL_GetMemsize,
                       CNN_FLOOR_POOL_Create,
                       floor_pool_forward,
                       CNN_FLOOR_POOL_Reshape,
                       0);
    NET_REGISTER_LAYER(ReLU,
                       CNN_RELU_GetModelMemsize,
                       CNN_RELU_CreateModel,
                       CNN_RELU_GetMemsize,
                       CNN_RELU_Create,
                       relu_forward,
                       CNN_RELU_Reshape,
                       1);
    NET_REGISTER_LAYER(Concat,
                       CNN_CONCAT_GetModelMemsize,
                       CNN_CONCAT_CreateModel,
                       CNN_CONCAT_GetMemsize,
                       CNN_CONCAT_Create,
                       concat_forward,
                       CNN_CONCAT_Reshape,
                       0);
    NET_REGISTER_LAYER(LRN,
                       CNN_LRN_GetModelMemsize,
                       CNN_LRN_CreateModel,
                       CNN_LRN_GetMemsize,
                       CNN_LRN_Create,
                       lrn_forward,
                       CNN_LRN_Reshape,
                       0);
    NET_REGISTER_LAYER(Dropout,
                       CNN_DROPOUT_GetModelMemsize,
                       CNN_DROPOUT_CreateModel,
                       CNN_DROPOUT_GetMemsize,
                       CNN_DROPOUT_Create,
                       dropout_forward,
                       CNN_DROPOUT_Reshape,
                       1);
    NET_REGISTER_LAYER(InnerProduct,
                       CNN_FULLYCONNECTED_GetModelMemsize,
                       CNN_FULLYCONNECTED_CreateModel,
                       CNN_FULLYCONNECTED_GetMemsize,
                       CNN_FULLYCONNECTED_Create,
                       fc_forward,
                       CNN_FULLYCONNECTED_Reshape,
                       0);
    NET_REGISTER_LAYER(Softmax,
                       CNN_SOFTMAX_GetModelMemsize,
                       CNN_SOFTMAX_CreateModel,
                       CNN_SOFTMAX_GetMemsize,
                       CNN_SOFTMAX_Create,
                       softmax_forward,
                       CNN_SOFTMAX_Reshape,
                       0);
    NET_REGISTER_LAYER(Eltwise,
                       CNN_ELTWISE_GetModelMemsize,
                       CNN_ELTWISE_CreateModel,
                       CNN_ELTWISE_GetMemsize,
                       CNN_ELTWISE_Create,
                       eltwise_forward,
                       CNN_ELTWISE_Reshape,
                       0);
    NET_REGISTER_LAYER(ROIPooling,
                       CNN_ROIPOOL_GetModelMemsize,
                       CNN_ROIPOOL_CreateModel,
                       CNN_ROIPOOL_GetMemsize,
                       CNN_ROIPOOL_Create,
                       roipool_forward,
                       CNN_ROIPOOL_Reshape,
                       0);
    NET_REGISTER_LAYER(Reshape,
                       CNN_RESHAPE_GetModelMemsize,
                       CNN_RESHAPE_CreateModel,
                       CNN_RESHAPE_GetMemsize,
                       CNN_RESHAPE_Create,
                       reshape_forward,
                       CNN_RESHAPE_Reshape,
                       1);
    NET_REGISTER_LAYER(FrcnOutput,
                       CNN_FROUT_GetModelMemsize,
                       CNN_FROUT_CreateModel,
                       CNN_FROUT_GetMemsize,
                       CNN_FROUT_Create,
                       frout_forward,
                       CNN_FROUT_Reshape,
                       0);
    NET_REGISTER_LAYER(FrcnOutputSdp,
                       CNN_FROUT_SDP_GetModelMemsize,
                       CNN_FROUT_SDP_CreateModel,
                       CNN_FROUT_SDP_GetMemsize,
                       CNN_FROUT_SDP_Create,
                       frout_sdp_forward,
                       CNN_FROUT_SDP_Reshape,
                       0);
    NET_REGISTER_LAYER(TanH,
		               CNN_TANH_GetModelMemsize,
		               CNN_TANH_CreateModel,
		               CNN_TANH_GetMemsize,
		               CNN_TANH_Create,
		               tanh_forward,
		               CNN_TANH_Reshape,
		               1);
	NET_REGISTER_LAYER(Normalize,
					   CNN_NORMALIZE_GetModelMemsize,
		               CNN_NORMALIZE_CreateModel,
		               CNN_NORMALIZE_GetMemsize,
		               CNN_NORMALIZE_Create,
		               normalize_forward,
		               CNN_NORMALIZE_Reshape,
		               1);
	NET_REGISTER_LAYER(BN,
		               CNN_BN_GetModelMemsize,
		               CNN_BN_CreateModel,
		               CNN_BN_GetMemsize,
		               CNN_BN_Create,
		               bn_forward,
		               CNN_BN_Reshape,
		               0);

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ȡĳ�������
* ��  ��: 
*         net                    - I ���綨��
*         layer_index            - I ������
* ����ֵ: ���������Ϊlayer type������ΪNULL
***************************************************************************************************/
const char *CNN_NET_GetLayerType(NET *net,
                                 int  layer_index)
{
    if (layer_index < 0)
    {
        layer_index += net->layer_num;
    }

    HKA_CHECK_ERROR(layer_index < 0, NULL);
    HKA_CHECK_ERROR(layer_index >= net->layer_num, NULL);

    return &net->layers[layer_index].layer_model->type;
}

/***************************************************************************************************
* ��  ��: ��ȡĳ�������
* ��  ��:
*         net                    - I ���綨��
*         layer_index            - I ������
* ����ֵ: ���������Ϊlayer type������ΪNULL
***************************************************************************************************/
const char *CNN_NET_GetLayerName(NET *net,
                                 int  layer_index)
{
    if (layer_index < 0)
    {
        layer_index += net->layer_num;
    }

    HKA_CHECK_ERROR(layer_index < 0, NULL);
    HKA_CHECK_ERROR(layer_index >= net->layer_num, NULL);

    return &net->layers[layer_index].layer_model->name;
}


/***************************************************************************************************
* ��  ��: ���ݲ����������LAYER_DATA������и��ĺ���
* ��  ��: layer_factory          - I   layer����
*         ld                     - I/O layer����
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_set_layer_func(const LAYER_FACTORY *layer_factory,
                               LAYER_MODEL         *ld)
{
    HKA_S32                  type_idx;
    const LAYER_CONSTRUCTOR *constructor;

    for (type_idx = 0; type_idx < layer_factory->layer_type_num; type_idx++)
    {
        constructor = &layer_factory->layer_constructor[type_idx];
        if (strcmp(constructor->type, ld->type) == 0)
        {
            ld->create_model     = constructor->create_model;
            ld->get_modelmemsize = constructor->get_modelmemsize;
            ld->create           = constructor->create;
            ld->get_memsize      = constructor->get_memsize;
            ld->forward          = constructor->forward;
            ld->reshape          = constructor->reshape;
            ld->in_place         = constructor->in_place;

            return HIK_VCA_LIB_S_OK;
        }
    }

    return HIK_VCA_LIB_KEY_PARAM_ERR;
}

/***************************************************************************************************
* ��  ��: ���LAYER_PIN�Ƿ���Ч
* ��  ��: layer_pin              - I layer�������Ϣ
* ����ֵ: 0����Ч��1����Ч
***************************************************************************************************/
int CNN_NET_check_layer_pin_valid(LAYER_PIN layer_pin)
{
    return ((layer_pin.lid >= 1) && (layer_pin.oid >= 0));
}

/***************************************************************************************************
* ��  ��: �������LAYER_PIN�Ƿ����
* ��  ��: layer_pin1             - I layer�������Ϣ
*         layer_pin2             - I layer�������Ϣ
* ����ֵ: 0������ȣ�1�����
***************************************************************************************************/
int CNN_NET_check_layer_pin_equal(LAYER_PIN layer_pin1,
                                  LAYER_PIN layer_pin2)
{
    return ((layer_pin1.lid == layer_pin2.lid) && (layer_pin1.oid == layer_pin2.oid));
}

/***************************************************************************************************
* ��  ��: ����Ԫ�ص�������
* ��  ��: s                      - I/O ����
*         ele                    - I   Ԫ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_add_to_set(CNN_SET_I *set,
                           int        ele)
{
    int i;

    if (set->ele_num >= MAX_SET_I_ELE_NUM)
    {
        return HIK_VCA_LIB_E_MEM_OUT;
    }

    for (i = 0; i < set->ele_num; i++)
    {
        if (set->elements[i] == ele)
        {
            return HIK_VCA_LIB_S_OK;
        }
    }

    set->elements[set->ele_num] = ele;
    set->ele_num++;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ���BLOB_NOTE
* ��  ��: name                   - I ����
*         layer_id               - I layer��id
*         out_num                - I ���blob�����
*         blobnote               - I BLOB_NOTEָ��
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_fill_blobnote(const char *name,
                           int         layer_id,
                           int         out_num,
                           BLOB_NOTE  *blobnote)
{
    blobnote->name     = (const HKA_S08 *)name;
    blobnote->layer_id = layer_id;
    blobnote->out_num  = out_num;
}

/***************************************************************************************************
* ��  ��: ��ȡ�����ܲ���
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: �����ܲ���
***************************************************************************************************/
int CNN_NET_get_layersize(char  *ptr,
                          char **ptr_next)
{
    int layer_size = *(int *)ptr;

    *ptr_next = ptr + sizeof(int);
    return layer_size;
}

/***************************************************************************************************
* ��  ��: ������һ�������
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: ��һ������ݵ���ʼ��ַ
***************************************************************************************************/
const char *CNN_NET_get_layer(char  *ptr,
                              char **ptr_next)
{
    const char layer_identifier[] = "layer:";

    if (strncmp(ptr, layer_identifier, strlen(layer_identifier)) == 0)
    {
        *ptr_next = ptr + strlen(layer_identifier);
        return ptr + strlen(layer_identifier);
    }
    return NULL;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer������
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer������
***************************************************************************************************/
const char *CNN_NET_get_layer_name(char  *ptr,
                                   char **ptr_next)
{
    *ptr_next = ptr + strlen(ptr) + 1;
    return ptr;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer������
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer������
***************************************************************************************************/
const char *CNN_NET_get_layer_type(char  *ptr,
                                   char **ptr_next)
{
    *ptr_next = ptr + strlen(ptr) + 1;
    return ptr;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer��hyperparams
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer��hyperparams
***************************************************************************************************/
const char *CNN_NET_get_layer_hyperparams(char  *ptr,
                                          char **ptr_next)
{
    char      *tmp_ptr;
    const char hyperparams_identifier[] = "hyperparams:";

    if (strncmp(ptr, hyperparams_identifier, strlen(hyperparams_identifier)) == 0)
    {
        tmp_ptr   = ptr + strlen(hyperparams_identifier);
        *ptr_next = tmp_ptr + sizeof(int) + (*(int *)tmp_ptr);
        return tmp_ptr + sizeof(int);
    }
    return NULL;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer�Ĳ���
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer�Ĳ���
***************************************************************************************************/
const char *CNN_NET_get_layer_paramsblobs(char  *ptr,
                                          char **ptr_next)
{
    char      *tmp_ptr;
    const char hyperparams_identifier[] = "paramblobs:";

    if (strncmp(ptr, hyperparams_identifier, strlen(hyperparams_identifier)) == 0)
    {
        tmp_ptr   = ptr + strlen(hyperparams_identifier);
        *ptr_next = tmp_ptr + sizeof(int) + (*(int *)tmp_ptr);
        return tmp_ptr + 4;
    }
    return NULL;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer������blob����
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer������blob����
***************************************************************************************************/
int CNN_NET_get_layer_bottom_size(char  *ptr,
                                  char **ptr_next)
{
    char      *tmp_ptr;
    const char bottom_identifier[] = "bottom:";

    if (strncmp(ptr, bottom_identifier, strlen(bottom_identifier)) == 0)
    {
        tmp_ptr   = ptr + strlen(bottom_identifier);
        *ptr_next = tmp_ptr + sizeof(int);
        return *(int *)tmp_ptr;
    }
    return 0;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer������blob����
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer������blob����
***************************************************************************************************/
const char *CNN_NET_get_layer_input_name(char  *ptr,
                                         char **ptr_next)
{
    *ptr_next = ptr + strlen(ptr) + 1;
    return ptr;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer�����blob����
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer�����blob����
***************************************************************************************************/
int CNN_NET_get_layer_top_size(char  *ptr,
                               char **ptr_next)
{
    char      *tmp_ptr;
    const char top_identifier[] = "top:";

    if (strncmp(ptr, top_identifier, strlen(top_identifier)) == 0)
    {
        tmp_ptr   = ptr + strlen(top_identifier);
        *ptr_next = tmp_ptr + sizeof(int);
        return *(int *)tmp_ptr;
    }
    return 0;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer�����blob����
* ��  ��: ptr                    - I ��������ָ��
*         ptr_next               - O ����������ݵĺ�һ��λ��
* ����ֵ: layer�����blob����
***************************************************************************************************/
const char *CNN_NET_get_layer_output_name(char  *ptr,
                                          char **ptr_next)
{
    *ptr_next = ptr + strlen(ptr) + 1;
    return ptr;
}

/***************************************************************************************************
* ��  ��: ��NET������һ��layer
* ��  ��: net                    - I/O NET��ָ��
*         name                   - I   layer������
*         type                   - I   layer������
*         hyperparams            - I   layer�ĳ�����
*         param_blobs            - I   layer�Ĳ���
* ����ֵ: -1: ���������������������ʧ�ܣ�
*          0: ��֧�ָ����͵�layer��
*       ����: ���ӵ�layer��id
***************************************************************************************************/
int CNN_NET_add_layer(NET_MODEL  *net,
                      const char *name,
                      const char *type,
                      const char *hyperparams,
                      const char *param_blobs)
{
    HRESULT      hr;
    int          layer_id = net->next_layer_id;
    LAYER_MODEL *layer    = &net->layers[net->layer_num];

    HKA_CHECK_ERROR(net->layer_num >= CNN_MAX_LAYER_NUM, -1);

    net->next_layer_id++;
    net->layer_num++;

    memset(layer, 0, sizeof(LAYER_MODEL));

    layer->id = layer_id;

    CNN_CHECK_ERROR(strlen(name) >= MAX_STRING_LENGTH,
                    "Error: layer name too long",
                    HIK_VCA_CNN_MODEL_ERROR);

    strcpy(layer->name, name);

    CNN_CHECK_ERROR(strlen(type) >= MAX_STRING_LENGTH,
                    "Error: layer type name too long",
                    HIK_VCA_CNN_MODEL_ERROR);

    strcpy(layer->type, type);

    layer->hyperparams = hyperparams;
    layer->param_blobs = param_blobs;

    hr = CNN_NET_set_layer_func(&net->layer_factory, layer);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, 0);

    return layer_id;
}


/***************************************************************************************************
* ��  ��: ����id���Ҷ�Ӧ��LAYER_DATA
* ��  ��: net                    - I NETָ��
*         id                     - I layer id
* ����ֵ: NULL: �����ڣ�����Ϊ��Ӧ��LAYER_DATA��ָ��
***************************************************************************************************/
LAYER_MODEL *CNN_NET_get_layer_model(NET_MODEL *net_model,
                                     int        id)
{
    int idx;

    for (idx = 0; idx < net_model->layer_num; idx++)
    {
        if (net_model->layers[idx].id == id)
        {
            return &net_model->layers[idx];
        }
    }

    return NULL;
}

/***************************************************************************************************
* ��  ��: ����id���Ҷ�Ӧ��LAYER_DATA
* ��  ��: net                    - I NETָ��
*         id                     - I layer id
* ����ֵ: NULL: �����ڣ�����Ϊ��Ӧ��LAYER_DATA��ָ��
***************************************************************************************************/
LAYER_DATA *CNN_NET_get_layer_data(NET *net,
                                   int  id)
{
    int idx;

    for (idx = 0; idx < net->layer_num; idx++)
    {
        if (net->layers[idx].layer_model->id == id)
        {
            return &net->layers[idx];
        }
    }

    return NULL;
}

/***************************************************************************************************
* ��  ��: ����idΪlayer_id�Ĳ����ڵ����
* ��  ��: net                    - I/O NETָ��
*         layer_id               - I   ���id
* ����ֵ: -1��δ�ҵ���>=0�����
***************************************************************************************************/
int CNN_NET_get_layer_index(NET *net,
                            int  layer_id)
{
    int         li, layersSize;
    LAYER_DATA *layer;

    layersSize = net->layer_num;

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];
        if (layer->id == layer_id)
        {
            return li;
        }
    }

    return -1;
}

/***************************************************************************************************
* ��  ��: �Բ�����������������1
* ��  ��: net                    - I/O NETָ��
*         lm                     - I   ���ģ������
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_inc_required_layer_num(NET_MODEL   *net,
                                    LAYER_MODEL *lm)
{
    int i;

    if (0 == lm->in_place)
    {
        lm->required_layer_num++;
    }
    else
    {
        for (i = 0; i < lm->input_layers_id.ele_num; i++)
        {
            int          input_layer_id = lm->input_layers_id.elements[i];
            LAYER_MODEL *layer          = CNN_NET_get_layer_model(net, input_layer_id);

            CNN_NET_inc_required_layer_num(net, layer);
        }
    }
}

/***************************************************************************************************
* ��  ��: �Բ�����������������1
* ��  ��: net                    - I/O NETָ��
*         lm                     - I   ���ģ������
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_inc_required_layer_num_ld(NET        *net,
                                       LAYER_DATA *ld)
{
    int          i;
    LAYER_MODEL *lm = ld->layer_model;

    if (0 == lm->in_place)
    {
        ld->required_layer_num++;
    }
    else
    {
        for (i = 0; i < lm->input_layers_id.ele_num; i++)
        {
            int         input_layer_id = lm->input_layers_id.elements[i];
            LAYER_DATA *layer          = CNN_NET_get_layer_data(net, input_layer_id);

            CNN_NET_inc_required_layer_num_ld(net, layer);
        }
    }
}

/***************************************************************************************************
* ��  ��: �Բ�����������������1
* ��  ��: net                    - I/O NETָ��
*         ld                     - I   ������
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_dec_required_layer_num(NET        *net,
                                    LAYER_DATA *ld)
{
    int i;

    ld->required_layer_num--;

    if (1 == ld->layer_model->in_place)
    {
        for (i = 0; i < ld->layer_model->input_layers_id.ele_num; i++)
        {
            int         input_layer_id = ld->layer_model->input_layers_id.elements[i];
            LAYER_DATA *layer          = CNN_NET_get_layer_data(net, input_layer_id);

            CNN_NET_dec_required_layer_num(net, layer);
        }
    }
}

#ifdef CNN_CONCAT_OPT
void CNN_NET_dec_feed_concat_required_layer_num(NET        *net,
                                                LAYER_DATA *ld)
{
    int i;
    int feed_to_concat = 0;

    for (i = 0; i < MAX_OUTPUT_BLOBS; i++)
    {
        feed_to_concat |= ld->layer_model->feed_to_concat[i];
    }

    ld->required_layer_num--;

    if ((1 == ld->layer_model->in_place) || feed_to_concat)
    {
        for (i = 0; i < ld->layer_model->input_layers_id.ele_num; i++)
        {
            int         input_layer_id = ld->layer_model->input_layers_id.elements[i];
            LAYER_DATA *layer = CNN_NET_get_layer_data(net, input_layer_id);

            CNN_NET_dec_feed_concat_required_layer_num(net, layer);
        }
    }
}

void CNN_NET_set_feed_to_concat(NET_MODEL    *net,
                                LAYER_MODEL *ld_out, 
                                int         out_num)
{
    if (0 == ld_out->in_place)
    {
        ld_out->feed_to_concat[out_num] = 1;
    }
    else
    {
        // ����in-place�����Ĳ㣬��feed_to_concatҪ���ݵ�����ʵ����blob

        LAYER_PIN   layer_pin = ld_out->input_blobs_id[out_num];
        LAYER_MODEL *layer = CNN_NET_get_layer_model(net, layer_pin.lid);

        CNN_NET_set_feed_to_concat(net, layer, layer_pin.oid);
    }
}
#endif


/***************************************************************************************************
* ��  ��: ������������ϵ����
* ��  ��: net                    - I/O NETָ��
*         out_layer_id           - I   ���layer��id
*         out_num                - I   �����blob�����
*         in_layer_id            - I   ����layer��id
*         in_num                 - I   �����blob�����
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_connect(NET_MODEL *net,
                        int        out_layer_id,
                        int        out_num,
                        int        in_layer_id,
                        int        in_num)
{
    HRESULT      hr;
    LAYER_MODEL *ld_out = CNN_NET_get_layer_model(net, out_layer_id);
    LAYER_MODEL *ld_in  = CNN_NET_get_layer_model(net, in_layer_id);
    LAYER_PIN    from   = { out_layer_id, out_num };

    if (in_num >= MAX_INPUT_BLOBS)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

    if (ld_in->input_blobs_num <= in_num)
    {
        ld_in->input_blobs_num = in_num + 1;
    }
    else
    {
        LAYER_PIN storedFrom = ld_in->input_blobs_id[in_num];
        if (CNN_NET_check_layer_pin_valid(storedFrom) && (!CNN_NET_check_layer_pin_equal(storedFrom, from)))
        {
            return HIK_VCA_CNN_MODEL_ERROR;
        }
    }

    ld_in->input_blobs_id[in_num] = from;

    hr = CNN_NET_add_to_set(&ld_in->input_layers_id, from.lid);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    hr = CNN_NET_add_to_set(&ld_out->required_outputs, out_num);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

#ifdef CNN_CONCAT_OPT
    if (strcmp(ld_in->type, "Concat") == 0)
    {
        CNN_NET_set_feed_to_concat(net, ld_out, out_num);
    }
#endif

    CNN_NET_inc_required_layer_num(net, ld_out);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����һ�����룬�������������Ӧ�������ϵ����
* ��  ��: input_name             - I   ����blob������
*         layer_id               - I   ����layer��id
*         in_num                 - I   ����blob�����
*         net                    - I/O NET��ָ��
*         blobnotes              - I   ���е����blob����Ϣ
*         blobnote_num           - I   BLOB_NOTE�ĸ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_add_input(const char *input_name,
                          int         layer_id,
                          int         in_num,
                          NET_MODEL  *net,
                          BLOB_NOTE  *blobnotes,
                          int         blobnote_num)
{
    int idx;

    for (idx = blobnote_num - 1; idx >= 0; idx--)
    {
        if (strcmp(blobnotes[idx].name, input_name) == 0)
        {
            break;
        }
    }

    HKA_CHECK_ERROR(idx < 0, HIK_VCA_CNN_MODEL_ERROR);

    return CNN_NET_connect(net, blobnotes[idx].layer_id, blobnotes[idx].out_num, layer_id, in_num);
}

/***************************************************************************************************
* ��  ��: �����blob����Ϣ���ӵ�BLOB_NOTE������
* ��  ��: output_name            - I   ���blob������
*         layer_id               - I   ���blob��layer��id
*         out_num                - I   ���blob�����
*         blobnotes              - I/O BLOB_NOTEָ��
*         blobnote_num           - I/O �������ǰ��BLOB_NOTE������������º��BLOB_NOTE����
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_add_output(const char *output_name,
                        int         layer_id,
                        int         out_num,
                        BLOB_NOTE  *blobnotes,
                        int        *blobnote_num)
{
    CNN_NET_fill_blobnote(output_name, layer_id, out_num, &blobnotes[*blobnote_num]);
    (*blobnote_num)++;
}

/***************************************************************************************************
* ��  ��: ����model������
* ��  ��: net                    - I ����
*         ptr                    - I ģ������ָ��
*         ptr_next               - O �����ֵ���ݺ��ģ������ָ��λ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_LoadName(NET_MODEL   *net,
                         char        *ptr,
                         char       **ptr_next)
{
    int        len = 0;
    const char name_identifier[] = "name:";
    memset(net->name, 0, MAX_STRING_LENGTH);
    if (strncmp(ptr, name_identifier, strlen(name_identifier)) == 0)
    {
        ptr = ptr + strlen(name_identifier);
        len = *(int*)ptr;
        ptr = ptr + sizeof(int);
        CNN_CHECK_ERROR(len >= MAX_STRING_LENGTH,
                        "Error: model name too long", 
                        HIK_VCA_CNN_MODEL_ERROR);
        strncpy(net->name, ptr, len);
        *ptr_next = ptr + len;
    }
    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ���ؾ�ֵ����
* ��  ��: net                    - I ����
*         ptr                    - I ģ������ָ��
*         ptr_next               - O �����ֵ���ݺ��ģ������ָ��λ��
*         copy_data              - I �Ƿ񿽱����ݵ�mean_blob��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_LoadMean(NET_MODEL *net,
                         char      *ptr,
                         char     **ptr_next,
                         int        copy_data)
{
    int        mean_value_n;
    int        mean_file_size;
    int        blob_channels;
    int        blob_height;
    int        blob_width;
    const char mean_value_identifier[] = "mean_value:";
    const char mean_file_identifier[]  = "mean_file:";

    net->mean_val_or_file = 0;
    net->mean_blob.ndims  = 4;
    net->mean_blob.type   = CNN_DT_FLT32;           // ��ֵʼ����float
    memset(net->mean_blob.shape, 0, sizeof(net->mean_blob.shape[0]) * CNN_BLOB_MAX_DIM);

    if (strncmp(ptr, mean_value_identifier, strlen(mean_value_identifier)) == 0)
    {
        ptr          = ptr + strlen(mean_value_identifier);
        mean_value_n = *(int *)ptr;

        net->mean_val_or_file = 1;

        net->mean_blob.shape[0] = 1;
        net->mean_blob.shape[1] = mean_value_n;
        net->mean_blob.shape[2] = 1;
        net->mean_blob.shape[3] = 1;

        ptr += sizeof(int);
        if (copy_data)
        {
            memcpy(net->mean_blob.data, ptr, mean_value_n * data_type_size[net->mean_blob.type]);
        }

        *ptr_next = ptr + mean_value_n * data_type_size[net->mean_blob.type];
    }
    else if (strncmp(ptr, mean_file_identifier, strlen(mean_file_identifier)) == 0)
    {
        ptr = ptr + strlen(mean_file_identifier);

        mean_file_size = *(int *)ptr;
        ptr           += sizeof(int);

        blob_channels = *(int *)ptr;
        ptr          += sizeof(int);

        blob_height = *(int *)ptr;
        ptr        += sizeof(int);

        blob_width = *(int *)ptr;
        ptr       += sizeof(int);

        net->mean_val_or_file = 2;

        net->mean_blob.shape[0] = 1;
        net->mean_blob.shape[1] = blob_channels;
        net->mean_blob.shape[2] = blob_height;
        net->mean_blob.shape[3] = blob_width;

        CNN_CHECK_ERROR(mean_file_size != CNN_BLOB_GetDataSize(&net->mean_blob),
                        "mean_file_size != mean_blob_size",
                        HIK_VCA_CNN_MODEL_ERROR);

        if (copy_data)
        {
            memcpy(net->mean_blob.data, ptr, mean_file_size);
        }

        *ptr_next = ptr + mean_file_size;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����scale��ֵ
* ��  ��: net                    - I ����
*         ptr                    - I ģ������ָ��
*         ptr_next               - O �����ֵ���ݺ��ģ������ָ��λ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_LoadScale(NET_MODEL *net,
                          char      *ptr,
                          char     **ptr_next)
{
    const char scale_identifier[] = "scale:";

    net->scale = 1.0f;

    if (strncmp(ptr, scale_identifier, strlen(scale_identifier)) == 0)
    {
        ptr        = ptr + strlen(scale_identifier);
        net->scale = *(float *)ptr;

        *ptr_next = ptr + sizeof(float);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ������blob��Ϣ�Ƿ���ȷ
* ��  ��: net                    - I NET���
* ����ֵ: ����״̬��
***************************************************************************************************/
HRESULT CNN_check_out_blobinfo(NET *net)
{
    int i;
    int layer_index;
    int blob_idx;

    for (i = 0; i < net->blob_num; i++)
    {
        layer_index = net->out_blob_info[i].layer_idx;
        blob_idx    = net->out_blob_info[i].blob_idx;

        // ���layer_index
        if (layer_index < 0)
        {
            layer_index += net->layer_num;
        }
        HKA_CHECK_ERROR(layer_index < 0, HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(layer_index >= net->layer_num, HIK_VCA_LIB_KEY_PARAM_ERR);

        // ���blob_idx
        if (blob_idx < 0)
        {
            blob_idx += net->layers[layer_index].output_blobs_num;
        }
        HKA_CHECK_ERROR(blob_idx < 0, HIK_VCA_LIB_KEY_PARAM_ERR);
        HKA_CHECK_ERROR(blob_idx >= net->layers[layer_index].output_blobs_num,
                        HIK_VCA_LIB_KEY_PARAM_ERR);

        net->out_blob_info[i].layer_idx = layer_index;
        net->out_blob_info[i].blob_idx  = blob_idx;
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: �������о���������pad
* ��  ��: 
*         net_model                    - I/O ����ģ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_set_net_pad(NET_MODEL *net_model)
{
    int                 layer_num = net_model->layer_num;
    int                 li;
    int                 kernel_h, kernel_w;
    CONVOLUTION_MODEL   *conv_layer_model;
    int                 pad_h, pad_w;
    int                 max_pad = 0;

    net_model->net_pad.pad_h    = 0;
    net_model->net_pad.pad_w    = 0;

    for (li = 0; li < layer_num; li++)
    {
        if (strcmp(net_model->layers[li].type, "Convolution") == 0)
        {
            conv_layer_model    = (CONVOLUTION_MODEL *)net_model->layers[li].model_handle;
            kernel_h            = conv_layer_model->ker_h;
            kernel_w            = conv_layer_model->ker_w;

            pad_h               = CNN_get_pad(kernel_h);
            pad_w               = CNN_get_pad(kernel_w);

            max_pad             = HKA_MAX(max_pad, pad_h);
            max_pad             = HKA_MAX(max_pad, pad_w);
        }
    }

#ifdef ARCH_SUPPORT_FP16
    net_model->net_pad.pad_h    = max_pad;
    net_model->net_pad.pad_w    = max_pad;
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ʼ��NET�е���������Ϣ
* ��  ��: model                  - I ģ������
*         net                    - O �����ʼ���������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_InitModel(char      *model,
                          NET_MODEL *net_model)
{
    int          i, li;
    int          id;
    int          in_num;
    int          out_num;
    int          top_size;
    int          layersSize;
    int          bottom_size;
    int          blobnote_num = 0;
    HRESULT      hr;
    const char  *name;
    const char  *type;
    const char  *hyperparams;
    const char  *paramblobs;
    BLOB_NOTE    blobnotes[CNN_MAX_LAYER_NUM * MAX_OUTPUT_BLOBS];
    LAYER_MODEL *layer;
    char        *ptr;
    const char  *layer_ptr;
	
printf("00\n");

    CNN_NET_init_layer_factory(&net_model->layer_factory);

    // start from 1, so 0 is invalid(for convenience of check_layer_pin_valid)
    net_model->next_layer_id = 1;

    net_model->layer_num = 0;

    ptr        = model;
    layersSize = CNN_NET_get_layersize(ptr, &ptr);
    HKA_CHECK_ERROR(0 == layersSize, HIK_VCA_CNN_MODEL_ERROR);
	
printf("11\n");

    for (li = 0; li < layersSize; li++)
    {
        //printf("Li: %d\n", li);
        layer_ptr = CNN_NET_get_layer(ptr, &ptr);
        HKA_CHECK_ERROR(NULL == layer_ptr, HIK_VCA_CNN_MODEL_ERROR);
        //printf("m0\n");
        name        = CNN_NET_get_layer_name(ptr, &ptr);
        type        = CNN_NET_get_layer_type(ptr, &ptr);
        hyperparams = CNN_NET_get_layer_hyperparams(ptr, &ptr);
        paramblobs  = CNN_NET_get_layer_paramsblobs(ptr, &ptr);

        id = CNN_NET_add_layer(net_model, name, type, hyperparams, paramblobs);
        HKA_CHECK_ERROR(id <= 0, HIK_VCA_CNN_MODEL_ERROR);
        //printf("m1\n");
        bottom_size = CNN_NET_get_layer_bottom_size(ptr, &ptr);
        for (in_num = 0; in_num < bottom_size; in_num++)
        {
            hr = CNN_NET_add_input(CNN_NET_get_layer_input_name(ptr, &ptr), id, in_num, net_model, blobnotes, blobnote_num);
            HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
        }

        //printf("m2\n");
        //printf("input_blob_num: %d ", net_model->layers[li].input_blobs_num);
        //
        //for (i = 0; i < net_model->layers[li].input_blobs_num; i++)
        //{
        //    printf("%d %d ", net_model->layers[li].input_blobs_id[i].lid, net_model->layers[li].input_blobs_id[i].oid);
        //}
        //
        //printf("\n");

        top_size = CNN_NET_get_layer_top_size(ptr, &ptr);
        for (out_num = 0; out_num < top_size; out_num++)
        {
            CNN_NET_add_output(CNN_NET_get_layer_output_name(ptr, &ptr), id, out_num, blobnotes, &blobnote_num);
        }
		//printf("m3\n");
        net_model->layers[li].output_blobs_num = top_size;
    }

    // ��Ҫ�ڳ�ʼ�����������������ZIP�㣬�޷��ɵ�����Ϣȷ��
    //hr = CNN_init_zip_model(net_model);
    //CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_ZIP_init_model", hr);

    if (strcmp(net_model->layers[0].type, "Input") != 0)
    {
        return HIK_VCA_CNN_MODEL_ERROR;
    }

printf("22\n");

    // check parent layers
    for (li = 0; li < layersSize; li++)
    {
        layer = &net_model->layers[li];
        for (in_num = 0; in_num < layer->input_blobs_num; in_num++)
        {
            if (layer->input_blobs_id[in_num].lid >= layer->id)
            {
                return HIK_VCA_CNN_MODEL_ERROR; // inputs' layer's id must < current layer's id
            }
        }
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��ʼ��NET�е���������Ϣ
* ��  ��: model                  - I ģ������
*         net                    - O �����ʼ���������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_Init(NET_MODEL *net_model,
                     NET       *net)
{
    int          i, li;
    int          id;
    int          in_num;
    int          out_num;
    int          layersSize;
    int          blobnote_num = 0;
    HRESULT      hr;
    const char  *type;
    const char  *hyperparams;
    const char  *paramblobs;
    LAYER_DATA  *layer;
    LAYER_MODEL *layer_model;
    char        *ptr;
    const char  *layer_ptr;

    layersSize     = net_model->layer_num;
    net->layer_num = net_model->layer_num;

    net->net_model = net_model;
	
printf("A %d  %d \n",
	net->in_blob_num, net_model->layers[li].output_blobs_num);

    for (li = 0; li < layersSize; li++)
    {
        net->layers[li].id = net_model->layers[li].id;

        net->layers[li].input_blobs_num    = net_model->layers[li].input_blobs_num;
        net->layers[li].output_blobs_num   = net_model->layers[li].output_blobs_num;
        net->layers[li].required_layer_num = net_model->layers[li].required_layer_num;

        net->layers[li].get_memsize = net_model->layers[li].get_memsize;
        net->layers[li].create      = net_model->layers[li].create;
        net->layers[li].forward     = net_model->layers[li].forward;
        net->layers[li].reshape     = net_model->layers[li].reshape;

        net->layers[li].layer_model = &net_model->layers[li];
    }

    // �������blob����prototxt�ж��������blob��Ŀ�Ƿ����
    HKA_CHECK_ERROR(net->in_blob_num != net->layers[0].output_blobs_num, HIK_VCA_CNN_MODEL_ERROR);
	
printf("B\n");

    for (i = 0; i < net->in_blob_num; i++)
    {
        net->layers[0].output_blobs[i].ndims    = 4;
        net->layers[0].output_blobs[i].type     = CNN_DT_FLT32;
        net->layers[0].output_blobs[i].shape[0] = net->in_blob_shape[i][0];
        net->layers[0].output_blobs[i].shape[1] = net->in_blob_shape[i][1];
        net->layers[0].output_blobs[i].shape[2] = net->in_blob_shape[i][2];
        net->layers[0].output_blobs[i].shape[3] = net->in_blob_shape[i][3];
    }

    // bind inputs
    for (li = 0; li < layersSize; li++)
    {
        layer       = &net->layers[li];
        layer_model = &net_model->layers[li];

        for (in_num = 0; in_num < layer->input_blobs_num; in_num++)
        {
            LAYER_PIN   from   = layer_model->input_blobs_id[in_num];
            LAYER_DATA *out_ld = CNN_NET_get_layer_data(net, from.lid);
            layer->input_blobs[in_num] = &out_ld->output_blobs[from.oid];
        }
#ifdef CNN_CONCAT_OPT
        net->layers[li].net = net;
#endif
    }

printf("C\n");
    // ���Ҫ������ⲿ��blob��Ϣ�Ƿ���ȷ
    hr = CNN_check_out_blobinfo(net);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    // ��Ҫ���blob��layer��required_layer_num��ֵ��1����ֹ���ڴ汻�ظ�����
    for (i = 0; i < net->blob_num; i++)
    {
        layer = &net->layers[net->out_blob_info[i].layer_idx];

        CNN_NET_inc_required_layer_num_ld(net, layer);
    }

#ifdef CNN_CONCAT_OPT
    // ��Ҫfeed��concat���blob���ڲ��ǰһ���required_layer_num��1��
    // ��ֹ��concat���䣬Ȼ���ֱ�����Ϊ��blob����������յ���Ҫfeed��concat���blob���ڲ������������һ���ط�
    for (li = 0; li < layersSize; li++)
    {
        int feed_to_concat = 0;

        layer = &net->layers[li];
        for (i = 0; i < MAX_OUTPUT_BLOBS; i++)
        {
            feed_to_concat |= layer->layer_model->feed_to_concat[i];
        }

        if (1 == feed_to_concat)
        {
            for (i = 0; i < layer->layer_model->input_layers_id.ele_num; i++)
            {
                int         input_layer_id = layer->layer_model->input_layers_id.elements[i];
                LAYER_DATA *ld = CNN_NET_get_layer_data(net, input_layer_id);

                CNN_NET_inc_required_layer_num_ld(net, ld);
            }
        }
    }
#endif

    return HIK_VCA_LIB_S_OK;
}




void CNN_NET_free_mem(NET           *net,
                      CNN_MEM_LIST  *fml,
                      const CNN_MEM *layer_alloced_mem,
                      int            start_layer_idx)
{
    LAYER_DATA *layer = &net->layers[start_layer_idx];

    if (0 == layer->layer_model->in_place)
    {
        if (0 == layer->required_layer_num)
        {
            CNN_MM_Free(fml, layer_alloced_mem[start_layer_idx].offset, layer_alloced_mem[start_layer_idx].size);
        }
    }
    else
    {
        int i;
        for (i = 0; i < layer->layer_model->input_layers_id.ele_num; i++)
        {
            int input_layer_id = layer->layer_model->input_layers_id.elements[i];
            int layer_index    = CNN_NET_get_layer_index(net, input_layer_id);

            CNN_NET_free_mem(net, fml, layer_alloced_mem, layer_index);
        }
    }
}

HRESULT CNN_NET_mem_man(CNN_MEM      *layer_alloced_mem,
                        int           layer_idx,
                        CNN_MEM_LIST *fml,
                        NET          *net)
{
    int             i, j, input_layer_id, layer_index;
    LAYER_DATA      *layer = &net->layers[layer_idx];
    LAYER_DATA      *prev_layer;

    // �ͷſ��ͷŵ��ڴ�
    for (i = 0; i < layer->layer_model->input_layers_id.ele_num; i++)
    {
        input_layer_id = layer->layer_model->input_layers_id.elements[i];
        layer_index = CNN_NET_get_layer_index(net, input_layer_id);
        CNN_CHECK_ERROR(-1 == layer_index,
                        "CNN_NET_get_layer_index error: Not found",
                        HIK_VCA_CNN_MODEL_ERROR);

        CNN_NET_dec_required_layer_num(net, &net->layers[layer_index]);

        CNN_NET_free_mem(net, fml, layer_alloced_mem, layer_index);
    }

#ifdef CNN_CONCAT_OPT
    // �ͷŵ�feed_to_concat���ǰһ����ڴ�
    if (strcmp(layer->layer_model->type, "Concat") == 0)
    {
        for (i = 0; i < layer->layer_model->input_layers_id.ele_num; i++)
        {
            input_layer_id = layer->layer_model->input_layers_id.elements[i];
            prev_layer = CNN_NET_get_layer_data(net, input_layer_id);

            for (j = 0; j < prev_layer->layer_model->input_layers_id.ele_num; j++)
            {
                input_layer_id = prev_layer->layer_model->input_layers_id.elements[j];
                layer_index = CNN_NET_get_layer_index(net, input_layer_id);

                CNN_NET_dec_feed_concat_required_layer_num(net, &net->layers[layer_index]);

                CNN_NET_free_mem(net, fml, layer_alloced_mem, layer_index);
            }
        }
    }
#endif

    return HIK_VCA_LIB_S_OK;
}


static void CNN_NET_print_memtab(LAYER_DATA *layer, VCA_MEM_TAB_V2 *mem_tab, int num)
{
    int i;
    //for (i = 0; i < num; i++)
    for (i = 2; i < num; i++)
    {
        printf("%5d %-20s %-5d %-5fM\n",
            layer->id,
            layer->layer_model->type,
            mem_tab[i].size,
            mem_tab[i].size * 1.0 / 1024.0 / 1024.0);
    }
}

#if 0
/***************************************************************************************************
* ��  ��: �������в����һ���layer type
* ��  ��:
*               net                    - I / O Net Model Handle
* ����ֵ: ״̬��
***************************************************************************************************/
static void CNN_NET_set_layer_next_type(NET_MODEL *net)
{
    int           i, li, layersSize;
    LAYER_MODEL  *layer;
    HKA_S32       layerid;
    HKA_S32       next_layer_id;
    const char*   next_layer_type;

    layersSize = net->layer_num;

    for (li = 0; li < layersSize; li++)
    {
        layer           = &net->layers[li];
        next_layer_type = layer->type;
        next_layer_id   = layer->id;

        layer->next_layer_type = NULL;
        layer->next_layer_id   = -1;

        if (layer->input_blobs_num > 0)
        {
            for (i = 0; i < layer->input_blobs_num; i++)
            {
                layerid = layer->input_blobs_id[i].lid;
                net->layers[layerid - 1].next_layer_type = next_layer_type;
                net->layers[layerid - 1].next_layer_id   = next_layer_id;
                net->layers[layerid - 1].do_relu         = next_layer_type;
            }
        }
    }

    // ���next_layer_type��inplace��
    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];
    
        if ((layer->next_layer_type) && 
            (strcmp(layer->next_layer_type, "ReLU") == 0))
        {
            layerid = net->layers[layer->next_layer_id - 1].next_layer_id;
            
            layer->next_layer_type = net->layers[layerid - 1].type;
            layer->next_layer_id = net->layers[layerid - 1].id;
        }
    }
}
#endif


/***************************************************************************************************
* ��  ��: �������в����һ���layer type
* ��  ��:
*               net                    - I / O Net Model Handle
* ����ֵ: ״̬��
***************************************************************************************************/
static void CNN_NET_set_layer_next_types(NET_MODEL *net)
{
    int           i, li, layersSize;
    LAYER_MODEL  *layer;
    HKA_S32       layerid;
    HKA_S32       next_layer_id;
    int           output_num;
    const char*   next_layer_type;

    layersSize = net->layer_num;

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];
        memset(&layer->layer_output, 0, sizeof(LAYER_OUTPUT));
    }

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];

        next_layer_type = layer->type;
        next_layer_id   = layer->id;

        for (i = 0; i < layer->input_blobs_num; i++)
        {
            layerid     = layer->input_blobs_id[i].lid;
            output_num  = net->layers[layerid - 1].layer_output.out_num;

            CNN_CHECK_ERROR((output_num + 1) >= CNN_MAX_REQUIRE_LAYER_NUM, 
                            "(output_num + 1) >= CNN_MAX_REQUIRE_LAYER_NUM",
                            HIK_VCA_CNN_MODEL_ERROR);

            net->layers[layerid - 1].layer_output.layer_type[output_num] = next_layer_type;
            net->layers[layerid - 1].layer_output.layer_id[output_num]   = next_layer_id;
            net->layers[layerid - 1].layer_output.out_num++;
            net->layers[layerid - 1].do_relu = next_layer_type;
        }
    }

/***************************************** DEBUG INFO *********************************************

    printf("============================================================\n");
    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];
        printf("name layer->layer_output.out_num %-32s %d.......................... ",
                layer->name,
                layer->layer_output.out_num);

        for (i = 0; i < layer->input_blobs_num; i++)
        {
            printf("%-16s ", net->layers[layer->input_blobs_id[i].lid - 1].name);
        }
        printf("\n");
    }

***************************************************************************************************/
}

/***************************************************************************************************
* ��  ��: �ж�ĳһ���͵Ĳ��Ƿ���layer_model�������
* ��  ��:
*               layer_model     - I  layer model
*               type            - I  layer type
* ����ֵ: 1->�ڣ�0->����
***************************************************************************************************/
int CNN_NET_type_in_output(NET_MODEL *net, LAYER_MODEL *layer_model, const char* type)
{
    int           i;
    LAYER_MODEL  *out_layer;

    for (i = 0; i < layer_model->layer_output.out_num; i++)
    {
        // out_layer��Layer_model��һ��ֱ�������
        out_layer = CNN_NET_get_layer_model(net, layer_model->layer_output.layer_id[i]);

        // ���out_layer������Ϊtype, ˵��layer_model���������������Ϊtype�Ĳ�
        if (strcmp(out_layer->type, type) == 0)
        {
            return 1;
        }
        else
        {
            // out_layer�����Inplace�㣬������ݹ�����
            if (out_layer->in_place == 1)
            {
                return CNN_NET_type_in_output(net, out_layer, type);
            }
        }
    }

    // ֱ�������͵ݹ������Ĳ��ж�û��type�㣬��˵��layer_model��ȷʵû��type��

    return 0;
}

/***************************************************************************************************
* ��  ��: ��������������ڴ�
* ��  ��: net                    - I ���綨��
*         mem_tab                - O �ڴ���Ϣ
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_GetMemsize(NET           *net,
                           VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT        hr;
    int            i, li, layersSize;
    VCA_MEM_TAB_V2 layer_tmp_tab[LAYER_MEM_TAB_NUM];
    LAYER_DATA    *layer;
    int            tabi;

    VCA_MEM_TAB_V2 *layer_cpu_handle_tab = &layer_tmp_tab[0];
    VCA_MEM_TAB_V2 *layer_cpu_data_tab   = &layer_tmp_tab[1];
    VCA_MEM_TAB_V2 *layer_gpu_data_tab   = &layer_tmp_tab[2];

    VCA_MEM_TAB_V2 *layer_data_tab = layer_cpu_data_tab;

    VCA_MEM_TAB_V2 *net_cpu_handle_tab = &mem_tab[0];
    VCA_MEM_TAB_V2 *net_cpu_data_tab   = &mem_tab[1];
    VCA_MEM_TAB_V2 *net_gpu_data_tab   = &mem_tab[2];

    VCA_MEM_TAB_V2 *net_data_tab = net_cpu_data_tab;

    size_t          used_mem;
    size_t          max_output_mem      = 0;
    int             net_pad_h, net_pad_w;

    CNN_MEM         layer_alloced_mem[CNN_MAX_LAYER_NUM] = { 0 };
    CNN_MEM_LIST    fml;
    VCA_MEM_TAB_V2  fusion_mem_tab[CNN_MAX_LAYER_NUM];
    size_t          fusion_mem_tab_size = 0;


    net_pad_h       = net->net_model->net_pad.pad_h;
    net_pad_w       = net->net_model->net_pad.pad_w;

#ifdef CNN_CUDA_OPT
    layer_data_tab = layer_gpu_data_tab;
    net_data_tab   = net_gpu_data_tab;
#endif

    if (sizeof(size_t) == 4)
    {
        CNN_MM_Init(&fml, 0xffffffff);
    }
    else
    {
        CNN_MM_Init(&fml, 0xffffffffffffffff);
    }

    memset(mem_tab, 0, sizeof(mem_tab[0]) * HIK_CNN_MEM_TAB_NUM);
    layersSize = net->layer_num;

    CNN_BASE_set_net_pad(net, 0);

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];

        printf("%d %d %s %s\n",li, layer->id, layer->layer_model->name, layer->layer_model->type);

        hr = layer->get_memsize(layer, layer_tmp_tab);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr)

        //CNN_NET_print_memtab(layer, layer_tmp_tab, LAYER_MEM_TAB_NUM);

        /*---------------------------------------------------------------------------------------------------------------*/
        net_cpu_handle_tab->size += layer_cpu_handle_tab->size;
        net_cpu_data_tab->size   += layer_cpu_data_tab->size;

        net_gpu_data_tab->size   += layer_gpu_data_tab->size;

        net_cpu_handle_tab->alignment = HKA_MAX(net_cpu_handle_tab->alignment, layer_cpu_handle_tab->alignment);
        net_cpu_data_tab->alignment   = HKA_MAX(net_cpu_data_tab->alignment, layer_cpu_data_tab->alignment);
        net_gpu_data_tab->alignment   = HKA_MAX(net_gpu_data_tab->alignment, net_gpu_data_tab->alignment);
        /*---------------------------------------------------------------------------------------------------------------*/

        layer_alloced_mem[li] = CNN_MM_Alloc(&fml, layer_data_tab->size);
        HKA_CHECK_ERROR(-1 == layer_alloced_mem[li].size, HIK_VCA_LIB_E_MEM_OUT);

        used_mem       = CNN_MM_MaxMemAlloced(&fml);
        max_output_mem = (used_mem > max_output_mem) ? used_mem : max_output_mem;

        hr = CNN_NET_mem_man(layer_alloced_mem, li, &fml, net);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    }

    net_data_tab->size = max_output_mem;

#ifdef CNN_CUDA_OPT
    net_data_tab->size += CNN_SIZE_ALIGN(CNN_CUDNN_MEM_SIZE);
#endif

    return HIK_VCA_LIB_S_OK;
}



/***************************************************************************************************
* ��  ��: ���ø���layer��create�����Դ�������
* ��  ��: net                    - I/O ���綨��
*         mem_buf                - I   �ڴ�  0: handle 
                                             1: model_cpu
                                             2: output_data_cpu 
                                             3:model_gpu
                                             4:output_data_gpu
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_Create(NET    *net,
                       CNN_BUF mem_buf[LAYER_MEM_TAB_NUM])
{
    HRESULT     hr;
    int         i, li, layersSize;
    LAYER_DATA *layer;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];
    CNN_BUF *cpu_data_buf   = &mem_buf[1];
    CNN_BUF *gpu_data_buf   = &mem_buf[2];

    VCA_MEM_TAB_V2 tmp_tab[LAYER_MEM_TAB_NUM];
    int            tabi;

    CNN_MEM layer_alloced_mem[CNN_MAX_LAYER_NUM]     = { 0 };

    CNN_BUF  tmp_buf         = *cpu_data_buf;
    CNN_BUF *output_blob_buf = cpu_data_buf;

    VCA_MEM_TAB_V2 *data_tab = tmp_tab + 1;                              // cpu_data tab

    CNN_MEM_LIST     fml;
    VCA_MEM_TAB_V2   fusion_mem_tab[CNN_MAX_LAYER_NUM];
    CNN_BUF          fusion_buf;
    int              net_pad_h, net_pad_w;

    char             *mem_base       = cpu_data_buf->cur_pos;
    size_t            gpu_data_size  = (char*)mem_buf[2].end - (char*)mem_buf[2].cur_pos;
    char             *gpu_data_base  = mem_buf[2].cur_pos;
    size_t            fusion_mem_tab_size = 0;

#ifdef CNN_CUDA_OPT
    data_tab        =  tmp_tab + 2;                      // gpu_data tab
    output_blob_buf =  gpu_data_buf;
    tmp_buf         = *gpu_data_buf;                    // gpu_data��cpu_dataֻ��һ��ʹ���ڴ����
    mem_base        =  gpu_data_buf->cur_pos;
#endif

    CNN_MM_Init(&fml, ((char *)tmp_buf.end - (char *)tmp_buf.cur_pos));

    layersSize  = net->layer_num;
    net_pad_h   = net->net_model->net_pad.pad_h;
    net_pad_w   = net->net_model->net_pad.pad_w;

    CNN_BASE_set_net_pad(net, 0);

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];
        //printf("create: %d %s %s\n", li, layer->layer_model->type, layer->layer_model->name);

        // ����ÿһ���pad


        // ��net�е�cuda_handle����layer_data
#ifdef CNN_CUDA_OPT
        layer->cuda_handle = &net->cuda_handle;
#endif  // CNN_CUDA_OPT

        hr = layer->get_memsize(layer, tmp_tab);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

        layer_alloced_mem[li] = CNN_MM_Alloc(&fml, data_tab->size);
        HKA_CHECK_ERROR(-1 == layer_alloced_mem[li].size, HIK_VCA_LIB_E_MEM_OUT);

        hr = CNN_NET_mem_man(layer_alloced_mem, li, &fml, net);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr)

        output_blob_buf->start   = (char *)mem_base + layer_alloced_mem[li].offset;
        output_blob_buf->cur_pos = output_blob_buf->start;
        output_blob_buf->end     = (char *)output_blob_buf->start + layer_alloced_mem[li].size;

        hr = layer->create(layer, mem_buf, &layer->layer_handle);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    }

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ��������������ڴ�
* ��  ��: net                    - I ���綨��
*         mem_tab                - O �ڴ���Ϣ
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_GetModelMemsize(NET_MODEL     *net,
                                VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    HRESULT        hr;
    int            i, li, layersSize;
    VCA_MEM_TAB_V2 layer_tmp_tab[MODEL_MEM_TAB_NUM];
    LAYER_MODEL   *layer;
    int            tabi;

    VCA_MEM_TAB_V2 *layer_cpu_handle_tab = layer_tmp_tab;
    VCA_MEM_TAB_V2 *layer_cpu_model_tab  = layer_tmp_tab + 1;
    VCA_MEM_TAB_V2 *layer_gpu_model_tab  = layer_tmp_tab + 2;

    VCA_MEM_TAB_V2 *net_cpu_handle_tab   = mem_tab;
    VCA_MEM_TAB_V2 *net_cpu_model_tab    = mem_tab + 1;
    VCA_MEM_TAB_V2 *net_gpu_model_tab    = mem_tab + 2;

    const int       conv_hf_sizes[NET_CONV_HF_SIZE][2] = {{1, 1}};
    VCA_MEM_TAB_V2  fusion_mem_tab[CNN_MAX_LAYER_NUM];

    size_t          max_weight_size      = 0;
    size_t          fusion_mem_tab_size  = 0;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    layersSize = net->layer_num;

    CNN_CHECK_ERROR(layersSize > CNN_MAX_LAYER_NUM,
                    "layers_num > CNN_MAX_LAYER_NUM",
                    HIK_VCA_CNN_MODEL_ERROR);

    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];

        printf("%d %d %s %s\n", li, layer->id, layer->name, layer->type);

        hr = layer->get_modelmemsize(layer->hyperparams, layer->param_blobs, layer, layer_tmp_tab);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr)

        net_cpu_handle_tab->size += layer_cpu_handle_tab->size;
        net_cpu_model_tab->size  += layer_cpu_model_tab->size;
        net_gpu_model_tab->size  += layer_gpu_model_tab->size;

        max_weight_size               = HKA_MAX(layer_gpu_model_tab->size, 
                                                max_weight_size);

        net_cpu_handle_tab->alignment = HKA_MAX(net_cpu_handle_tab->alignment, 
                                                layer_cpu_handle_tab->alignment);
        net_cpu_model_tab->alignment  = HKA_MAX(net_cpu_model_tab->alignment, 
                                                layer_cpu_model_tab->alignment);
        net_gpu_model_tab->alignment  = HKA_MAX(net_gpu_model_tab->alignment, 
                                                layer_gpu_model_tab->alignment);
    }

    CNN_NET_set_layer_next_types(net);

#ifdef ARCH_SUPPORT_FP16
    net->max_weight_size        = max_weight_size;
    net_gpu_model_tab->size    += max_weight_size * sizeof(float) / sizeof(cnn_half);
#endif

    return HIK_VCA_LIB_S_OK;
}


/***************************************************************************************************
* ��  ��: ���ø���layer��create�����Դ�������
* ��  ��: net                    - I/O ���綨��
*         mem_buf                - I   �ڴ�  0: handle 1: model_cpu 2: model_gpu
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_NET_CreateModel(NET_MODEL *net,
                            CNN_BUF    mem_buf[LAYER_MEM_TAB_NUM])
{
    HRESULT                   hr;
    NET_MODEL                 net_ex;
    LAYER_MODEL              *layer;
    CONVOLUTION_MODEL        *conv_model;
    int                       i, li, layersSize;
    int                       support_zip;

    // ��Ҫ����horizontal fusion�ľ����˴�С
    const int                 conv_hf_sizes[NET_CONV_HF_SIZE][2] = {{1, 1}};

    layersSize = net->layer_num;
    
    for (li = 0; li < layersSize; li++)
    {
        layer = &net->layers[li];

#ifdef ARCH_SUPPORT_FP16
        layer->fp16_workspace = net->fp16_workspace;
#endif
        printf("%d %s %s\n", li, layer->name, layer->type);

        hr = layer->create_model(layer->hyperparams,
                                 layer->param_blobs, 
                                 layer, 
                                 mem_buf, 
                                 &layer->model_handle);
        HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);
    }
printf("M0\n");
    // ����ÿһ�����һ��
    CNN_NET_set_layer_next_types(net);

    // �������������в�����pad, ��ֵ��net�е�pad
    hr = CNN_NET_set_net_pad(net);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_NET_set_net_pad", hr);
	printf("M1\n");

#ifdef CNN_CUDA_OPT
    // �ж������Ƿ�֧��ZIP
    hr = CNN_NET_EX_support_zip(net, &support_zip);
    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "CNN_NET_EX_support_zip", hr);
	printf("M2\n");

    net->support_zip = support_zip;
#endif

    return HIK_VCA_LIB_S_OK;
}

static HRESULT CNN_NET_set_format(LAYER_DATA *ld)
{
    HRESULT hr = CNN_BASE_SetBlobFormat(ld->input_blobs, 
                                        ld->input_blobs_num, 
                                        ld->output_blobs, 
                                        ld->output_blobs_num);
    return hr;
}

static void CNN_NET_print_format(LAYER_DATA *ld)
{
    int n;
    int blob_num = ld->output_blobs_num;

    for (n = 0; n < blob_num; n++)
    {
        printf("%s ", CNN_blob_format_str(ld->output_blobs[n].format));
    }
}

/***************************************************************************************************
* ��  ��: �������forwardʱ�᲻����ĳһ������blob��Ԫ�ظ���Ϊ0(�����Ͻ�proposal�������ֿ�����)
* ��  ��:
*         ld             - I/O          ��һ�������
* ����ֵ: �ò�����Ԫ�ظ����Ƿ�Ϊ0,    1->�ǣ�0->��
* ��  ע:
***************************************************************************************************/
static int CNN_NET_forward_check_input_empty(LAYER_DATA *ld)
{
    int i, j;

    for (i = 0; i < ld->input_blobs_num; i++)
    {
        // �����һ������Ԫ�ظ���Ϊ0�����������Ҳ��0
        if (CNN_BLOB_GetDataNum(ld->input_blobs[i]) == 0)
        {
            for (j = 0; j < ld->output_blobs_num; j++)
            {
                ld->output_blobs[j].shape[0] = 0;
            }
            return 1;
        }
    }
    return 0;
}


/***************************************************************************************************
* ��  ��: �жϵ�li���ǲ���eltmentwise�㲢�Һ����һ��bn��
* ��  ��:
*         net_model      - I          ����ģ��
*         li             - I          ����
* ����ֵ:  1->�ǣ�0->��
* ��  ע:
***************************************************************************************************/
static int CNN_NET_elt_width_bn(NET_MODEL *net, int li)
{
    if(!(strncmp(net->layers[li].type, ELTWISE_LAYER_TYPE, MAX_STRING_LENGTH) == 0))
    {
        return 0;
    }
    if (((li + 1) < net->layer_num) && 
        strncmp(net->layers[li + 1].type, BN_LAYER_TYPE, MAX_STRING_LENGTH) == 0)
    {
        return 1;
    }
    return 0;
}

#ifdef CNN_CUDA_OPT
/***************************************************************************************************
* ��  ��: ���þ�������һ���ǲ���relu�ı��
* ��  ��: 
*         layer               - I ��ǰ������
*         net                 - I ����
* ����ֵ: ״̬��  1: ��һ����relu��0:����relu
* ��  ע:
***************************************************************************************************/
static int CNN_NET_set_conv_relu_flag(int li, const LAYER_DATA *layer, const NET *net)
{
    CONVOLUTION_LAYER   *conv_layer;

    int                 ret     = 0;

#ifndef CNN_CUDA_OPT
    conv_layer          = layer->layer_handle;
    conv_layer->is_relu = 0;
    return 0;
#endif

    //conv_layer          = layer->layer_handle;
    //conv_layer->is_relu = 0;
    //return 0;

    if (strcmp(layer->layer_model->type, "Convolution") == 0)
    {
        conv_layer              = layer->layer_handle;
        conv_layer->is_relu     = 0;

        if (((li + 1) < net->layer_num) && 
            (strcmp(net->layers[li + 1].layer_model->type, "ReLU") == 0))
        {
            conv_layer->is_relu = 1;
            ret                 = 1;
        }
        else
        {
            conv_layer->is_relu = 0;
        }
    }

    return ret;
}

/***************************************************************************************************
* ��  ��: ���þ�������һ���ǲ���relu�ı��
* ��  ��: 
*         layer               - I ��ǰ������
*         net                 - I ����
* ����ֵ: ״̬��  1: ��һ����ROI��0:����ROI
* ��  ע:
***************************************************************************************************/
static int CNN_NET_set_rpn_fused_flag(int li, const LAYER_DATA *layer, const NET *net)
{
    PROPOSAL_LAYER      *proposal_layer;
    ROI_POOLING_LAYER   *roi_pooling_layer;
    int                  ret = 0;
    return               0;

#ifndef CNN_CUDA_OPT
    if (strcmp(layer->layer_model->type, "RpnProposal") == 0)
    {
        proposal_layer          = layer->layer_handle;
        proposal_layer->do_roi  = 0;
        return 0;
    }
#endif

    if (strcmp(layer->layer_model->type, "RpnProposal") == 0)
    {
        proposal_layer          = layer->layer_handle;
        proposal_layer->do_roi  = 0;
        return 0;
    }

    if (strcmp(layer->layer_model->type, "RpnProposal") == 0)
    {
        proposal_layer              = layer->layer_handle;
        proposal_layer->do_roi      = 0;

        if (((li + 1) < net->layer_num) && 
            (strcmp(net->layers[li + 1].layer_model->type, "ROIPooling") == 0))
        {
            proposal_layer->do_roi  = 1;
            ret                     = 1;
            proposal_layer->roi_info.roi_pooling_layer = net->layers[li + 1].layer_handle;
            proposal_layer->roi_info.ld                = &net->layers[li + 1];
        }
        else
        {
            proposal_layer->do_roi  = 0;
        }
    }

    return ret;
}

/***************************************************************************************************
* ��  ��: ����Eltwise����һ���ǲ���BN��ı��,ͬʱ����
* ��  ��: 
*         li                  - I ����
*         layer               - I ��ǰ������
*         net                 - I ����
* ����ֵ: ״̬��  1: �ǣ� 0: ����
* ��  ע:
***************************************************************************************************/
static int CNN_NET_set_elt_bn_flag(int li, const LAYER_DATA *layer, const NET *net)
{
    ELTWISE_LAYER       *elt_layer;
    int                 ret    = 0;

#ifndef ELTWISE_BN_COMBINE_OPT
    if (strncmp(layer->layer_model->type, ELTWISE_LAYER_TYPE, MAX_STRING_LENGTH) == 0)
    {
        elt_layer               = layer->layer_handle;
        elt_layer->do_bn        = 0;
        elt_layer->bn_layer     = NULL;
    }
    return 0;
#endif

    if (strncmp(layer->layer_model->type, ELTWISE_LAYER_TYPE, MAX_STRING_LENGTH) == 0)
    {
        elt_layer              = layer->layer_handle;
        elt_layer->do_bn       = 0;
        elt_layer->bn_layer    = NULL;

        if (((li + 1) < net->layer_num) && 
            (strncmp(net->layers[li + 1].layer_model->type, BN_LAYER_TYPE, MAX_STRING_LENGTH) == 0))
        {
            elt_layer->do_bn        = 1;
            elt_layer->bn_layer     = net->layers[li + 1].layer_handle;
            ret                     = 1;
            memcpy(&elt_layer->bn_out_blob, &net->layers[li + 1].output_blobs[0], sizeof(CNN_BLOB));
        }
        else
        {
            elt_layer->do_bn    = 0;
            elt_layer->bn_layer = NULL;
            ret                 = 0;
        }
    }
    return ret;
}

/***************************************************************************************************
* ��  ��: ����Eltwise����һ����BN��������һ����RELU�ı��,ͬʱ���ر��
* ��  ��:
*         li                  - I ����
*         layer               - I ��ǰ������
*         net                 - I ����
* ����ֵ: ״̬��  1: �ǣ� 0: ����
* ��  ע:
***************************************************************************************************/
static int CNN_NET_set_elt_bn_relu_flag(int li, const LAYER_DATA *layer, const NET *net)
{
    ELTWISE_LAYER       *elt_layer;
    int                 ret = 0;

#ifndef ELTWISE_BN_RELU_COMBINE_OPT
    if (strncmp(layer->layer_model->type, ELTWISE_LAYER_TYPE, MAX_STRING_LENGTH) == 0)
    {
        elt_layer               = layer->layer_handle;
        elt_layer->do_bn_relu   = 0;
        elt_layer->do_bn        = 0;
        elt_layer->bn_layer     = NULL;
    }
    return 0;
#endif

    if (strncmp(layer->layer_model->type, ELTWISE_LAYER_TYPE, MAX_STRING_LENGTH) == 0)
    {
        elt_layer             = layer->layer_handle;
        elt_layer->do_bn_relu = 0;
        elt_layer->do_bn      = 0;
        elt_layer->bn_layer   = NULL;
        ret                   = 0;

        if (((li + 2) < net->layer_num) &&
            (strncmp(net->layers[li + 1].layer_model->type, BN_LAYER_TYPE, MAX_STRING_LENGTH) == 0) &&
            (strncmp(net->layers[li + 2].layer_model->type, RELU_LAYER_TYPE, MAX_STRING_LENGTH) == 0))
        {
            elt_layer->do_bn_relu = 1;
            elt_layer->bn_layer   = net->layers[li + 1].layer_handle;
            elt_layer->relu_layer_ld = &net->layers[li + 2];
            ret                   = 1;
            memcpy(&elt_layer->bn_out_blob, &net->layers[li + 1].output_blobs[0], sizeof(CNN_BLOB));
        }
    }
    return ret;
}

#endif


#ifdef CNN_PROFILE_LAYER // profile��

int     conv_timer_id;
int     fc_timer_id;
int     next_relu;
int     do_conv;        //������conv����relu��bias
int     do_fc;
int     conv_switch;
int     fc_switch;

double CNN_NET_cal_calculation(int      img_height, 
                               int      img_width, 
                               int      img_channel, 
                               int      kernel_h, 
                               int      kernel_w,
                               int      kernel_num, 
                               int      stride_h,
                               int      stride_w,
                               int      batch_size)
{
    double   calculation = 1.0;

    calculation *= img_height / stride_h;
    calculation *= img_width / stride_w;
    calculation *= img_channel;
    calculation *= kernel_h;
    calculation *= kernel_w;
    calculation *= kernel_num;
    calculation *= batch_size;
    calculation *= 2;

    return calculation / 1000000000.0;    //G��
}


double CNN_NET_GetMaxgflops()
{
#ifdef ARCH_SUPPORT_FP16
    return 1024;
#else
    return 512;
#endif
}

static void CNN_NET_profile(int timer_id, LAYER_DATA  *layer_handle, int height, int width, int channel, int batch_size, int print_bias)
{
    double  avg_time, cal, gflops = 0.0, utilization = 0.0;
    int     M, K, N, i;

    int     kernel_size, kernel_num, stride;
    int     pool_size;

    CONVOLUTION_MODEL       *conv_model     = (CONVOLUTION_MODEL *)     layer_handle->layer_model->model_handle;
    POOLING_MODEL           *pool_model     = (POOLING_MODEL *)         layer_handle->layer_model->model_handle;;
    FULLY_CONNECTED_MODEL   *fc_model       = (FULLY_CONNECTED_MODEL *) layer_handle->layer_model->model_handle;

    CNN_BLOB                *input_blob     = layer_handle->input_blobs[0];

    avg_time = opt_profile_info[timer_id].time_used_total / opt_profile_info[timer_id].profile_count;

    kernel_size     = 0;
    kernel_num      = 0;
    stride          = 0;
    cal             = 0;
    
    int             ker_h = 0;
    int             ker_w = 0;
    int             stride_h = 0;
    int             stride_w = 0;

    if (!strcmp(layer_handle->layer_model->type, "Convolution"))
    {
        kernel_num  = conv_model->out_cn;
        cal         = CNN_NET_cal_calculation(height, 
                                              width, 
                                              channel, 
                                              conv_model->ker_h, 
                                              conv_model->ker_w, 
                                              kernel_num, 
                                              conv_model->stride_h, 
                                              conv_model->stride_w, 
                                              batch_size);
       
        ker_h       = conv_model->ker_h;
        ker_w       = conv_model->ker_w;
        stride_h    = conv_model->stride_h;
        stride_w    = conv_model->stride_w;
        //printf("%15s %5d %5d %5d %5d %5d %5d %5d %5f %5f\n", layer_handle->layer_model->type, width, height, channel, batch_size, kernel_size, kernel_num, stride, avg_time, cal);
    }
    else if(!strcmp(layer_handle->layer_model->type, "Pooling"))
    {
        pool_size   = pool_model->kernel_h;
        stride_h    = pool_model->stride_h;
        stride_w    = pool_model->stride_w;
        ker_h       = pool_model->kernel_h;
        ker_w       = pool_model->kernel_w;

        cal = ker_w * ker_h * batch_size * height * width * channel / stride_w / stride_h;
        cal = cal / 1000000000.0;    //G��

        //printf("%15s %5d %5d %5d %5d %5d %5d    %5f   \n", layer_handle->layer_model->type, width, height, channel, batch_size, pool_size, stride, avg_time);
    }
    else if(!strcmp(layer_handle->layer_model->type, "InnerProduct"))
    {
        M = 1;
        for (i = 0; i < fc_model->axis; i++)
        {
            M *= input_blob->shape[i];
        }

        K = 1;
        for ( ; i < input_blob->ndims; i++)
        {
            K *= input_blob->shape[i];
        }

        N = fc_model->num_outputs;

        kernel_num = N;
        cal = 1.0 * M * N * K + 1.0 *  M * N * (K - 1);
        cal /= 1000000000.0;
        gflops = cal / avg_time * 1000.0;

        utilization = gflops / CNN_NET_GetMaxgflops();
    }
    else
    {
        //printf("%15s %5d %5d %5d %5d          %5f  \n", layer_handle->layer_model->type, width, height, channel, batch_size, avg_time);
        cal = 0.0f;
    }

    gflops      = cal / avg_time * 1000.0;
    utilization = gflops / CNN_NET_GetMaxgflops();

    printf("%5d %25s %15s %5d %5d %5d %5d %5d %5d %5d %5d %5d %10f %10f %10f %10f\n", 
                                                                    timer_id, 
                                                                    print_bias ? "bias" : layer_handle->layer_model->name, 
#ifdef PROFILE_RELU_WITH_BIAS
                                                                    print_bias ? "bias" : (!strcmp(layer_handle->layer_model->type, "ReLU")) ? "ReLU_bias" : layer_handle->layer_model->type, 
#else
                                                                    layer_handle->layer_model->type, 
#endif
                                                                    width, 
                                                                    height, 
                                                                    channel, 
                                                                    batch_size, 
                                                                    ker_h, 
                                                                    ker_w, 
                                                                    kernel_num, 
                                                                    stride_h, 
                                                                    stride_w, 
                                                                    avg_time, 
                                                                    print_bias ? 0.0 : cal,
                                                                    print_bias ? 0.0 : gflops,
                                                                    print_bias ? 0.0 : utilization);
    //OPT_PRINT_INFO(layer_handle->layer_model->type, timer_id);
}


void CNN_NET_Reserve_layer_output(LAYER_DATA *ld, CNN_BLOB *blob, int layer_index)
{
    int         blob_num = ld->output_blobs_num;
    int         i;
    cudaError_t err;

    memset(blob, 0, sizeof(CNN_BLOB) * MAX_OUTPUT_BLOBS);

    for (i = 0; i < blob_num; i++)
    {
        memcpy(blob + i, &ld->output_blobs[i], sizeof(CNN_BLOB));

#ifdef ARCH_SUPPORT_FP16
        if (ld->output_blobs[i].data_gpu_fp16)
        {
            err = cudaMalloc(&blob[i].data_gpu_fp16, CNN_BLOB_GetDataNum(blob + i) * sizeof(short));
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", HIK_VCA_LIB_E_PTR_NULL);
            err = cudaMemcpy(blob[i].data_gpu_fp16, ld->output_blobs[i].data_gpu_fp16,  CNN_BLOB_GetDataNum(blob + i) * sizeof(short), cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", HIK_VCA_LIB_E_PTR_NULL);
        }
#endif
        if (ld->output_blobs[i].data_gpu)
        {
            err = cudaMalloc(&blob[i].data_gpu, CNN_BLOB_GetDataNum(blob + i) * sizeof(float));
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMalloc", HIK_VCA_LIB_E_PTR_NULL);
            err = cudaMemcpy(blob[i].data_gpu, ld->output_blobs[i].data_gpu, CNN_BLOB_GetDataNum(blob + i) * sizeof(float), cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", HIK_VCA_LIB_E_PTR_NULL);
        }
        if (ld->output_blobs[i].data)
        {
            if (layer_index > 0)
            {
                blob[i].data = malloc(CNN_BLOB_GetDataNum(blob + i) * sizeof(float));
                CNN_CHECK_ERROR(blob[i].data == NULL, "malloc", HIK_VCA_LIB_E_PTR_NULL);
                memcpy(blob[i].data, ld->output_blobs[i].data, CNN_BLOB_GetDataNum(blob + i) * sizeof(float));
            }
        }
    }
}

void CNN_NET_Restore_layer_output(LAYER_DATA *ld, CNN_BLOB *blob, int layer_index)
{
    int         blob_num = ld->output_blobs_num;
    int         i;
    cudaError_t err;

    for (i = 0; i < blob_num; i++)
    {
#ifdef ARCH_SUPPORT_FP16
        if (blob[i].data_gpu_fp16)
        {
            err = cudaMemcpy(ld->output_blobs[i].data_gpu_fp16, blob[i].data_gpu_fp16,  CNN_BLOB_GetDataNum(blob + i) * sizeof(short), cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", HIK_VCA_LIB_E_PTR_NULL);
            err = cudaFree(blob[i].data_gpu_fp16);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaFree", HIK_VCA_LIB_E_PTR_NULL);
        }
#endif
        if (blob[i].data_gpu)
        {
            err = cudaMemcpy(ld->output_blobs[i].data_gpu, blob[i].data_gpu, CNN_BLOB_GetDataNum(blob + i) * sizeof(float), cudaMemcpyDeviceToDevice);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaMemcpy", HIK_VCA_LIB_E_PTR_NULL);
            err = cudaFree(blob[i].data_gpu);
            CNN_CHECK_ERROR(err != cudaSuccess, "cudaFree", HIK_VCA_LIB_E_PTR_NULL);
        }
        if (blob[i].data)
        {
            if (layer_index > 0)
            {
                memcpy(ld->output_blobs[i].data, blob[i].data, CNN_BLOB_GetDataNum(blob + i) * sizeof(float));
                free(blob[i].data);
            }
        }
    }
}

/***************************************************************************************************
* ��  ��: forward����
* ��  ��: net                    - I ���綨��
*         proc_in             - I process��������Ϣ
* ����ֵ: ״̬��
* ��  ע:
***************************************************************************************************/
HRESULT CNN_NET_Forward(NET                     *net,
                        HKA_CNN_FORWARD_IN_INFO *proc_in)
{
    int         i, li;
    int         end_layer_idx = proc_in->end_layer_idx;
    LAYER_DATA *layer;
    HRESULT     hr;
    int         profile_iter;

    static      int process_count = 0;
    const       int max_process_count = 1;

    int         height, width, channel, batch_size, in_num;
    int         timer_id = 0;

    CNN_BLOB    input_blobs[MAX_INPUT_BLOBS];
    CNN_BLOB    output_blobs[MAX_OUTPUT_BLOBS];

    int         net_pad_h = net->net_model->net_pad.pad_h;
    int         net_pad_w = net->net_model->net_pad.pad_w;

    int         support_zip;         // ģ���Ƿ�֧��ZIP
    int         not_zip;             // ��ģ��֧��ZIP��ǰ����,����ʱ����batch�Ƿ�2������ȷ���Ƿ����ZIP
    // 1 -> ��zip�� 0 -> zip

#ifdef CNN_CUDA_OPT
    int         next_relu_flag;
#endif

    support_zip = net->net_model->support_zip;
    not_zip = net->layers[0].output_blobs[0].shape[0] % 2; // ����batch_size��������ʱ�Ƿ�zip
    not_zip = support_zip ? not_zip : 1;                   // ������籾����֧��ZIP������not_zipΪ1

    net_pad_h = not_zip ? 0 : net_pad_h;
    net_pad_w = not_zip ? 0 : net_pad_w;

    if (end_layer_idx < 0)
    {
        end_layer_idx += net->layer_num;
    }

    // �ⲿ���ݸ�ֵ�����������
    for (i = 0; i < proc_in->in_blob_num; i++)
    {
        net->layers[0].output_blobs[i].ndims = 4;
        net->layers[0].output_blobs[i].shape[0] = proc_in->in_blob[i].shape[0];
        net->layers[0].output_blobs[i].shape[1] = proc_in->in_blob[i].shape[1];
        net->layers[0].output_blobs[i].shape[2] = proc_in->in_blob[i].shape[2];
        net->layers[0].output_blobs[i].shape[3] = proc_in->in_blob[i].shape[3];

        net->layers[0].output_blobs[i].data = proc_in->in_blob[i].data;
        net->layers[0].output_blobs[i].type = cnn_get_blob_type();
    }

#ifdef CNN_CONCAT_OPT
    // ��Ϊconcat�������blob���ڴ�ָ����Ҫ����ָ���������ȵ���һ��
    for (li = 0; li <= end_layer_idx; li++)
    {
        layer = &net->layers[li];
        //layer->reshape(layer->layer_handle, layer);
    }
#endif

    for (li = 0; li < MAX_OPT_PROFILE_INFO_NUM; li++)
    {
        OPT_PROFILE_TIME_RESET(li);
    }

    CNN_BASE_set_net_pad(net, 1);

    for (li = 0; li <= end_layer_idx; li++)
    {
        layer = &net->layers[li];

        if (CNN_NET_forward_check_input_empty(layer))
        {
            printf("CNN_NET_forward_check_input_empty(layer) failed\n");
            continue;
        }

        layer->layer_model->reshape(layer->layer_handle, layer);

#ifndef CNN_CUDA_OPT
        layer->layer_model->forward(layer->layer_handle, layer);
#else

        // ����ÿһ���format
        CNN_BASE_set_layer_data_format(layer, li, not_zip);

#ifdef PROFILE_RELU_WITH_BIAS
        next_relu_flag = CNN_NET_set_conv_relu_flag(li, layer, net);
#else
        next_relu_flag = 0;
#endif


        conv_switch = 1;
        fc_switch   = 1;

#if CNN_PROFILE_LAYER_COUNT == 1

#else
        hr = layer->layer_model->forward(layer->layer_handle, layer);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "layer->forward failed", hr);

        CNN_NET_Reserve_layer_output(layer, output_blobs, li);
#endif

        //conv��FC�㻹����bias����Ҫ������ʱ��
        if (!strcmp(layer->layer_model->type, "Convolution"))
        {
            conv_switch = 0;
            fc_switch   = 0;
            do_conv     = 1;
            do_fc       = 1;

            OPT_PROFILE_TIME_BY_EVENT_START(timer_id);

            for (profile_iter = 0; profile_iter < CNN_PROFILE_LAYER_COUNT; profile_iter++)
            {
                hr = layer->layer_model->forward(layer->layer_handle, layer);
                CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "layer->forward failed", hr);
            }
            OPT_PROFILE_TIME_BY_EVENT_STOP(timer_id, layer->layer_model->type, CNN_PROFILE_LAYER_COUNT, 0);

            timer_id++;
            do_conv     = 0;
            do_fc       = 0;

            OPT_PROFILE_TIME_BY_EVENT_START(timer_id);
            for (profile_iter = 0; profile_iter < CNN_PROFILE_LAYER_COUNT; profile_iter++)
            {
                if (not_zip == 1)
                {
                    hr = layer->layer_model->forward(layer->layer_handle, layer);
                    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "layer->forward failed", hr);
                }
            }
            OPT_PROFILE_TIME_BY_EVENT_STOP(timer_id, layer->layer_model->type, CNN_PROFILE_LAYER_COUNT, 0);
        }
        else
        {
            OPT_PROFILE_TIME_BY_EVENT_START(timer_id);
#if CNN_PROFILE_LAYER_COUNT != 1
            if (strcmp(layer->layer_model->type, "FrcnOutput") != 0)
            {
#endif
                for (profile_iter = 0; profile_iter < CNN_PROFILE_LAYER_COUNT; profile_iter++)
                {
                    hr = layer->layer_model->forward(layer->layer_handle, layer);
                    CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "layer->forward failed", hr);
                }
#if CNN_PROFILE_LAYER_COUNT != 1
            }
#endif
            OPT_PROFILE_TIME_BY_EVENT_STOP(timer_id, layer->layer_model->type, CNN_PROFILE_LAYER_COUNT, 0);
        }

#if CNN_PROFILE_LAYER_COUNT == 1
#else
        CNN_NET_Restore_layer_output(layer, output_blobs, li);
#endif

        if (next_relu_flag)
        {
            layer = &net->layers[++li];
            layer->reshape(layer->layer_handle, layer);
        }
#endif
        timer_id++;
    }

    if (process_count < max_process_count - 1)
    {
        printf("process_count: %d\n", process_count);
        process_count++;
    }
    else
    {
        for (li = 0; li < timer_id; li++)
        {
            if(opt_profile_info[li].profile_count != max_process_count)
            {
                printf("%d %d---------------------------------------profile error\n", opt_profile_info[li].profile_count, max_process_count);
            }
        }

        timer_id = 0;
        for (li = 0; li <= end_layer_idx; li++)
        {
            layer = &net->layers[li];

#ifdef PROFILE_RELU_WITH_BIAS
            next_relu_flag      = CNN_NET_set_conv_relu_flag(li, layer, net);
#else
            next_relu_flag      = 0;
#endif

            if (!strcmp(layer->layer_model->type, "Convolution"))
            {
                batch_size = layer->input_blobs[0]->shape[0];
                channel    = layer->input_blobs[0]->shape[1];
                height     = layer->input_blobs[0]->shape[2];
                width      = layer->input_blobs[0]->shape[3];

                CNN_NET_profile(timer_id++, layer, height, width, channel, batch_size, 0);

                if (next_relu_flag)
                {
                    layer = &net->layers[++li];
                }

                batch_size = layer->input_blobs[0]->shape[0];
                channel    = layer->input_blobs[0]->shape[1];
                height     = layer->input_blobs[0]->shape[2];
                width      = layer->input_blobs[0]->shape[3];

                CNN_NET_profile(timer_id, layer, height, width, channel, batch_size, !next_relu_flag);
            }
            else
            {
                if (li == 0)
                {
                    batch_size  = layer->output_blobs[0].shape[0];
                    channel     = layer->output_blobs[0].shape[1];
                    height      = layer->output_blobs[0].shape[2];
                    width       = layer->output_blobs[0].shape[3];
                }
                else
                {
                    batch_size  = layer->input_blobs[0]->shape[0];
                    channel     = layer->input_blobs[0]->shape[1];
                    height      = layer->input_blobs[0]->shape[2];
                    width       = layer->input_blobs[0]->shape[3];
                }
                CNN_NET_profile(timer_id, layer, height, width, channel, batch_size, 0);
            }
            timer_id++;
        }

        printf("timer_id %d\n", timer_id);
    }

    return HIK_VCA_LIB_S_OK;
}
#else   // release��
/***************************************************************************************************
* ��  ��: forward����
* ��  ��: net                    - I ���綨��
*         proc_in             - I process��������Ϣ
* ����ֵ: ״̬��
* ��  ע:
***************************************************************************************************/
HRESULT CNN_NET_Forward(NET                     *net,
                        HKA_CNN_FORWARD_IN_INFO *proc_in)
{
    int         i, li, iter;
    int         end_layer_idx = proc_in->end_layer_idx;
    LAYER_DATA *layer;
    HRESULT     hr;
    int         net_pad_h = net->net_model->net_pad.pad_h;
    int         net_pad_w = net->net_model->net_pad.pad_w;

    int         support_zip;         // ģ���Ƿ�֧��ZIP
    int         not_zip;             // ��ģ��֧��ZIP��ǰ����,����ʱ����batch�Ƿ�2������ȷ���Ƿ����ZIP
                                     // 1 -> ��zip�� 0 -> zip

	int         timer_id = 0;
	int         print_flag =0;

#ifdef CNN_CUDA_OPT
    int         next_relu_flag;      // conv���Ƿ��relu
    int         next_roi_flag;       // proposal���Ƿ��roi
    int         elt_bn_flag;         // elt����Ƿ��bn
    int         elt_bn_relu_flag;    // elt����Ƿ��bn��relu
#endif

    support_zip = net->net_model->support_zip;
    not_zip     = net->layers[0].output_blobs[0].shape[0] % 2; // ����batch_size��������ʱ�Ƿ�zip
    not_zip     = support_zip ? not_zip : 1;                   // ������籾����֧��ZIP������not_zipΪ1

    net_pad_h   = not_zip ? 0 : net_pad_h;
    net_pad_w   = not_zip ? 0 : net_pad_w;

    if (end_layer_idx < 0)
    {
        end_layer_idx += net->layer_num;
    }

    // �ⲿ���ݸ�ֵ�����������
    for (i = 0; i < proc_in->in_blob_num; i++)
    {
        net->layers[0].output_blobs[i].ndims    = 4;
        net->layers[0].output_blobs[i].shape[0] = proc_in->in_blob[i].shape[0];
        net->layers[0].output_blobs[i].shape[1] = proc_in->in_blob[i].shape[1];
        net->layers[0].output_blobs[i].shape[2] = proc_in->in_blob[i].shape[2];
        net->layers[0].output_blobs[i].shape[3] = proc_in->in_blob[i].shape[3];

        net->layers[0].output_blobs[i].data = proc_in->in_blob[i].data;
        net->layers[0].output_blobs[i].type = cnn_get_blob_type();
    }

    for (li = 0; li <= end_layer_idx; li++)
    {
        layer = &net->layers[li];

#ifdef CNN_CONCAT_OPT
        //layer->reshape(layer->layer_handle, layer);
#endif
    }

    CNN_BASE_set_net_pad(net, 1);

    for (li = 0; li <= end_layer_idx; li++)
    {
        layer = &net->layers[li];

        if (CNN_NET_forward_check_input_empty(layer))
        {
            //printf("=========================================================== CNN_NET_forward_check_input_empty\n");
            continue;
        }

        layer->reshape(layer->layer_handle, layer);

        //printf("process %d %d %-55s %+25s\n", li, layer->id, layer->layer_model->name, layer->layer_model->type);
        //printf("process %d %d %-55s %+25s\n", li, layer->id, layer->layer_model->name, layer->layer_model->type);

#ifndef CNN_CUDA_OPT
        layer->layer_model->forward(layer->layer_handle, layer);
#else
        // ����ÿһ���format
        CNN_BASE_set_layer_data_format(layer, li, not_zip);

        //printf("process %d %d %-55s %+25s", li, layer->id, layer->layer_model->name, layer->layer_model->type);
        //for (iter = 0; iter < layer->output_blobs_num; iter++)
        //{
        //    printf(" %d, ", layer->output_blobs[iter].pad.pad_h);
        //}
        //printf("\n");
        
        next_relu_flag      = CNN_NET_set_conv_relu_flag(li, layer, net);
        next_roi_flag       = CNN_NET_set_rpn_fused_flag(li, layer, net);
        //elt_bn_relu_flag    = CNN_NET_set_elt_bn_relu_flag(li, layer, net);
if(strcmp(layer->layer_model->type, "Convolution") != 0)
{
	print_flag=1;
}
else
{
	print_flag=0;
}

OPT_PROFILE_TIME_START(timer_id);

        hr                  = layer->layer_model->forward(layer->layer_handle, layer);
        CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "layer->forward failed", hr);

OPT_PROFILE_TIME_STOP(timer_id, layer->layer_model->type, 1, print_flag);

timer_id++;


        //cudaDeviceSynchronize();
        //cudaError_t err = cudaGetLastError();
        //if (err != cudaSuccess)
        //{
        //    printf("%d %s\n", li, layer->layer_model->type);
        //    return CNN_convert_cudart_error_code(err);
        //}

        if (next_relu_flag)
        {
            layer = &net->layers[++li];
            layer->reshape(layer->layer_handle, layer);
            //CNN_CHECK_ERROR(elt_bn_relu_flag, "elt_bn_relu_flag == 1", HIK_VCA_LIB_KEY_PARAM_ERR);
        }

        if (next_roi_flag)
        {
            layer = &net->layers[++li];
            layer->reshape(layer->layer_handle, layer);
        }

        /*
        if (elt_bn_relu_flag)
        {
            li += 2;
            layer = &net->layers[li];
            layer->reshape(layer->layer_handle, layer);
            CNN_CHECK_ERROR(next_relu_flag, "next_relu_flag == 1", HIK_VCA_LIB_KEY_PARAM_ERR);
        }
        */
#endif // CNN_CUDA_OPT
    }

    return HIK_VCA_LIB_S_OK;
}

#endif

/***************************************************************************************************
* ��  ��: ��ȡĳ������blob
* ��  ��: net                    - I ���綨��
*         layer_index            - I ������
*         out_index              - I ���blob�����
* ����ֵ: ���������Ϊblobָ�룬����ΪNULL
***************************************************************************************************/
CNN_BLOB *CNN_NET_GetBlob(NET *net,
                          int  layer_index,
                          int  out_index)
{
    if (layer_index < 0)
    {
        layer_index += net->layer_num;
    }

    HKA_CHECK_ERROR(layer_index < 0, NULL);
    HKA_CHECK_ERROR(layer_index >= net->layer_num, NULL);

    if (out_index < 0)
    {
        out_index += net->layers[layer_index].output_blobs_num;
    }

    HKA_CHECK_ERROR(out_index < 0, NULL);
    HKA_CHECK_ERROR(out_index >= net->layers[layer_index].output_blobs_num, NULL);

    return &net->layers[layer_index].output_blobs[out_index];
}



/***************************************************************************************************
* ��  ��: ��������Ԫ��ֵ��1
* ��  ��: 
*       set           - I/O         ����
* ����ֵ: ��
***************************************************************************************************/
void CNN_NET_inc_set_i(CNN_SET_I *set)
{
    int i;
    for (i = 0; i < set->ele_num; i++)
    {
        set->elements[i]++;
    }
}

