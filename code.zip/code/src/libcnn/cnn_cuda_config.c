/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: cnn_cuda_config.c
* �ļ���ʶ: 
* ժ    Ҫ:
*
* ��ǰ�汾: 1.0.0
* ��    ��: Ѧ����
* ��    ��: 2016-02-29
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#include "cnnfp16_lib.h"
#else
#include "cnn_lib.h"
#endif
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include "cnn_cuda_config.h"
#include "vca_common.h"


/***************************************************************************************************
* ��  ��: ��cudnn�Ĵ�����ת����VCA������
* ��  ��:
*         cudnn_sts           -I         cudnn״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cudnn_error_code(cudnnStatus_t  cudnn_sts)
{
    return CNN_CUDNN_ERROR_CODE_BASE + (int)cudnn_sts;
}

/***************************************************************************************************
* ��  ��: ��cublas�Ĵ�����ת����VCA������
* ��  ��:
*         cublas_sts           -I         cublas״̬��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cublas_error_code(cublasStatus_t  cublas_sts)
{
    return CNN_CUBLAS_ERROR_CODE_BASE + (int)cublas_sts;
}

/***************************************************************************************************
* ��  ��: ��cuda����ʱ�Ĵ�����ת����VCA������
* ��  ��:
*         cuda_err           -I         cuda������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_convert_cudart_error_code(cudaError_t  cuda_err)
{
    return CNN_CUDA_ERROR_CODE_BASE + (int)cuda_err;
}




/***************************************************************************************************
* ��  ��: ��HIKCUDA_HANDLE��ֵ��CNN_CUDA_HANDLE
* ��  ��: 
*         cuda_handle            -O   cnn cuda handle
*         hik_cuda_handle        -I   hik cuda handle
*         cnn_buf                -I   �ڴ滺��
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_create_cuda_handle(CNN_CUDA_HANDLE              *cuda_handle, 
                               HIKCUDA_HANDLE               *hik_cuda_handle, 
                               CNN_BUF                      *cnn_buf)
{
    cuda_handle->cublas_handle.cublas_handle    = hik_cuda_handle->cublas_handle.cublas_handle;
    CNN_CHECK_ERROR(cuda_handle->cublas_handle.cublas_handle == NULL, "cuda_handle->cublas_handle.cublas_handle is NULL",   HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.cudnn_handle = hik_cuda_handle->cudnn_handle.cudnn_handle;
    CNN_CHECK_ERROR(cuda_handle->cublas_handle.cublas_handle == NULL, "cuda_handle->cublas_handle.cublas_handle is NULL", HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.srcTensorDesc     = hik_cuda_handle->cudnn_handle.srcTensorDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.srcTensorDesc == NULL, "cuda_handle->cudnn_handle.srcTensorDesc is NULL",     HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.dstTensorDesc     = hik_cuda_handle->cudnn_handle.dstTensorDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.dstTensorDesc == NULL, "cuda_handle->cudnn_handle.dstTensorDesc is NULL",     HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.biasTensorDesc    = hik_cuda_handle->cudnn_handle.biasTensorDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.biasTensorDesc == NULL, "cuda_handle->cudnn_handle.biasTensorDesc is NULL",   HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.filterDesc        = hik_cuda_handle->cudnn_handle.filterDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.filterDesc == NULL, "cuda_handle->cudnn_handle.filterDesc is NULL",           HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.convDesc          = hik_cuda_handle->cudnn_handle.convDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.convDesc == NULL, "cuda_handle->cudnn_handle.convDesc is NULL",               HIK_VCA_LIB_E_PTR_NULL);

    cuda_handle->cudnn_handle.poolingDesc       = hik_cuda_handle->cudnn_handle.poolingDesc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.poolingDesc == NULL, "cuda_handle->cudnn_handle.poolingDesc is NULL",         HIK_VCA_LIB_E_PTR_NULL);

#if CUDNN_VERSION >= 4000
    cuda_handle->cudnn_handle.lrn_desc          = hik_cuda_handle->cudnn_handle.lrn_desc;
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.lrn_desc == NULL, "cuda_handle->cudnn_handle.lrn_desc is NULL",               HIK_VCA_LIB_E_PTR_NULL);
#else
    cuda_handle->cudnn_handle.lrn_desc = NULL;
#endif

    cuda_handle->cudnn_handle.cudnn_mem_size    = CNN_CUDNN_MEM_SIZE;
    cuda_handle->cudnn_handle.cudnn_mem         = CNN_alloc_buffer(cnn_buf, CNN_SIZE_ALIGN(cuda_handle->cudnn_handle.cudnn_mem_size), CNN_CUDA_MEM_ALIGNMENT, 0);
    CNN_CHECK_ERROR(cuda_handle->cudnn_handle.cudnn_mem == NULL, "cuda_handle->cudnn_handle.cudnn_mem",                     HIK_VCA_LIB_E_MEM_OUT);

    return HIK_VCA_LIB_S_OK;
}
#endif
