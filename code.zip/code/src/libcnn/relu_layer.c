/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: relu_layer.c
* �ļ���ʶ: RELU_LAYER_C
* ժ    Ҫ: relu��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-02
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <string.h>
#include <stdio.h>
#ifdef CNN_CUDA_OPT
#include <cudnn.h>
#include "act_layer_cuda.h"
#include "relu_layer_cuda.h"
#endif // CNN_CUDA_OPT
#include "relu_layer.h"

/***************************************************************************************************
* ��  ��: ��ʼ��
* ��  ��: hyperparams            - I   ������
*         param_blobs            - I   ����
*         ld                     - I/O ��layer������
*         concat_layer           - I/O ��layer�ľ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RELU_init(const char *hyperparams,
                      const char *param_blobs,
                      LAYER_MODEL *ld,
                      RELU_MODEL *relu_model)
{
    int         r;
    const char  nsl[] = "negative_slope";
    const char *ptr;

    relu_model->negative_slope = 0.f;
    if ((NULL != hyperparams) && (ptr = strstr(hyperparams, nsl)))
    {
        r = sscanf(ptr + strlen(nsl) + 1, "%f", &relu_model->negative_slope);
        HKA_CHECK_ERROR(1 != r, HIK_VCA_CNN_MODEL_ERROR);
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RELU_Reshape(void       *handle,
                         LAYER_DATA *ld)
{
    int bi;

    for (bi = 0; bi < ld->output_blobs_num; bi++)
    {
        memcpy(&ld->output_blobs[bi].shape, 
               ld->input_blobs[bi]->shape,
               sizeof(SHAPE_UNIT_TYPE) * CNN_BLOB_MAX_DIM);

        ld->output_blobs[bi].ndims          = ld->input_blobs[bi]->ndims;
        ld->output_blobs[bi].type           = ld->input_blobs[bi]->type;
        ld->output_blobs[bi].format         = ld->input_blobs[bi]->format;
        ld->output_blobs[bi].data           = ld->input_blobs[bi]->data;
        ld->output_blobs[bi].data_gpu       = ld->input_blobs[bi]->data_gpu;
        ld->output_blobs[bi].data_gpu_fp16  = ld->input_blobs[bi]->data_gpu_fp16;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RELU_Create(LAYER_DATA *ld,
                        CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                        void      **handle)
{
    HRESULT     hr;
    RELU_LAYER *relu_layer;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    HKA_CHECK_ERROR(ld->input_blobs_num != ld->output_blobs_num, HIK_VCA_CNN_MODEL_ERROR);
    HKA_CHECK_ERROR(0 == ld->input_blobs_num, HIK_VCA_CNN_MODEL_ERROR);

    relu_layer = (RELU_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                CNN_SIZE_ALIGN(sizeof(RELU_LAYER)),
                                                CNN_MEM_ALIGN_SIZE,
                                                1);
    HKA_CHECK_MEMOUT(relu_layer);

    relu_layer->model = ld->layer_model->model_handle;

    hr = CNN_RELU_Reshape(relu_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = relu_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_RELU_GetMemsize(LAYER_DATA    *ld,
                            VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    HRESULT         hr;
    VCA_MEM_TAB_V2 *cpu_handle_tab = mem_tab;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(RELU_LAYER)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    hr = CNN_RELU_Reshape(NULL, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_RELU_CreateModel(const char *hyperparams,
                             const char *param_blobs,
                             LAYER_MODEL *ld,
                             CNN_BUF     mem_buf[MODEL_MEM_TAB_NUM],
                             void      **handle)
{
    HRESULT     hr;
    RELU_MODEL *relu_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    relu_model = (RELU_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
                                                CNN_SIZE_ALIGN(sizeof(RELU_MODEL)),
                                                CNN_MEM_ALIGN_SIZE,
                                                1);
    HKA_CHECK_MEMOUT(relu_model);

    hr = CNN_RELU_init(hyperparams, param_blobs, ld, relu_model);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = relu_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_RELU_GetModelMemsize(const char    *hyperparams,
                                 const char    *param_blobs,
                                 LAYER_MODEL    *ld,
                                 VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    VCA_MEM_TAB_V2 *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab,
                       CNN_SIZE_ALIGN(sizeof(RELU_MODEL)),
                       CNN_MEM_ALIGN_SIZE,
                       VCA_MEM_PERSIST,
                       VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_RELU_Forward(void       *handle,
                         LAYER_DATA *ld)
{
    int         i, bi;
    int         blob_data_num;
    float       d;
    float       negative_slope;
    RELU_LAYER *relu_layer = (RELU_LAYER *)handle;

    negative_slope = relu_layer->model->negative_slope;

    if (CNN_DT_FLT32 == ld->output_blobs[0].type)
    {
        for (bi = 0; bi < ld->output_blobs_num; bi++)
        {
            float *data = (float *)ld->output_blobs[bi].data;
            blob_data_num = CNN_BLOB_GetDataNum(&ld->output_blobs[0]);
            for (i = 0; i < blob_data_num; i++)
            {
                d       = data[i];
                data[i] = (d > 0.f) ? d : negative_slope * d;
            }
        }
    }
    return HIK_VCA_LIB_S_OK;
}

#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: �����ǰ�򴫲���ʹ��cudnn��
* ��  ��:
*           cnn_cudnn_handle       - I/O cudnn handle
*           data                   - �������
*           type                   - ��������
*           n                      - n
*           c                      - c
*           h                      - h
*           w                      - w
*           act_mode               - ���ʽ��������RELU��sigmoid��
* ����ֵ: ������
***************************************************************************************************/
HRESULT cnn_act_forward_cudnn(CNN_CUDNN_HANDLE          *cnn_cudnn_handle,
                              float_t                   *data,
                              BLOB_DATA_TYPE             type,
                              int                        n,
                              int                        c,
                              int                        h,
                              int                        w,
                              cudnnActivationMode_t      act_mode)
{
    cudnnHandle_t                   cudnn_handle    = cnn_cudnn_handle->cudnn_handle;
    cudnnTensorDescriptor_t         src_tensor_desc = cnn_cudnn_handle->srcTensorDesc;
    cudnnTensorDescriptor_t         dst_tensor_desc = cnn_cudnn_handle->dstTensorDesc;

    float                           alpha           = 1.0f;
    float                           beta            = 0.0f;
    cudnnStatus_t                   cudnn_sts;

    cudnnTensorFormat_t             tensor_format   = CUDNN_TENSOR_NCHW;                   //Ŀǰֻ֧�������ڴ����з�ʽ
    cudnnDataType_t                 data_type        = (type == CNN_DT_FLT32) ? CUDNN_DATA_FLOAT : CUDNN_DATA_HALF;

    cudnn_sts = cudnnSetTensor4dDescriptor(src_tensor_desc, tensor_format, data_type, n, c, h, w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));
    cudnn_sts = cudnnSetTensor4dDescriptor(dst_tensor_desc, tensor_format, data_type, n, c, h, w);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnSetTensorNdDescriptor failed", CNN_convert_cudnn_error_code(cudnn_sts));

#if CUDNN_VERSION >= 5000
    cudnn_sts   = cudnnActivationForward_v3(cudnn_handle, act_mode, &alpha, src_tensor_desc, data, &beta, dst_tensor_desc, data);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnActivationForward", CNN_convert_cudnn_error_code(cudnn_sts));
#else
    cudnn_sts   = cudnnActivationForward(cudnn_handle, act_mode, &alpha, src_tensor_desc, data, &beta, dst_tensor_desc, data);
    CNN_CHECK_ERROR(cudnn_sts != CUDNN_STATUS_SUCCESS, "cudnnActivationForward", CNN_convert_cudnn_error_code(cudnn_sts));
#endif

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: RELU��ǰ�򴫲���ʹ��cudnn��
* ��  ��:
*           cnn_cudnn_handle       - I/O cudnn handle
*           data                   - �������
*           type                   - ��������
*           n                      - n
*           c                      - c
*           h                      - h
*           w                      - w
* ����ֵ: ������
***************************************************************************************************/
static HRESULT cnn_relu_forward_cudnn(CNN_CUDNN_HANDLE          *cnn_cudnn_handle,
                                      float_t                   *data,
                                      BLOB_DATA_TYPE             type,
                                      int                        n,
                                      int                        c,
                                      int                        h,
                                      int                        w)
{
    return cnn_act_forward_cudnn(cnn_cudnn_handle, data, type, n, c, h, w, CUDNN_ACTIVATION_RELU);
}


/***************************************************************************************************
* ��  ��: RELU��ǰ�򴫲�(CUDA��)
* ��  ��: 
*           relu_layer             - I/O layer
*           ld                     - I/O �ò������
* ����ֵ: ������
***************************************************************************************************/
HRESULT CNN_RELU_Forward_Cuda_Opt(RELU_LAYER         *relu_layer,
                                  LAYER_DATA         *ld)
{
    float                   negative_slope;
    HRESULT                 hr;
    CNN_CUDNN_HANDLE        *cnn_cudnn_handle   = &ld->cuda_handle->cudnn_handle;
    BLOB_DATA_TYPE          type = ld->output_blobs[0].type;
    void                    *data = ld->output_blobs[0].data_gpu;
    BLOB_DATA_FORMAT       format = ld->output_blobs[0].format;

    type                    = ld->output_blobs[0].type;

    if (type == CNN_DT_FLT16)
    {
        data = ld->output_blobs[0].data_gpu_fp16;
    }

    negative_slope = relu_layer->model->negative_slope;

    if (negative_slope == 0.0f)
    {
        if (format == CNN_FORMAT_NCHW)
        {
            hr = cnn_relu_forward_cudnn(cnn_cudnn_handle, 
                                        data,
                                        type,
                                        ld->output_blobs[0].shape[0], 
                                        ld->output_blobs[0].shape[1], 
                                        ld->output_blobs[0].shape[2], 
                                        ld->output_blobs[0].shape[3]);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_relu_forward_cudnn", hr);
        }
        else
        {
        	#if 1
            hr = cnn_relu_forward_cudnn(cnn_cudnn_handle, 
                                        data,
                                        type,
                                        ld->output_blobs[0].shape[0], 
                                        ld->output_blobs[0].shape[1], 
                                        ld->output_blobs[0].shape[2] + 2 * ld->output_blobs[0].pad.pad_h, 
                                        ld->output_blobs[0].shape[3] + 2 * ld->output_blobs[0].pad.pad_h);
            CNN_CHECK_ERROR(hr != HIK_VCA_LIB_S_OK, "cnn_relu_forward_cudnn", hr);
			#else
			cnn_relu_forward_cuda(data,
			                      data,
			                      type,
			                      format,
			                      ld->output_blobs[0].shape[1]* ld->output_blobs[0].shape[2] * ld->output_blobs[0].shape[3],                                   
			                      ld->output_blobs[0].shape[0], 
                                  ld->output_blobs[0].shape[1], 
                                  ld->output_blobs[0].shape[2], 
                                  ld->output_blobs[0].shape[3], 
                                  ld->input_blobs[0]->pad.pad_h,
                                  ld->output_blobs[0].pad.pad_h);
			#endif
        }
    }
    else
    {
        printf("negative_slope != 0.0f not implemented\n");
        return HIK_VCA_LIB_KEY_PARAM_ERR;
    }
    return HIK_VCA_LIB_S_OK;
}


#endif  // CNN_CUDA_OPT