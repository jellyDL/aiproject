/***************************************************************************************************
* ��Ȩ��Ϣ����Ȩ����(c) , ���ݺ����������ּ����ɷ����޹�˾, ��������Ȩ��
*
* �ļ�����: dropout_layer.c
* �ļ���ʶ: DROPOUT_LAYER_C
* ժ    Ҫ: dropout��ĺ���ʵ��
*
* ��ǰ�汾: 1.0.0
* ��    ��: ̷����
* ��    ��: 2016-02-01
* ��    ע:
***************************************************************************************************/
#ifdef CNN_USED_AS_FRCNN
#include "cnn_redef.h"
#endif
#include <memory.h>
#include "dropout_layer.h"

/***************************************************************************************************
* ��  ��: ����������������shape
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_DROPOUT_Reshape(void       *handle,
                            LAYER_DATA *ld)
{
    int            i;
    HRESULT        hr;

    ld->output_blobs_num = ld->input_blobs_num;

    for (i = 0; i < ld->input_blobs_num; i++)
    {
        memcpy(&ld->output_blobs[i].shape, 
               ld->input_blobs[i]->shape,
               sizeof(SHAPE_UNIT_TYPE) * CNN_BLOB_MAX_DIM);

        ld->output_blobs[i].ndims          = ld->input_blobs[i]->ndims;
        ld->output_blobs[i].type           = ld->input_blobs[i]->type;
        ld->output_blobs[i].format         = ld->input_blobs[i]->format;
        ld->output_blobs[i].data           = ld->input_blobs[i]->data;
        ld->output_blobs[i].data_gpu       = ld->input_blobs[i]->data_gpu;
        ld->output_blobs[i].data_gpu_fp16  = ld->input_blobs[i]->data_gpu_fp16;
    }

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����layer
* ��  ��: ld                     - I/O �ò���ص�����
*         mem_buf                - I   �ڴ�
*         handle                 - O   ���
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_DROPOUT_Create(LAYER_DATA *ld,
                           CNN_BUF     mem_buf[LAYER_MEM_TAB_NUM],
                           void      **handle)
{
    int            i;
    HRESULT        hr;
    DROPOUT_LAYER *dropout_layer;

    CNN_BUF                 *cpu_handle_buf       = mem_buf;

    dropout_layer = (DROPOUT_LAYER *)CNN_alloc_buffer(cpu_handle_buf,
                                                      CNN_SIZE_ALIGN(sizeof(DROPOUT_LAYER)),
                                                      CNN_MEM_ALIGN_SIZE,
                                                      1);
    HKA_CHECK_MEMOUT(dropout_layer);

    dropout_layer->model = ld->layer_model->model_handle;

    hr = CNN_DROPOUT_Reshape(dropout_layer, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    *handle = dropout_layer;

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ��ȡlayer���ڴ��С
* ��  ��: ld                     - I �ò���ص�����
*         mem_tab                - O �ڴ��
* ����ֵ: ״̬��
***************************************************************************************************/
HRESULT CNN_DROPOUT_GetMemsize(LAYER_DATA *ld,
                               VCA_MEM_TAB_V2 mem_tab[LAYER_MEM_TAB_NUM])
{
    int             i;
    HRESULT hr;
    VCA_MEM_TAB_V2     *cpu_handle_tab = mem_tab;

    memset(mem_tab, 0, sizeof(mem_tab[0]) * LAYER_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(DROPOUT_LAYER)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    hr = CNN_DROPOUT_Reshape(NULL, ld);
    HKA_CHECK_ERROR(HIK_VCA_LIB_S_OK != hr, hr);

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_DROPOUT_CreateModel(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, CNN_BUF mem_buf[MODEL_MEM_TAB_NUM], void **handle)
{
    int            i;
    HRESULT        hr;
    DROPOUT_MODEL *dropout_model;

    CNN_BUF *cpu_handle_buf = &mem_buf[0];

    dropout_model = (DROPOUT_MODEL *)CNN_alloc_buffer(cpu_handle_buf,
        CNN_SIZE_ALIGN(sizeof(DROPOUT_MODEL)),
        CNN_MEM_ALIGN_SIZE,
        1);
    HKA_CHECK_MEMOUT(dropout_model);
    
    *handle = dropout_model;

    return HIK_VCA_LIB_S_OK;
}

HRESULT CNN_DROPOUT_GetModelMemsize(const char *hyperparams, const char *param_blobs, LAYER_MODEL *ld, VCA_MEM_TAB_V2 mem_tab[MODEL_MEM_TAB_NUM])
{
    int             i;
    VCA_MEM_TAB_V2     *cpu_handle_tab = &mem_tab[0];

    memset(mem_tab, 0, sizeof(mem_tab[0]) * MODEL_MEM_TAB_NUM);

    CNN_BASE_SetMemTab(cpu_handle_tab, CNN_SIZE_ALIGN(sizeof(DROPOUT_MODEL)), CNN_MEM_ALIGN_SIZE, VCA_MEM_PERSIST, VCA_MEM_PLAT_CPU);

    return HIK_VCA_LIB_S_OK;
}

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�
* ��  ��: handle                 - I/O ��layer�ľ��
*         ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_DROPOUT_Forward(void       *handle,
                            LAYER_DATA *ld)
{
    return HIK_VCA_LIB_S_OK;
}


#ifdef CNN_CUDA_OPT

/***************************************************************************************************
* ��  ��: ����ǰ�򴫲�(CUDA��)
* ��  ��: 
*           dropout_layer          - I/O ��layer�ľ��
*           ld                     - I/O �ò������
* ����ֵ: ��
***************************************************************************************************/
HRESULT CNN_DROPOUT_Forward_Cuda_Opt(DROPOUT_LAYER          *dropout_layer,
                                     LAYER_DATA             *ld)
{
    return HIK_VCA_LIB_S_OK;
}

#endif