#define OPT_CUDA_PROFILE

#ifdef OPT_CUDA_PROFILE
#include <cuda_runtime.h>
#endif
#include <stdio.h>
#include "opt_profile.h"

//profileȫ�ֱ���
OPT_PROFILE_INFO    opt_profile_info[MAX_OPT_PROFILE_INFO_NUM];

/***************************************************************************************************
* ��  ��: profile��ʱ��Ϣ
* ��  ��:
*               num         ָ��ʹ�õļ�ʱ��
* ����ֵ: ��
***************************************************************************************************/
void opt_profile_time_start(int num)
{
#ifdef OPT_TIMER

#ifdef LINUX
#else
    QueryPerformanceFrequency(&opt_profile_info[num].freq);
#endif

    cudaDeviceSynchronize();

#ifdef LINUX
    gettimeofday(&(opt_profile_info[num].start), NULL);
#else
    QueryPerformanceCounter(&opt_profile_info[num].start);
#endif

#endif
}



/***************************************************************************************************
* ��  ��: profile��ʱ��Ϣ
* ��  ��:
*               num         ָ��ʹ�õļ�ʱ��
* ����ֵ: ��
***************************************************************************************************/
void opt_profile_time_by_event_start(int num)
{
#if 0
     cudaError_t err ;
     err = cudaEventCreate(&opt_profile_info[num].e_start);
     if (err != cudaSuccess)
     {
         printf("cudaEventCreate failed\n");
         exit(0);
     }
     err = cudaEventCreate(&opt_profile_info[num].e_stop);
     if (err != cudaSuccess)
     {
         printf("cudaEventCreate failed\n");
         exit(0);
     }
     printf("++++++++++++++++++++++++++++++opt_profile_time_by_event_start\n");
     cudaEventRecord(opt_profile_info[num].e_start, 0);
#endif
}


void opt_profile_time_reset(int num)
{
    //memset(opt_profile_info + num, 0, sizeof(OPT_PROFILE_INFO));
    double          time_used;                              //��ʱ
    int             profile_count;                          //��������
    double          time_used_total;                        //�ܺ�ʱ
    double          calculation;                            //������
    double          gflops;                                 //������ / ��ʱ

    double          time_used_max;
    double          time_used_min;

    //cudaEventCreate(&opt_profile_info[num].e_start);
    //cudaEventCreate(&opt_profile_info[num].e_stop);
    //cudaEventDestroy(opt_profile_info[num].e_start);
    //cudaEventDestroy(opt_profile_info[num].e_stop);

    opt_profile_info[num].time_used             = 0.0;
    opt_profile_info[num].profile_count = 0;
    opt_profile_info[num].time_used_total       = 0.0;
    opt_profile_info[num].calculation           = 0.0;
    opt_profile_info[num].gflops                = 0.0;
    opt_profile_info[num].time_used_max         = -100000000.0;
    opt_profile_info[num].time_used_min         = 9999999999.0;
}    



void opt_print_info(const char *str, int num)
{

    printf("%10s: avg: %10f max: %10f min: %10f total: %10f iter: %10d\n",
        str,
        opt_profile_info[num].time_used_total / opt_profile_info[num].profile_count,
        opt_profile_info[num].time_used_max,
        opt_profile_info[num].time_used_min,
        opt_profile_info[num].time_used_total,
        opt_profile_info[num].profile_count);
}

/***************************************************************************************************
* ��  ��: profile��ʱ��Ϣ
* ��  ��:
*               num                 ָ��ʹ�õļ�ʱ��
*               str                 �ַ�����Ϣ
*               iter                �ܹ���������
*               print_flag          ��ӡ��Ϣ��־
* ����ֵ: ��
***************************************************************************************************/
void opt_profile_time_stop(int num, const char *str, int iter, int print_flag)
{
#ifdef OPT_TIMER
    double             time_used;

#ifdef OPT_CUDA_PROFILE
    cudaDeviceSynchronize();
#endif

#ifdef LINUX
    gettimeofday(&(opt_profile_info[num].end), NULL);
#else
    QueryPerformanceCounter(&opt_profile_info[num].end);
#endif


#ifdef LINUX
    time_used = 1.0 * (opt_profile_info[num].end.tv_sec - opt_profile_info[num].start.tv_sec) * 1000.0 + 1.0 * (opt_profile_info[num].end.tv_usec - opt_profile_info[num].start.tv_usec) / 1000.0;
#else
    time_used = 1.0 * (opt_profile_info[num].end.QuadPart - opt_profile_info[num].start.QuadPart) / opt_profile_info[num].freq.QuadPart * 1000;
#endif

    time_used /= iter;

    opt_profile_info[num].time_used_max = opt_profile_info[num].time_used_max > time_used ? opt_profile_info[num].time_used_max : time_used;
    opt_profile_info[num].time_used_min = opt_profile_info[num].time_used_min < time_used ? opt_profile_info[num].time_used_min : time_used;

    opt_profile_info[num].time_used        = time_used;
    opt_profile_info[num].time_used_total += time_used;
    opt_profile_info[num].profile_count   += 1;

    if (print_flag)
    {
        printf("num%d , %s time_used: %f avg: %f max: %f min: %f total: %f iter: %d\n", 
			   num,
               str, 
               time_used, 
               opt_profile_info[num].time_used_total / opt_profile_info[num].profile_count, 
               opt_profile_info[num].time_used_max,
               opt_profile_info[num].time_used_min,
               opt_profile_info[num].time_used_total,
               opt_profile_info[num].profile_count);
    }
#else
    opt_profile_info[num].time_used = 0.0;
#endif
}


/***************************************************************************************************
* ��  ��: profile��ʱ��Ϣ
* ��  ��:
*               num                 ָ��ʹ�õļ�ʱ��
*               str                 �ַ�����Ϣ
*               iter                �ܹ���������
*               print_flag          ��ӡ��Ϣ��־
* ����ֵ: ��
***************************************************************************************************/
void opt_profile_time_by_event_stop(int num, const char *str, int iter, int print_flag)
{
#if 0
#ifdef OPT_TIMER
   float time_used;
   cudaError_t err;
   cudaEventRecord(opt_profile_info[num].e_stop, 0);
   cudaEventSynchronize(opt_profile_info[num].e_stop);
   cudaEventElapsedTime(&time_used, opt_profile_info[num].e_start, opt_profile_info[num].e_stop);

   time_used /= iter;
   opt_profile_info[num].time_used_max      = opt_profile_info[num].time_used_max > time_used ? opt_profile_info[num].time_used_max : time_used;
   opt_profile_info[num].time_used_min      = opt_profile_info[num].time_used_min < time_used ? opt_profile_info[num].time_used_min : time_used;

   opt_profile_info[num].time_used          = time_used;
   opt_profile_info[num].time_used_total    += time_used;
   opt_profile_info[num].profile_count      += 1;

   err = cudaEventDestroy(opt_profile_info[num].e_start);
   if (err != cudaSuccess)
   {
       printf("cudaEventDestroy failed\n");
       exit(0);
   }
   err = cudaEventDestroy(opt_profile_info[num].e_stop);
   if (err != cudaSuccess)
   {
       printf("cudaEventDestroy failed\n");
       exit(0);
   }

   if (print_flag)
   {
       printf("%s time_used: %f avg: %f max: %f min: %f total: %f iter: %d\n", 
              str, 
              time_used, 
              opt_profile_info[num].time_used_total / opt_profile_info[num].profile_count, 
              opt_profile_info[num].time_used_max,
              opt_profile_info[num].time_used_min,
              opt_profile_info[num].time_used_total,
              opt_profile_info[num].profile_count);
   }

    
#else
    opt_profile_info[num].time_used = 0.0;
#endif
#endif
}
